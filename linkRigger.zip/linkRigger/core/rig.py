from maya import cmds

from linkRigger.core import meta
from linkRigger import components


class Rig(object):
    
    _INSTANCE = None
    
    def __new__(cls, *args, **kwargs):
        if cls._INSTANCE is None:
            cls._INSTANCE = super(Rig, cls).__new__(cls)
            cls._INSTANCE.__init__(*args, **kwargs)
        return cls._INSTANCE
        
    
    def __repr__(self):
        return f'<Link Rig Master at {hex(id(self))}>'
    
    
    def __getattr__(self, attr:str) -> 'CharacterManager|None':
        characterManagers = meta.listSceneMetaNodes(ofType=components.CharacterManager)
        for c in characterManagers:
            if c.name == attr:
                return c
        return None
        
    
    def __getitem__(self, attr) -> 'CharacterManager|None':
        if attr not in self.__dict__:
            return self.__getattr__(attr)
        return self.__dict__.get(attr)
        
        
if __name__ == '__main__':
    rig = Rig()
    
    rig.LinkRig.rebuild()
    rig._INSTANCE is rig
    #rig['LinkRig'].componentsManager.Master_M.hideGuidesAxis()
    #rig.LinkRig.componentsManager.VChain_L






