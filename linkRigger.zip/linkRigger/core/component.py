import json
from maya import cmds
from maya.api import OpenMaya as om2
from linkRigger.core import meta
from linkRigger import components

from linkRigger.core.layerNodes import DeformLayer
from linkRigger.core.layerNodes import GuideLayer
from linkRigger.core.layerNodes import InputLayer
from linkRigger.core.layerNodes import OutputLayer
from linkRigger.core.layerNodes import RigLayer

from linkRigger.utils import attrUtils
from linkRigger.utils import nameUtils
from linkRigger.utils import nodeUtils
from linkRigger.utils import curveUtils

from linkRigger.rig import jointBinding
from linkRigger.rig import spaceSwitch
from linkRigger.rig import mirror


class Component(meta.MetaNode):
    
    def __repr__(self) -> str:
        return f'<Component {self.__class__.__name__} at {hex(id(self))} {self.nodeName or None}>'
    
    
    
    @classmethod    
    def _setupAttrs_(self, instance:'Component'):
        ''' 
        Add custom attributes specific to the component.
        
        This method is intended to be overridden by subclasses, 
        allowing different components to define their unique attributes.
        '''
        raise NotImplementedError("Subclasses must implement '_setupAttrs_'.")
        
        
    @classmethod
    def _setupGuides_(cls, instance:'Component'):
        ''' 
        Add custom Guide modules specific to the component.
        
        Subclasses should override this method to implement their own 
        Guide setups tailored to their specific requirements.
        '''
        raise NotImplementedError("Subclasses must implement '_setupGuides_'.")
        
        
    @classmethod
    def _setupComponent_(
                         cls, 
                         instance : 'component' = None, 
                         side     : str = '', 
                         parent   : 'CharacterManager' = None
                         ) -> 'Component':
                            
        newName = instance.nodeName.rsplit(f'_{side}_meta', 1)[0] # get name
        
        attrUtils.addAttr(instance.nodeName, 'name',  type='string', value=newName) 
        attrUtils.addAttr(instance.nodeName, 'side', type='string', value=side)
        attrUtils.addAttr(instance.nodeName, 'isComponent', type='bool', value=True) 
        
        attrUtils.addAttr(instance.nodeName, 'hasRebuild', type='bool', value=True)
        attrUtils.addAttr(instance.nodeName, 'hasBuild', type='bool')
        
        attrUtils.addAttr(instance.nodeName, 'componentGroup', type='message')
        attrUtils.addAttr(instance.nodeName, 'origScale',  type='double', value=1)
        
        attrUtils.addAttr(instance.nodeName, 'componentInfo', type='compound', nc=4)
        attrUtils.addAttr(instance.nodeName, 'guideData', type='string', parent='componentInfo')
        attrUtils.addAttr(instance.nodeName, 'inputData', type='string', parent='componentInfo')
        attrUtils.addAttr(instance.nodeName, 'outputData', type='string', parent='componentInfo')
        attrUtils.addAttr(instance.nodeName, 'rigData', type='string', parent='componentInfo')
   
        componentGroup = nodeUtils.createNode('transform', nameUtils.uniqNameSuffix(newName, f'_{side}_hrc'), True, False)                  
        cmds.connectAttr(f'{componentGroup}.message', f'{instance.nodeName}.componentGroup')
        
        # connect metaParent
        if parent is None or not isinstance(parent, components.CharacterManager):
            return om2.MGlobal.displayWarning(f"Invalid argument for 'parent' - Expected 'CharacterManager', got '{type(parent).__name__}'")
        instance.addMetaParent(parent.componentsManager)
        cmds.parent(componentGroup, parent.componentsManager.componentsGroup)
            
              
    @classmethod    
    def create(
               cls, 
               nodeName : str    = '',
               side     : str    = '',
               metaId   : 'uuid' = '',
               parent   : 'CharacterManager' = None
               ) -> 'Component':
                        
        componentName = nodeName or cls.__name__
        sideName      = side or 'M'
        nodeName      = nameUtils.uniqNameSuffix(f'{componentName}', f'_{sideName}_meta')
        
        instance = super().create(nodeName, metaId)
        cls._setupComponent_(instance, sideName, parent)
        
        # add layerNodes
        baseName = instance.baseName  
        GuideLayer.create(nodeName=nameUtils.uniqNameSuffix(f'{baseName}_guideLayer_meta'), parent=instance) 
        InputLayer.create(nodeName=nameUtils.uniqNameSuffix(f'{baseName}_inputLayer_meta'), parent=instance)
        OutputLayer.create(nodeName=nameUtils.uniqNameSuffix(f'{baseName}_outputLayer_meta'), parent=instance)
        RigLayer.create(nodeName=nameUtils.uniqNameSuffix(f'{baseName}_rigLayer_meta'), parent=instance)
        DeformLayer.create(nodeName=nameUtils.uniqNameSuffix(f'{baseName}_deformLayer_meta'), parent=instance)
        
        cls._setupAttrs_(instance)
        cls._setupGuides_(instance)
        return instance
        
        
    @property
    def origScale(self) -> float:
        return cmds.getAttr(f'{self.nodeName}.origScale')
        
        
    @origScale.setter
    def origScale(self, value:float):
        cmds.setAttr(f'{self.nodeName}.origScale', value)
            

    @property
    def guideData(self) -> dict:
        data = cmds.getAttr(f'{self.nodeName}.guideData')
        return json.loads(data) if data else {}
        
        
    @guideData.setter
    def guideData(self, data:dict):
        cmds.setAttr(f'{self.nodeName}.guideData', json.dumps(data), type='string')
        
    
    @property
    def rigData(self) -> dict:
        data = cmds.getAttr(f'{self.nodeName}.rigData')
        return json.loads(data) if data else {}
        
        
    @rigData.setter
    def rigData(self, data:dict):
        cmds.setAttr(f'{self.nodeName}.rigData', json.dumps(data), type='string')
      
    
    @property
    def isComponent(self) -> bool:
        '''
        The significance of this attribute is that we can use hasattr to determine whether it is a component object.
        '''
        return cmds.getAttr(f'{self.nodeName}.isComponent') 
        
        
    @property
    def baseName(self) -> str:
        '''
        Returns the base name of the object, formatted as `{componentName}_{side}`.
        '''
        return f'{self.name}_{self.side}'
        
        
    @property
    def hasRebuild(self) -> bool:
        return cmds.getAttr(f'{self.nodeName}.hasRebuild')
   
    @hasRebuild.setter
    def hasRebuild(self, value:bool):
        attrUtils.setAttr(f'{self.nodeName}.hasRebuild', value)
        attrUtils.setAttr(f'{self.nodeName}.hasBuild', not value)
          
    @property
    def hasBuild(self) -> bool:
        return cmds.getAttr(f'{self.nodeName}.hasBuild')
         
    @hasBuild.setter
    def hasBuild(self, value:bool):
        self.hasRebuild = not value
           
            
    @property
    def side(self) -> str:
        return cmds.getAttr(f'{self.nodeName}.side') 
    
    
    @property
    def name(self) -> str:
        return cmds.getAttr(f'{self.nodeName}.name')
  
  
    def setName(self, newName:str=''):
        oldName = self.name 
        if not newName or newName == oldName:
            return 
        side = self.side
        
        newNodeName  = nameUtils.uniqNameSuffix(newName, f'_{side}_meta', '*_meta')
        resolvedName = newNodeName.rsplit(f'_{side}_meta', 1)[0]
        
        attrUtils.setAttr(f'{self.nodeName}.name', resolvedName, type='string') # update nameAttr
        cmds.rename(self.nodeName, newNodeName) # update nodeName

        # update component nodesName
        nodeUUIDS = {cmds.ls(node, uid=True)[0] for node in self.getAllNodes(includeGroup=True)}
        for nodeUUID in nodeUUIDS:
            node = cmds.ls(nodeUUID)[0]
            cmds.rename(node, f"{resolvedName}{node.replace(oldName, '')}")
                   
                   
    def setSide(self, newSide:str=''):
        oldSide = self.side 
        if not newSide or oldSide == newSide:
            return
        oldName = self.name
        
        attrUtils.setAttr(f'{self.nodeName}.side', newSide, type='string')
        
        newNodeName = nameUtils.uniqNameSuffix(oldName, f'_{newSide}_meta', '*_meta')
        newName = newNodeName.rsplit(f'_{newSide}_meta', 1)[0]
        attrUtils.setAttr(f'{self.nodeName}.name', newName, type='string') # update nameAttr
        cmds.rename(self.nodeName, newNodeName) # update nodeName

        # update component side
        _newName = f'{newName}_{newSide}'
        _oldName = f'{oldName}_{oldSide}'
            
        nodeUUIDS = {cmds.ls(node, uid=True)[0] for node in self.getAllNodes(includeGroup=True)}
        for nodeUUID in nodeUUIDS:
            node = cmds.ls(nodeUUID)[0]
            cmds.rename(node, f"{_newName}{node.replace(_oldName, '')}")
        
           
    @property
    def componentGroup(self) -> str:
        return cmds.listConnections(f'{self.nodeName}.componentGroup', d=False, s=True)[0]
    
    
    @property
    def characterManager(self) -> 'CharacterManager':
        return self.metaParents(True, ofType='CharacterManager')[0]      
        
    @property
    def componentsManager(self) -> 'ComponentsManager':
        return self.characterManager.componentsManager
            
    @property
    def deformManager(self) -> 'DeformManager':
        return self.characterManager.deformManager
        
    @property
    def geoManager(self) -> 'GeoManager':
        return self.characterManager.geoManager
          
          
          
    @property
    def guideLayer(self) -> 'GuideLayer':
        return self.metaChildren(ofType='GuideLayer')[0]
         
    @property
    def inputLayer(self) -> 'InputLayer':
        return self.metaChildren(ofType='InputLayer')[0]
         
    @property
    def outputLayer(self) -> 'OutputLayer':
        return self.metaChildren(ofType='OutputLayer')[0]
           
    @property
    def rigLayer(self) -> 'RigLayer':
        return self.metaChildren(ofType='RigLayer')[0]
           
    @property
    def deformLayer(self) -> 'DeformLayer':
        return self.metaChildren(ofType='DeformLayer')[0]
           
    
    def getAllNodes(self, includeGroup=True, includejoints=True) -> 'list[str]':
        allNodes = []
        if self.characterManager.hasRebuild:
            allNodes.extend(self.guideLayer.getAllNodes())
            
        if includeGroup:
            allNodes.append(self.componentGroup)
            '''
            We need to filter out componentMeta so that it doesn't affect the child components during renaming.
            '''
            layerNodes = [node 
                          for node in cmds.listConnections(f'{self.nodeName}.metaChildren', d=False, s=True) or [] 
                          if not cmds.attributeQuery('isComponent', n=node, ex=True)]
            allNodes.extend(layerNodes)
                
        allNodes.extend(self.inputLayer.getAllNodes(includeGroup))
        allNodes.extend(self.outputLayer.getAllNodes(includeGroup))
        allNodes.extend(self.rigLayer.getAllNodes(includeGroup))
        allNodes.extend(self.deformLayer.getAllNodes(includeGroup, includejoints))
        return allNodes
    
    
    def listGuideNodesWithTag(self, tag:str) -> 'list[GuideNode]':
        '''
        Returns guide nodes containing the given tag string in their tags.
        '''
        return [guideNode for guideNode in self.listGuideNodes(includeRoot=False) if tag in guideNode.guideTag]
            
        
    def listGuideNodes(self, includeRoot=False) -> 'list[GuideNode]':
        return self.guideLayer.listGuideNodes(includeRoot)
        
          
    def addComponentParent(self, parentGuideNode:'GuideNode') -> bool:
        return self.guideLayer.addComponentParent(parentGuideNode)
        
  
    def removeComponentParent(self) -> bool:
        return self.guideLayer.removeComponentParent()
        
   
    def select(self):
        self.guideLayer.guideRootNode.select()
    
    
    def showGuidesAxis(self):
        for guide in self.listGuideNodes():
            guide.showAxis()
        self.guideLayer.guideAxisVis = True
            
            
    def hideGuidesAxis(self):
        for guide in self.listGuideNodes():
            guide.hideAxis()
        self.guideLayer.guideAxisVis = False
            
            
    def listChildComponentNode(
                              self, 
                              recursive=True, 
                              ofType=None
                              ) -> 'list[Component]':
        return [metaNode for metaNode in self.metaChildren(recursive, ofType) if hasattr(metaNode, 'isComponent')]
           
           
    def unJointsToWorld(self):
        '''
        The current design will not delete skinned joints. Instead, this method unparents skinned joints from their parent objects. 
        This is crucial for the next step, which involves removing invalid joints.

        For example, suppose the scene contains two components: fkChain1 and fkChain2. If fkChain1's guide3 is set as the parent of fkChain2, 
        and later during a rebuild, the jointCount parameter of fkChain1 is set to 2, guide3 will be deleted. By using this unparenting method beforehand, 
        we can prevent accidental deletion of skinned joints in fkChain2 when removing invalid joints (in this case, the invalid joint is fk03)
        '''
        deformLayer = self.deformLayer
        skinJoints  = deformLayer.listJointNodes(unique=True)
        if not skinJoints:
            return
        
        '''
        Here's an important note: After we scale the rig and return to guide mode, 
        since the joints are not deleted, they will still retain their scale values. 
        If we immediately switch to joint mode, the joints will be ungrouped to world space. 
        Because the joints have scale values, they will automatically generate an empty group as their parent object. Therefore,
        we need to first reset the joint scales to their default values
        '''
        for joint in skinJoints:
            cmds.setAttr(f'{joint.nodeName}.s', 1, 1, 1)
            
        nodeUtils.toWorldSpace(list({joint.nodeName for joint in skinJoints}))
        
 
    def deleteUnusedJoints(self):
        '''
        Delete invalid skinned joints, if any
        '''
        deformLayer = self.deformLayer
        guideTags = self.guideLayer.listGuideTags(includeRoot=False)
        for tag in deformLayer.listJointTags():
            if tag not in guideTags:
                deformLayer.deleteJointFromTag(tag)


    def _buildJoint_(self):
        '''
        Define the logic for creating joints specific to the component.

        This method should be overridden by subclasses to implement 
        the custom joint creation logic for each component.
        '''
        raise NotImplementedError("Subclasses must implement '_buildJoint_'.")


    def setupBuild(self):
        self._buildJoint_()
        

    def _parentJoint_(self, rootJointTag=''):
        '''
        Ensure the component's root joint is properly placed within the hierarchy
        '''
        # 0 get metaParent
        parentComponent = self.metaParent()
        if not parentComponent:
            return
        
        # 1 check parent is component
        rootJoint = self.deformLayer.jointNodeFromTag(rootJointTag)
        if not hasattr(parentComponent, 'isComponent'):
            if rootJoint is not None:
                cmds.parent(rootJoint.nodeName, self.deformManager.deformGroup)
            '''
            If the rootJoint cannot be found, terminate immediately, 
            as the current component may not generate any joints
            '''
            return
            
        # 2 to parent joint
        parentGuideTag = self.guideLayer.parentGuide.guideTag
        parentJoint = parentComponent.deformLayer.jointNodeFromTag(parentGuideTag)
        
        if parentJoint is None:
            '''
            Check if the parentGuide generates corresponding joints. 
            If it does, perform the parenting.
            Because some components (such as the God component) may not generate joints, 
            simply use the deformGroup as the parent instead
            '''
            cmds.parent(rootJoint.nodeName, self.deformManager.deformGroup)
        else:
            cmds.parent(rootJoint.nodeName, parentJoint.nodeName)
            

    def _buildControl_(self):
        '''
        Define the logic for creating controls specific to the component.

        This method should be overridden by subclasses to implement 
        the custom control creation logic for each component.
        '''
        raise NotImplementedError("Subclasses must implement '_buildControl_'.")
        
        
    def _buildOutput_(self):
        '''
        Define the logic for creating the output node specific to the component.

        The output node is typically constrained to joints and acts as 
        the constraint target for parenting other components.

        This method should be overridden by subclasses to implement 
        their custom logic for output node creation.
        '''
        raise NotImplementedError("Subclasses must implement '_buildOutput_'.")
        
        
    def _buildInput_(self):
        '''
        Define the logic for creating the input port specific to the component.

        The input port controls the transformations of the current component 
        and is constrained by the output node of another component. 

        This method should be overridden by subclasses to implement 
        their custom logic for input port creation and connection.
        '''
        raise NotImplementedError("Subclasses must implement '_buildInput_'.")
        
        
    def _updateControlScale_(self):
        '''
        update scale
        '''
        currentScale = cmds.xform(self.guideLayer.guideRootNode.nodeName, q=True, s=True, ws=True)[0]
            
        newScale = currentScale / self.origScale
        for ctrl in self.rigLayer.listControlNodes():
            curveUtils._scaleSpline(ctrl.nodeName, newScale)
        self.origScale = currentScale

   
    def build(self):
        self._parentJoint_()
        self._buildControl_()
        self._buildOutput_()
        self._buildInput_()
        
        self._updateControlScale_()


    def _buildParent_(self):
        # 0 get parent guide
        parentGuide = self.guideLayer.parentGuide
        if parentGuide is None:
            return
            
        # 1 get outputNode
        inputNode = self.inputLayer.inputNodeFromTag('world')
        parentOutputNode = parentGuide.guideLayer.guideNodeToOutputNode(parentGuide)
        multNode = spaceSwitch.offsetParentMatrixSet(inputNode, parentOutputNode)
        inputNode.addExtraNodestoMeta([multNode])
        
        
    def _buildSpaceSwitch_(self):
        self.rigLayer.setSpaceSwitch()
        
        
    def seaming(self):
        self._buildParent_()
        self._buildSpaceSwitch_()


    def _componentAttr_(self):
        '''
        Define additional attributes specific to the component.

        This method should be overridden by subclasses to declare 
        any custom attributes required for the component's functionality.
        '''
        raise NotImplementedError("Subclasses must implement '_componentAttr_'.")
        
        
    def _setComponentAttr_(self):
        '''
        Set the values of the additional attributes specific to the component.

        This method should be overridden by subclasses to initialize or 
        configure the custom attributes defined in '_componentAttr_'.
        '''
        raise NotImplementedError("Subclasses must implement '_setComponentAttr_'.")
        
        
    def componentData(self) -> dict:
        guideLayer = self.guideLayer
        rigLayer   = self.rigLayer
        
        # get parent
        parentMetaNode  = self.metaParent()
        
        parentGuideNode    = guideLayer.parentGuide
        parentGuideNodeTag = parentGuideNode.guideTag if parentGuideNode else None
  
        data = {'metaClass' : self.metaClass,
                'metaId'    : self.metaId,
                'name'      : self.name,
                'side'      : self.side,
                'origScale' : self.origScale,

                'componentAttr' : self._componentAttr_(),

                'guidesTransformsData' : guideLayer.getGuidesTransformsData(),
                'spaceSwitchInfo'      : rigLayer.getDuplicateSpaceSwitchData(),
                'controlShapesData'    : rigLayer.getDuplicateControlShapesData(),

                'parentMetaClass'    : parentMetaNode.metaClass,
                'parentMetaId'       : parentMetaNode.metaId,
                'parentGuideNodeTag' : parentGuideNodeTag}

        return data
        
   
    @staticmethod    
    def setData(
                datas:list, 
                characterManager=None, 
                parentComponent=None
                ) -> 'list[Component] | None':
        '''
        Duplicate or generate a new template based on the component data
        Currently, it is only applicable for calls from the duplicate and loadRigFromTemplate methods.

        Args:
            datas (list): A list of dictionaries containing component data.
            
            characterManager: If the duplicate method is called, the current rig's characterManager node will be passed in; otherwise, 
                              the parameter logic is handled by the loadRigFromTemplate method.
                              
            parentComponent: When the duplicate method is called, the current component's parentComponent is passed in.

        Returns:
            list[Component] | None: If a parentComponent is provided (typically passed in by the duplicate method), 
                                    the entire created component list will be returned.
        '''   
        
        # 0 initialize parent mapping if a parentComponent is provided               
        parentMap = {parentComponent.metaId : parentComponent.nodeName}  if parentComponent is not None else {}
        allComponentNodeList = []
        
        # 1 create components
        for data in datas:
            componentNode = getattr(components, data['metaClass']).create(data['name'], data['side'], parent=characterManager)
            parentMap[data['metaId']] = componentNode.nodeName # update parentMap
            allComponentNodeList.append(componentNode)
            
            componentNode._setComponentAttr_(data['componentAttr'])
            componentNode.rigLayer.setDuplicateControlShapesData(data['controlShapesData'])
            componentNode.origScale = data['origScale']
          
        # 2 set parent
        for componentNode, data in zip(allComponentNodeList, datas):
            
            if data['parentMetaClass'] != 'ComponentsManager':
                parentComponent = characterManager.componentsManager.componentFromNodeName(parentMap[data['parentMetaId']])
                if parentComponent is not None:
                    parentGuideNode = parentComponent.guideLayer.guideNodeFromTag(data['parentGuideNodeTag'])
                    componentNode.addComponentParent(parentGuideNode)
                else:
                    om2.MGlobal.displayWarning(f'Please check the {componentNode}, the parentGuideNode was not retrieved correctly.')
            # set local matrix transforms   
            componentNode.guideLayer.setGuidesTransforms(data['guidesTransformsData'])
            # update and set space switch data
            newSpaceData = RigLayer.updateDuplicateSpaceSwitchData(parentMap, data['spaceSwitchInfo'])
            componentNode.rigLayer.setDuplicateSpaceSiwtchData(newSpaceData)
            
        if parentComponent is not None:
            return allComponentNodeList
    
    
    def getDuplicateData(self):
        duplicateData = [self.componentData()]
        # add child data
        for childComponent in self.listChildComponentNode(recursive=True):
            duplicateData.append(childComponent.componentData())
        return duplicateData
                
        
    def duplicate(
                 self, 
                 side:str='', 
                 selectRootGuideNode=True
                 ) -> 'list[Component]':
                    
        duplicateData = self.getDuplicateData()
        if side:
            for data in duplicateData:
                data['side'] = side       
        componentNodes = self.setData(duplicateData, self.characterManager, parentComponent=self.metaParent())
        if selectRootGuideNode:
            componentNodes[0].select()
        return componentNodes
        
        
    def _sortGuideNodes_(self):
        '''
        Sort the guideNodes to ensure correct hierarchical relationships.
        ﻿
        When performing global matrix mirroring, it is essential to maintain 
        the correct update order of guideNodes to avoid inconsistencies. 
        For example, parent nodes should appear before child nodes in the order. 
        This ensures that when a global matrix transformation is applied to a parent, 
        its child nodes will not be affected incorrectly due to a prior transformation.
        ﻿
        This method should be overridden by subclasses to define custom 
        sorting logic based on specific requirements of the component.
        '''
        raise NotImplementedError("Subclasses must implement '_sortGuideNodes_'.")
    
    
    def _postMirror_(self):
        '''
        Perform corrective actions after mirroring components.
    
        Certain components, such as VChain, require corrective actions post-mirroring. 
        For instance, after the mirroring process, the aimVector and upVector may need to be inverted to maintain the correct orientation and behavior. 
        This method should be overridden by subclasses to define specific corrective actions based on the component's requirements.
        '''
        raise NotImplementedError("Subclasses must implement '_postMirror_'.")
    
        
    def mirror(
               self, 
               axis='x', 
               side='R'
               ) -> 'list[Component]':
        
        # 0 get mirror component
        mirrorComponentNodes = self.duplicate(side, selectRootGuideNode=False)
        
        # 1 get all guides
        allGuideNodes = []
        for component in mirrorComponentNodes:
            guides = self._sortGuideNodes_(component.listGuideNodes(includeRoot=True))
            allGuideNodes.extend(guides)
            
        # 2 set localMatrix        
        oldMatrixs = [guide.globalMatrix for guide in allGuideNodes]
        
        for guideNode, oldMatrix in zip(allGuideNodes, oldMatrixs):
            mirrorMatrix = mirror.mirrorMatrix(oldMatrix, axis)
            cmds.xform(guideNode.nodeName, m=mirrorMatrix, ws=True)
            
        for component in mirrorComponentNodes:    
            component.guideLayer.updateGuidesLocalMatrix() 
            component._postMirror_()
 
        # 3 update mirror parent
        rootComponents = [component for component in mirrorComponentNodes 
                          if component.metaParent() not in mirrorComponentNodes]
        for component in rootComponents:
            parent = component.metaParent()
            if parent is None or not hasattr(parent, 'isComponent'):
                continue
            mirrorParentComponent = parent.mirrorComponent
            if mirrorParentComponent is None:
                continue
            try:
                parentGuideTag = component.guideLayer.parentGuide.guideTag
                newParentGuide = mirrorParentComponent.guideLayer.guideNodeFromTag(parentGuideTag)
                component.addComponentParent(newParentGuide)
            except Exception as e:
                om2.MGlobal.displayError(f"Couldn't find the mirrored parent component GuideNode. Assigned to the root guide instead. Error: {str(e)}")
                component.addComponentParent(mirrorParentComponent.guideLayer.guideRootNode)
                
        # 4 select mirror root guide
        cmds.select([component.guideLayer.guideRootNode.nodeName for component in rootComponents], ne=True, replace=True)
        return mirrorComponentNodes
            
        
    @property    
    def mirrorComponent(self) -> 'Component|None':
        mirrorComponentNodes = [component 
                              for component in self.componentsManager.listComponentNodes()
                              if (component.nodeName != self.nodeName
                              and component.metaClass == self.metaClass
                              and component.name == self.name)]
        if not mirrorComponentNodes:
            return
        
        baseMirrorMap = {'L': 'R', 'left': 'right', 'l': 'r', 'Left': 'Right', 'lt': 'rt', 'LEFT': 'RIGHT'}
        mirrorMap = {**baseMirrorMap, **{v: k for k, v in baseMirrorMap.items()}}
        
        oppositeSide = mirrorMap.get(self.side)
        if not oppositeSide:
            return
        _mirrorComponent = next((component for component in mirrorComponentNodes if component.side == oppositeSide), None)
        return _mirrorComponent
        
    
    def symmetrizeComponent(self, axis:str='x'):
        self.guideLayer.symmetrizeComponent(axis)
        for child in self.listChildComponentNode(recursive=False):
            child.symmetrizeComponent(axis)
            
            
    def deleteGuides(self):
        '''
        This action will delete the guideLayer node.
        '''
        self.guideLayer.delete()
        # update hasBuild attr  
        self.hasBuild = True
        
    
    def delete(self, includeGroup=True, includejoints=True):
        
        for child in self.listChildComponentNode(recursive=False):
            child.delete(includeGroup=includeGroup, includejoints=includejoints)
        allNodes = self.getAllNodes(includeGroup, includejoints)
        if allNodes:
            for node in allNodes: 
                cmds.setAttr(f'{node}.nodeState', 2)  
            cmds.delete(allNodes)

            
    def cacheComponentData(self):
        # 0 cache GuideData to attr
        guideLayer = self.guideLayer
        rigLayer  = self.rigLayer
        
        guideData = self._componentAttr_()
        guideData['guidesTransformsData'] = guideLayer.getGuidesTransformsData()
        parentGuideNode = guideLayer.parentGuide
        guideData['parentGuideTag'] = parentGuideNode.guideTag if parentGuideNode is not None else '__NULL__'
        self.guideData = guideData
        
        # 1 cache spaceSwitchData to attr
        rigData = {'spaceSwitchInfo':rigLayer.getDuplicateSpaceSwitchData()}
        self.rigData = rigData
        
    
        
    def rebuild(self):
        # 0 update controlShapes to meta
        self.rigLayer.updateAllControlNodeShape()
        
        # 1 delete rigNodes, Does not include skin joints :)
        self.delete(includeGroup=False, includejoints=False)
        
        # 3 create guideLayer and guideNodes
        guideData = self.guideData
        baseName = self.baseName
        GuideLayer.create(nodeName=nameUtils.uniqNameSuffix(f'{baseName}_guideLayer_meta'), parent=self) 
        self.__class__._setupGuides_(self)
        
        # 4 update componentAttr
        self._setComponentAttr_(guideData)

     
    def postRebuild(self):
        guideData = self.guideData
        rigData   = self.rigData
        # 0 connect componentParent
        parentGuideTag = guideData['parentGuideTag']
        if parentGuideTag != '__NULL__':
            parentGuideNode = self.metaParent().guideLayer.guideNodeFromTag(parentGuideTag)
            self.addComponentParent(parentGuideNode)
            
        # 1 set spaceSwitch
        self.rigLayer.rebuildConnectSpaceSwitchData(rigData['spaceSwitchInfo'])
            
        # 2 set guideNodes localMatrix and rotateOrder
        self.guideLayer.setGuidesTransforms(guideData['guidesTransformsData'])
        
        # 3 update hasRebuild attr  
        self.hasRebuild = True
        
        
 


if __name__ == '__main__':
    c = Component.create()
    
    # c2 = Component.create()
    # #c.setSide('M')
    # #c.setName('Component')
    # #meta.listSceneMetaNodes()
    # c.setName('FF')
    # c2.setName('FF')
    # c2.setSide('ddc')

    





