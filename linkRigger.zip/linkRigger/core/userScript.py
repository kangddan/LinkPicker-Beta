from maya import cmds
from maya.api import OpenMaya as om2


class UserScript(object):
    
    pass