from maya import cmds
from maya.api import OpenMaya as om2
from linkRigger.core.nodes import BaseNode

from linkRigger.utils import attrUtils
from linkRigger.utils import nameUtils
from linkRigger.core import meta


class JointNode(BaseNode):
    
    def __init__(self, nodeName:str):
        if not self.isJoint(nodeName):
            raise TypeError(f'{nodeName} is not a valid joint node.')
        self.node = nodeName
              
        
    @property
    def jointTag(self) -> str:
        return cmds.getAttr(f'{self.nodeName}.jointTag')
        
        
    @jointTag.setter
    def jointTag(self, newTag:str=''):
        cmds.setAttr(f'{self.nodeName}.jointTag', newTag, type='string')
        
        
    @staticmethod
    def isJoint(nodeName:str) -> bool:
        return cmds.attributeQuery('jointTag', n=nodeName, ex=True)
        
        
    @property
    def deformLayer(self) -> 'DeformLayer':
        return next((layer for layer in self.layer if layer.metaClass == 'DeformLayer'), None)
    
    def segmentScaleCompensat(self, switch:bool):
        cmds.setAttr(f'{self.nodeName}.segmentScaleCompensate', switch)
        
 
    def freeze(self, makeIdentity=False):
        '''
        https://www.linkedin.com/pulse/tools-freeze-rotation-joint-artem-efimovich/
        '''
        if makeIdentity:
            '''
            Calling the cmds.makeIdentity method will automatically enable the joint's segmentScaleCompensate attribute, 
            which makes no sense. This will undoubtedly disrupt our matrix-based rigging workflow, 
            so we manually call the segmentScaleCompensate method again to correct it.
            '''
            cmds.makeIdentity(self.nodeName, a=True, r=True, t=False, s=False)
            self.segmentScaleCompensat(True)
        else:
            fnTfm = om2.MFnTransform(self.node)
            rot = fnTfm.rotation().asMatrix()

            joPlug = fnTfm.findPlug('jointOrient', False)  
            joX = joPlug.child(0)  
            x = joX.asDouble() 
            joY = joPlug.child(1)  
            y = joY.asDouble()  
            joZ = joPlug.child(2)  
            z = joZ.asDouble() 

            jo = om2.MEulerRotation(x, y, z).asMatrix()
            ro = rot * jo
            trApi = om2.MTransformationMatrix(ro)
            newjo = trApi.rotation()

            fnTfm.setRotation(om2.MEulerRotation(0, 0, 0), om2.MSpace.kTransform)  
            joX.setDouble(newjo.x)  
            joY.setDouble(newjo.y) 
            joZ.setDouble(newjo.z) 

        
        
    def lockJointOrient(self):
        cmds.setAttr(f'{self.nodeName}.jointOrient', l=True)
        
        
    def unlockJointOrient(self):
        cmds.setAttr(f'{self.nodeName}.jointOrient', l=False)
        
            
    def listExtraNodes(self) -> 'list[str]':
        return cmds.listConnections(f'{self.nodeName}.extraNodes', d=False, s=True) or []
          
          
    def addExtraNodestoMeta(self, extraNodes:'list'=None):
        for node in extraNodes or []:
            if node is None: continue
            cmds.connectAttr(f'{node}.message', f'{self.nodeName}.extraNodes', f=True, na=True)
            
            
    def deleteExtraNodes(self):
        nodes = self.listExtraNodes()
        if nodes:
            cmds.delete(nodes)
            
            
    @classmethod
    def create(cls, baseName:str, 
                    tag:str, 
                    layer:'RigLayer|DeformLayer'=None):
        node = cmds.createNode('joint', n=nameUtils.uniqNameSuffix(f'{baseName}', f'_{tag}_jnt'))
        attrUtils.addAttr(node, 'jointTag', type='string', value=tag)
        #attrUtils.addAttr(node, 'constraintTarget', type='message')
        attrUtils.addAttr(node, 'extraNodes', type='message', multi=True, im=False)
        
        instance = cls(node)
        instance.segmentScaleCompensat(False)
        if layer:
            layer.addJointNodeToMeta(instance)

        return instance
      

if __name__ == '__main__':
    j = JointNode.create('sb', 'ttt')
    j.freeze()
    #j.jointTag
    # j.listExtraNodes()
    # j.addExtraNodestoMeta(['sb2', 'sb1'])
    # j.deleteExtraNodes()
        