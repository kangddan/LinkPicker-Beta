from maya import cmds
from maya.api import OpenMaya as om2
from linkRigger.core.nodes import BaseNode

from linkRigger.core import meta
from linkRigger.utils import attrUtils
from linkRigger.utils import nameUtils
from linkRigger.utils import curveUtils
from linkRigger.rig import ShapesManager, ColorManager


class ControlNode(BaseNode):
    
    def __init__(self, nodeName:str):
        if not self.isControlNode(nodeName):
            raise TypeError(f'{nodeName} is not a valid control node.')
        self.node = nodeName
        
        
    @staticmethod
    def isControlNode(nodeName:str) -> bool:
        return cmds.attributeQuery('controlTag', n=nodeName, ex=True)
        
    
    @property
    def controlTag(self) -> str:
        return cmds.getAttr(f'{self.nodeName}.controlTag')
        
        
    @controlTag.setter
    def controlTag(self, newTag:str=''):
        cmds.setAttr(f'{self.nodeName}.controlTag', newTag, type='string')
        
        
    @property
    def rigLayer(self) -> 'RigLayer':
        return next((layer for layer in self.layer if layer.metaClass == 'RigLayer'), None)
        
    
    @property
    def parent(self) -> str:
        return cmds.listRelatives(self.nodeName, parent=True, path=True)[0]


    @property
    def spaceParent(self) -> str:
        return attrUtils.getNodeByTag(f'{self.nodeName}.groups', 'group', 'groupTag', tag='space')

      
    @property
    def topParent(self) -> str:
        return attrUtils.getNodeByTag(f'{self.nodeName}.groups', 'group', 'groupTag', tag='top')
        
        
    def listParents(self) -> list[str]:
        return attrUtils.getConnectedNodes(f'{self.nodeName}.groups', 'group')
        
    @property    
    def controlShapeData(self) -> dict:
        return curveUtils.getData(self.node)
        
        
    def listShapes(self) -> list[str]:
        return [om2.MDagPath.getAPathTo(shape).fullPathName()
                for shape in curveUtils._getSplineShapes(self.node)]
            
        
        
    @classmethod  
    def __parentToMeta__(cls,
                         sourceNode:str,
                         groupNode:str, 
                         tag:str):
        index = attrUtils.findEmptyIndex(f'{sourceNode}.groups', 'group')
        cmds.connectAttr(f'{groupNode}.message', f'{sourceNode}.groups[{index}].group', f=True)
        cmds.setAttr(f'{sourceNode}.groups[{index}].groupTag', tag, type='string')
    
        
    @classmethod
    def create(cls, nodeName:str,
                    tag:str,
                    shape:'str'='FK',
                    scale:float=1.0,
                    color:list=None,
                    axis: str='y',
                    spaceGroup:bool=True,
                    rigLayer:'RigLayer'=None,
                    tagSuffix:str=''):
                        
        # 0 create shape
        cacheShape = cacheAxis = cacheScale = settingcolor = None
        if rigLayer:
            '''
            Check if there is cached curve data; if it exists, the scaling and orientation should remain at their default values. 
            '''
            cacheShape:'dict|None' = rigLayer.shapeFromControlTag(tag)
            if cacheShape is not None:
                cacheAxis = 'y'
                cacheScale = 1
        # get color    
        override  = ColorManager.override()    
        settingcolor = ColorManager.runColor(nodeName) if override else None
        
        
        controlName =  nameUtils.uniqNameSuffix(f'{nodeName}', f'_{tag}{tagSuffix}_ctrl' if tagSuffix else f'_{tag}_ctrl')
        control = curveUtils.create(
                                    name  = controlName,
                                    data  = cacheShape or ShapesManager[shape],
                                    scale = cacheScale or scale,
                                    axis  = cacheAxis or axis,
                                    color = color if color else settingcolor
                                    )
        attrUtils.addAttr(control, 'controlTag', type='string', value=tag)
        attrUtils.addAttr(control, 'groups', type='compound', multi=True, nc=2)
        attrUtils.addAttr(control, 'group', type='message', parent='groups')
        attrUtils.addAttr(control, 'groupTag', type='string', parent='groups')
        
        # 1 create group
        topGrp = cmds.createNode('transform', n=nameUtils.uniqNameSuffix(f'{nodeName}', f'_{tag}_hrc'))
        cls.__parentToMeta__(control, topGrp, 'top')
        
        if spaceGroup:
            spaceGrp = cmds.createNode('transform', n=nameUtils.uniqNameSuffix(f'{nodeName}', f'_{tag}_space'))
            attrUtils.addAttr(spaceGrp, 'extraNodes', type='message', multi=True, im=False)
            
            cls.__parentToMeta__(control, spaceGrp, 'space')
            cmds.parent(control, spaceGrp)
            cmds.parent(spaceGrp, topGrp)
        else:
            cmds.parent(control, topGrp)
        
        instance = cls(control)    
        # 3 to meta attr
        if rigLayer:
            rigLayer.addRigNodetoMeta(instance)
        return instance
                                 
if __name__ == '__main__':
    c = ControlNode.create('sb', 'wc', 'BENDY', 1, axis='y', spaceGroup=True)
    #c.listShapes()
    # c.controlTag
    # c.spaceParent
    # c.listParents()
    # c.topParent

                    
        
        