from maya import cmds
from maya.api import OpenMaya as om2
from linkRigger.core.nodes import BaseNode
from linkRigger.core import meta

from linkRigger.utils import attrUtils
from linkRigger.utils import nameUtils


class TaggedNode(BaseNode):
    
    def __init__(self, nodeName:str):
        if not self.isTaggedNode(nodeName):
            raise TypeError(f'{nodeName} is not a valid tagged node.')
        TaggedNode.setColor(nodeName)
        self.node = nodeName
        
    @property
    def taggedTag(self) -> str:
        return cmds.getAttr(f'{self.nodeName}.taggedTag')
        
        
    @taggedTag.setter
    def taggedTag(self, newTag:str=''):
        cmds.setAttr(f'{self.nodeName}.taggedTag', newTag, type='string')
        
        
    @staticmethod
    def isTaggedNode(nodeName:str) -> bool:
        return cmds.attributeQuery('taggedTag', n=nodeName, ex=True)
        
        
    @staticmethod    
    def setColor(nodeName:str):
        if cmds.attributeQuery('useOutlinerColor', n=nodeName, ex=True):
            cmds.setAttr(f'{nodeName}.useOutlinerColor', True)
            cmds.setAttr(f'{nodeName}.outlinerColor', 1, 1, 0)
        
        
    @classmethod
    def create(cls, 
                nodeType:str,
                baseName:str, 
                tag:str, 
                suffix:str='tagged',
                layer:'RigLayer'=None,
                note:str=None):
        node = cmds.createNode(nodeType, n=nameUtils.uniqNameSuffix(f'{baseName}', f'_{tag}_{suffix}'))
        attrUtils.addAttr(node, 'taggedTag', type='string', value=tag)
 
        instance = cls(node)
        if layer:
            layer.addTaggedNodetoMeta(instance, tag, note)

        return instance
        
if __name__ == '__main__':
    o = TaggedNode.create('sb', 'fuck')
    #o.outputLayer
    