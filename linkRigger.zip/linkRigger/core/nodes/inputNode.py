from maya import cmds
from maya.api import OpenMaya as om2
from linkRigger.core.nodes import BaseNode
from linkRigger.core import meta

from linkRigger.utils import attrUtils
from linkRigger.utils import nameUtils


class InputNode(BaseNode):
    
    def __init__(self, nodeName:str):
        if not self.isInput(nodeName):
            raise TypeError(f'{nodeName} is not a valid input node.')
        self.node = nodeName
        
    @property
    def inputTag(self) -> str:
        return cmds.getAttr(f'{self.nodeName}.inputTag')
        
        
    @inputTag.setter
    def inputTag(self, newTag:str=''):
        cmds.setAttr(f'{self.nodeName}.inputTag', newTag, type='string')
        
        
    @staticmethod
    def isInput(nodeName:str) -> bool:
        return cmds.attributeQuery('inputTag', n=nodeName, ex=True)
        
        
    @property
    def inputLayer(self) -> 'InputLayer':
        return next((layer for layer in self.layer if layer.metaClass == 'InputLayer'), None)
        
        
    @classmethod
    def create(cls, baseName:str, 
                    tag:str, 
                    inputLayer=None):
        node = cmds.createNode('transform', n=nameUtils.uniqNameSuffix(f'{baseName}', f'_{tag}_input'))
        attrUtils.addAttr(node, 'inputTag', type='string', value=tag)
        attrUtils.addAttr(node, 'extraNodes', type='message', multi=True, im=False)
        
        instance = cls(node)
        if inputLayer:
            inputLayer.addOutputNodestoMeta(instance)

        return instance
        
    
    def listExtraNodes(self) -> 'list[str]':
        return cmds.listConnections(f'{self.nodeName}.extraNodes', d=False, s=True) or []
          
          
    def addExtraNodestoMeta(self, extraNodes:'list'=None):
        for node in extraNodes or []:
            if node is None: continue
            cmds.connectAttr(f'{node}.message', f'{self.nodeName}.extraNodes', f=True, na=True)
            
            
    def deleteExtraNodes(self):
        nodes = self.listExtraNodes()
        if nodes:
            cmds.delete(nodes)
        
if __name__ == '__main__':
    o = InputNode.create('sb', 'fuck')
    o.inputLayer
    