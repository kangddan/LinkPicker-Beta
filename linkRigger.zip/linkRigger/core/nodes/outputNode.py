from maya import cmds
from maya.api import OpenMaya as om2
from linkRigger.core.nodes import BaseNode
from linkRigger.core import meta

from linkRigger.utils import attrUtils
from linkRigger.utils import nameUtils


class OutputNode(BaseNode):
    
    def __init__(self, nodeName:str):
        if not self.isOutput(nodeName):
            raise TypeError(f'{nodeName} is not a valid output node.')
        self.node = nodeName
        
    @property
    def outputTag(self) -> str:
        return cmds.getAttr(f'{self.nodeName}.outputTag')
        
        
    @outputTag.setter
    def outputTag(self, newTag:str=''):
        cmds.setAttr(f'{self.nodeName}.outputTag', newTag, type='string')
        
        
    @staticmethod
    def isOutput(nodeName:str) -> bool:
        return cmds.attributeQuery('outputTag', n=nodeName, ex=True)
        
    
    def connectJointDrive(self, jointNode:'JointNode', space=False, offset=False):
        if space:
            cmds.connectAttr(f'{jointNode.nodeName}.worldMatrix[0]', f'{self.nodeName}.offsetParentMatrix')
        else:
            if not offset:
                cmds.connectAttr(f'{jointNode.nodeName}.matrix', f'{self.nodeName}.offsetParentMatrix')
            else:
                '''
                The offset parameter is primarily used when the driving object is a ControlNode.
                ensuring that the relative position remains consistent.
                '''
                offsetMatrix = cmds.getAttr(f'{jointNode.topParent}.matrix')
                multNode = cmds.createNode('multMatrix', name=f'{jointNode.shortName}_offsetMatrix')
                cmds.connectAttr(f'{jointNode.nodeName}.matrix', f'{multNode}.matrixIn[0]', f=True)
                cmds.setAttr(f'{multNode}.matrixIn[1]', offsetMatrix, type='matrix')
                cmds.connectAttr(f'{multNode}.matrixSum', f'{self.nodeName}.offsetParentMatrix', f=True)
                self.addExtraNodestoMeta([multNode])
                      
        self.resetLocalMatrix()
    
        
    def resetLocalMatrix(self):
        cmds.xform(self.nodeName, m=list(om2.MMatrix()), ws=False)
        
        
    @property
    def outputLayer(self) -> 'OutputLayer':
        return next((layer for layer in self.layer if layer.metaClass == 'OutputLayer'), None)
            
            
    def listExtraNodes(self) -> 'list[str]':
        return cmds.listConnections(f'{self.nodeName}.extraNodes', d=False, s=True) or []
          
          
    def addExtraNodestoMeta(self, extraNodes:'list'=None):
        for node in extraNodes or []:
            if node is None: continue
            cmds.connectAttr(f'{node}.message', f'{self.nodeName}.extraNodes', f=True, na=True)
            
            
    def deleteExtraNodes(self):
        nodes = self.listExtraNodes()
        if nodes:
            cmds.delete(nodes)
        
        
    @classmethod
    def create(cls, baseName:str, 
                    tag:str, 
                    outputLayer=None):
        node = cmds.createNode('transform', n=nameUtils.uniqNameSuffix(f'{baseName}', f'_{tag}_output'))
        attrUtils.addAttr(node, 'outputTag', type='string', value=tag)
        attrUtils.addAttr(node, 'extraNodes', type='message', multi=True, im=False)
        
        instance = cls(node)
        if outputLayer:
            outputLayer.addOutputNodestoMeta(instance)

        return instance
        
if __name__ == '__main__':
    o = OutputNode.create('sb', 'fuck')
    #o.outputLayer
    