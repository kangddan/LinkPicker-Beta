from maya import cmds
from maya.api import OpenMaya as om2
from linkRigger.core.nodes import BaseNode

from linkRigger.core import meta
from linkRigger.utils import attrUtils
from linkRigger.utils import nameUtils
from linkRigger.utils import nodeUtils
from linkRigger.utils import curveUtils
from linkRigger.utils import pathUtils

from linkRigger.rig import ShapesManager


class GuideNode(BaseNode):
    
    @classmethod
    def __addAxisShapeAttr__(cls, guideNode:str) -> None:
        shapes = curveUtils._getSplineShapes(guideNode)
        for shape in shapes:
            node = om2.MFnDependencyNode(shape)
            
            node.findPlug('alwaysDrawOnTop', False).setBool(True) # xray
            
            colorData = curveUtils._getShapeColor(node)
            '''
            If it is an indexed color, then the shapeNode is part of the axis.
            '''
            if not colorData[0]: 
                attrUtils.addAttr(node.name(), 'isAxis', type='bool', value=True)
                node.findPlug('lineWidth', False).setFloat(1.5) 
    
    
    @classmethod
    def __createGuide__(
                        cls,
                        name:str,
                        shape:str='',
                        size:float=1.0,
                        guideTag:str=''
                        ) -> str:

        guide = curveUtils.create(name, ShapesManager[shape], size)
        
        attrUtils.addAttr(guide, 'isRoot', type='bool', value=shape=='GUIDE_ROOT')
        attrUtils.addAttr(guide, 'guideTag', type='string', value=guideTag)
        attrUtils.addAttr(guide, 'guideParent', type='message')
        attrUtils.addAttr(guide, 'guideChildren', type='message', m=True, im=False)
        
        cls.__addAxisShapeAttr__(guide)
        for attr in ['t', 'r', 's']:
            for i in ['x', 'y', 'z']:
                cmds.setAttr(f'{guide}.{attr}{i}', keyable=False, channelBox=True)
        return guide
        
        
    @classmethod
    def createGuideLine(
                        cls, 
                        baseName:str, 
                        startNode:str, 
                        endNode:str, 
                        guideTag=''
                        ) -> 'tuple(nodes)':
                            
        guideLine = curveUtils.create(nameUtils.uniqNameSuffix(f'{baseName}', f'_{guideTag}_guide_line'), 
                                      ShapesManager['GUIDE_LINE'], 
                                      template=True)
        
        cmds.setAttr(f'{guideLine}.alwaysDrawOnTop', True)
                                      
        startVectorNode = cmds.createNode('pointMatrixMult', name=nameUtils.uniqNameSuffix(f'{baseName}', f'_{guideTag}_start_vector'))
        endVectorNode   = cmds.createNode('pointMatrixMult', name=nameUtils.uniqNameSuffix(f'{baseName}', f'_{guideTag}_end_vector'))
        
        attrUtils.addAttr(startVectorNode, 'lineTag', type='string', value='start')
        attrUtils.addAttr(endVectorNode, 'lineTag', type='string', value='end')
        
        cmds.connectAttr(f'{startNode}.worldMatrix[0]', f'{startVectorNode}.inMatrix', f=True)
        cmds.connectAttr(f'{endNode}.worldMatrix[0]', f'{endVectorNode}.inMatrix', f=True)
        
        cmds.connectAttr(f'{startVectorNode}.output', f'{guideLine}.controlPoints[0]', f=True)
        cmds.connectAttr(f'{endVectorNode}.output', f'{guideLine}.controlPoints[1]', f=True)
        return guideLine, startVectorNode, endVectorNode
    
    
    @classmethod
    def createRootGuide(
                        cls,
                        baseName   : str='', 
                        guideSize  : float=1.0,
                        guideLayer : 'GuideLayer'=None
                        ) -> 'GuideNode':
                            
        guideTag = shape = 'root'                    
        guideGroup = nodeUtils.createNode('transform', nameUtils.uniqNameSuffix(f'{baseName}_{guideTag}_guide_srt'))
        guideNode  = cls.__createGuide__(name     = nameUtils.uniqNameSuffix(f'{baseName}_root_guide'), 
                                         shape    = 'GUIDE_ROOT', 
                                         size     = guideSize, 
                                         guideTag = guideTag)
        
        cmds.parent(guideNode, guideGroup)
        
        for shape in curveUtils._getSplineShapes(guideNode):
            node = om2.MFnDependencyNode(shape)
            node.findPlug('lineWidth', False).setFloat(1.5) 
                
        if guideLayer:
            cmds.parent(guideGroup, guideLayer.guideGroup)
            guideLayer.addGuideNodestoMeta(guideNode, None, guideTag, [guideGroup], []) # connect attr
        return cls(guideNode)
    
    
    @classmethod
    def createBaseGuide(
                        cls, 
                        baseName    : str='', 
                        guideTag    : str='',
                        guideSize   : float=1.0,
                        parentGuide : 'GuideNode'=None,
                        guideLayer  : 'GuideLayer'=None,
                        addGroup    : bool=False,
                        guideShape  : str='',
                        ) -> 'GuideNode':
        
        guideGroup = nodeUtils.createNode('transform', nameUtils.uniqNameSuffix(f'{baseName}_{guideTag}_guide_srt')) if addGroup else None
        guideNode  = cls.__createGuide__(name     = nameUtils.uniqNameSuffix(f'{baseName}_{guideTag}_guide'), 
                                         shape    = guideShape or 'GUIDE_BASE', 
                                         size     = guideSize, 
                                         guideTag = guideTag)
        # lock scale attr                                 
        attrUtils.lockBaseAttr(guideNode, ['sx', 'sy', 'sz'], vis=False)
        # set parent                               
        if guideGroup: 
            cmds.parent(guideNode, guideGroup)
        
        if parentGuide:
            cmds.parent(guideGroup or guideNode, parentGuide.nodeName)
            guideLine, decMatNode1, decMatNode2 = cls.createGuideLine(baseName, parentGuide.nodeName, guideNode, guideTag)
            guideLayer.addGuideNodestoMeta(guideNode, guideLine, guideTag, [guideGroup], [decMatNode1, decMatNode2]) # connect attr
            cmds.parent(guideLine, guideLayer.guideLineGroup) # set parent
        else:
            guideLayer.addGuideNodestoMeta(guideNode, None, guideTag, [guideGroup], None)
        return cls(guideNode)
        
    
    def addParentGuide(
                       self, 
                       baseName:str,
                       parentGuideNode:'GuideNode', 
                       guideLayer:'GuideLayer'
                        ) -> None:
        '''
        Adds a parent GuideNode to this GuideNode object at a later stage, after its creation.
        This method shares some logic with the create method, but is specifically designed 
        for adding a parent to an already created GuideNode object.
        
        hipGuide = nodes.GuideNode.createBaseGuide(parent=None)
        cogGuide = nodes.GuideNode.createBaseGuide(parent=rootGuide)
        hipGuide.addParentGuide(baseName, cogGuide, guideLayer)
        '''
        guideGroup = self.groupFromGuideLayer
        cmds.parent(guideGroup or self.nodeName, parentGuideNode.nodeName)
        
        guideLine, decMatNode1, decMatNode2 = GuideNode.createGuideLine(baseName, parentGuideNode.nodeName, self.nodeName, self.guideTag)
        cmds.parent(guideLine, guideLayer.guideLineGroup)
        # connect nodes
        index = attrUtils.getIndexByTag(f'{guideLayer.nodeName}.guideNodes', 'guideTag', self.guideTag) 
        basePath = f'{guideLayer}.guideNodes[{index}]'
        cmds.connectAttr(f'{guideLine}.message',f'{basePath}.guideLineNode') 
        cmds.connectAttr(f'{decMatNode1}.message', f'{basePath}.guideExtraNodes', f=True, na=True)
        cmds.connectAttr(f'{decMatNode2}.message', f'{basePath}.guideExtraNodes', f=True, na=True)
        
        
    def __init__(self, nodeName:str):
        if not self.isGuideNode(nodeName):
            raise TypeError(f'{nodeName} is not a valid guide node.')
        self.node = nodeName
        
        
    @staticmethod
    def isGuideNode(guideNode:str) -> bool:
        return cmds.attributeQuery('guideTag', n=guideNode, ex=True)
        
    
    @property
    def guideTag(self) -> str:
        return cmds.getAttr(f'{self.nodeName}.guideTag')
        
        
    @guideTag.setter
    def guideTag(self, newTag:str=''):
        cmds.setAttr(f'{self.nodeName}.guideTag', newTag, type='string')
        
    
    @property
    def guideLayer(self) -> 'GuideLayer':
        return next((layer for layer in self.layer if layer.metaClass == 'GuideLayer'), None)
        
        
    @property    
    def tagFromGuideLayer(self):
        '''
        Retrieve the guideTag from componentGuideMeta.

        Returns:
            str: The guideTag associated with the current node in the componentGuideMeta.

        Raises:
            ValueError: If no corresponding guideNode is found for this node in the componentGuideMeta.
        '''
        guideLayer = self.guideLayer.nodeName
        for attrIndex in range((cmds.getAttr(f'{guideLayer}.guideNodes', mi=True) or [0])[-1] + 1):
            node = cmds.listConnections(f'{guideLayer}.guideNodes[{attrIndex}].guideNode', d=False, s=True) 
            if node and cmds.ls(node[0], long=True)[0] == self.nodeName:
                return cmds.getAttr(f'{guideLayer}.guideNodes[{attrIndex}].guideTag')
                
        raise ValueError(f"No guideNode tag found for '{pathUtils.rootName(self.nodeName)}'.")
        
        
    @property
    def groupFromGuideLayer(self) -> str:
        guideLayer = self.guideLayer.nodeName
        index = attrUtils.getIndexByTag(f'{guideLayer}.guideNodes', 'guideTag', self.guideTag)  
        groups = cmds.listConnections(f'{guideLayer}.guideNodes[{index}].guideGroups', d=False, s=True)
        return groups[0] if groups else None  
        
        
    @property
    def indexFromGuideLayer(self) -> int:
        '''
        Retrieves the index of this guideNode in the guideNodes array of the componentGuideMeta.

        Returns:
            int: The index of the guideNode.

        Raises:
            ValueError: If the guideNode is not found in the guideNodes array.
        '''
        guideLayer = self.guideLayer.nodeName
        return attrUtils.getIndexByLongName(f'{guideLayer}.guideNodes', 'guideNode', self.nodeName)
        
        
    @property
    def localMatrixFromGuideLayer(self) -> list:
        guideLayer = self.guideLayer.nodeName
        index = self.indexFromGuideLayer
        
        matrix = cmds.getAttr(f'{guideLayer}.guideNodes[{index}].guideLocalMatrix')
        if matrix is None:
            '''
            This is a very strange issue: if we do not update the matrix attribute, 
            we cannot access it. To resolve this, we need to initialize the matrix 
            with an update.
            '''
            cmds.setAttr(f'{guideLayer}.guideNodes[{index}].guideLocalMatrix', list(om2.MMatrix()), type='matrix')
            return cmds.getAttr(f'{guideLayer}.guideNodes[{index}].guideLocalMatrix')
        return matrix
               
  
    @property
    def guideParent(self) -> 'GuideNode':
        pGuide = cmds.listConnections(f'{self.nodeName}.guideParent', d=True, s=False)
        return GuideNode(pGuide[0]) if pGuide else None
        
        
    @property
    def guideChildren(self) -> 'list[GuideNode]':
        childrenGuideNodes = cmds.listConnections(f'{self.nodeName}.guideChildren', d=False, s=True) or []
        return [GuideNode(guideNodeName) for guideNodeName in childrenGuideNodes]
        
    
    @property
    def isRoot(self) -> bool:
        return cmds.getAttr(f'{self.nodeName}.isRoot')
             
    
    def connectParent(self, parentGuide:'GuideNode'):
        cmds.connectAttr(f'{self.nodeName}.guideParent', f'{parentGuide.nodeName}.guideChildren', f=True, na=True)
        
        
    def disconnectParent(self):
        guideParent = self.guideParent
        if guideParent:
            cmds.disconnectAttr(f'{self.nodeName}.guideParent', f'{guideParent.nodeName}.guideChildren', na=True)
        
         
    def axisVis(self, vis=True):
        for shape in curveUtils._getSplineShapes(self.node):
            node = om2.MFnDependencyNode(shape)
            if not node.hasAttribute('isAxis'):
                continue
            node.findPlug('visibility', False).setBool(vis) 
                
                
    def showAxis(self):
        self.axisVis(True)
        
        
    def hideAxis(self):
        self.axisVis(False)
        
        
    def select(self):
        cmds.select(self.nodeName, ne=True, replace=True)
        
        
    def listExtraNodes(self) -> list:
        guideLayer = self.guideLayer.nodeName
        index      = self.indexFromGuideLayer
        return cmds.listConnections(f'{guideLayer}.guideNodes[{index}].guideExtraNodes', d=False, s=True) or []
        
        
    def extraNodeByTag(self, tag:str) -> str:
        extraNodes = self.listExtraNodes()
        return next((node 
                     for node in extraNodes 
                     if cmds.attributeQuery('lineTag', n=node, ex=True) and cmds.getAttr(f'{node}.lineTag') == tag), None)
                     
                     
    def addExtraNodes(self, extraNodes:list=None):
        path = f'{self.guideLayer.nodeName}.guideNodes[{self.indexFromGuideLayer}].guideExtraNodes'
        for node in extraNodes or []:
            cmds.connectAttr(f'{node}.message', path, f=True, na=True)
            
        
        
    
        
if __name__ == '__main__':
    root = GuideNode.createBaseGuide('sb', 'ss')
    #root.node
    
    #sb = f'{repr(root)}'
    #root.guideTag
    
    #base = GuideNode.createBaseGuide('sb', 'wca', 1, root, addGroup=True)
    
    #base.showAxis()
        
        
        
        
        
        
        
        
