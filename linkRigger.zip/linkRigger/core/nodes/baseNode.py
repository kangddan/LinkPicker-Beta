from maya import cmds
from maya.api import OpenMaya as om2

from linkRigger.utils import pathUtils
from linkRigger.core import meta

from linkRigger.utils import attrUtils
from linkRigger.utils import nameUtils


class BaseNode(object):
    
    def __hash__(self):
        return hash(self.nodeName)
    
    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        return self.nodeName == other.nodeName
    
    
    def __repr__(self):
        return f'<{self.__class__.__name__} at {hex(id(self))} {self.shortName or None}>'
               
                       
    def __str__(self):
        return self.nodeName
        
    
    @property
    def node(self) -> om2.MDagPath:
        return self._node
          
           
    @node.setter    
    def node(self, nodeName:str):
        self._node = om2.MDagPath.getAPathTo(om2.MGlobal.getSelectionListByName(nodeName).getDependNode(0)) 
    
    @property
    def shortName(self) -> 'str|None':
        nodeName = self.nodeName
        return pathUtils.rootName(self.nodeName) if nodeName else None

    @property
    def nodeName(self) -> 'str|None':
        nodeName = self.node.fullPathName()
        return nodeName if nodeName else None
        
        
    @property
    def layer(self) -> 'list[LayerNode]':
        nodes = cmds.listConnections(f'{self.nodeName}.message', d=True, s=False) or []
        layerNodes = [meta.MetaNode(node) for node in nodes if meta.MetaNode.isMetaNode(node)]
        if not layerNodes:
            raise ValueError(f"No layerNode node found connected to '{self.shortName}'.")
        return layerNodes
    
    
    def setVisibility(self, value):
        visibilityPlug = om2.MFnDagNode(self.node).findPlug('visibility', False)
        visibilityPlug.setBool(value)
        
    def show(self):
        self.setVisibility(True)
        
        
    def hide(self):
        self.setVisibility(False)
        
        
    def setRotateOrder(self, rotateOrder:'int|str'):
        if isinstance(rotateOrder, int):
            cmds.setAttr(f'{self.nodeName}.rotateOrder', rotateOrder)
        elif isinstance(rotateOrder, str):
            rotMap = {'xyz': 0, 'yzx': 1, 'zxy': 2,
                      'xzy': 3, 'yxz': 4, 'zyx': 5}
            cmds.setAttr(f'{self.nodeName}.rotateOrder', rotMap[rotateOrder])
            
    
    def rotateOrderBy(self, refNode:'str|BaseNode'):
        if isinstance(refNode, str):
            index = cmds.getAttr(f'{refNode}.rotateOrder')
        else:
            index = refNode.rotateOrder
        
        cmds.setAttr(f'{self.nodeName}.rotateOrder', index)
        
    
    @property
    def rotateOrder(self) -> int:
        return cmds.getAttr(f'{self.nodeName}.rotateOrder')
        
        
    @property
    def globalMatrix(self) -> 'list[float * 16]':
        worldMatrix = self.node.inclusiveMatrix()
        rotatePivot = om2.MFnTransform(self.node).rotatePivot(om2.MSpace.kTransform)
        offset      = rotatePivot * worldMatrix
        worldMatrix[12], worldMatrix[13], worldMatrix[14], _ = offset
        return list(worldMatrix)
        
        
    @property    
    def localMatrix(self) -> 'list[float * 16]':
        parentInverseMatrix = self.node.exclusiveMatrixInverse()
        localMatrix         = self.node.inclusiveMatrix() * parentInverseMatrix
        return list(localMatrix)
        
        
    @property      
    def globalPosition(self) -> 'list[float * 3]':
        globalVec = om2.MFnTransform(self.node).translation(om2.MSpace.kWorld)
        return list(globalVec)
        
        
    @property      
    def localPosition(self) -> 'list[float * 3]':
        localVec = om2.MFnTransform(self.node).translation(om2.MSpace.kTransform)
        return list(localVec)  
        
        
    @property
    def uuid(self) -> str:
        return om2.MFnDependencyNode(self.node.node()).uuid().asString() if self.nodeName else ''
            
    