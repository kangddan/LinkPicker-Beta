import json
from collections import OrderedDict

from maya import cmds
from maya.api import OpenMaya as om2
from linkRigger.core import meta
from linkRigger.utils import attrUtils
from linkRigger.utils import nameUtils
from linkRigger.utils import nodeUtils

from linkRigger.core import nodes
from linkRigger.rig import mirror


class GuideLayer(meta.MetaNode):
    
    @classmethod
    def setupGuideLayer(cls, instance=None, parent=None):
        # decompos nodeName
        baseName = instance.nodeName.rsplit(f'_meta', 1)[0]
        
        # add guide attr
        attrUtils.addAttr(instance.nodeName, 'extraNodes', type='message', multi=True)  
        attrUtils.addAttr(instance.nodeName, 'guideGroup', type='message')
        attrUtils.addAttr(instance.nodeName, 'guideLineGroup', type='message')
        attrUtils.addAttr(instance.nodeName, 'guideParentData', type='string')
        attrUtils.addAttr(instance.nodeName, 'guideAxisVis', type='bool', value=True)
        
        # guide attr
        attrUtils.addAttr(instance.nodeName, 'guideNodes', type='compound', nc=6, multi=True)
        attrUtils.addAttr(instance.nodeName, 'guideNode', type='message', parent='guideNodes')
        attrUtils.addAttr(instance.nodeName, 'guideLineNode', type='message', parent='guideNodes')
        attrUtils.addAttr(instance.nodeName, 'guideTag', type='string', parent='guideNodes')
        attrUtils.addAttr(instance.nodeName, 'guideLocalMatrix', type='matrix', parent='guideNodes')
        attrUtils.addAttr(instance.nodeName, 'guideGroups', type='message', multi=True, im=False, parent='guideNodes') # Handle indexed attributes more elegantly
        attrUtils.addAttr(instance.nodeName, 'guideExtraNodes', type='message', multi=True, im=False, parent='guideNodes') # Handle indexed attributes more elegantly
        
        
        
        # add grps                      
        guideGroup = nodeUtils.createNode('transform', nameUtils.uniqNameSuffix(baseName, '_hrc'), True, False)
        guideLineGroup = nodeUtils.createNode('transform', nameUtils.uniqNameSuffix(baseName, '_line_hrc'), True, False, guideGroup)

        # connect
        cmds.connectAttr(f'{guideGroup}.message', f'{instance.nodeName}.guideGroup')
        cmds.connectAttr(f'{guideLineGroup}.message', f'{instance.nodeName}.guideLineGroup')

        # connect metaNode
        if parent is not None:
            instance.addMetaParent(parent)
            cmds.parent(guideGroup, parent.componentGroup)
        

    @classmethod    
    def create(cls, nodeName:str='', 
                    metaId:'uuid'='',
                    parent:'MetaNode'=None):
        instance = super().create(nodeName, metaId)
        cls.setupGuideLayer(instance, parent)
        return instance
        
    
    @property
    def guideAxisVis(self) -> bool:
        return cmds.getAttr(f'{self.nodeName}.guideAxisVis')
        
    @guideAxisVis.setter
    def guideAxisVis(self, value:bool):
        cmds.setAttr(f'{self.nodeName}.guideAxisVis', value)
    
        
    @property
    def guideGroup(self) -> str:
        return cmds.listConnections(f'{self.nodeName}.guideGroup', d=False, s=True)[0]
        
        
    @property
    def guideLineGroup(self) -> str:
        return cmds.listConnections(f'{self.nodeName}.guideLineGroup', d=False, s=True)[0]  
        
       
        
    def updateGuideParentData(self):
        parentMap = {}
        for guide in self.listGuideNodes(False):
            guideGroup = guide.groupFromGuideLayer
            parent = cmds.listRelatives(guideGroup if guideGroup else guide.nodeName, parent=True, path=True)
            
            if parent and cmds.attributeQuery('guideTag', n=parent[0], ex=True):
                parentTag = cmds.getAttr(f'{parent[0]}.guideTag')  
                parentMap[guide.guideTag] = '' if parentTag == 'root' else parentTag

        cmds.setAttr(f'{self.nodeName}.guideParentData', json.dumps(parentMap), type='string')
    
    
    def setGuideParentData(self, newData:dict):
        cmds.setAttr(f'{self.nodeName}.guideParentData', json.dumps(newData), type='string')
    
    
    @property
    def guideParentData(self) -> dict:
        data = cmds.getAttr(f'{self.nodeName}.guideParentData')
        if not data:
            self.updateGuideParentData()
            data = cmds.getAttr(f'{self.nodeName}.guideParentData')

        return json.loads(data)
        
        
      
    @property
    def guideRootIndex(self) -> int:
        return attrUtils.getIndexByTag(f'{self.nodeName}.guideNodes', 'guideTag', tag='root')
        
        
    @property
    def guideRootNode(self) -> nodes.GuideNode:
        index = self.guideRootIndex
        return nodes.GuideNode(cmds.listConnections(f'{self.nodeName}.guideNodes[{index}].guideNode', d=False, s=True)[0])
        
        
    @property
    def guideRootGroup(self) -> str:
        index = self.guideRootIndex  
        return cmds.listConnections(f'{self.nodeName}.guideNodes[{index}].guideGroups', d=False, s=True)[0]
     
     
    @property
    def guideRootLineNode(self) -> 'str | None':
        index = self.guideRootIndex  
        lineNode = cmds.listConnections(f'{self.nodeName}.guideNodes[{index}].guideLineNode', d=False, s=True)
        return lineNode[0] if lineNode else None 
        
        
    @property
    def guideRootExtraNodes(self) -> list:
        index = self.guideRootIndex 
        return cmds.listConnections(f'{self.nodeName}.guideNodes[{index}].guideExtraNodes', d=False, s=True) or []
            
                       
    def getAllNodes(self) -> 'list[str]':
        return list(set(cmds.listConnections(f'{self.nodeName}', d=False, s=True) or []))
                
 
    def addGuideNodestoMeta(self, guideNode:str=None, 
                                  guideLineNode:str=None, 
                                  guideTag:str=None, 
                                  guideGroups:list=None,
                                  guideExtraNodes:list=None):
        '''
        Connect corresponding nodes to the guideNodes attribute.

        Args:
            guideNode (str): Name of the guide node to connect.
            guideLineNode (str): Name of the guide line node to connect.
            guideTag (str): Tag to set on the guide attribute.
            guideGroups (list): Guide groups
            guideExtraNodes (list): List of extra guide nodes to connect, typically decompose matrix nodes.
        '''                          
        newIndex = attrUtils.findEmptyIndex(f'{self.nodeName}.guideNodes', 'guideNode', d=False, s=True) # get index
        basePath = f'{self.nodeName}.guideNodes[{newIndex}]'
        if guideNode:
            cmds.connectAttr(f'{guideNode}.message', f'{basePath}.guideNode')
        if guideLineNode:
            cmds.connectAttr(f'{guideLineNode}.message',f'{basePath}.guideLineNode') 
        if guideTag:
            cmds.setAttr(f'{basePath}.guideTag', guideTag, type='string')
        if guideGroups:
            for grp in filter(None, guideGroups):
                cmds.connectAttr(f'{grp}.message', f'{basePath}.guideGroups', f=True, na=True)
        if guideExtraNodes:
            for node in filter(None, guideExtraNodes):
                cmds.connectAttr(f'{node}.message', f'{basePath}.guideExtraNodes', f=True, na=True)
    
    
    def addComponentParent(self, parentGuideNode:'GuideNode') -> bool:
        '''
        Add a parent to the current component
        Args:
            parentGuideNode (GuideNode): Target Guide.
        '''
        if self.parentGuide == parentGuideNode: 
            om2.MGlobal.displayWarning(f"The node '{parentGuideNode.shortName}' is already set as the parent for '{self.guideRootNode.shortName}'")  
            return False  
            
        elif parentGuideNode in self.listGuideNodes(includeRoot=True):
            om2.MGlobal.displayWarning(f"Cannot add the node '{parentGuideNode.shortName}' as it is already part of the guide hierarchy.")
            return False 
            
        elif parentGuideNode in self.childrenGuide:
            om2.MGlobal.displayWarning(f"Cannot add the node '{parentGuideNode.shortName}' as the parent because it is a child of '{self.nodeName}'")
            return False 
            
        # 0 clear componentParent
        self.removeComponentParent()
        
        guideRootGroup = self.guideRootGroup                    
        oldMatrix = cmds.xform(self.guideRootNode.nodeName, q=True, m=True, ws=True) # get global matrx
    
        # 1 get componentMeta
        parentComponentMeta = parentGuideNode.guideLayer.metaParent() 
   
        # 2 add constraint
        parentConstraint:str = cmds.parentConstraint(parentGuideNode.nodeName, guideRootGroup, w=1, mo=False)[0]
        scaleConstraint:str  = cmds.scaleConstraint(parentGuideNode.nodeName, guideRootGroup, w=1, mo=False)[0]
        
        # 3 to oldMatrix
        cmds.xform(self.guideRootNode.nodeName, m=oldMatrix, ws=True)
        
        # 4 set metaAttr
        componentMeta = self.metaParent()
        componentMeta.removeAllMetaParents().addMetaParent(parentComponentMeta)
        self.guideRootNode.connectParent(parentGuideNode)

        # 5 create guide line
        guideRootLineNode, decMatNode1, decMatNode2 = nodes.GuideNode.createGuideLine(componentMeta.baseName, 
                                                                                      parentGuideNode.nodeName, 
                                                                                      self.guideRootNode.nodeName, 
                                                                                      guideTag='parent')
        # 6 connect rootGuide meta attr
        index = self.guideRootIndex
        cmds.connectAttr(f'{guideRootLineNode}.message' ,f'{self.nodeName}.guideNodes[{index}].guideLineNode', f=True)
        for node in (parentConstraint, scaleConstraint, decMatNode1, decMatNode2):
            cmds.connectAttr(f'{node}.message', f'{self.nodeName}.guideNodes[{index}].guideExtraNodes', f=True, na=True)
            
        # 7 set guideLine group
        cmds.parent(guideRootLineNode, self.guideLineGroup)
        cmds.select(cl=True)
        return True
        
                
    def removeComponentParent(self) -> bool:
        # 0 delete guideLine nodes
        if self.parentGuide is None:
            return  False
            
        cmds.delete(self.guideRootExtraNodes)
        cmds.delete(self.guideRootLineNode)
        
        # 1 parent to componentsManager
        component = self.metaParent()
        componentsManager = component.componentsManager
        component.removeAllMetaParents().addMetaParent(componentsManager)
            
        # 2 disconnect guide attr
        self.guideRootNode.disconnectParent()
        
        # 3 reset guideRootGroup pose
        oldMatrix = cmds.xform(self.guideRootNode.nodeName, q=True, m=True, ws=True)
        cmds.xform(self.guideRootGroup, m=list(om2.MMatrix()), ws=False)
        cmds.xform(self.guideRootNode.nodeName, m=oldMatrix, ws=True)
        return True
    
    
    def listGuideNodes(self, includeRoot:bool=False) -> 'list[GuideNode]':
        '''
        Retrieves all connected GuideNode objects.

        Args:
            includeRoot (bool): If False, excludes nodes with the 'root' tag.
                                Defaults to False.

        Returns:
            list[GuideNode]: A list of GuideNode objects connected to the attribute array.
        '''
        guideNodesList = []
        for guide in attrUtils.getConnectedNodes(f'{self.nodeName}.guideNodes', 'guideNode'):
            if not includeRoot and cmds.getAttr(f'{guide}.guideTag') == 'root':
                continue
            guideNodesList.append(nodes.GuideNode(guide))

        return guideNodesList
        
    
    def listGuideTags(self, includeRoot:bool=False) -> 'list[str]':
        '''
        Return the guide tags stored in the guide layer node
        '''
        tags = []
        baePath = f'{self.nodeName}.guideNodes'
        for index in range((cmds.getAttr(baePath, mi=True) or [0])[-1] + 1):
            tag = cmds.getAttr(f'{baePath}{[index]}.guideTag')
            if not tag:
                continue
            if tag =='root' and not includeRoot:
                continue
            tags.append(tag)
        return tags

        
        
    def listGuideNodesOrdered(self, includeRoot:bool=False) -> 'list[GuideNode]':
        '''
        Retrieves all GuideNode objects in a top-down hierarchical order.

        This method traverses the guide hierarchy starting from the root node 
        and retrieves all connected GuideNode objects in a top-down order 
        (parent -> child -> grandchild)

        Args:
            includeRoot (bool): If True, includes the root node in the returned list.
                                Defaults to False.

        Returns:
            list[GuideNode]: A list of GuideNode objects in top-down hierarchical order.
        '''
        guideRootNodeName = self.guideRootNode.nodeName
        
        allNodes = cmds.listRelatives(guideRootNodeName, ad=True, type='transform') or []
        if includeRoot:
            allNodes.insert(-1, guideRootNodeName) 
        allNodes.reverse()
        return [nodes.GuideNode(node) for node in allNodes if cmds.attributeQuery('guideTag', n=node, ex=True)]
        
             
    def updateGuidesLocalMatrix(self):
        basePath = f'{self.nodeName}.guideNodes'
        targetAttr = 'guideNode'
        for i in attrUtils.getValidIndexs(basePath, targetAttr):
            node = cmds.listConnections(f'{basePath}[{i}].{targetAttr}', d=False, s=True)[0]
            cmds.setAttr(f'{basePath}[{i}].guideLocalMatrix', cmds.getAttr(f'{node}.matrix'), type='matrix')

  
    def delete(self):
        # update child guide parent
        '''
        for guide in self.listGuideNodes(True):   
            for childGuide in guide.guideChildren:
                childGuide.guideLayer.removeComponentParent()
        '''
        allNodes = self.getAllNodes()
        for node in allNodes:
            cmds.setAttr(f'{node}.nodeState', 2)
        cmds.delete(self.getAllNodes())
        
    
    def getGuideIndex(self, guide:'GuideNode') -> int:
        return attrUtils.getIndexByLongName(f'{self.nodeName}.guideNodes', 'guideNode', guide.nodeName)
        
        
    def deleteGuide(self, guide:'GuideNode'):
        if guide.guideLayer != self:
            return
        # update child guide parent
        for childGuide in guide.guideChildren:
            childGuide.guideLayer.removeComponentParent()

        index = self.getGuideIndex(guide)
        basePath = f'{self.nodeName}.guideNodes[{index}]'
        
        deleteNodes = [guide.nodeName]
        deleteNodes.extend(cmds.listConnections(f'{basePath}.guideLineNode', d=False, s=True) or [])
        deleteNodes.extend(cmds.listConnections(f'{basePath}.guideExtraNodes', d=False, s=True) or [])
        deleteNodes.extend(cmds.listConnections(f'{basePath}.guideGroups', d=False, s=True) or [])
        cmds.delete(deleteNodes)
        cmds.removeMultiInstance(basePath, b=True)  
        
        
    @staticmethod    
    def updateGuideLineStartNode(guide:'GuideNode', 
                                 targetGuideNode:'GuideNode'):
        
        startVectorNode = guide.extraNodeByTag('start')
        cmds.connectAttr(f'{targetGuideNode.nodeName}.worldMatrix[0]', f'{startVectorNode}.inMatrix', f=True)
        
        
    def updateGuideParent(self, 
                          guide:'GuideNode',
                          parentGuide:'GuideNode'):
                            
        if guide.guideLayer != self or guide.guideTag == 'root':
            return
            
        self.updateGuideLineStartNode(guide, parentGuide)
        
        guideGroup = guide.groupFromGuideLayer
        if guideGroup: 
            cmds.parent(guideGroup, parentGuide.nodeName)
        else:
            cmds.parent(guide.nodeName, parentGuide.nodeName)
       
        
    def guideNodeFromTag(self, tag:str) -> 'GuideNode':
        node = attrUtils.getNodeByTag(f'{self.nodeName}.guideNodes', 'guideNode', 'guideTag', tag)
        if node is None:
            raise ValueError(f"No ControlNode with tag '{tag}' found on '{self.nodeName}'.")
        return nodes.GuideNode(node)
        
    def guideLineFromTag(self, tag:str) -> str:
        guideLineNode = attrUtils.getNodeByTag(f'{self.nodeName}.guideNodes', 'guideLineNode', 'guideTag', tag)
        if guideLineNode is None:
            raise ValueError(f"No ControlNode with tag '{tag}' found on '{self.nodeName}'.")
        return guideLineNode
        
        
    @property    
    def parentGuide(self) -> 'GuideNode|None':
        return self.guideRootNode.guideParent
        

    @property
    def childrenGuide(self) -> 'list[GuideNode]':
        allChildrenGuideNode = []
        for componentNode in self.metaParent().listChildComponentNode(True):
            allChildrenGuideNode.extend(componentNode.listGuideNodes(includeRoot=True))
        return allChildrenGuideNode
                 
        
    def guideNodeToOutputNode(self, guideNode:'GuideNode'):
        outputNode = self.metaParent().outputLayer.outputNodeFromTag(guideNode.guideTag)
        return outputNode
        
        
    def getSelectedGuideNodes(self) -> 'list[GuideNode]':
        selGuideNodes = [nodes.GuideNode(node)
                         for node in cmds.ls(sl=True, type='transform', long=True)
                         if cmds.attributeQuery('guideTag', n=node, ex=True)] 
        if not selGuideNodes: 
            return [] 
               
        return [guideNode 
                for guideNode in selGuideNodes 
                if guideNode in self.listGuideNodes(includeRoot=True)]
                 
            
    def getData(self) -> dict:
        pass
        
        
    def setData(self, data:dict):
        pass
        
    
    def duplicate(self):
        pass
        
        
    def mirror(self):
        pass
    
    
    def symmetrizeComponent(self, axis:str='x'):
        '''
        Coordinate symmetry and unify rotation order for the mirrored component
        '''
        mirrorComponent = self.metaParent().mirrorComponent
        if mirrorComponent is None:
            return
            
        mirrorGuides = mirrorComponent._sortGuideNodes_(mirrorComponent.listGuideNodes(includeRoot=True))
        
        selfGuideDataMap = {guide.guideTag: [guide.globalMatrix, guide.rotateOrder] 
                            for guide in self.listGuideNodes(includeRoot=True)}
    
        for mirrorGuide in mirrorGuides:
            guideTag = mirrorGuide.guideTag
            if guideTag not in selfGuideDataMap:
                continue
            
            mirrorMatrix, rotateOrder = selfGuideDataMap[guideTag]
            mirrorGuide.setRotateOrder(rotateOrder)
            cmds.xform(mirrorGuide.nodeName, m=mirror.mirrorMatrix(mirrorMatrix, axis), ws=True)

        mirrorComponent.guideLayer.updateGuidesLocalMatrix()  
        
    
    def getGuidesTransformsData(self) -> dict:
        self.updateGuidesLocalMatrix()
        guideTransformsData = {}
        for guideNode in self.listGuideNodes(includeRoot=True):
            guideTag = guideNode.guideTag
            guideTransformsData[guideTag] = {'localMatrix':guideNode.localMatrixFromGuideLayer, 
                                             'rotateOrder':guideNode.rotateOrder}
        return guideTransformsData
        
        
    def setGuidesTransforms(self, data:dict, space:bool=False):
        '''
        Sets guide node localMatrix and rotateOrder.

        Args:
            data (dict): Dictionary with guideTag as keys and values containing:
                         - 'localMatrix': 4x4 transformation matrix (local space).
                         - 'rotateOrder': Rotation order as an integer.
                         
            space (bool): locol or world space

        Example:
            data = {
                'fk01': {'localMatrix': [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1], 
                           'rotateOrder': 0},
                'fk02': {'localMatrix': [0.707, 0.707, 0, 0, -0.707, 0.707, 0, 0, 0, 0, 1, 0, 1, 2, 3, 1], 
                           'rotateOrder': 1}
            }

        Notes:
            - Sets the rotate order first, then applies the localMatrix.
        '''
        for guideNode in self.listGuideNodes(includeRoot=True):
            guideData:dict = data[guideNode.guideTag]
            guideNode.setRotateOrder(guideData['rotateOrder'])                   # 0
            cmds.xform(guideNode.nodeName, m=guideData['localMatrix'], ws=space) # 1
            
            



if __name__ == '__main__':
    g = ComponentGuide.create('Gode_M_guide_meta')
    #g.setSide('R')
    
    #g.setName('fkChang')
