import json
from maya import cmds
from maya.api import OpenMaya as om2
from linkRigger.core import meta
from linkRigger.core import nodes

from linkRigger.utils import attrUtils
from linkRigger.utils import nameUtils
from linkRigger.utils import nodeUtils

from linkRigger.rig import spaceSwitch


class RigLayer(meta.MetaNode):
    
    @classmethod
    def setupRigLayer(cls, instance=None, parent=None):
        baseName = instance.nodeName.rsplit(f'_meta', 1)[0]
        attrUtils.addAttr(instance.nodeName, 'extraNodes', type='message', multi=True, im=False)  
        attrUtils.addAttr(instance.nodeName, 'rigGroup', type='message')
        # ctrl attr
        attrUtils.addAttr(instance.nodeName, 'controlNodes', type='compound', multi=True, nc=4)
        attrUtils.addAttr(instance.nodeName, 'controlNode', type='message', parent='controlNodes')
        attrUtils.addAttr(instance.nodeName, 'controlTag', type='string', parent='controlNodes')
        attrUtils.addAttr(instance.nodeName, 'controlGroups', type='message', multi=True, im=False, parent='controlNodes') # Handle indexed attributes more elegantly
        attrUtils.addAttr(instance.nodeName, 'controlShapeData', type='string', parent='controlNodes')
        
        # ikjoint attr
        attrUtils.addAttr(instance.nodeName, 'jointNodes', type='compound', multi=True, nc=2)
        attrUtils.addAttr(instance.nodeName, 'jointNode', type='message', parent='jointNodes')
        attrUtils.addAttr(instance.nodeName, 'jointTag', type='string', parent='jointNodes')
        
        # tagged attr
        attrUtils.addAttr(instance.nodeName, 'taggedNodes', type='compound', multi=True, nc=3)
        attrUtils.addAttr(instance.nodeName, 'taggedNode', type='message', parent='taggedNodes')
        attrUtils.addAttr(instance.nodeName, 'taggedTag', type='string', parent='taggedNodes')
        attrUtils.addAttr(instance.nodeName, 'note', type='string', parent='taggedNodes')
        
        # space switch attr
        attrUtils.addAttr(instance.nodeName, 'spaceSwitchTargets', type='compound', multi=True, nc=15)
        attrUtils.addAttr(instance.nodeName, 'useTranslate', type='bool', parent='spaceSwitchTargets')
        attrUtils.addAttr(instance.nodeName, 'useRotate', type='bool', parent='spaceSwitchTargets')
        attrUtils.addAttr(instance.nodeName, 'useScale', type='bool', parent='spaceSwitchTargets')
        attrUtils.addAttr(instance.nodeName, 'useShear', type='bool', parent='spaceSwitchTargets')
        attrUtils.addAttr(instance.nodeName, 'isParent', type='bool', parent='spaceSwitchTargets')
        
        attrUtils.addAttr(instance.nodeName, 'attrName', type='string', parent='spaceSwitchTargets')
        attrUtils.addAttr(instance.nodeName, 'targetComponentBaseName', type='string', parent='spaceSwitchTargets')
        attrUtils.addAttr(instance.nodeName, 'targetComponentMetaId', type='string', parent='spaceSwitchTargets')
        attrUtils.addAttr(instance.nodeName, 'targetGuideNode', type='message', parent='spaceSwitchTargets')
        attrUtils.addAttr(instance.nodeName, 'targetGuideTag', type='string', parent='spaceSwitchTargets')
        
        attrUtils.addAttr(instance.nodeName, 'drivenGuideNode', type='message', parent='spaceSwitchTargets')
        attrUtils.addAttr(instance.nodeName, 'drivenGuideTag', type='string', parent='spaceSwitchTargets')
        
        attrUtils.addAttr(instance.nodeName, 'outputNode', type='message', parent='spaceSwitchTargets')
        attrUtils.addAttr(instance.nodeName, 'spaceGroup', type='message', parent='spaceSwitchTargets')
        attrUtils.addAttr(instance.nodeName, 'spaceSwitchExtraNodes', type='message', multi=True, parent='spaceSwitchTargets') 
        
          
        # add grp                     
        rigGroup = nodeUtils.createNode('transform', nameUtils.uniqNameSuffix(baseName, '_hrc'), True, False)
        # connect
        cmds.connectAttr(f'{rigGroup}.message', f'{instance.nodeName}.rigGroup')
        # connect metaNode
        if parent is not None:
            instance.addMetaParent(parent)
            cmds.parent(rigGroup, parent.componentGroup)
            
        
    @classmethod    
    def create(cls, nodeName:str='', 
                    metaId:'uuid'='',
                    parent:'MetaNode'=None):
        instance = super().create(nodeName, metaId)
        cls.setupRigLayer(instance, parent)
        return instance
        
    @property
    def rigGroup(self) -> str:
        return cmds.listConnections(f'{self.nodeName}.rigGroup', d=False, s=True)[0]
        
        
    def shapeFromControlTag(self, controlTag:str) -> 'dict|None':
        index = attrUtils.getIndexByTag(f'{self.nodeName}.controlNodes', 'controlTag', controlTag)
        if index < 0:
            return None
        shape = cmds.getAttr(f'{self.nodeName}.controlNodes[{index}].controlShapeData')
        return json.loads(shape) if shape else None
    

    def clearAllShapeData(self):
        basePath = f'{self.nodeName}.controlNodes'
        indexs = cmds.getAttr(basePath, mi=True)
        if not indexs:
            return
        for index in indexs:
            cmds.setAttr(f'{basePath}[{index}].controlShapeData', '', type='string')
            
        
  
    def getAllNodes(self, includeGroup=True) -> 'list[str]':
        allNodes = []
        if includeGroup:
            allNodes.append(self.rigGroup)
        
        extraNodes:'list[str]' = cmds.listConnections(f'{self.nodeName}.extraNodes', d=False, s=True) or []
        taggedNodes:'list[str]' = attrUtils.getConnectedNodes(f'{self.nodeName}.taggedNodes', 'taggedNode')
        jointNodes:'list[str]' = attrUtils.getConnectedNodes(f'{self.nodeName}.jointNodes', 'jointNode')
        controlNodes:'list[str]' = attrUtils.getConnectedNodes(f'{self.nodeName}.controlNodes', 'controlNode')
        groupNodes:'list[str]' = attrUtils.getConnectedNodes(f'{self.nodeName}.controlNodes', 'controlGroups')
        
        allNodes.extend(extraNodes)
        allNodes.extend(taggedNodes)
        allNodes.extend(jointNodes)
        allNodes.extend(controlNodes)
        allNodes.extend(groupNodes)
        
        # add space switch nodes
        for ctrl in self.listControlNodes():
            spaceGroup = ctrl.spaceParent
            if spaceGroup is not None:
                spaceNodes = cmds.listConnections(f'{spaceGroup}.extraNodes', d=False, s=True) or []
                allNodes.extend(spaceNodes)

        return list(set(allNodes))
        
        
    def addExtraNodesToMeta(self, nodes:list):
        for node in nodes:
            cmds.connectAttr(f'{node}.message', f'{self.nodeName}.extraNodes', f=True, na=True)
    
    
    def addTaggedNodetoMeta(self, taggedInstance:'TaggedNode|str'=None, taggedTag:str=None, note:str=None):
        newIndex = attrUtils.findEmptyIndex(f'{self.nodeName}.taggedNodes', 'taggedNode', d=False, s=True) # get index
        basePath = f'{self.nodeName}.taggedNodes[{newIndex}]'
        
        if isinstance(taggedInstance, str):
            cmds.connectAttr(f'{taggedInstance}.message', f'{basePath}.taggedNode')
            nodes.taggedNode.TaggedNode.setColor(taggedInstance)
            if not cmds.attributeQuery('taggedTag', node=taggedInstance, ex=True):
                attrUtils.addAttr(taggedInstance, 'taggedTag', type='string', value=taggedTag or 'null')
        else:
            cmds.connectAttr(f'{taggedInstance.nodeName}.message', f'{basePath}.taggedNode')
        cmds.setAttr(f'{basePath}.taggedTag', taggedTag or taggedInstance.taggedTag, type='string')
        cmds.setAttr(f'{basePath}.note', note or 'null', type='string')
        
        
    def addJointNodeToMeta(self, jointInstance:'Joint'=None, jointTag=None):
        newIndex = attrUtils.findEmptyIndex(f'{self.nodeName}.jointNodes', 'jointNode', d=False, s=True) # get index
        basePath = f'{self.nodeName}.jointNodes[{newIndex}]'
        
        cmds.connectAttr(f'{jointInstance.nodeName}.message', f'{basePath}.jointNode')
        cmds.setAttr(f'{basePath}.jointTag', jointTag or jointInstance.jointTag, type='string')
   
        
    def addRigNodetoMeta(self, controlInstance:'Control'=None):
        
        newIndex = attrUtils.findEmptyIndex(f'{self.nodeName}.controlNodes', 'controlNode', d=False, s=True) # get index
        basePath = f'{self.nodeName}.controlNodes[{newIndex}]'
        
        cmds.connectAttr(f'{controlInstance.nodeName}.message', f'{basePath}.controlNode')
        cmds.setAttr(f'{basePath}.controlTag', controlInstance.controlTag, type='string')
        cmds.setAttr(f'{basePath}.controlShapeData', json.dumps(controlInstance.controlShapeData), type='string') # save control shapeData
        
        for group in controlInstance.listParents():
            if group is None: continue
            cmds.connectAttr(f'{group}.message', f'{basePath}.controlGroups', f=True, na=True)
            
            
    def listControlNodes(self) -> 'list[ControlNode]':
        return [nodes.ControlNode(controlNode) for controlNode in attrUtils.getConnectedNodes(f'{self.nodeName}.controlNodes', 'controlNode')]
        
    
    def updateAllControlNodeShape(self):
        basePath = f'{self.nodeName}.controlNodes'
        tagAttr  = 'controlTag'
        for control in self.listControlNodes():
            index = attrUtils.getIndexByTag(basePath, tagAttr, control.controlTag)
            if index < 0:
                continue
            cmds.setAttr(f'{basePath}[{index}].controlShapeData', json.dumps(control.controlShapeData), type='string')
            
    
    def taggedNodeFromTag(self, 
                          tag:str, 
                          asObject=False
                          ) -> 'str|TaggedNode|None':
        node = attrUtils.getNodeByTag(f'{self.nodeName}.taggedNodes', 'taggedNode', 'taggedTag', tag)
        if node and asObject:
            return nodes.TaggedNode(node)
        return node
        
        
    def controlNodeFromTag(self, tag:str) -> 'ControlNode':
        node = attrUtils.getNodeByTag(f'{self.nodeName}.controlNodes', 'controlNode', 'controlTag', tag)
        if node is None:
            raise ValueError(f"No ControlNode with tag '{tag}' found on '{self.nodeName}'.")
        return nodes.ControlNode(node)
    
    
    def listSpaceSwitchTargetGuideNodes(self) -> 'list[GuideNode]':
        return [nodes.GuideNode(cmds.listConnections(f'{self.nodeName}.spaceSwitchTargets[{i}].targetGuideNode', d=False, s=True)[0])
               for i in attrUtils.getValidIndexs(f'{self.nodeName}.spaceSwitchTargets', 'targetGuideNode')]
    
 
    # add space switch 
    def addSpaceSwitch(
                       self, 
                       drivenGuideNode:'GuideNode',
                       targetGuideNode:'GuideNode',
                       attrName:str='',
                       useTranslate:bool=True,
                       useRotate:bool=True,
                       useScale:bool=True,
                       useShear:bool=True,
                       isParent:bool=False
                       ) -> bool:
                        
        # 0 get valid attr path
        index = attrUtils.findEmptyIndex(f'{self.nodeName}.spaceSwitchTargets', 'targetGuideNode')
        basePath = f'{self.nodeName}.spaceSwitchTargets[{index}]'
                        
        # 1 check parent                
        if isParent:
            cmds.setAttr(f'{basePath}.isParent', True)
            cmds.setAttr(f'{basePath}.attrName', attrName, type='string')
            cmds.connectAttr(f'{drivenGuideNode.nodeName}.message', f'{basePath}.targetGuideNode', f=True)
            cmds.connectAttr(f'{drivenGuideNode.nodeName}.message', f'{basePath}.drivenGuideNode', f=True)
            cmds.setAttr(f'{basePath}.drivenGuideTag', drivenGuideNode.guideTag, type='string')
            return
            
        
        # basic space switch     
        if targetGuideNode in self.metaParent().guideLayer.childrenGuide:
            om2.MGlobal.displayWarning(f"Cannot add '{targetGuideNode.shortName}' as a spaceSwitch target "
                                       f"because it is part of a child component of '{self.metaParent().nodeName}'")
            return False
        
        cmds.connectAttr(f'{targetGuideNode.nodeName}.message', f'{basePath}.targetGuideNode', f=True)
        cmds.setAttr(f'{basePath}.attrName', attrName, type='string')
        cmds.setAttr(f'{basePath}.useTranslate', useTranslate)
        cmds.setAttr(f'{basePath}.useRotate', useRotate)
        cmds.setAttr(f'{basePath}.useScale', useScale)
        cmds.setAttr(f'{basePath}.useShear', useShear)
        
        cmds.setAttr(f'{basePath}.targetComponentBaseName', targetGuideNode.guideLayer.metaParent().baseName, type='string')
        cmds.setAttr(f'{basePath}.targetComponentMetaId', targetGuideNode.guideLayer.metaParent().metaId, type='string')
        cmds.setAttr(f'{basePath}.targetGuideTag', targetGuideNode.guideTag, type='string')
        
        cmds.connectAttr(f'{drivenGuideNode.nodeName}.message', f'{basePath}.drivenGuideNode', f=True)
        cmds.setAttr(f'{basePath}.drivenGuideTag', drivenGuideNode.guideTag, type='string')
        return True
        
        
    def deleteSpaceSwitch(self, targetGuideNode:'GuideNode'):
        basePath = f'{self.nodeName}.spaceSwitchTargets'
        index = attrUtils.getIndexByLongName(basePath, 'targetGuideNode', targetGuideNode.nodeName)
        cmds.removeMultiInstance(f'{basePath}[{index}]', b=True)   
        
  
    def deleteAllSpaceSwitch(self):
        '''
        Delete all space switch data
        '''
        basePath = f'{self.nodeName}.spaceSwitchTargets'
        for attrIndex in range((cmds.getAttr(basePath, mi=True) or [0])[-1] + 1):
            cmds.removeMultiInstance(f'{basePath}[{attrIndex}]', b=True)  
            
            
    def deleteDrivenGuideSpaceSwitch(self, drivenGuideNode:'GuideNode'):
        '''
        Delete all space switch data from the driven guide node
        '''
        basePath = f'{self.nodeName}.spaceSwitchTargets'
        indexs = attrUtils.getIndexsByLongName(basePath, 'drivenGuideNode', drivenGuideNode.nodeName)
        for attrIndex in indexs:
            cmds.removeMultiInstance(f'{basePath}[{attrIndex}]', b=True)  
        

        
    def updateSpaceSwitchInfo(self):
            
        # 0 clear invalid attr
        invalidIndexs = set()
        invalidIndexs.update(attrUtils.getInvalidIndexs(f'{self.nodeName}.spaceSwitchTargets', 'targetGuideNode'))
        invalidIndexs.update(attrUtils.getInvalidIndexs(f'{self.nodeName}.spaceSwitchTargets', 'drivenGuideNode'))
  
        for i in sorted(invalidIndexs, reverse=True): 
            cmds.removeMultiInstance(f'{self.nodeName}.spaceSwitchTargets[{i}]', b=True)  
        
        # 1 update nwe data
        indexs:'list[int]' = attrUtils.getValidIndexs(f'{self.nodeName}.spaceSwitchTargets', 'targetGuideNode')
        for i in indexs:
            basePath = f'{self.nodeName}.spaceSwitchTargets[{i}]'
            # check parent
            if cmds.getAttr(f'{basePath}.isParent'):
                drivenGuideNode = nodes.GuideNode(cmds.listConnections(f'{basePath}.drivenGuideNode', d=False, s=True)[0])
                cmds.setAttr(f'{basePath}.drivenGuideTag', drivenGuideNode.guideTag, type='string')
                continue
                
            targetGuideNode = nodes.GuideNode(cmds.listConnections(f'{basePath}.targetGuideNode', d=False, s=True)[0])
            cmds.setAttr(f'{basePath}.targetComponentBaseName', targetGuideNode.guideLayer.metaParent().baseName, type='string')
            cmds.setAttr(f'{basePath}.targetComponentMetaId', targetGuideNode.guideLayer.metaParent().metaId, type='string')
            cmds.setAttr(f'{basePath}.targetGuideTag', targetGuideNode.guideTag, type='string')
            
            drivenGuideNode = nodes.GuideNode(cmds.listConnections(f'{basePath}.drivenGuideNode', d=False, s=True)[0])
            cmds.setAttr(f'{basePath}.drivenGuideTag', drivenGuideNode.guideTag, type='string')
        
        
    def connectOutputNodeAndSpaceGroup(self):
        indexs:'[int...]' = attrUtils.getValidIndexs(f'{self.nodeName}.spaceSwitchTargets', 'targetGuideNode')
        for i in indexs:
            basePath = f'{self.nodeName}.spaceSwitchTargets[{i}]'
            # check parent
            if cmds.getAttr(f'{basePath}.isParent'):
                drivenGuideTag   = cmds.getAttr(f'{basePath}.drivenGuideTag')
                spaceGroup:'str' = self.controlNodeFromTag(drivenGuideTag).spaceParent
                cmds.connectAttr(f'{spaceGroup}.message', f'{basePath}.spaceGroup', f=True)
                continue
                
            targetGuideNode:'GuideNode' = nodes.GuideNode(cmds.listConnections(f'{basePath}.targetGuideNode', d=False, s=True)[0])
            targetGuideTag:str = cmds.getAttr(f'{basePath}.targetGuideTag')
            
            outputNode:'OutputNode' = targetGuideNode.guideLayer.metaParent().outputLayer.outputNodeFromTag(targetGuideTag)
            
            drivenGuideTag   = cmds.getAttr(f'{basePath}.drivenGuideTag')
            spaceGroup:'str' = self.controlNodeFromTag(drivenGuideTag).spaceParent
            
            cmds.connectAttr(f'{outputNode.nodeName}.message', f'{basePath}.outputNode', f=True)
            cmds.connectAttr(f'{spaceGroup}.message', f'{basePath}.spaceGroup', f=True)
            

    def getSpaceSwitchData(self) -> 'list[dict]':
        
        basePath = f'{self.nodeName}.spaceSwitchTargets'
        indexs = attrUtils.getValidIndexs(basePath, 'targetGuideNode')
        if not indexs:
            return []
            
        _datas = []
        for i in indexs:
            baseAttrPath = f'{basePath}[{i}]'
            data = {}
            # check Parent
            isParent = cmds.getAttr(f'{baseAttrPath}.isParent')
            
            data['attrName']  = cmds.getAttr(f'{baseAttrPath}.attrName')
            data['outputNode']  = isParent or cmds.listConnections(f'{baseAttrPath}.outputNode')[0]
            
            data['controlNode'] = self.controlNodeFromTag(cmds.getAttr(f'{baseAttrPath}.drivenGuideTag')).nodeName
            data['spaceGroup']  = cmds.listConnections(f'{baseAttrPath}.spaceGroup')[0]
            
            data['useTranslate'] = cmds.getAttr(f'{baseAttrPath}.useTranslate')
            data['useRotate'] = cmds.getAttr(f'{baseAttrPath}.useRotate')
            data['useScale'] = cmds.getAttr(f'{baseAttrPath}.useScale')
            data['useShear'] = cmds.getAttr(f'{baseAttrPath}.useShear')
            data['isParent'] = isParent
            _datas.append(data)
            
        # data Mapping
        newData = []; controlNodeMap = {}
        for item in _datas:
            controlNode = item['controlNode']
            spaceGroup  = item['spaceGroup']
            outputNode  = item['outputNode']
            targetsInfo = {key: value for key, value in item.items() if key not in ['controlNode', 'spaceGroup', 'outputNode']}
            if controlNode not in controlNodeMap:
                newEntry = {'controlNode': controlNode, 'spaceGroup': spaceGroup, 'targets': {}}
                newData.append(newEntry)
                controlNodeMap[controlNode] = newEntry
            controlNodeMap[controlNode]['targets'][outputNode] = targetsInfo
  
        return newData
        
        
    def setSpaceSwitch(self):
        self.updateSpaceSwitchInfo()
        self.connectOutputNodeAndSpaceGroup()
        spaceData = self.getSpaceSwitchData()
        for data in spaceData:
            ctrl      :str  = data['controlNode']
            spaceGroup:str  = data['spaceGroup']
            targets   :dict = data['targets']
            nodes     :list = spaceSwitch.createSpaceSwitch(self.metaParent().baseName, ctrl, spaceGroup, targets)
            for node in nodes:
                cmds.connectAttr(f'{node}.message', f'{spaceGroup}.extraNodes', f=True, na=True)
        
        
    ############################## Duplicate ##############################   
    def getDuplicateSpaceSwitchData(self) -> 'list[dict]':
        self.updateSpaceSwitchInfo()
        basePath = f'{self.nodeName}.spaceSwitchTargets'
        indexs = attrUtils.getValidIndexs(basePath, 'targetGuideNode')
        if not indexs:
            return []
            
        datas = []
        for i in indexs:
            baseAttrPath = f'{basePath}[{i}]'
            data = {}
            data['useTranslate'] = cmds.getAttr(f'{baseAttrPath}.useTranslate')
            data['useRotate'] = cmds.getAttr(f'{baseAttrPath}.useRotate')
            data['useScale'] = cmds.getAttr(f'{baseAttrPath}.useScale')
            data['useShear'] = cmds.getAttr(f'{baseAttrPath}.useShear')
            
            data['attrName']  = cmds.getAttr(f'{baseAttrPath}.attrName')
            
            # check Parent
            isParent = cmds.getAttr(f'{baseAttrPath}.isParent')
            data['isParent']  = isParent
            if isParent:
                data['targetComponentBaseName']  = ''
                data['targetComponentMetaId']  = ''
                
                data['targetGuideTag']  = ''
                data['drivenGuideTag']  = cmds.getAttr(f'{baseAttrPath}.drivenGuideTag')
            else:
                
                '''
                The primary purpose of the `targetComponentBaseName` attribute is to distinguish, 
                whether the `drivenGuideTag` originates from the current component or another component.
                
                Check whether the spaceSwitch targetGuide is part of itself. 
                If it is, set the componentName to '__SELF__COMPONENT__' for additional handling
                
                The goal is to query the current component's GuideTag, 
                when using its own outputNode as the space switch target, 
                instead of duplicating the target's component
                '''
                _targetComponentBaseName = cmds.getAttr(f'{baseAttrPath}.targetComponentBaseName')
                targetComponentBaseName = _targetComponentBaseName if _targetComponentBaseName != self.metaParent().baseName else '__SELF__COMPONENT__'
                data['targetComponentBaseName']  = targetComponentBaseName
                data['targetComponentMetaId']  = cmds.getAttr(f'{baseAttrPath}.targetComponentMetaId')
                
                data['targetGuideTag']  = cmds.getAttr(f'{baseAttrPath}.targetGuideTag')
                data['drivenGuideTag']  = cmds.getAttr(f'{baseAttrPath}.drivenGuideTag')
            datas.append(data)
        return datas
        
        
    @staticmethod    
    def updateDuplicateSpaceSwitchData(
                                       metaIdMap:dict, 
                                       data:'list[dict]'
                                       ) -> 'list[dict]':
        '''
        Updates the provided `data` by mapping old UUIDs to newly created objects during the Duplicate process.
        This ensures that the space switch targets are correctly resolved and mapped to the corresponding
        components in the duplicated structure, thereby maintaining the correct parent-child relationships.
        ﻿
        During the Duplicate process, components are recreated, and their original UUIDs are replaced by 
        new component names. This method uses a mapping (`metaIdMap`) to resolve old UUIDs to new names,
        updating the `targetComponentNodeName` field in the space switch data.
        ﻿
        Args:
        metaIdMap (dict): 
        A dictionary containing the mapping between the old UUIDs (from the original structure) 
        and the new component names (from the duplicated structure). This ensures that parent-child 
        relationships can still be accurately restored using the old UUIDs.
        data (list[dict]): 
        Space switch data that includes references to old UUIDs from the Duplicate process.
        Each dictionary in the list represents an individual space switch entry.
        ﻿
        Returns:
        list[dict]: The updated space switch data, with the `targetComponentNodeName` field replaced 
        by the new component names resolved from `metaIdMap`. If a UUID cannot be resolved, the 
        `targetComponentNodeName` field is set to an empty string.

        Example:
            newSpaceData = self.rigLayer.updateDuplicateSpaceSwitchData(childParentMap, data['componentInfo']['spaceSwitchInfo'])
            componentNode.rigLayer.setDuplicateSpaceSwitchData(newSpaceData)
        '''
        for spaceData in data:
            metaId = spaceData['targetComponentMetaId']
            nodeName = metaIdMap.get(metaId, None)
            
            spaceData['targetComponentNodeName'] = '' if nodeName is None else nodeName

        return data
          
    
    def _processSpaceSwitchData_(
                                 self, 
                                 data:list, 
                                 isRebuild=False
                                 ) -> None:
        '''
        Internal method to process spaceSwitch data for setting or rebuilding connections.
        
        Args:
        data (list):  
        List of dictionaries containing spaceSwitch data.
        isRebuild (bool):  
        If True, the method handles rebuild logic; otherwise, it processes initial setup logic.
        '''
        if not data:
            return

        componentsManager = self.metaParent().componentsManager
        guideLayer = self.metaParent().guideLayer

        for spaceData in data:
            if spaceData['isParent']:
                index = attrUtils.findEmptyIndex(f'{self.nodeName}.spaceSwitchTargets', 'targetGuideNode')
                basePath = f'{self.nodeName}.spaceSwitchTargets[{index}]'
                cmds.setAttr(f'{basePath}.attrName', spaceData['attrName'], type='string')
                cmds.setAttr(f'{basePath}.isParent', True)
                drivenGuideTag = spaceData['drivenGuideTag']
                cmds.setAttr(f'{basePath}.drivenGuideTag', drivenGuideTag, type='string')
                
                drivenGuideNode = guideLayer.guideNodeFromTag(drivenGuideTag)
                cmds.connectAttr(f'{drivenGuideNode.nodeName}.message', f'{basePath}.targetGuideNode', f=True)
                cmds.connectAttr(f'{drivenGuideNode.nodeName}.message', f'{basePath}.drivenGuideNode', f=True)
                
            else:
                targetComponent = None
                if not isRebuild:
                    '''
                    Determine the targetComponent based on duplication scenarios.
                    There are three cases for determining the targetComponent:
                    1. If targetComponentBaseName is '__SELF__COMPONENT__', it originates from its own guide.
                       Retrieve the correct target by querying the guideTag.
                    2. If the targetComponent is part of a duplicated component, 
                       retrieve the target using cached metaId data to map the new componentNodeName.
                    3. If the targetComponent is not part of the duplication process, 
                       directly query the target using the metaId.
                    '''
                    if spaceData['targetComponentBaseName'] == '__SELF__COMPONENT__':
                        targetComponent = self.metaParent()
                    else:
                        targetComponent = (componentsManager.componentFromNodeName(spaceData['targetComponentNodeName'])
                                           or componentsManager.componentFromMetaId(spaceData['targetComponentMetaId']))
                else:
                    '''
                    During rebuild, use metaId directly to retrieve the targetComponent.
                    '''
                    targetComponent = componentsManager.componentFromMetaId(spaceData['targetComponentMetaId'])

                if targetComponent is None:
                    if not isRebuild:
                        raise ValueError(
                            f"Target component not found. BaseName: {spaceData['targetComponentBaseName']}, "
                            f"NodeName: {spaceData['targetComponentNodeName']}, MetaId: {spaceData['targetComponentMetaId']}"
                        )
                    else:
                        '''
                        Skip if targetComponent is not found during rebuild!
                        '''
                        continue
                
                index = attrUtils.findEmptyIndex(f'{self.nodeName}.spaceSwitchTargets', 'targetGuideNode')
                basePath = f'{self.nodeName}.spaceSwitchTargets[{index}]'

                cmds.setAttr(f'{basePath}.useTranslate', spaceData['useTranslate'])
                cmds.setAttr(f'{basePath}.useRotate', spaceData['useRotate'])
                cmds.setAttr(f'{basePath}.useScale', spaceData['useScale'])
                cmds.setAttr(f'{basePath}.useShear', spaceData['useShear'])
                cmds.setAttr(f'{basePath}.attrName', spaceData['attrName'], type='string')
                        
                targetGuideTag = spaceData['targetGuideTag']
                drivenGuideTag = spaceData['drivenGuideTag']
                cmds.setAttr(f'{basePath}.targetComponentBaseName', targetComponent.baseName, type='string')
                cmds.setAttr(f'{basePath}.targetComponentMetaId', targetComponent.metaId, type='string')
                cmds.setAttr(f'{basePath}.targetGuideTag', targetGuideTag, type='string')
                cmds.setAttr(f'{basePath}.drivenGuideTag', drivenGuideTag, type='string')

                targetGuideNode = targetComponent.guideLayer.guideNodeFromTag(targetGuideTag)
                drivenGuideNode = guideLayer.guideNodeFromTag(drivenGuideTag)
                cmds.connectAttr(f'{targetGuideNode.nodeName}.message', f'{basePath}.targetGuideNode', f=True)
                cmds.connectAttr(f'{drivenGuideNode.nodeName}.message', f'{basePath}.drivenGuideNode', f=True)


    def setDuplicateSpaceSiwtchData(self, data:list=None):
        '''
        In the case of duplication, the process can be more complex due to the creation of new components. 
        If the spaceSwitch's targetComponent is part of a newly created component,
        we need to dynamically determine the target. There are three possible scenarios
        For more details, refer to '_processSpaceSwitchData_'.
        '''
        self._processSpaceSwitchData_(data, isRebuild=False)


    def rebuildConnectSpaceSwitchData(self, data:list=None):
        '''
        If it is during the rebuild phase
        the connections between metaNodes will be preserved, and the metaId will be used directly to retrieve the correct targetComponent.
        '''
        # From build to rebuild, we need to first clear all current spaceSwitch attributes because we will rebuild them based on the data.
        self.updateSpaceSwitchInfo()
        self._processSpaceSwitchData_(data, isRebuild=True)
        
        
    def getDuplicateControlShapesData(self) -> 'list[dict]':
        shapesDataList = []
        basePath = f'{self.nodeName}.controlNodes'
        for attrIndex in range((cmds.getAttr(basePath, mi=True) or [0])[-1] + 1):
            controlTag = cmds.getAttr(f'{basePath}{[attrIndex]}.controlTag')
            controlShapeData = cmds.getAttr(f'{basePath}{[attrIndex]}.controlShapeData')
            if not controlTag or not controlShapeData:
                continue
            shapesData = {}
            shapesData['controlTag'] = controlTag
            shapesData['controlShapeData'] = controlShapeData
            shapesDataList.append(shapesData)
        return shapesDataList
        
        
    def setDuplicateControlShapesData(self, data:'list[dict]'):
        if not data:
            return
        basePath = f'{self.nodeName}.controlNodes'
        
        for attrIndex, shapeData in enumerate(data):
            cmds.setAttr(f'{basePath}{[attrIndex]}.controlTag', shapeData['controlTag'], type='string')
            cmds.setAttr(f'{basePath}{[attrIndex]}.controlShapeData', shapeData['controlShapeData'], type='string')
        

      
if __name__ == '__main__':
    i = RigLayer.create('Gode_M_rig_meta')
    #i.getSpaceSwitchData()
    #i.addSpaceSwitch(root, 'parent', True, True, True, True)
    #i.deleteSpaceSwitch(root)
