from maya import cmds
from maya.api import OpenMaya as om2
from collections import OrderedDict

from linkRigger.core import meta
from linkRigger.core import nodes

from linkRigger.utils import attrUtils
from linkRigger.utils import nameUtils
from linkRigger.utils import nodeUtils


class DeformLayer(meta.MetaNode):
    
    @classmethod
    def setupDeformLayer(cls, instance=None, parent=None):
        baseName = instance.nodeName.rsplit(f'_meta', 1)[0]
        attrUtils.addAttr(instance.nodeName, 'extraNodes', type='message', multi=True)  
        attrUtils.addAttr(instance.nodeName, 'deformGroup', type='message')
        # add joints attr
        attrUtils.addAttr(instance.nodeName, 'jointNodes', type='compound', multi=True, nc=2)
        attrUtils.addAttr(instance.nodeName, 'jointNode', type='message', parent='jointNodes')
        attrUtils.addAttr(instance.nodeName, 'jointTag', type='string', parent='jointNodes')
        
        # add grps                      
        deformGroup = nodeUtils.createNode('transform', nameUtils.uniqNameSuffix(baseName, '_hrc'), True, False)
        cmds.setAttr(f'{deformGroup}.visibility', False)
        # connect
        cmds.connectAttr(f'{deformGroup}.message', f'{instance.nodeName}.deformGroup')
        # connect metaNode
        if parent is not None:
            instance.addMetaParent(parent)
            cmds.parent(deformGroup, parent.componentGroup)

        
    @classmethod    
    def create(cls, nodeName:str='', 
                    metaId:'uuid'='',
                    parent:'MetaNode'=None):
        instance = super().create(nodeName, metaId)
        cls.setupDeformLayer(instance, parent)
        return instance
        
    @property
    def deformGroup(self) -> str:
        return cmds.listConnections(f'{self.nodeName}.deformGroup', d=False, s=True)[0]
       
       
    def getAllNodes(self, 
                    includeGroup=True, 
                    includejoints=True
                    ) -> 'list[str]':
        '''
        Returns a list of all related nodes, including group and joint nodes if specified.

        NOTE:
        Normally, `includejoints` is set to False only during a rebuild, 
        as the current design does not delete skin joints.
        '''
        allNodes = []
        if includeGroup:
            allNodes.append(self.deformGroup)
       
        
        for joint in self.listJointNodes(): # add constr nodes
            allNodes.extend(joint.listExtraNodes())
            if includejoints:
                allNodes.append(joint.nodeName)

        return list(set(allNodes))
        
    
    def addJointNodeToMeta(self, jointInstance:'Joint'=None, jointTag=None):
        '''
        Add joints to the meta node, with support for checking joints with the same tag — skip them if they already exist.
        '''
        if jointTag in self.listJointTags():
            index = attrUtils.getIndexByTag(f'{self.nodeName}.jointNodes', 'jointTag', jointTag)
        else:
            index = attrUtils.findEmptyIndex(f'{self.nodeName}.jointNodes', 'jointNode', d=False, s=True) # get new index
        basePath = f'{self.nodeName}.jointNodes[{index}]'
        
        if not cmds.isConnected(f'{jointInstance.nodeName}.message', f'{basePath}.jointNode'):
            cmds.connectAttr(f'{jointInstance.nodeName}.message', f'{basePath}.jointNode', f=True)
            cmds.setAttr(f'{basePath}.jointTag', jointTag or jointInstance.jointTag, type='string')
        
    '''
    def updateJointFromTag(self, jointInstance:'Joint'=None, jointTag:str=None):
        index = attrUtils.getIndexByTag(f'{self.nodeName}.jointNodes', 'jointTag', jointTag)
        if index == -1:
            return
        cmds.connectAttr(f'{jointInstance.nodeName}.message', f'{self.nodeName}.jointNodes[{index}].jointNode', f=True)
    '''        
          
            
    def listJointNodes(self, unique:bool=False) -> 'list[Joint]':
        '''
        Get a list of connected joint nodes, with optional duplicate filtering
        '''
        jointNodes =  [nodes.JointNode(joint) 
                       for joint in attrUtils.getConnectedNodes(f'{self.nodeName}.jointNodes', 'jointNode')]
        if unique:
            uniqueJoints = OrderedDict((node.nodeName, node) for node in jointNodes)
            return list(uniqueJoints.values())
        else:
            return jointNodes
    
    
    def listJointTags(self) -> 'list[str]':
        '''
        Return the joint tags stored in the deform layer node
        '''
        tags = []
        basePath = f'{self.nodeName}.jointNodes'
        for index in range((cmds.getAttr(basePath, mi=True) or [0])[-1] + 1):
            tag = cmds.getAttr(f'{basePath}[{index}].jointTag')
            if tag:
                tags.append(tag)
        return tags

        
    def jointNodeFromTag(self, tag:str) -> 'JointNode|None':
        '''
        Get joints by tag
        '''
        node:str = attrUtils.getNodeByTag(f'{self.nodeName}.jointNodes', 'jointNode', 'jointTag', tag)
        return nodes.JointNode(node) if node else None
        
        
    def deleteJointFromTag(self, tag:str) -> bool:
        '''
        Delete joints by tag and the corresponding multiple attributes stored on the node
        '''
        jointNode = self.jointNodeFromTag(tag)
        if jointNode is None:
            return False
            
        cmds.delete(jointNode.nodeName)
        basePath = f'{self.nodeName}.jointNodes'
        index    = attrUtils.getIndexByTag(basePath, 'jointTag', tag)
        cmds.removeMultiInstance(f'{basePath}[{index}]', b=True)  
        return True
        
        
    def setJointMirrorLabel(self) -> bool:
        '''
        Set a custom mirror label for the joint nodes to facilitate mirrored skinning
        '''
        joints:list = self.listJointNodes(unique=True)
        if not joints:
            return False
            
        component = self.metaParent()
        side:str = component.side
        name:str = component.name
        baseName:str = component.baseName
        
        if side[0].upper() == 'R':
            sideIndex = 2
        elif side[0].upper() == 'L':
            sideIndex = 1
        elif side[0].upper() in ('C', 'M'):
            sideIndex = 0
        else:
            om2.MGlobal.displayWarning("Invalid side designation. -> f'{side}'")
            return False
        # set label    
        for joint in joints:
            longName    = joint.nodeName
            mirrorLabel = joint.shortName.replace(f'{baseName}', f'{name}')
            cmds.setAttr(f'{longName}.side', sideIndex)
            cmds.setAttr(f'{longName}.type', 18)
            cmds.setAttr(f'{longName}.otherType', mirrorLabel, type='string')

        return True
        
        
    def clearJointMirrorLabel(self) -> bool:
        '''
        clear the custom mirror label from the joint nodes
        '''
        joints:list = self.listJointNodes(unique=True)
        if not joints:
            return False
        for joint in joints:
            longName = joint.nodeName
            cmds.setAttr(f'{longName}.side', 3)
            cmds.setAttr(f'{longName}.type', 18)
            cmds.setAttr(f'{longName}.otherType', '', type='string')
            cmds.setAttr(f'{longName}.type', 0)
            cmds.setAttr(f'{longName}.drawLabel', 0)
        return True
        
        
        
        
 
        
if __name__ == '__main__':
    i = DeformLayer.create('Gode_M_deform_meta')
    i.getAllNodes()
    
    # ch = meta.listSceneMetaNodes(ofType='CharacterManager')[0]
    # componentNodes = ch.componentsManager.listComponentNodes()
    
    # cmds.select(componentNodes[3].deformLayer.getAllNodes(includeGroup=False, includejoints=False))
                
                