from maya import cmds
from linkRigger.core import meta
from linkRigger.core import nodes

from linkRigger.utils import attrUtils
from linkRigger.utils import nameUtils
from linkRigger.utils import nodeUtils


class OutputLayer(meta.MetaNode):
    
    @classmethod
    def setupOutputLayer(cls, instance=None, parent=None):
        baseName = instance.nodeName.rsplit(f'_meta', 1)[0]
        attrUtils.addAttr(instance.nodeName, 'extraNodes', type='message', multi=True) 
        attrUtils.addAttr(instance.nodeName, 'outputGroup', type='message')
        # output attr
        attrUtils.addAttr(instance.nodeName, 'outputNodes', type='compound', multi=True, nc=2)
        attrUtils.addAttr(instance.nodeName, 'outputNode', type='message', parent='outputNodes')
        attrUtils.addAttr(instance.nodeName, 'outputTag', type='string', parent='outputNodes')
        
        # add grps                      
        outputGroup = nodeUtils.createNode('transform', nameUtils.uniqNameSuffix(baseName, '_hrc'), True, False)
        cmds.setAttr(f'{outputGroup}.visibility', False)
        # connect
        cmds.connectAttr(f'{outputGroup}.message', f'{instance.nodeName}.outputGroup')
        # connect metaNode
        if parent is not None:
            instance.addMetaParent(parent)
            cmds.parent(outputGroup, parent.componentGroup)
            
        
    @classmethod    
    def create(cls, nodeName:str='', 
                    metaId:'uuid'='',
                    parent:'MetaNode'=None):
        instance = super().create(nodeName, metaId)
        cls.setupOutputLayer(instance, parent)
        return instance
        
        
    @property
    def outputGroup(self) -> str:
        return cmds.listConnections(f'{self.nodeName}.outputGroup', d=False, s=True)[0]
        
       
    def getAllNodes(self, includeGroup=True) -> 'list[str]':
        allNodes = []
        if includeGroup:
            allNodes.append(self.outputGroup)
            
        nodes:'list[str]' = attrUtils.getConnectedNodes(f'{self.nodeName}.outputNodes', 'outputNode')
        allNodes.extend(nodes)
        allNodes.extend(
            multMatrix
            for node in nodes
            for multMatrix in cmds.listConnections(f'{node}.extraNodes', d=False, s=True) or []
        )
        return list(set(allNodes))
        
        
    def addOutputNodestoMeta(self, outputInstance:'OutputNode'=None):
        newIndex = attrUtils.findEmptyIndex(f'{self.nodeName}.outputNodes', 'outputNode', d=False, s=True) # get index
        basePath = f'{self.nodeName}.outputNodes[{newIndex}]'
        
        cmds.connectAttr(f'{outputInstance.nodeName}.message', f'{basePath}.outputNode')
        cmds.setAttr(f'{basePath}.outputTag', outputInstance.outputTag, type='string')
        
        
    def listOutputNodes(self) -> 'list[OutputNode]':
        return [nodes.OutputNode(outputNode) for outputNode in attrUtils.getConnectedNodes(f'{self.nodeName}.outputNodes', 'outputNode')]
        
        
    def outputNodeFromTag(self, tag:str) -> 'OutputNode':
        node = attrUtils.getNodeByTag(f'{self.nodeName}.outputNodes', 'outputNode', 'outputTag', tag)
        if node is None:
            raise ValueError(f"No OutputNode with tag '{tag}' found on '{self.nodeName}'.")
        return nodes.OutputNode(node)
        
        
if __name__ == '__main__':
    o = OutputLayer.create('Gode_M_output_meta')
    o.getAllNodes()
                