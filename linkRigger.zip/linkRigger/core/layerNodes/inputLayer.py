from maya import cmds
from linkRigger.core import meta
from linkRigger.core import nodes

from linkRigger.utils import attrUtils
from linkRigger.utils import nameUtils
from linkRigger.utils import nodeUtils


class InputLayer(meta.MetaNode):
    
    @classmethod
    def setupInputLayer(cls, instance=None, parent=None):
        baseName = instance.nodeName.rsplit(f'_meta', 1)[0]
        attrUtils.addAttr(instance.nodeName, 'extraNodes', type='message', multi=True)  
        attrUtils.addAttr(instance.nodeName, 'inputGroup', type='message')
        
        attrUtils.addAttr(instance.nodeName, 'inputNodes', type='compound', multi=True, nc=3)
        attrUtils.addAttr(instance.nodeName, 'inputNode', type='message', parent='inputNodes')
        attrUtils.addAttr(instance.nodeName, 'inputTag', type='string', parent='inputNodes')
        attrUtils.addAttr(instance.nodeName, 'driveNode', type='message', parent='inputNodes')
        # add grps                      
        inputGroup = nodeUtils.createNode('transform', nameUtils.uniqNameSuffix(baseName, '_hrc'), True, False)
        cmds.setAttr(f'{inputGroup}.visibility', False)
        # connect
        cmds.connectAttr(f'{inputGroup}.message', f'{instance.nodeName}.inputGroup')
        # connect metaNode
        if parent is not None:
            instance.addMetaParent(parent)
            cmds.parent(inputGroup, parent.componentGroup)
            
        
    @classmethod    
    def create(cls, nodeName:str='', 
                    metaId:'uuid'='',
                    parent:'MetaNode'=None):
        instance = super().create(nodeName, metaId)
        cls.setupInputLayer(instance, parent)
        return instance
        
    def addOutputNodestoMeta(self, inputInstance:'InputNode'):
        newIndex = attrUtils.findEmptyIndex(f'{self.nodeName}.inputNodes', 'inputNode', d=False, s=True) # get index
        basePath = f'{self.nodeName}.inputNodes[{newIndex}]'
        
        cmds.connectAttr(f'{inputInstance.nodeName}.message', f'{basePath}.inputNode')
        cmds.setAttr(f'{basePath}.inputTag', inputInstance.inputTag, type='string')
        
        
    @property
    def inputGroup(self) -> str:
        return cmds.listConnections(f'{self.nodeName}.inputGroup', d=False, s=True)[0]
       
       
    def getAllNodes(self, includeGroup=True) -> 'list[str]':
        allNodes = []
        if includeGroup:
            allNodes.append(self.inputGroup)
            
        nodes:'list[str]' = attrUtils.getConnectedNodes(f'{self.nodeName}.inputNodes', 'inputNode')
        # Add connected nodes and their multMatrix nodes
        allNodes.extend(nodes)
        allNodes.extend(
            multMatrix
            for node in nodes
            for multMatrix in cmds.listConnections(f'{node}.extraNodes', d=False, s=True) or []
        )
        return list(set(allNodes))
        
        
    def listInputNodes(self) -> 'list[InputNode]':
        return [nodes.InputNode(inputNode) for inputNode in attrUtils.getConnectedNodes(f'{self.nodeName}.inputNodes', 'inputNode')]
        
        
    def inputNodeFromTag(self, tag:str) -> 'InputNode':
        node = attrUtils.getNodeByTag(f'{self.nodeName}.inputNodes', 'inputNode', 'inputTag', tag)
        if node is None:
            raise ValueError(f"No InputNode with tag '{tag}' found on '{self.nodeName}'.")
        return nodes.InputNode(node)
        
    
        
if __name__ == '__main__':
    i = InputLayer.create('Gode_M_input_meta')
