from maya import cmds
from maya.api import OpenMaya as om2
from linkRigger.core import meta
from linkRigger.utils import attrUtils
from linkRigger.utils import nameUtils
from linkRigger.utils import nodeUtils

from linkRigger.core.managerNodes import ComponentsManager
from linkRigger.core.managerNodes import DeformManager
from linkRigger.core.managerNodes import GeoManager



class CharacterManager(meta.MetaNode):
    
    @classmethod
    def setupCharacterManager(cls, instance):
        name = instance.nodeName.rsplit('_meta', 1)[0]
        attrUtils.addAttr(instance.nodeName, 'name', type='string', value=name)
        attrUtils.addAttr(instance.nodeName, 'hasRebuild', type='bool', value=True)
        attrUtils.addAttr(instance.nodeName, 'hasBinding', type='bool')
        attrUtils.addAttr(instance.nodeName, 'hasBuild', type='bool')
        attrUtils.addAttr(instance.nodeName, 'characterGroup', type='message')
   
        characterGroup  = nodeUtils.createNode('transform', nameUtils.uniqNameSuffix(name, '_hrc'), True, False)
        cmds.connectAttr(f'{characterGroup}.message', f'{instance.nodeName}.characterGroup')

        
    @classmethod    
    def create(cls, nodeName:str='',
                    metaId:'uuid'=''):
        nodeName = nameUtils.uniqNameSuffix(nodeName or 'LinkRig', '_meta')
        instance = super().create(nodeName, metaId)
        cls.setupCharacterManager(instance)
        
        # add children
        name = instance.name   
        ComponentsManager.create(nodeName=nameUtils.uniqNameSuffix(name, '_componentsManager_meta'), parent=instance)
        DeformManager.create(nodeName=nameUtils.uniqNameSuffix(name, '_deformManager_meta'), parent=instance)
        GeoManager.create(nodeName=nameUtils.uniqNameSuffix(name, '_geoManager_meta'), parent=instance)
        return instance
    
    
    @property
    def name(self):
        return cmds.getAttr(f'{self.nodeName}.name')    
        
       
    @property
    def componentsManager(self) -> ComponentsManager:
        return self.metaChildren(ofType='ComponentsManager')[0]
        
        
    @property
    def deformManager(self) -> DeformManager:
        return self.metaChildren(ofType='DeformManager')[0]
        
        
    @property
    def geoManager(self) -> GeoManager:
        return self.metaChildren(ofType='GeoManager')[0]
    

    @property
    def characterGroup(self) -> str:
        return cmds.listConnections(f'{self.nodeName}.characterGroup', d=False, s=True)[0]
                
            
    @property
    def hasRebuild(self) -> bool:
        return cmds.getAttr(f'{self.nodeName}.hasRebuild')
        
        
    @hasRebuild.setter
    def hasRebuild(self, value:bool):
        attrUtils.setAttr(f'{self.nodeName}.hasRebuild', value)
        attrUtils.setAttr(f'{self.nodeName}.hasBuild', not value)
        
        
    @property
    def hasBuild(self) -> bool:
        return cmds.getAttr(f'{self.nodeName}.hasBuild')
        
        
    @hasBuild.setter
    def hasBuild(self, value:bool):
        self.hasRebuild = not value
        
    
    @property
    def hasBinding(self) -> bool:
        return cmds.getAttr(f'{self.nodeName}.hasBinding')
        
    @hasBinding.setter
    def hasBinding(self, value:bool):
        attrUtils.setAttr(f'{self.nodeName}.hasBinding', value)
        
        
    def rebuild(self) -> bool:
        self.deformManager.hideDeformGroup()
        self.componentsManager.showcomponentsGroup()
        self.hasBinding = False
        if self.hasRebuild:
            return False
        
        self.componentsManager.rebuild()
        self.hasRebuild = True
        
        return True
        
        
    
    def build(self) -> bool: 
        self.hasBinding = False
        if self.hasBuild:
            return False
        
        self.componentsManager.build()
        self.hasBuild = True
        
        self.deformManager.hideDeformGroup()
        self.componentsManager.showcomponentsGroup()
        return True
                
                  
    def delete(self):
        self.componentsManager.delete()
        cmds.delete(self.getAllNodes())
        
        
    def binding(self) -> bool:
        if self.hasBuild or self.hasBinding:
            return False
        self.componentsManager.binding()
        self.hasBinding = True
        cmds.select(cl=True)
        self.deformManager.showDeformGroup()
        self.componentsManager.hidecomponentsGroup()
        return True
        
           
    def setName(self, name:str):
        oldName = self.name # cache old meta name
        if not name or name == oldName:
            return 

        newNodeName = nameUtils.uniqNameSuffix(name, f'_meta')
        newName = newNodeName.rsplit(f'_meta', 1)[0]

        attrUtils.setAttr(f'{self.nodeName}.name', newName, type='string') # update name
        nameUtils.rename(self.nodeName, newNodeName) # update nodeName
        # update component nodesName
        for node in self.getAllNodes():
            nameUtils.rename(node, nameUtils.uniqNameSuffix(newName, node.replace(oldName, '')))
        
        
    def getAllNodes(self) -> 'list[str]':
        nodes = list(set(cmds.listConnections(f'{self.nodeName}', d=False, s=True) or []))
        nodes.extend(self.componentsManager.getAllNodes())
        nodes.extend(self.deformManager.getAllNodes())
        nodes.extend(self.geoManager.getAllNodes())
        return nodes
            
        


if __name__ == '__main__':
    c = CharacterManager.create()
    #c.hasBuild
    #c.setName('sb')
    # c.setName('sbwca')
    # c.rebuild()

    




    
    


    

    
