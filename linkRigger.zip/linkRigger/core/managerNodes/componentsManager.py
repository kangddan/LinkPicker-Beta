import json
from maya import cmds
from maya.api import OpenMaya as om2

from linkRigger.core import meta
from linkRigger.utils import attrUtils
from linkRigger.utils import nameUtils
from linkRigger.utils import nodeUtils
from linkRigger.rig   import skin


class ComponentsManager(meta.MetaNode):
    
    def __getattr__(self, attr:str) -> 'Component | None':
        component = self.componentFromNodeName(f'{attr}_meta')
        if component:
            return component
        raise AttributeError(f"Component '{attr}' not found in ComponentsManager.")
        
    
    def __getitem__(self, attr):
        if attr not in self.__dict__:
            return self.__getattr__(attr)
        return self.__dict__.get(attr)
    
    
    @classmethod
    def setupComponentsManager(cls, instance=None, parent=None):
        # decompos nodeName
        _uprName = parent.nodeName.rsplit(f'_meta', 1)[0]
        
        attrUtils.addAttr(instance.nodeName, 'componentsGroup', type='message')
        componentsGroup = nodeUtils.createNode('transform', nameUtils.uniqNameSuffix(_uprName, '_component_hrc'), True, False)
        cmds.connectAttr(f'{componentsGroup}.message', f'{instance.nodeName}.componentsGroup')
        
        # add script attr
        attrUtils.addAttr(instance.nodeName, 'postScript', type='string')
        
        # to parent
        instance.addMetaParent(parent)
        cmds.parent(componentsGroup, parent.characterGroup)


    @classmethod    
    def create(cls, nodeName:str='', 
                    metaId:'uuid'='', 
                    parent:'MetaNode'=None):
        instance = super().create(nodeName, metaId)
        cls.setupComponentsManager(instance, parent)
        return instance
        
        
    @property
    def postScript(self) -> 'list[dict]':
        data = cmds.getAttr(f'{self.nodeName}.postScript') or '[]'
        return json.loads(data)
        
        
    @postScript.setter
    def postScript(self, data:list):
        cmds.setAttr(f'{self.nodeName}.postScript', json.dumps(data), type='string')
        
        
    @property
    def componentsGroup(self) -> str:
        return cmds.listConnections(f'{self.nodeName}.componentsGroup', d=False, s=True)[0] 
        
    
    def showcomponentsGroup(self):
        cmds.setAttr(f'{self.componentsGroup}.visibility', True)
        
    def hidecomponentsGroup(self):
        cmds.setAttr(f'{self.componentsGroup}.visibility', False)
        
        
    def listComponentNodes(
                          self, 
                          recursive=True, 
                          ofType=None
                          ) -> 'list[Components]':
        return [node for node in self.metaChildren(recursive, ofType) if hasattr(node, 'isComponent')]
    
        
    def getAllNodes(self) -> list:
        return [self.componentsGroup]
        
        
    def delete(self):
        '''
        The deletion method here retrieves only the direct child components, 
        rather than recursively retrieving all components, 
        as the direct child components will automatically query and delete their own subcomponents.
        '''
        for component in self.listComponentNodes(recursive=False):
            component.delete(includeGroup=True)
            
            
    def binding(self):
        componentNodes = self.listComponentNodes()
        
        # 1 cache skin joints    
        for component in componentNodes:
            component.unJointsToWorld()
            
        for component in componentNodes:
            component.deleteUnusedJoints()
            
        # 2 create joints    
        for component in componentNodes:
            component.setupBuild()
            
        for component in componentNodes:
            component._parentJoint_()
        
        # 3 setBindPos    
        self.setBindPos()
        
        
    def build(self):
        componentNodes = self.listComponentNodes()
        
        # 0 cache data
        for component in componentNodes:
            component.cacheComponentData()
        
        # 1 cache skin joints    
        for component in componentNodes:
            component.unJointsToWorld()
                  
        for component in componentNodes:
            component.deleteUnusedJoints()
            
        # 2 create joints    
        for component in componentNodes:
            component.setupBuild()
            
        # 3 create rig
        for component in componentNodes:
            component.build()
            
        # 4 link component and set space switch
        for component in componentNodes:
            component.seaming()
            
        # 5 delete guides    
        for component in componentNodes:
            component.deleteGuides()
            
        # 6 setBindPos
        self.setBindPos()
            
        # 7 run post script
        self.runPostScripts()
        
        
        cmds.select(cl=True)
        
        
    def rebuild(self):
        '''
        The purpose of reversing the list is to delete from the child components first, 
        avoiding the scenario where deleting the parent component automatically deletes its child components. 
        This ensures that we can properly record the controller shapes of the child components.
        '''
        componentNodes = self.listComponentNodes()
        # Filter components created after the rig stage
        componentNodes = [componentNode for componentNode in componentNodes if componentNode.hasBuild]
        componentNodes.reverse()
        
        for component in componentNodes:
            component.rebuild()
            
        for component in componentNodes:
            component.postRebuild()
            
        cmds.select(cl=True)
        
        
    def runPostScripts(self):
        scripts = self.postScript
        
        for script in scripts:
            name, code = next(iter(script.items()))
            try:
                scope = {}
                exec(code, scope)
                mainFunc = scope.get('main')
                if callable(mainFunc):
                    cmds.evalDeferred(mainFunc) 
                else:
                    om2.MGlobal.displayWarning(f"script '{name}' has no main() function.")
            except Exception as e:
                om2.MGlobal.displayWarning(f"Error executing script '{name}': {e}")
                

    
    def setBindPos(self) -> None:
        joints = self.metaParent().deformManager.getAllSkinJoints()
        skinClusters = skin.getSkinClusters(joints)
        if skinClusters:
            skin.setBindPose(skinClusters)
    
    
    def componentFromName(self, newName:str) -> 'Component|None':
        for component in self.listComponentNodes():
            if component.name == newName:
                return component
                
    
    def componentFromNodeName(self, newNodeName:str) -> 'Component|None':
        for component in self.listComponentNodes():
            if component.nodeName == newNodeName:
                return component
                
                
    def componentFromMetaId(self, metaId:str) -> 'Component|None':
        for component in self.listComponentNodes():
            if component.metaId == metaId:
                return component
    
    

if __name__ == '__main__':
    c = ComponentsManager.create('test')
    c.listComponentNodes()
    