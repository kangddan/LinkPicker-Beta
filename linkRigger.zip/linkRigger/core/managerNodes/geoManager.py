from maya import cmds
from maya.api import OpenMaya as om2
from linkRigger.core import meta
from linkRigger.utils import attrUtils
from linkRigger.utils import nameUtils
from linkRigger.utils import nodeUtils


class GeoManager(meta.MetaNode):
    
    @classmethod
    def setupGeoManager(cls, instance=None, parent=None):
        # decompos nodeName
        _uprName = parent.nodeName.rsplit(f'_meta', 1)[0]
        
        attrUtils.addAttr(instance.nodeName, 'geoGroup', type='message')
        geoGroup = nodeUtils.createNode('transform', nameUtils.uniqNameSuffix(_uprName, '_geo_hrc'), True, False)
        cmds.connectAttr(f'{geoGroup}.message', f'{instance.nodeName}.geoGroup')
        
        # to parent
        instance.addMetaParent(parent)
        cmds.parent(geoGroup, parent.characterGroup)


    @classmethod    
    def create(cls, nodeName:str='', 
                    metaId:'uuid'='',
                    parent:'MetaNode'=None):
        instance = super().create(nodeName, metaId)
        cls.setupGeoManager(instance, parent)
        return instance
        
        
    @property
    def geoGroup(self) -> str:
        return cmds.listConnections(f'{self.nodeName}.geoGroup', d=False, s=True)[0]
        
        
        
    def getAllNodes(self) -> list:
        return [self.geoGroup]
    
    

if __name__ == '__main__':
    c = ComponentsManager.create('test')

    