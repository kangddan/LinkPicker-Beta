from maya import cmds
from maya.api import OpenMaya as om2
from linkRigger.core import meta
from linkRigger.utils import attrUtils
from linkRigger.utils import nameUtils
from linkRigger.utils import nodeUtils


class DeformManager(meta.MetaNode):
    
    @classmethod
    def setupDeformManager(cls, instance=None, parent=None):
        # decompos nodeName
        _uprName = parent.nodeName.rsplit(f'_meta', 1)[0]
        
        attrUtils.addAttr(instance.nodeName, 'deformGroup', type='message')
        attrUtils.addAttr(instance.nodeName, 'localAxisVis', type='bool', value=False)
        
        deformGroup = nodeUtils.createNode('transform', nameUtils.uniqNameSuffix(_uprName, '_deform_hrc'), True, False)
        cmds.setAttr(f'{deformGroup}.visibility', False)
        cmds.connectAttr(f'{deformGroup}.message', f'{instance.nodeName}.deformGroup')
        
        # to parent
        instance.addMetaParent(parent)
        cmds.parent(deformGroup, parent.characterGroup)


    @classmethod    
    def create(cls, nodeName:str='', 
                    metaId:'uuid'='', 
                    parent:'MetaNode'=None):
        instance = super().create(nodeName, metaId)
        cls.setupDeformManager(instance, parent)
        return instance
        
        
    @property
    def deformGroup(self) -> str:
        return cmds.listConnections(f'{self.nodeName}.deformGroup', d=False, s=True)[0] 
    
    @property
    def deformGroupVis(self) -> bool:
        return cmds.getAttr(f'{self.deformGroup}.visibility')
        
    @deformGroupVis.setter
    def deformGroupVis(self, value:bool):
        cmds.setAttr(f'{self.deformGroup}.visibility', value)
        
    def showDeformGroup(self):
        self.deformGroupVis = True
        
    def hideDeformGroup(self):
        self.deformGroupVis = False
        
     
    def getAllNodes(self) -> list:
        return [self.deformGroup]
        
        
    def getAllSkinJoints(self) -> 'list[str]':
        '''
        get all joints
        '''
        components = self.metaParent().componentsManager.listComponentNodes()
        joints = []
        for component in components:
            _joints = component.deformLayer.listJointNodes(unique=True)
            joints.extend(joint.nodeName for joint in _joints)
        return joints
        
        
    def jointsLocalAxisVis(self, value:bool):
        for joint in self.getAllSkinJoints():
            cmds.setAttr(f'{joint}.displayLocalAxis', value)
    
    
    @property
    def localAxisVis(self) -> bool:
        return cmds.getAttr(f'{self.nodeName}.localAxisVis')
        
        
    @localAxisVis.setter
    def localAxisVis(self, value:bool):
        cmds.setAttr(f'{self.nodeName}.localAxisVis', value)
        self.jointsLocalAxisVis(value)
        
        
    def setMirrorLabels(self) -> None:
        components = self.metaParent().componentsManager.listComponentNodes()
        for component in components:
            component.deformLayer.setJointMirrorLabel()
        
        
    def clearMirrorLabels(self) -> None:
        components = self.metaParent().componentsManager.listComponentNodes()
        for component in components:
            component.deformLayer.clearJointMirrorLabel()
    

if __name__ == '__main__':
    c = DeformManager.create('test')

    