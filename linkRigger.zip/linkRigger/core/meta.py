import uuid
from maya import cmds
from maya.api import OpenMaya as om2
from linkRigger.utils import attrUtils


def iterSceneMetaNodes(ofType=None) -> 'iterator':
    '''
    Get meta nodes from the scene.

    Args:
        ofType (metaClassStr or MetaClass): Meta node type filter. Can be a string or a MetaClass.

    Returns:
        iterator: Yields MetaNode instances.

    Example:
        iterSceneMetaNodes()
        iterSceneMetaNodes(components.FkChanComponent)
        list(iterSceneMetaNodes('FkChanComponent'))
    '''
    for nodeName in cmds.ls(type='network'):
        if not MetaNode.isMetaNode(nodeName):
            continue
        _metaNode = MetaNode(nodeName)
        if ofType is None:
            yield _metaNode
        elif isinstance(ofType, str) and _metaNode.metaClass == ofType:
            yield _metaNode
        elif isinstance(ofType, type) and isinstance(_metaNode, ofType):
            yield _metaNode
            
            
def metaNodeFromMetaId(metaId:str) -> 'MetaNode':
    return next((metaNode for metaNode in iterSceneMetaNodes() if metaNode.metaId == metaId), None)
            
            
def listSceneMetaNodes(ofType=None) -> 'list[MetaNode]':
    '''
    Get a list of meta nodes.

    Args:
        ofType (metaClassStr or MetaClass): Meta node type filter. Can be a string or a MetaClass.

    Returns:
        list: A list of MetaNode instances representing the meta nodes in the scene.

    Example:
        listSceneMetaNodes()
        listSceneMetaNodes(ofType='FkChanComponent')
    '''
    return list(iterSceneMetaNodes(ofType))
    
                                    
class MetaNode(object):
    
    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        return self.nodeName == other.nodeName and self.metaClass == other.metaClass
        
    def __hash__(self):
        return hash((self.nodeName, self.metaClass))
     
     
    def __repr__(self):
        return f'<{self.__class__.__name__} at {hex(id(self))} {self.nodeName or None}>'
               
                       
    def __str__(self):
        return self.nodeName 
        
    
    def __new__(cls, nodeName:str=''):
        if not cls.isMetaNode(nodeName):
            raise TypeError(f'{nodeName} is not a valid meta node.')
            
        metaClassName:str = cmds.getAttr(f'{nodeName}.metaClass')
        
        if metaClassName == cls.__name__:
            '''
            Prevent recursion by directly instantiating the current class
            if the class name matches. No need for dynamic loading.
            '''
            return super().__new__(cls)
            
        from linkRigger import components  
        
        metaClass = getattr(components, metaClassName, None)
        if metaClass is None:
            raise ValueError(f"Class '{metaClassName}' is not registered in the 'components' module.")
        return metaClass(nodeName)

        
    def __init__(self, nodeName:str=''):
        self.node = nodeName
        
        
    @classmethod
    def isMetaNode(cls, nodeName:str) -> bool:
        return cmds.attributeQuery('metaClass', n=nodeName, ex=True)
        
          
    @classmethod
    def create(cls, 
               nodeName:str,
               metaId:'uuid'=''
               ) -> 'MetaNode':
                
        node = cmds.createNode('network', name=nodeName)
        attrUtils.addAttr(node, 'metaClass', type='string', value=cls.__name__)
        attrUtils.addAttr(node, 'metaVersion', type='string', value='1.0.0')
        attrUtils.addAttr(node, 'metaId', type='string', value=metaId or str(uuid.uuid4()))
        attrUtils.addAttr(node, 'metaParent', type='message', multi=True)
        attrUtils.addAttr(node, 'metaChildren', type='message', multi=True)
        return cls(node)
        
        
    @property
    def metaClass(self) -> str:
        return cmds.getAttr(f'{self.nodeName}.metaClass')
        
        
    @property
    def version(self) -> str:
        return cmds.getAttr(f'{self.nodeName}.metaVersion')
        
        
    @property
    def metaId(self) -> str:
        return cmds.getAttr(f'{self.nodeName}.metaId')
        
        
    @metaId.setter    
    def metaId(self, uuid:str=''):
        cmds.setAttr(f'{self.nodeName}.metaId', uuid, type='string')

    
    @property
    def node(self) -> om2.MFnDependencyNode:
        return self._node
          
           
    @node.setter    
    def node(self, nodeName:str):
        self._node = om2.MFnDependencyNode(om2.MGlobal.getSelectionListByName(nodeName).getDependNode(0)) 
           
           
    @property
    def nodeName(self) -> 'str|None':
        nodeName = self.node.name()
        return nodeName if nodeName else None
        
        
    @property
    def uuid(self) -> str:
        return self.node.uuid().asString() if self.nodeName else ''
        
       
    def addMetaParent(self, parent:'MetaNode'):
        '''
        Connect this node to a parent.

        Args:
            parent (MetaNode): The parent MetaNode to connect to.

        Notes:
            - Ensures no duplicate connections are made.

        Example:
            childNode.addMetaParent(parentNode)
        '''
        childs = cmds.listConnections(f'{parent.nodeName}.metaChildren', d=False, s=True) or []
        if self.nodeName in childs:
            return
        attrUtils.connectMultiAttr(f'{self.nodeName}.metaParent', f'{parent.nodeName}.metaChildren')
             
             
    def addMetaChild(self, child:'MetaNode'):
        '''
        Connect this node to a child if not already connected.

        Args:
            child (MetaNode): The child MetaNode to connect to.

        Notes:
            - Ensures no duplicate connections are made.
            - Uses `addMetaParent` to establish the connection.

        Example:
            parentNode.addMetaChild(childNode)
        '''
        childs = cmds.listConnections(f'{self.nodeName}.metaChildren', d=False, s=True) or []
        if child.nodeName in childs:
            return
        child.addMetaParent(self)
        
               
    def removeMetaParent(self, parent:'MetaNode'=None) -> 'self':
        '''
        Remove connection(s) from the metaParent attribute.

        Args:
            parent (MetaNode, optional): The parent MetaNode to remove. If None, all parents are removed.

        Raises:
            ValueError: If the specified parent is not connected.

        Notes:
            - If no `parent` is specified, all parent connections are removed.
            
        Returns:
            MetaNode: self.

        Example:
            node.removeMetaParent(parentNode)
            node.removeMetaParent()  # Removes all parent connections
        '''
        if parent is None:
            self.removeAllMetaParents()
            return
        
        connections = cmds.listConnections(f'{self.nodeName}.metaParent', p=True, d=True, s=False, c=True) or []
        index = next((i for i, item in enumerate(connections) if item.startswith(f'{parent.nodeName}.')), None)
        if index is None:
            raise ValueError(f"Node '{parent.nodeName}' is not a parent of '{self.nodeName}' and cannot be removed.")
        cmds.disconnectAttr(connections[index-1], connections[index])
        return self
          
          
    def removeAllMetaParents(self) -> 'self':
        '''
        Remove all connections from the metaParent attribute.

        Notes:
            - Disconnects all parent connections for the current node.
        
        Returns:
            MetaNode: self.

        Example:
            node.removeAllMetaParents()
        '''
        connections = cmds.listConnections(f'{self.nodeName}.metaParent', p=True, d=True, s=False, c=True) or []
        if not connections:
            return
            
        for i in range(0, len(connections), 2):
            cmds.disconnectAttr(connections[i], connections[i+1])
        return self
        
            
    def iterMetaParents(self, recursive=False, ofType=None, visited=None) -> 'iterator': 
        '''
        Iterate over meta parents of the node, optionally filtering by type.

        Args:
            recursive (bool): If True, fetch all parents recursively.
            ofType (str or MetaClass, optional): Filter for meta nodes of a specific type.
            visited (set): Tracks visited nodes to avoid duplicates (internal use).

        Yields:
            MetaNode: Unique parent MetaNode instances.

        Example:
            list(node.iterMetaParents())
            list(node.iterMetaParents(recursive=True, ofType='Character'))
        '''
        visited = visited or set()
            
        parents = cmds.listConnections(f'{self.nodeName}.metaParent', d=True, s=False) or []
        for parent in parents:
            if not MetaNode.isMetaNode(parent) or parent in visited:
                continue
            visited.add(parent)
            _metaNode = MetaNode(parent)

            if ofType is None or (
                isinstance(ofType, str) and _metaNode.metaClass == ofType) or (
                isinstance(ofType, type) and isinstance(_metaNode, ofType)):
                yield _metaNode
                
            if recursive:
                yield from _metaNode.iterMetaParents(recursive=recursive, ofType=ofType, visited=visited)
        
          
    def metaParents(self, recursive=False, ofType=None) -> 'list[MetaNode]':
        '''
        Get meta parents of the node, optionally filtering by type.

        Args:
            recursive (bool): If True, fetch all parents recursively.
            ofType (metaClassStr or MetaClass, optional): Filter for meta nodes of a specific type.

        Returns:
            list[MetaNode]: A list of unique MetaNode parent instances.

        Example:
            node.metaParents()
            node.metaParents(recursive=True, ofType='Character')
        '''
        return list(self.iterMetaParents(recursive=recursive, ofType=ofType))
        
    
    def metaParent(self) -> 'MetaNode | None':
        '''
        Get the first parent meta node.

        Returns:
            MetaNode: The first parent MetaNode, or None if no parents exist.

        Notes:
            - If the node has multiple parents, only the first parent is returned.
            - For all parents, use `metaParents(recursive=False)`.

        Example:
            node.metaParent()
        '''
        parents = self.metaParents(recursive=False)
        return parents[0] if parents else None
        

    def iterMetaChildren(self, recursive=False, ofType=None, visited=None) -> 'iterator':
        '''
        Iterate over meta children of the node.

        Args:
            recursive (bool): If True, fetch all children recursively.
            ofType (str or MetaClass): Meta node type filter. Can be a string or a MetaClass.
            visited (set): Tracks visited nodes to avoid duplicates (internal use).

        Yields:
            MetaNode: Unique child MetaNode instances.

        Example:
            for child in node.iterMetaChildren():
                print(child)
            for child in node.iterMetaChildren(ofType='FkChanComponent'):
                print(child)
        '''
        visited = visited or set()

        childs = cmds.listConnections(f'{self.nodeName}.metaChildren', d=False, s=True) or []
        for child in childs:
            if not MetaNode.isMetaNode(child) or child in visited:
                continue
            visited.add(child)
            _metaNode = MetaNode(child)

            if ofType is None or (
                isinstance(ofType, str) and _metaNode.metaClass == ofType) or (
                isinstance(ofType, type) and isinstance(_metaNode, ofType)):
                yield _metaNode

            if recursive:
                yield from _metaNode.iterMetaChildren(recursive=recursive, ofType=ofType, visited=visited)
           
                
    def metaChildren(self, recursive=False, ofType=None) -> 'list[MetaNode]':
        '''
        Get a list of child meta nodes.

        Args:
            recursive (bool): If True, fetch all children recursively.
            ofType (metaClassStr or MetaClass): Meta node type filter. Can be a string or a MetaClass.

        Returns:
            list: A list of MetaNode instances representing child nodes.

        Example:
            node.metaChildren()
            node.metaChildren(recursive=True, ofType='FkChanComponent')
        '''
        return list(self.iterMetaChildren(recursive=recursive, ofType=ofType))
        
