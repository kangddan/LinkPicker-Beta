from pprint import pprint
import json

from maya import cmds
from maya.api import OpenMaya as om2

from linkRigger.core import meta
from linkRigger import components
from linkRigger.core.layerNodes import RigLayer


class BuildManager(object):
    
    @classmethod    
    def saveRigAsTemplate(
                          cls, 
                          characterManager:'CharacterManager'=None, 
                          rigName:str=''
                          ) -> dict:
        '''                    
        if characterManager.hasBuild:
            return om2.MGlobal.displayWarning('Please switch to guide mode.')
        '''
            
        components = characterManager.componentsManager.listComponentNodes(recursive=True)
        componentsData = [component.componentData() for component in components]
        rigData = {'rigName'        : rigName or characterManager.name,
                   'componentsData' : componentsData}
        return rigData
          
    @classmethod
    def loadRigFromTemplate(
                            cls, 
                            rigData:dict, 
                            add=True, 
                            characterManager=None
                            ) -> tuple:
        # 0 get CharacterManager                    
        if characterManager and not add:
            characterManager.delete(); characterManager = None    
        if characterManager is None:
            characterManager = components.CharacterManager.create(nodeName=rigData['rigName'])
        if characterManager.hasBuild:
            om2.MGlobal.displayWarning('Please switch to guide mode.')
            return False, ''
        
        components.Component.setData(rigData['componentsData'], characterManager, parentComponent=None)
        return True, characterManager.node.uuid().asString()
        
        
        
        
        
if __name__ == '__main__':
    character = meta.listSceneMetaNodes(ofType=components.CharacterManager)[1]
    om2.MFnDependencyNode(character.componentsManager.listComponentNodes()[0].listGuideNodes()[0].node.node()).uuid().asString()
    rigData = BuildManager.saveRigAsTemplate(character)
    #rigData2 = BuildManager.saveRigAsTemplate(character)

    BuildManager.loadRigFromTemplate(rigData, False, None)
    
    #len(cmds.ls())
    character.build()
    character.rebuild()
    #pprint(rigData)
    #character[0].setName('kdd')
    #character.componentsManager.listComponentNodes()[1].duplicate()
  
        

        