from maya import cmds
from maya.api import OpenMaya as om2
from linkRigger import components

from linkRigger.utils import attrUtils, nodeUtils

from linkRigger.core import nodes
from linkRigger.rig  import jointBinding


class FkChain(components.Component):
        
    @classmethod
    def _setupAttrs_(cls, instance):
        attrUtils.addAttr(instance.nodeName, 'jointCount',  type='long', value=3, min=1)
        
            
    @classmethod
    def _setupGuides_(cls, instance):
        baseName   = instance.baseName
        guideLayer = instance.guideLayer
        
        rootGuide = nodes.GuideNode.createRootGuide(baseName, 1, guideLayer)   
        
        fk01Guide = nodes.GuideNode.createBaseGuide(baseName, 'fk01', 0.5, rootGuide, guideLayer, True)
        fk02Guide = nodes.GuideNode.createBaseGuide(baseName, 'fk02', 0.5, fk01Guide, guideLayer, True)
        fk03Guide = nodes.GuideNode.createBaseGuide(baseName, 'fk03', 0.5, fk02Guide, guideLayer, True)
        rootGuide.select()
        #move
        cmds.setAttr(f'{fk02Guide.nodeName}.tx', 3)
        cmds.setAttr(f'{fk03Guide.nodeName}.tx', 3)
        # update jointCount
        instance.jointCount = 3
    
    
    def updateParentGuide(self, parentMap:dict):
        guideLayer = self.guideLayer
        guideNodes = self.listGuideNodes(False)
        
        guideNodesTagMap = {guide.guideTag: guide for guide in guideNodes}

        for tag, guide in guideNodesTagMap.items():
            guideParentTag = parentMap.get(tag)
            if guideParentTag:
                parentGuide    = guideNodesTagMap[guideParentTag]
                parentGuideTag = parentGuide.guideTag
                
                guideGroup = guide.groupFromGuideLayer or guide.nodeName
                parent = cmds.listRelatives(guideGroup, parent=True, path=True)
                if parent and cmds.attributeQuery('guideTag', n=parent[0], ex=True) and cmds.getAttr(f'{parent[0]}.guideTag') == parentGuideTag:
                    continue   
                cmds.matchTransform(guideGroup, parentGuide.nodeName)
                guideLayer.updateGuideParent(guide, parentGuide)
        
    
    def __addGuide__(self, baseName:str, 
                           index:int,
                           parentGuide:'GuideNode',
                           guideLayer:'GuideLayer') -> 'GuideNode':
        index += 1                    
        nweGuide = nodes.GuideNode.createBaseGuide(baseName, f'fk{index:02}', 0.5, parentGuide, guideLayer, True)
        guideGroup = nweGuide.groupFromGuideLayer
        if guideGroup: cmds.matchTransform(guideGroup, parentGuide)
        # set matrix
        cacheLocalMatrix = nweGuide.localMatrixFromGuideLayer
        if cacheLocalMatrix == list(om2.MMatrix()):
            cmds.xform(f'{nweGuide.nodeName}', m=parentGuide.localMatrixFromGuideLayer, ws=False)
        else:
            cmds.xform(f'{nweGuide.nodeName}', m=cacheLocalMatrix, ws=False)
        return nweGuide
        
        
    def __subGuide__(self, guides: 'list[GuideNode]', 
                        value: int, 
                        guideLayer:'GuideLayer'):
                            
        excessCount = len(guides) - value
        if excessCount <= 0:
            return

        for i in range(excessCount):
            guide = guides.pop()  
            guideLayer.deleteGuide(guide)
        guides[-1].select()
   
    
    @property
    def jointCount(self) -> int:
        return cmds.getAttr(f'{self.nodeName}.jointCount')
        
    @jointCount.setter
    def jointCount(self, value:int):
        cmds.setAttr(f'{self.nodeName}.jointCount', value)
        
        
    def setJointCount(self, value:int) -> bool:
        if value < 1 or value == self.jointCount: 
            return False

        # 0 update metaAttr
        self.jointCount = value
        
        # 1 update localMatrix
        baseName, guideLayer = self.baseName, self.guideLayer
        guideLayer.updateGuidesLocalMatrix()
        guides = guideLayer.listGuideNodes(includeRoot=False)
        guidesCount = len(guides)
        
        # add guide
        if value > guidesCount:
            parentGuide = guides[-1]
            for i in range(guidesCount, value):
                parentGuide = self.__addGuide__(baseName, i, parentGuide, guideLayer)
                guideLayer.updateGuidesLocalMatrix()
            parentGuide.select()
        # sub guide
        elif value < guidesCount:                                       
            self.__subGuide__(guides, value, guideLayer)
            
        return True
            
            
    def addGuideBySelect(self) -> bool:
        # 0 get guideNodes
        selGuideNodes = self.guideLayer.getSelectedGuideNodes()
        if not selGuideNodes: 
            return False  
        selfGuideNodes = self.listGuideNodes(includeRoot=False)   
         
        # 1 create newGuide    
        guideLayer = self.guideLayer
        baseName   = self.baseName
        guideCount = len(selfGuideNodes)
        
        nweGuideNodeList = []
        for selGuideNode in selGuideNodes:
            guideCount += 1
            nweGuideNode = nodes.GuideNode.createBaseGuide(baseName, f'fk{guideCount:02}', 0.5, selGuideNode, guideLayer, True)
            guideGroup = nweGuideNode.groupFromGuideLayer
            if guideGroup: 
                cmds.matchTransform(guideGroup, selGuideNode)
            nweGuideNodeList.append(nweGuideNode.nodeName)
            
        # 3 update jointCount
        self.jointCount = guideCount
        cmds.select(nweGuideNodeList)
        return True
    
    
    def unJointsToWorld(self):
        super().unJointsToWorld()
        
        
    def deleteUnusedJoints(self):
        super().deleteUnusedJoints()   
        
        
        
    def _buildJoint_(self):

        # 1 update guide data
        guideLayer = self.guideLayer
        guideLayer.updateGuideParentData()
        guideParentMap = guideLayer.guideParentData
        
        baseName    = self.baseName
        deformLayer = self.deformLayer
        jointTags   = deformLayer.listJointTags()
        guides      = guideLayer.listGuideNodes(False)

        # 2 create joint
        jointMap = {}
        for guide in guides:
            guideTag = guide.guideTag
            _joint = None
            if guideTag in jointTags:
                _joint = deformLayer.jointNodeFromTag(guideTag)

            joint = _joint or nodes.JointNode.create(baseName, guideTag, deformLayer)
                
            joint.rotateOrderBy(guide)
            cmds.matchTransform(joint.nodeName, guide.nodeName, pos=True, rot=True, scale=False)
            joint.freeze()
            jointMap[guideTag] = joint
            
        # 3 set parent
        for tag, joint in jointMap.items():
            parentJointTag = guideParentMap.get(tag)
            if parentJointTag:
                parentJoint = jointMap[parentJointTag]
                cmds.parent(joint.nodeName, parentJoint.nodeName)
                
        # 4 to group
        jointList = deformLayer.listJointNodes()
        cmds.parent(jointList[0], deformLayer.deformGroup) 
               
        
    def setupBuild(self):
        super().setupBuild()
        
        
    def _parentJoint_(self):
        super()._parentJoint_(rootJointTag='fk01')
        
        
    def _buildControl_(self):
        baseName  = self.baseName
        rigLayer  = self.rigLayer
        jointList = self.deformLayer.listJointNodes()
        guideParentMap = self.guideLayer.guideParentData
        
        # 1 creare fk
        contorlMap = {}
        for joint in jointList:
            jointTag = joint.jointTag
            fkControl = nodes.ControlNode.create(baseName, 
                                                 jointTag,
                                                 'FK',  
                                                 0.2, axis='y', spaceGroup=True, rigLayer=rigLayer)
            fkControl.rotateOrderBy(joint)
            cmds.matchTransform(fkControl.topParent, joint.nodeName, pos=True, rot=True, scale=False)
            contorlMap[jointTag] = fkControl
            
        for tag, control in contorlMap.items():
            parentControlTag = guideParentMap.get(tag)
            if parentControlTag:
                parentControl = contorlMap[parentControlTag]
                cmds.parent(control.topParent, parentControl.nodeName)
        
        # 2 to control Group
        controlList = rigLayer.listControlNodes()
        cmds.parent(controlList[0].topParent, rigLayer.rigGroup)
        
        # 3 add constr 
        for joint, control in zip(jointList, controlList):
            extraNodes = jointBinding.bindJointByMatrix(baseName, 
                                                        joint.jointTag, 
                                                        control.nodeName, 
                                                        joint.nodeName,
                                                        sourceParent=True)
            joint.addExtraNodestoMeta(extraNodes)
            
            
    def _buildOutput_(self):
        baseName    = self.baseName
        outputLayer = self.outputLayer
        jointList   = self.deformLayer.listJointNodes()
        guideParentMap = self.guideLayer.guideParentData
        
        # 0 create output node
        outputNodeMap = {}
        for joint in jointList:
            tag = joint.jointTag
            outputNode = nodes.OutputNode.create(baseName, tag, outputLayer)
            outputNode.rotateOrderBy(joint)
            outputNodeMap[tag] = outputNode
        # 1 set parent    
        for tag, outputNode in outputNodeMap.items():
            parentOutputNodeTag = guideParentMap.get(tag)
            if parentOutputNodeTag:
                parentOutputNode = outputNodeMap[parentOutputNodeTag]
                cmds.parent(outputNode.nodeName, parentOutputNode.nodeName)
        # 2 add drive
        outputNodes = outputLayer.listOutputNodes()
        for index, (joint, outputNode) in enumerate(zip(jointList, outputNodes)):
            if index == 0:
                outputNode.connectJointDrive(joint, space=True)
            else:
                outputNode.connectJointDrive(joint, space=False)
        # set rootNode to group
        cmds.parent(outputNodeMap['fk01'].nodeName, outputLayer.outputGroup)
        
    
    def _buildInput_(self):
        baseName   = self.baseName
        inputLayer = self.inputLayer
        
        inputNode = nodes.InputNode.create(baseName, 'world', inputLayer)
        cmds.parent(inputNode.nodeName, inputLayer.inputGroup)
        # connect opm
        fk01ControlNode = self.rigLayer.controlNodeFromTag('fk01')
        cmds.connectAttr(f'{inputNode.nodeName}.worldMatrix[0]', f'{fk01ControlNode.topParent}.offsetParentMatrix', f=True)
        
    def build(self):
        super().build()
        
    def _buildParent_(self):
        super()._buildParent_()
        
        
    def _buildSpaceSwitch_(self):
        super()._buildSpaceSwitch_()

    
    def seaming(self):
        super().seaming()
        
    
    def _componentAttr_(self) -> dict:
        self.guideLayer.updateGuideParentData()
        guideParentMap = self.guideLayer.guideParentData
        return {'jointCount':self.jointCount, 'parentMap':guideParentMap}
        
        
    def _setComponentAttr_(self, data:dict):
        self.setJointCount(data['jointCount'])
        self.updateParentGuide(data['parentMap'])
        
        
    def duplicate(
                 self, 
                 side:str='', 
                 selectRootGuideNode=True
                 ) -> 'list[Component]':
                    
        return super().duplicate(side=side, 
                                 selectRootGuideNode=selectRootGuideNode)
                                 
                                 
    def _sortGuideNodes_(self, guides):
        return guides
        
        
    def _postMirror_(self):
        pass
          
            
    def mirror(
               self, 
               axis='x', 
               side='R'
               ) -> 'list[Component]':

        return super().mirror(axis=axis, side=side)
        
    

    @staticmethod
    def getJointTransformsData(nodeName:str) -> dict:
        '''
        Get joint transform information. Note that we're retrieving the joint's world matrix, 
        but the key is still 'localMatrix'. This is because we are reusing the 
        setGuidesTransforms method inside guideLayer, and we need to maintain internal consistency.
        '''
        return {'localMatrix':cmds.getAttr(f'{nodeName}.worldMatrix'), 
                'rotateOrder':cmds.getAttr(f'{nodeName}.rotateOrder')}
           
                
    @staticmethod
    def getJointToGuideDatas(targetJoint:str) -> 'tuple(dict, dict)':
        '''
        Get joint parent-child mapping and joint transform data
        '''
        parentData     = {}
        transformsData = {}
        
        parentData['fk01'] = ''
        
        transformsData['fk01'] = FkChain.getJointTransformsData(targetJoint)
        transformsData['root'] = transformsData['fk01'] # add root transforms data
        
        childs = cmds.listRelatives(targetJoint, allDescendents=True, fullPath=True) or []
        
        if childs:
            childs.reverse()
            childsMap = {child : f'fk{i+2:02d}' for i, child in enumerate(childs)}
            childsMap[targetJoint] = 'fk01'

            for jointName, fkTag in childsMap.items():
                parent = cmds.listRelatives(jointName, parent=True, fullPath=True) or []
                if parent:
                    parentData[fkTag] = childsMap.get(parent[0], '')
                transformsData[fkTag] = FkChain.getJointTransformsData(jointName)
            
        return parentData, transformsData
        
    
    def jointToGuide(self) -> bool:
        joints = cmds.ls(sl=True, type='joint', long=True)
        if not joints:
            om2.MGlobal.displayWarning('Nothing selected. Please select joint.')
            return False

        parentData, transformsData = FkChain.getJointToGuideDatas(joints[0])
        self.setJointCount(len(parentData))
        self.updateParentGuide(parentData)
        self.guideLayer.setGuidesTransforms(transformsData, space=True)
        return True

        
        
if __name__ == '__main__':
    ch = components.CharacterManager.create()
    f = FkChain.create(parent=ch)
    #f.jointToGuide()
    #f.guideLayer.updateGuideParentData()
    #ch.rebuild()
    #f._buildJoint_()
    #f.guideData = {'woca':'kdd'}
    #f.setJointCount(6)
   # guideNodes = f.listGuideNodes()
    
    #f.guideLayer.updateGuideParent(guideNodes[-1], guideNodes[2])
    # f.duplicate()
    # #f.addGuideBySelect()
    # f.setupBuild()
    # f.build()
    # f.seaming()

