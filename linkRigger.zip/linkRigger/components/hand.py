from maya import cmds
from maya.api import OpenMaya as om2
from linkRigger import components

from linkRigger.utils import attrUtils, nodeUtils

from linkRigger.core import nodes
from linkRigger.rig  import jointBinding


class Hand(components.Component):
    
    pass
        
        

if __name__ == '__main__':
    a = Hand()