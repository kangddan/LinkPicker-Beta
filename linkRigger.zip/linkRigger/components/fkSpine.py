from maya import cmds
from maya.api import OpenMaya as om2
from linkRigger import components
import uuid
from linkRigger.utils import attrUtils
from linkRigger.utils import nameUtils
from linkRigger.utils import nodeUtils

from linkRigger.core import nodes

from linkRigger.rig import jointBinding
from linkRigger.rig import spaceSwitch
from linkRigger.rig import mirror


class FkSpine(components.Component):
    
    @classmethod
    def _setupAttrs_(cls, instance):
        attrUtils.addAttr(instance.nodeName, 'jointCount',  type='long', value=5, min=4)
        
        # TOOD: Whether to add a COG joint
        attrUtils.addAttr(instance.nodeName, 'hasCogJoint',  type='bool', value=True)
        
            
    @classmethod
    def _setupGuides_(cls, instance):
        baseName   = instance.baseName
        guideLayer = instance.guideLayer
        
        rootGuide = nodes.GuideNode.createRootGuide(baseName, 1, guideLayer)   
            
        cogGuide  = nodes.GuideNode.createBaseGuide(baseName, 'cog', 0.7, rootGuide, guideLayer, True)
        hipGuide  = nodes.GuideNode.createBaseGuide(baseName, 'hip', 0.5, cogGuide, guideLayer, True)
        
        fk01Guide = nodes.GuideNode.createBaseGuide(baseName, 'fk01', 0.7, cogGuide, guideLayer, True)
        fk02Guide = nodes.GuideNode.createBaseGuide(baseName, 'fk02', 0.7, fk01Guide, guideLayer, True)
        fk03Guide = nodes.GuideNode.createBaseGuide(baseName, 'fk03', 0.7, fk02Guide, guideLayer, True)
        rootGuide.select()
        #move
        cmds.setAttr(f'{fk01Guide.nodeName}.ty', 10)
        cmds.setAttr(f'{fk02Guide.nodeName}.ty', 10)
        cmds.setAttr(f'{fk03Guide.nodeName}.ty', 10)
        # update jointCount
        instance.jointCount = 5
        
        
        
    def __addGuide__(self, baseName:str, 
                           index:int,
                           parentGuide:'GuideNode',
                           guideLayer:'GuideLayer') -> 'GuideNode':
        index -= 1                    
        nweGuide = nodes.GuideNode.createBaseGuide(baseName, f'fk{index:02}', 0.7, parentGuide, guideLayer, True)
        guideGroup = nweGuide.groupFromGuideLayer
        if guideGroup: cmds.matchTransform(guideGroup, parentGuide)
        # set matrix
        cacheLocalMatrix = nweGuide.localMatrixFromGuideLayer
        if cacheLocalMatrix == list(om2.MMatrix()):
            cmds.xform(f'{nweGuide.nodeName}', m=parentGuide.localMatrixFromGuideLayer, ws=False)
        else:
            cmds.xform(f'{nweGuide.nodeName}', m=cacheLocalMatrix, ws=False)
        return nweGuide
        
        
    def __subGuide__(self, guides: 'list[GuideNode]', 
                        value: int, 
                        guideLayer:'GuideLayer'):
                            
        excessCount = len(guides) - value
        if excessCount <= 0:
            return

        for i in range(excessCount):
            guide = guides.pop()  
            guideLayer.deleteGuide(guide)
        guides[-1].select()
        
    
    @property
    def hasCogJoint(self) -> bool:
        return cmds.getAttr(f'{self.nodeName}.hasCogJoint')
        
    
    @hasCogJoint.setter
    def hasCogJoint(self, value:bool):
        return cmds.setAttr(f'{self.nodeName}.hasCogJoint', value)
   
    
    @property
    def jointCount(self) -> int:
        return cmds.getAttr(f'{self.nodeName}.jointCount')
        
        
    @jointCount.setter
    def jointCount(self, value:int):
        cmds.setAttr(f'{self.nodeName}.jointCount', value)
        
    
    def setJointCount(self, value:int) -> bool:
        if value < 4 or value == self.jointCount: 
            return False

        # 0 update metaAttr
        self.jointCount = value
        
        # 1 update localMatrix
        baseName, guideLayer = self.baseName, self.guideLayer
        guideLayer.updateGuidesLocalMatrix()
        guides = guideLayer.listGuideNodes(includeRoot=False)
        guidesCount = len(guides)
        
        # add guide
        if value > guidesCount:
            parentGuide = guides[-1]
            for i in range(guidesCount, value):
                parentGuide = self.__addGuide__(baseName, i, parentGuide, guideLayer)
                guideLayer.updateGuidesLocalMatrix()
            parentGuide.select()
        # sub guide
        elif value < guidesCount:                                       
            self.__subGuide__(guides, value, guideLayer)
        return True
    
    
    ###################################################### 0 #######################################################
    def unJointsToWorld(self):
        super().unJointsToWorld()
        
        
    def deleteUnusedJoints(self):
        super().deleteUnusedJoints()   
                
                
    def _buildJoint_(self):
        # 0 update guide data
        guideLayer = self.guideLayer
        guideLayer.updateGuideParentData()
        guideParentMap = guideLayer.guideParentData
        
        '''
        Update the parent of the cog to be the hip, ensuring that the skeletal chain is structured from the bottom up.
        '''
        guideParentMap['cog'] = 'hip'
        guideParentMap['hip'] = ''
        guideLayer.setGuideParentData(guideParentMap) # update data !
       
        baseName    = self.baseName
        deformLayer = self.deformLayer
        jointTags   = deformLayer.listJointTags()
        guides      = guideLayer.listGuideNodes(False)
         
        # 1 create joint
        jointMap = {}
        for guide in guides:
            guideTag = guide.guideTag
            _joint = None
            if guideTag in jointTags:
                _joint = deformLayer.jointNodeFromTag(guideTag)

            joint = _joint or nodes.JointNode.create(baseName, guideTag, deformLayer)
            
            joint.rotateOrderBy(guide)
            cmds.matchTransform(joint.nodeName, guide.nodeName, pos=True, rot=True, scale=False)
            joint.freeze()
            jointMap[guideTag] = joint
        
        # 2 set parent
        for tag, joint in jointMap.items():
            parentJointTag = guideParentMap.get(tag)
            if parentJointTag:
                parentJoint = jointMap[parentJointTag]
                cmds.parent(joint.nodeName, parentJoint.nodeName)
                
        # 3 to group
        cmds.parent(jointMap['hip'], deformLayer.deformGroup) 

        
        
    def setupBuild(self):
        super().setupBuild()
        

    ###################################################### 1 #######################################################   
    def _parentJoint_(self):
        super()._parentJoint_(rootJointTag='hip')
        

    def _buildControl_(self):
        baseName  = self.baseName
        rigLayer  = self.rigLayer
        jointList = self.deformLayer.listJointNodes()
        
        guideParentMap = self.guideLayer.guideParentData
        jointMap       = {joint.jointTag: joint for joint in jointList}
        
        
        # 0 create cog and hip
        cogControl = nodes.ControlNode.create(baseName, 'cog', 'COG', 1, spaceGroup=True, rigLayer=rigLayer)
        cogControl.rotateOrderBy(jointMap['cog'])
        
        cogSubControl = nodes.ControlNode.create(baseName, 'cogSub', 'COG', 0.95, spaceGroup=True, rigLayer=rigLayer)
        cogSubControl.rotateOrderBy(jointMap['cog'])
        cmds.parent(cogSubControl.topParent, cogControl.nodeName)
        
        hipControl = nodes.ControlNode.create(baseName, 'hip', 'HIP', 1, spaceGroup=True, rigLayer=rigLayer)
        hipControl.rotateOrderBy(jointMap['hip'])
        cmds.parent(hipControl.topParent, cogSubControl.nodeName)
        
        cmds.matchTransform(cogControl.topParent, jointMap['cog'].nodeName, pos=True, rot=True, scale=False)
        cmds.matchTransform(hipControl.topParent, jointMap['hip'].nodeName, pos=True, rot=True, scale=False)
        
        # 1 create fk
        contorlMap = {}
        for tag, joint in jointMap.items():
            if tag in ('hip', 'cog'):
                continue
            fkControl = nodes.ControlNode.create(baseName, 
                                                 tag,
                                                 'FK',  
                                                 1.5, axis='z', spaceGroup=True, rigLayer=rigLayer)
            fkControl.rotateOrderBy(joint)
            cmds.matchTransform(fkControl.topParent, joint.nodeName, pos=True, rot=True, scale=False)
            contorlMap[tag] = fkControl
        
        # 2 set parent
        for tag, control in contorlMap.items():
            parentControlTag = guideParentMap.get(tag)
            if parentControlTag in ('hip', 'cog'):
                continue
            if parentControlTag:
                parentControl = contorlMap[parentControlTag]
                cmds.parent(control.topParent, parentControl.nodeName)
        cmds.parent(contorlMap['fk01'].topParent, cogSubControl.nodeName)
        cmds.parent(cogControl.topParent, rigLayer.rigGroup)
              
        # 3 add constr 
        contorlMap['hip'] = hipControl
        contorlMap['cog'] = cogSubControl
        
        for tag, ctrl in contorlMap.items():
            joint = jointMap[tag]
            extraNodes = jointBinding.bindJointByMatrix(baseName, 
                                                        joint.jointTag, 
                                                        ctrl.nodeName, 
                                                        joint.nodeName,
                                                        sourceParent=True)
            joint.addExtraNodestoMeta(extraNodes)
            
            
    def _buildOutput_(self):
        baseName    = self.baseName
        outputLayer = self.outputLayer
        jointList   = self.deformLayer.listJointNodes()
        
        guideParentMap = self.guideLayer.guideParentData
        jointMap       = {joint.jointTag: joint for joint in jointList}
        
        # 0 create output node
        outputNodeMap = {}
        for tag, joint in jointMap.items():
            outputNode = nodes.OutputNode.create(baseName, tag, outputLayer)
            outputNode.rotateOrderBy(joint)
            outputNodeMap[tag] = outputNode
        
        # 1 set parent    
        for tag, outputNode in outputNodeMap.items():
            parentOutputNodeTag = guideParentMap.get(tag)
            if parentOutputNodeTag:
                parentOutputNode = outputNodeMap[parentOutputNodeTag]
                cmds.parent(outputNode.nodeName, parentOutputNode.nodeName)
                
        # 2 add drive         
        for tag, outputNode in outputNodeMap.items():
            joint = jointMap[tag]
            if tag == 'hip':
                outputNode.connectJointDrive(joint, space=True)
            else:
                outputNode.connectJointDrive(joint, space=False)
        
        # set rootNode to group
        cmds.parent(outputNodeMap['hip'].nodeName, outputLayer.outputGroup)
        
        
    def _buildInput_(self):
        baseName   = self.baseName
        inputLayer = self.inputLayer
        
        inputNode = nodes.InputNode.create(baseName, 'world', inputLayer)
        cmds.parent(inputNode.nodeName, inputLayer.inputGroup)
        # connect opm
        cogControlNode = self.rigLayer.controlNodeFromTag('cog')
        cmds.connectAttr(f'{inputNode.nodeName}.worldMatrix[0]', f'{cogControlNode.topParent}.offsetParentMatrix', f=True)
        
        
    def build(self):
        super().build()
    
    ###################################################### 2 #######################################################
    
    def _buildParent_(self):
        super()._buildParent_()
        
        
    def _buildSpaceSwitch_(self):
        super()._buildSpaceSwitch_()

    
    def seaming(self):
        super().seaming()
    
    
    
    def _componentAttr_(self) -> dict:
        return {'jointCount'  : self.jointCount,
                'hasCogJoint' : self.hasCogJoint}
        
        
    def _setComponentAttr_(self, data:dict):
        self.setJointCount(data['jointCount'])
        self.hasCogJoint = data['hasCogJoint']
        
        
    def duplicate(
                 self, 
                 side:str='', 
                 selectRootGuideNode=True
                 ) -> 'list[Component]':
                    
        return super().duplicate(side=side, 
                                 selectRootGuideNode=selectRootGuideNode)
        
        
    def _sortGuideNodes_(self, guides):
        '''
        We need to sort the FkSpine because the first guide is the hip. 
        we need to swap its position with the cogGuide to ensure the parent calculates the matrix first, avoiding any offsets. 
        '''
        guides[1], guides[2] = guides[2], guides[1]
        return guides
    
    
    def _postMirror_(self):
        pass
            
        
    def mirror(
               self, 
               axis='x', 
               side='R'
               ) -> 'list[Component]':

        return super().mirror(axis=axis, side=side)

            
        
        


if __name__ == '__main__':
    ch = components.CharacterManager.create()
    f = FkSpine.create(parent=ch)
    f.duplicate()
    ch.build()
    ch.rebuild()
    #f.hideGuidesAxis()
    #f.setJointCount(4)
    # f._buildJoint_()
    # f._buildControl_()
    # f._buildOutput_()
    # f._buildInput_()
    # f.buildControl()


    #f.setJointCount(1)
    #f.setupBuild()
    #f.build()
    #f.seaming()
    #f.outputLayer.listOutputNodes()[0].outputLayer
    #f.showGuidesAxis()
   # cmds.select(f.rigLayer.listControlNodes())


    #guides = f.listGuideNodes()
    
    #f.componentGuideMeta.deleteGuide(guides[2])
    #f.setName('sb')
    #f.setSide('FF')
    #f.jointCount
    #f.setJointCount(9)
    #cmds.listConnections('FkSpine_M_guide_meta.guideNodes[1]', d=False, s=True)
    
    #f.listGuideNodes()[-1].guideLayer.metaParent()
    #f.rigLayer.addSpaceSwitch(f.listGuideNodes()[-1], 'parent', True, True, True, True)


    
