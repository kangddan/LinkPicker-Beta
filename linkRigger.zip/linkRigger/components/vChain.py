from maya import cmds
from maya.api import OpenMaya as om2
from linkRigger import components

from linkRigger.utils import attrUtils, nodeUtils, guideUtils

from linkRigger.core import nodes
from linkRigger.rig  import jointBinding
from linkRigger.rig  import ikSystem


class VChain(components.Component):
    
    @classmethod
    def _setupAttrs_(cls, instance):
        attrUtils.addAttr(instance.nodeName, 'ikGuidesVis',  type='bool', value=False)
        attrUtils.addAttr(instance.nodeName, 'skipEndJointAlign',  type='bool', value=False)
        
        attrUtils.addAttr(instance.nodeName, 'wristBreak',  type='bool', value=False)
        attrUtils.addAttr(instance.nodeName, 'stretchSystem',  type='bool', value=True)
        attrUtils.addInt3Attribute(instance.nodeName, 'aimVector')
        attrUtils.addInt3Attribute(instance.nodeName, 'upVector')
        
     
    @classmethod
    def _setupGuides_(cls, instance):
        baseName   = instance.baseName
        guideLayer = instance.guideLayer
        
        rootGuide = nodes.GuideNode.createRootGuide(baseName, 1, guideLayer)   
        uprGuide  = nodes.GuideNode.createBaseGuide(baseName, 'upr', 0.7, rootGuide, guideLayer, True)
        midGuide  = nodes.GuideNode.createBaseGuide(baseName, 'mid', 0.7, rootGuide, guideLayer, True)
        endGuide  = nodes.GuideNode.createBaseGuide(baseName, 'end', 0.7, rootGuide, guideLayer, True)
        
        # create ik guides
        uprIkGuide  = nodes.GuideNode.createBaseGuide(baseName, 'uprIk', 0.5, uprGuide, guideLayer, True, 'GUIDE_BASE_IK')
        endIkGuide  = nodes.GuideNode.createBaseGuide(baseName, 'endIk', 0.5, endGuide, guideLayer, True, 'GUIDE_BASE_IK')
        poleGuide = nodes.GuideNode.createBaseGuide(baseName, 'poleIk', 1, rootGuide, guideLayer, True, 'GUIDE_IK_POLE')
        attrUtils.lockBaseAttr(poleGuide.nodeName, ['tx', 'ty', 'rx', 'ry', 'rz', 'sx', 'sy','sz'], vis=False)
        # conncet 
        cmds.connectAttr(f'{uprIkGuide.nodeName}.isRoot', f'{uprIkGuide.nodeName}.tx', f=True)
        cmds.connectAttr(f'{uprIkGuide.nodeName}.isRoot', f'{uprIkGuide.nodeName}.ty', f=True)
        cmds.connectAttr(f'{uprIkGuide.nodeName}.isRoot', f'{uprIkGuide.nodeName}.tz', f=True)
        
        cmds.connectAttr(f'{endIkGuide.nodeName}.isRoot', f'{endIkGuide.nodeName}.tx', f=True)
        cmds.connectAttr(f'{endIkGuide.nodeName}.isRoot', f'{endIkGuide.nodeName}.ty', f=True)
        cmds.connectAttr(f'{endIkGuide.nodeName}.isRoot', f'{endIkGuide.nodeName}.tz', f=True)
        
        # update guideLine
        guideLayer.updateGuideLineStartNode(midGuide, uprGuide)
        guideLayer.updateGuideLineStartNode(endGuide, midGuide)
        guideLayer.updateGuideLineStartNode(poleGuide, midGuide)
        
        # move
        cmds.setAttr(f'{midGuide.nodeName}.tx', 24); cmds.setAttr(f'{midGuide.nodeName}.tz', -1)
        cmds.setAttr(f'{endGuide.nodeName}.tx', 48)
        
        # add poleIkGuide System
        guideUtils.createVChainPoleSystem(baseName, rootGuide, uprGuide, midGuide, endGuide, poleGuide, offset=0.5)
        
        # default setting
        instance.align([1, 0, 0], [0, 0, -1])
        instance.hideIkGuides()
        rootGuide.select()
        
    @classmethod
    def create(cls, nodeName='', side='L', metaId='', parent=None) -> 'Component':
        return super().create(nodeName, side, metaId, parent)
        
    
    @property
    def wristBreak(self) -> bool:
        return cmds.getAttr(f'{self.nodeName}.wristBreak')  
        
        
    @wristBreak.setter
    def wristBreak(self, value:bool):
        cmds.setAttr(f'{self.nodeName}.wristBreak', value)
        
            
    @property
    def stretchSystem(self) -> bool:
        return cmds.getAttr(f'{self.nodeName}.stretchSystem')  
        
    @stretchSystem.setter
    def stretchSystem(self, value:bool):
        cmds.setAttr(f'{self.nodeName}.stretchSystem', value)
        
    @property
    def ikGuidesVis(self) -> bool:
        return cmds.getAttr(f'{self.nodeName}.ikGuidesVis') 
           
    @ikGuidesVis.setter
    def ikGuidesVis(self, value:bool):
        cmds.setAttr(f'{self.nodeName}.ikGuidesVis', value)
        
        guideLayer = self.guideLayer
        for tag in ('uprIk', 'endIk', 'poleIk'):
            guideNode = guideLayer.guideNodeFromTag(tag)
            guideLine = guideLayer.guideLineFromTag(tag)
            cmds.setAttr(f'{guideNode.nodeName}.v', value)
            cmds.setAttr(f'{guideLine}.v', value)
    
    def showIkGuides(self):
        self.ikGuidesVis = True
        
    def hideIkGuides(self):
        self.ikGuidesVis = False
        
        
    @property    
    def aimVector(self) -> list:
        return list(cmds.getAttr(f'{self.nodeName}.aimVector')[0])
         
    @aimVector.setter
    def aimVector(self, vector:list):
        cmds.setAttr(f'{self.nodeName}.aimVector', *vector)
        
        
    @property    
    def upVector(self) -> list:
        return list(cmds.getAttr(f'{self.nodeName}.upVector')[0])
     
    @upVector.setter
    def upVector(self, vector:list):
        cmds.setAttr(f'{self.nodeName}.upVector', *vector)
        
        
    @property
    def skipEndJointAlign(self) -> bool:
        return cmds.getAttr(f'{self.nodeName}.skipEndJointAlign')
        
    @skipEndJointAlign.setter
    def skipEndJointAlign(self, value:bool):
        cmds.setAttr(f'{self.nodeName}.skipEndJointAlign', value)
    
    
    def selectedGuidesToWorldRot(self):
        selGuideNodes = self.guideLayer.getSelectedGuideNodes()
        for guide in selGuideNodes:
            cmds.xform(f'{guide.nodeName}', ro=[0, 0, 0], ws=True)
    
    
    def alignIkEnd(self):
        guideLayer = self.guideLayer
        uprGuideNode, midGuideNode, endGuideNode, endIkGuideNode = [guideLayer.guideNodeFromTag(tag).nodeName 
                                                                    for tag in ['upr', 'mid', 'end', 'endIk']]  
        ikSystem.relativeWorldRotation(uprGuideNode, midGuideNode, endGuideNode, endIkGuideNode)
        
        
    def inverVectors(self, refVChain:'VChain'=None):
        '''
        Translate "aimVector" and "upVector" to their inverses, 
        primarily for ensuring the correct data update on the other side's VChain component when using mirror or symmetrize methods.
        '''
        self.aimVector = [- value for value in (refVChain.aimVector if refVChain else self.aimVector)]
        self.upVector  = [- value for value in (refVChain.upVector if refVChain else self.upVector)]
        
    
    
    def align(self, 
              aimVector:list=None, 
              upVector:list=None):
        
        guideLayer = self.guideLayer
        
        # 0 update attr
        self.aimVector = aimVector or self.aimVector
        self.upVector  = upVector or self.upVector
        
        # 1 get guides
        uprGuideNode, midGuideNode, endGuideNode, endIkGuideNode = [guideLayer.guideNodeFromTag(tag).nodeName 
                                                                    for tag in ['upr', 'mid', 'end', 'endIk']]  
        # 2 get align str
        aimStr = ikSystem.VChainSystem.vectorToDirection(self.aimVector)
        upStr = ikSystem.VChainSystem.vectorToDirection(self.upVector)
        
        # 2.5 get childrenComponents
        childRootGuides = [child.guideLayer.guideRootNode for child in self.listChildComponentNode(recursive=False)]
        cacheMatrix     = [rootGuide.globalMatrix for rootGuide in childRootGuides]
        
        # 3 align fkGuide
        ikSystem.VChainSystem.setAlign([uprGuideNode, midGuideNode, endGuideNode],
                                        aimStr, 
                                        upStr,
                                        self.skipEndJointAlign)
        # 3 align ikGuide
        ikSystem.relativeWorldRotation(uprGuideNode, midGuideNode, endGuideNode, endIkGuideNode)
        
        # 4 pin childComponent
        for rootGuide, matrix in zip(childRootGuides, cacheMatrix):
            cmds.xform(rootGuide.nodeName, m=matrix, ws=True)
        
    
    def unJointsToWorld(self):
        super().unJointsToWorld()
        
        
    def deleteUnusedJoints(self):
        super().deleteUnusedJoints()   
                
                
    def _buildJoint_(self):
        # 0 update guide data
        guideLayer = self.guideLayer
        guideLayer.setGuideParentData({'upr':'', 'mid':'upr', 'end':'mid'}) # update data !
        
        baseName    = self.baseName
        deformLayer = self.deformLayer
        jointTags   = deformLayer.listJointTags()
        guides      = [guideLayer.guideNodeFromTag(guide) for guide in ['upr', 'mid', 'end']]

        # 1 create joint
        jointList = []
        for guide in guides:
            guideTag = guide.guideTag
            _joint = None
            if guideTag in jointTags:
                _joint = deformLayer.jointNodeFromTag(guideTag)

            joint = _joint or nodes.JointNode.create(baseName, guideTag, deformLayer)

            joint.rotateOrderBy(guide)
            cmds.matchTransform(joint.nodeName, guide.nodeName, pos=True, rot=True, scale=False)
            joint.freeze(makeIdentity=False)
            jointList.append(joint)
            
        # 2 set parent
        for i in range(1, len(jointList)):
            cmds.parent(jointList[i], jointList[i-1])
      
        # 3 to group
        cmds.parent(jointList[0], deformLayer.deformGroup) 
        

        # set ikJoint to Meta
        '''
        We need to add the ikControls tag to the deformLayer and specify a uprJoint as the parentJoint for other components.
        '''
        for tag in ['uprIk', 'endIk', 'poleIk']:
            deformLayer.addJointNodeToMeta(jointList[0], tag)

                   
    def setupBuild(self):
        super().setupBuild()
        
        
    def _parentJoint_(self):
        super()._parentJoint_(rootJointTag='upr')
    
    
    def _createFkControls_(
                           self, 
                           rigLayer  : 'RigLayer', 
                           jointList : 'list[JointNode]'
                           ) -> 'list[ControlNode]':
        pass
        
    
    def _createIkJoints_(
                         self, 
                         rigLayer  : 'RigLayer', 
                         jointList : 'list[JointNode]'
                         ) -> 'list[ControlNode]':
        pass
        
    def _creareBlendNodes_(
                           self, 
                           rigLayer  : 'RigLayer', 
                           jointList : 'list[JointNode]'
                           ) -> 'list[ControlNode]':
        pass
 
    
    def _buildControl_(self):
        baseName   = self.baseName
        rigLayer   = self.rigLayer
        guideLayer = self.guideLayer
        jointList  = self.deformLayer.listJointNodes()[:3] 
        
        # 0 create fkControl and ikJoints and blendNodes
        fkControlList = []
        ikJointList   = []
        blendList     = []
        for joint in jointList:
            # create fk
            #fkControlTag = f'{joint.jointTag}Fk'
            fkControlTag = joint.jointTag
            fkControl = nodes.ControlNode.create(baseName, fkControlTag, 'FK', 0.5, axis='y', spaceGroup=True, rigLayer=rigLayer, tagSuffix='Fk')
            fkControl.rotateOrderBy(joint)
            cmds.matchTransform(fkControl.topParent, joint.nodeName, pos=True, rot=True, scale=False)
            fkControlList.append(fkControl)
            # create ik
            ikJointTag = f'{joint.jointTag}Ik'
            ikJoint = nodes.JointNode.create(baseName, ikJointTag, rigLayer)
            ikJoint.rotateOrderBy(joint)
            ikJoint.hide()
            cmds.matchTransform(ikJoint.nodeName, joint.nodeName, pos=True, rot=True, scale=False)
            ikJoint.freeze(makeIdentity=False)
            ikJointList.append(ikJoint)
            # create blend
            blendNode = nodes.TaggedNode.create('transform', baseName, joint.jointTag, 'blend', rigLayer)
            blendNode.rotateOrderBy(joint)
            blendList.append(blendNode)
                    
        # set parent
        for i in range(1, len(fkControlList)):
            cmds.parent(fkControlList[i].topParent, fkControlList[i-1].nodeName)
            cmds.parent(ikJointList[i].nodeName, ikJointList[i-1].nodeName)
            cmds.parent(blendList[i].nodeName, blendList[i-1].nodeName)
            
        # 1 create ik ctrl
        ikControlList = []
       
        uprIkGuideNode  = guideLayer.guideNodeFromTag('uprIk')
        poleIkGuideNode = guideLayer.guideNodeFromTag('poleIk')
        endIkGuideNode  = guideLayer.guideNodeFromTag('endIk')
        
        ikShapes = [{'shape':'POLE', 'scale':1}, 
                    {'shape':'POLE', 'scale':0.5}, 
                    {'shape':'POLE', 'scale':1}]
        for index, guide in enumerate([uprIkGuideNode, poleIkGuideNode, endIkGuideNode]):
            ikControl = nodes.ControlNode.create(baseName, guide.guideTag, 
                                                 ikShapes[index]['shape'], 
                                                 ikShapes[index]['scale'], 
                                                 axis='y', spaceGroup=True, rigLayer=rigLayer)
            ikControl.rotateOrderBy(guide)
            cmds.matchTransform(ikControl.topParent, guide.nodeName, 
                                pos=True, 
                                rot=False if index == 1 else True, 
                                scale=False)
            ikControlList.append(ikControl)
            
        attrUtils.lockBaseAttr(ikControlList[0].nodeName, ['rx', 'ry', 'rz', 'sx', 'sy','sz', 'ro'], vis=False)
        attrUtils.lockBaseAttr(ikControlList[1].nodeName, ['rx', 'ry', 'rz', 'sx', 'sy','sz', 'ro'], vis=False)

        # 2 create parent group
        parentSpaceGroup = nodes.TaggedNode.create('transform', baseName, 'parentSpace', 'srt', rigLayer)
        
        # 3 set parent
        cmds.parent(ikJointList[0].nodeName, parentSpaceGroup.nodeName)
        cmds.parent(fkControlList[0].topParent, parentSpaceGroup.nodeName)
        cmds.parent(blendList[0].nodeName, parentSpaceGroup.nodeName)
        
        cmds.parent(parentSpaceGroup.nodeName, rigLayer.rigGroup)
        for ikCtrl in ikControlList:
            cmds.parent(ikCtrl.topParent, rigLayer.rigGroup)
            
        # 4 create ikfkSwitch
        ikSystem.createIkFkSwitch(baseName,
                                  fkCtrls      = fkControlList, 
                                  ikCtrls      = ikControlList, 
                                  ikJoints     = ikJointList, 
                                  blendNodes   = blendList,
                                  deformJoints = jointList,
                                  rigLayer     = rigLayer)
            
        # 5 create ik system
        ikhandles = ikSystem.createBaseIk(baseName, 
                                          startJoint = ikJointList[0].nodeName, 
                                          midJoint   = ikJointList[1].nodeName, 
                                          endJoint   = ikJointList[2].nodeName,
                                          poleIkCtrl = ikControlList[1].nodeName, 
                                          endIkCtrl  = ikControlList[2].nodeName, 
                                          wristBreak = self.wristBreak,
                                          rigLayer   = rigLayer)
        if self.stretchSystem:
            ikSystem.strecth(baseName,
                             startJoint = ikJointList[0].nodeName,
                             midJoint   = ikJointList[1].nodeName,
                             endJoint   = ikJointList[2].nodeName,
                            
                             uprIkCtrl  = ikControlList[0].nodeName,
                             poleIkCtrl = ikControlList[1].nodeName,
                             endIkCtrl  = ikControlList[2].nodeName,
                             ikHandle   = ikhandles[0],
                             rigLayer   = rigLayer)
        # 6 add  ikfk constr                    
        jointBinding.bindJointByConstraint(blendList, jointList)
        '''
        for joint, control in zip(jointList, blendList):
            extraNodes = jointBinding.bindJointByMatrix(baseName, 
                                                        joint.jointTag, 
                                                        control.nodeName, 
                                                        joint.nodeName,
                                                        sourceParent=True)
            joint.addExtraNodestoMeta(extraNodes)
        '''
        
        # 7 update attr pos
        # attrUtils.addAttr(ikControlList[-1].nodeName, '_______', type='enum', en='VIS', keyable=False)
        # cmds.setAttr(f'{ikControlList[-1].nodeName}._______', cb=True, lock=True)
        # nodeUtils.updateAttr(ikControlList[-1].nodeName, 'ikUprCtrlVis')
        
    
    def _buildOutput_(self):
        baseName    = self.baseName
        outputLayer = self.outputLayer
        jointList   = self.deformLayer.listJointNodes()[:3] 
        
        rigLayer    = self.rigLayer
        ikCtrlList  = [rigLayer.controlNodeFromTag(tag) for tag in ['uprIk', 'poleIk', 'endIk']]
        
        # 0 create output node
        outputNodeList = []
        for joint in jointList:
            tag = joint.jointTag
            outputNode = nodes.OutputNode.create(baseName, tag, outputLayer)
            outputNode.rotateOrderBy(joint)
            outputNodeList.append(outputNode)
            
        # create ik output
        ikCtrlOutputNodeList = []
        for ikCtrl in ikCtrlList:
            tag = ikCtrl.controlTag
            outputNode = nodes.OutputNode.create(baseName, tag, outputLayer)
            outputNode.rotateOrderBy(ikCtrl)
            ikCtrlOutputNodeList.append(outputNode)
           
        # 1 set parent    
        for i in range(1, len(outputNodeList)):
            cmds.parent(outputNodeList[i].nodeName, outputNodeList[i-1].nodeName)
            
        # 2 add drive
        for index, (joint, outputNode) in enumerate(zip(jointList, outputNodeList)):
            if index == 0:
                outputNode.connectJointDrive(joint, space=True)
            else:
                outputNode.connectJointDrive(joint, space=False)
                
        # add ik output drive        
        for ikCtrl, ikOutputNode in zip(ikCtrlList, ikCtrlOutputNodeList):
            ikOutputNode.connectJointDrive(ikCtrl, space=True)
            # to group
            cmds.parent(ikOutputNode.nodeName, outputLayer.outputGroup)   
             
        # set rootNode to group
        cmds.parent(outputNodeList[0].nodeName, outputLayer.outputGroup)
        
    
    def _buildInput_(self):
        baseName   = self.baseName
        inputLayer = self.inputLayer
        rigLayer   = self.rigLayer
        
        inputNode = nodes.InputNode.create(baseName, 'world', inputLayer)
        cmds.parent(inputNode.nodeName, inputLayer.inputGroup)
        
        # connect opm
        ikCtrls = [rigLayer.controlNodeFromTag(tag) for tag in ['uprIk', 'poleIk', 'endIk']]
        
        for ikCtrl in ikCtrls:
            cmds.connectAttr(f'{inputNode.nodeName}.worldMatrix[0]', f'{ikCtrl.topParent}.offsetParentMatrix', f=True)
        
        parentSpaceGroup:str = rigLayer.taggedNodeFromTag('parentSpace')
        cmds.connectAttr(f'{inputNode.nodeName}.worldMatrix[0]', f'{parentSpaceGroup}.offsetParentMatrix', f=True)
        
    
    def build(self):
        super().build()
        
    
    def _buildParent_(self):
        super()._buildParent_()
        
        
    def _buildSpaceSwitch_(self):
        super()._buildSpaceSwitch_()

    
    def seaming(self):
        super().seaming()
        
        # update vis attr pos
        endIk = self.rigLayer.controlNodeFromTag('endIk').nodeName
        attrUtils.addAttr(endIk, '_______', type='enum', en='VIS', keyable=False)
        cmds.setAttr(f'{endIk}._______', cb=True, lock=True)
        nodeUtils.updateAttr(endIk, 'ikUprCtrlVis')
        
    
    def _componentAttr_(self) -> dict:

        return {'ikGuidesVis'       : self.ikGuidesVis, 
                'skipEndJointAlign' : self.skipEndJointAlign,
                'wristBreak'        : self.wristBreak,
                'stretchSystem'     : self.stretchSystem,
                'aimVector'         : self.aimVector,
                'upVector'          : self.upVector}
        
        
    def _setComponentAttr_(self, data:dict):
        self.ikGuidesVis       = data['ikGuidesVis']
        self.skipEndJointAlign = data['skipEndJointAlign']
        self.wristBreak        = data['wristBreak']
        self.stretchSystem     = data['stretchSystem']
        self.aimVector         = data['aimVector']
        self.upVector          = data['upVector']
        self.align(data['aimVector'],  data['upVector'])
        
        
    def duplicate(
                 self, 
                 side:str='', 
                 selectRootGuideNode=True
                 ) -> 'list[Component]':
                    
        return super().duplicate(side=side, 
                                 selectRootGuideNode=selectRootGuideNode)
                                                  
                                 
    def _sortGuideNodes_(self, guides):
        return guides
    
    
    def _postMirror_(self):
        '''
        Here, we only need to invert our own vectors, 
        because the mirror method directly retrieves components returned by the duplicate method, 
        and their data are synchronized.
        '''
        self.inverVectors(None)
        self.align()
    
    
    def mirror(
               self, 
               axis='x', 
               side='R'
               ) -> 'list[Component]':
        return super().mirror(axis=axis, side=side)

          
    def symmetrizeComponent(self, axis:str='X'):
        super().symmetrizeComponent(axis)
        
        _mirrorComponent = self.mirrorComponent
        if _mirrorComponent is None:
            return
        '''
        When using the symmetrize method, we need to consider some factors. 
        It is possible that during the editing process, 
        we have modified the vectors of components on both sides. 
        Therefore, when executing the symmetrize method, 
        we need to synchronize the vectors on the other side.
        '''
        _mirrorComponent.inverVectors(refVChain=self)
        _mirrorComponent.align()
        
        # update base attr
        _mirrorComponent.ikGuidesVis       = self.ikGuidesVis
        _mirrorComponent.skipEndJointAlign = self.skipEndJointAlign
        _mirrorComponent.stretchSystem     = self.stretchSystem

        
 
if __name__ == '__main__':
    ch = components.CharacterManager.create()
    v = VChain.create(parent=ch)
    v.wristBreak = True
    #v.showIkGuides()
    #v.selectedGuidesToWorldRot()
    #v._buildJoint_()
    # vGuide = v.listGuideNodes()
    # v2 = VChain.create(parent=ch)
    # v2.addComponentParent(vGuide[-4])
    v.align([0, -1, 0], [1, 0, 0])
    #v.mirror('x')
    #ch.build()
    #ch.rebuild()
    #v2.duplicate()
    #v.setupBuild()
    #v.build()
    # v._buildControl_()
    # v._buildOutput_()
    # v._buildInput_()
    #v.stretchSystem = False
    #v.delete()
    #v.setSide('FF')
    #ch.delete()
    #v.selectedGuidesToWorldRot()
    #v.showIkGuides()
    #v.hideIkGuides()
    #v.showIkGuides = False
    #v.skipEndJointAlign=False
    #v.align([1, 0, 0], [0, 0, -1])
    #v.setSide('F')
    #v.deleteGuides()
    #v.hideGuidesAxis()
    #v.delete()
    #ch.delete()
   # cmds.makeIdentity() 
    