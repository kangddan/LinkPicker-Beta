from maya import cmds
from maya.api import OpenMaya as om2
from linkRigger import components

from linkRigger.utils import attrUtils, nodeUtils
from linkRigger.core  import nodes
from linkRigger.rig   import jointBinding, ikSystem


class Aim(components.Component):
    
    @classmethod
    def _setupAttrs_(cls, instance):
        #attrUtils.addAttr(instance.nodeName, 'hasUpVectorControl', type='bool', value=False)
        
        attrUtils.addInt3Attribute(instance.nodeName, 'aimVector')
        attrUtils.addInt3Attribute(instance.nodeName, 'upVector')
        
                
    @classmethod
    def _setupGuides_(cls, instance):
        baseName   = instance.baseName
        guideLayer = instance.guideLayer
        
        rootGuide = nodes.GuideNode.createRootGuide(baseName, 0.6, guideLayer)   
        
        aimNodeGuide  = nodes.GuideNode.createBaseGuide(baseName, 'aim', 0.5,      rootGuide, guideLayer, True)
        targetGuide   = nodes.GuideNode.createBaseGuide(baseName, 'target', 0.3,   aimNodeGuide, guideLayer, True)
        upVectorGuide = nodes.GuideNode.createBaseGuide(baseName, 'upVector', 0.3, aimNodeGuide, guideLayer, True)
        #move
        cmds.setAttr(f'{targetGuide.nodeName}.tz', 5)
        cmds.setAttr(f'{upVectorGuide.nodeName}.ty', 3)
        instance.align([0, 0, 1], [0, 1, 0])
        rootGuide.select()
        
    
    @property    
    def aimVector(self) -> list:
        return list(cmds.getAttr(f'{self.nodeName}.aimVector')[0])
         
    @aimVector.setter
    def aimVector(self, vector:list):
        cmds.setAttr(f'{self.nodeName}.aimVector', *vector)
   
    @property    
    def upVector(self) -> list:
        return list(cmds.getAttr(f'{self.nodeName}.upVector')[0])
     
    @upVector.setter
    def upVector(self, vector:list):
        cmds.setAttr(f'{self.nodeName}.upVector', *vector)
        

    def align(self, 
              aimVector:list=None, 
              upVector:list=None):
        
        guideLayer = self.guideLayer
        
        # 0 update attr
        self.aimVector = aimVector or self.aimVector
        self.upVector  = upVector or self.upVector
        
        # 1 get guides
        aimNodeGuide, targetGuide, upVectorGuide = [guideLayer.guideNodeFromTag(tag)
                                                    for tag in ['aim', 'target', 'upVector']] 
        # 2 cache matrix                                            
        targetGuideOldMatrix   = targetGuide.globalMatrix
        upVectorGuideOldMatrix = upVectorGuide.globalMatrix
        
        aimNodeGuidePos = om2.MVector(aimNodeGuide.globalPosition)
        
        # get aim Matrix
        aimMatrix = ikSystem.VChainSystem.getMatrix(pos      = aimNodeGuidePos,
                                                    startPos = aimNodeGuidePos,
                                                    endPos   = om2.MVector(targetGuideOldMatrix[-4:-1]),
                                                    polePos  = om2.MVector(upVectorGuideOldMatrix[-4:-1]),
                                                    aim      = ikSystem.VChainSystem.vectorToDirection(self.aimVector),
                                                    up       = ikSystem.VChainSystem.vectorToDirection(self.upVector))
        # set matrix                                           
        cmds.xform(aimNodeGuide.nodeName, m=list(aimMatrix), ws=True)
        cmds.xform(targetGuide.nodeName, m=targetGuideOldMatrix, ws=True)
        cmds.xform(upVectorGuide.nodeName, m=upVectorGuideOldMatrix, ws=True)
        
        
    def inverVectors(self, refAim:'Aim'=None):
        '''
        Translate "aimVector" and "upVector" to their inverses, 
        primarily for ensuring the correct data update on the other side's Aim component when using mirror or symmetrize methods.
        '''
        self.aimVector = [- value for value in (refAim.aimVector if refAim else self.aimVector)]
        self.upVector  = [- value for value in (refAim.upVector if refAim else self.upVector)]
        
    
    def unJointsToWorld(self):
        super().unJointsToWorld()
        
        
    def deleteUnusedJoints(self):
        super().deleteUnusedJoints()   
        
        
    def _buildJoint_(self):

        baseName      = self.baseName
        deformLayer   = self.deformLayer
        jointTags     = deformLayer.listJointTags()
        aimGuideNode  = self.guideLayer.guideNodeFromTag('aim')
        
        # get joint or create joint
        _aimJoint = None
        if 'aim' in jointTags:
            _aimJoint = deformLayer.jointNodeFromTag('aim')
        aimJoint = _aimJoint or nodes.JointNode.create(baseName, 'aim', deformLayer)
        
        aimJoint.rotateOrderBy(aimGuideNode)
        cmds.matchTransform(aimJoint.nodeName, aimGuideNode.nodeName, pos=True, rot=True, scale=False)
        aimJoint.freeze()
            
        # set parent
        cmds.parent(aimJoint.nodeName, deformLayer.deformGroup) 
        
        # set ctrl to meta
        for tag in ['upVector', 'target']:
            deformLayer.addJointNodeToMeta(aimJoint, tag)
        
        
    def setupBuild(self):
        super().setupBuild()
        
        
    def _parentJoint_(self):
        super()._parentJoint_(rootJointTag='aim')
        
    
    def _buildControl_(self):
        baseName   = self.baseName
        rigLayer   = self.rigLayer
        guideLayer = self.guideLayer
        
        aimJoint = self.deformLayer.jointNodeFromTag('aim')
        
        aimGuide      = guideLayer.guideNodeFromTag('aim')
        targetGuide   = guideLayer.guideNodeFromTag('target')
        upVectorGuide = guideLayer.guideNodeFromTag('upVector')
        
        
        # 1 create aim ctrl
        aimControlList = []
        ctrlShapes = [{'shape':'AIM_FK',       'scale':1}, 
                      {'shape':'AIM_TARGET',   'scale':1}, 
                      {'shape':'AIM_UPVECTOR', 'scale':1}]
                      
        for index, guide in enumerate([aimGuide, targetGuide, upVectorGuide]):
            aimControl = nodes.ControlNode.create(baseName, guide.guideTag, 
                                                  ctrlShapes[index]['shape'], 
                                                  ctrlShapes[index]['scale'], 
                                                  axis='y', spaceGroup=True, rigLayer=rigLayer)
            aimControl.rotateOrderBy(guide)
            cmds.matchTransform(aimControl.topParent, guide.nodeName, pos=True, rot=True, scale=False)
            aimControlList.append(aimControl)
            
        # connect
        extraNodes = jointBinding.bindJointByMatrix(baseName, aimJoint.jointTag, 
                                                    aimControlList[0].nodeName, 
                                                    aimJoint.nodeName,
                                                    sourceParent=True)
        aimJoint.addExtraNodestoMeta(extraNodes)
        
        # add aim Cons
        aimCons = cmds.aimConstraint(aimControlList[1].nodeName, aimControlList[0].topParent, 
                                    aimVector=self.aimVector, upVector=self.upVector, worldUpType='object',
                                    worldUpObject=aimControlList[2].nodeName, weight=1)
        rigLayer.addExtraNodesToMeta(aimCons)
        # parent
        cmds.parent([ctrl.topParent  for ctrl in aimControlList], rigLayer.rigGroup)
        
    
    def _buildOutput_(self):
        baseName    = self.baseName
        outputLayer = self.outputLayer
        aimJoint    = self.deformLayer.jointNodeFromTag('aim')
        
        rigLayer    = self.rigLayer
        aimCtrls    = [rigLayer.controlNodeFromTag(tag) for tag in ['target', 'upVector']]
        aimCtrls.append(aimJoint)
        
        outputNodeList = []
        for node in aimCtrls:
            tag = node.jointTag if hasattr(node, 'jointTag') else node.controlTag
            outputNode = nodes.OutputNode.create(baseName, tag, outputLayer)
            outputNode.rotateOrderBy(node)
            outputNodeList.append(outputNode)
         
        # add output drive        
        for ctrl, outputNode in zip(aimCtrls, outputNodeList):
            outputNode.connectJointDrive(ctrl, space=True)
            # to group
            cmds.parent(outputNode.nodeName, outputLayer.outputGroup)   
   
        
    def _buildInput_(self):
        baseName   = self.baseName
        inputLayer = self.inputLayer
        rigLayer   = self.rigLayer
        
        inputNode = nodes.InputNode.create(baseName, 'world', inputLayer)
        cmds.parent(inputNode.nodeName, inputLayer.inputGroup)
        
        # connect opm
        aimCtrls = [rigLayer.controlNodeFromTag(tag) for tag in ['aim', 'target', 'upVector']]
        
        for aimCtrl in aimCtrls:
            cmds.connectAttr(f'{inputNode.nodeName}.worldMatrix[0]', f'{aimCtrl.topParent}.offsetParentMatrix', f=True)
   
    
    
    def _componentAttr_(self) -> dict:
        return {'aimVector' : self.aimVector,
                'upVector'  : self.upVector}
        
        
        
    def _setComponentAttr_(self, data:dict):
        self.aimVector = data['aimVector']
        self.upVector  = data['upVector']
        self.align(data['aimVector'],  data['upVector'])
        
    
    def _postMirror_(self):
        '''
        Here, we only need to invert our own vectors, 
        because the mirror method directly retrieves components returned by the duplicate method, 
        and their data are synchronized.
        '''
        self.inverVectors(None)
        self.align()
        
        
    def symmetrizeComponent(self, axis:str='X'):
        super().symmetrizeComponent(axis)
        
        _mirrorComponent = self.mirrorComponent
        if _mirrorComponent is None:
            return
        '''
        When using the symmetrize method, we need to consider some factors. 
        It is possible that during the editing process, 
        we have modified the vectors of components on both sides. 
        Therefore, when executing the symmetrize method, 
        we need to synchronize the vectors on the other side.
        '''
        _mirrorComponent.inverVectors(refAim=self)
        _mirrorComponent.align()
        
        # update base attr
        
    def _sortGuideNodes_(self, guides):
        return guides
        

    
    
                                    
    

        

if __name__ == '__main__':
    ch = components.CharacterManager.create()
    f = Aim.create(parent=ch)
    ch.build()
    #f.align([0, 1, 0], [1, 0, 0])
    #f._buildJoint_()
    #f.align()
    #f._buildJoint_()