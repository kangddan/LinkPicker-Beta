from maya import cmds
from linkRigger import components
from linkRigger.utils import attrUtils
from linkRigger.utils import nameUtils
from linkRigger.utils import nodeUtils

from linkRigger.core import nodes
from linkRigger.rig import jointBinding


class Master(components.Component):

    
    @classmethod
    def _setupAttrs_(cls, instance):
        attrUtils.addAttr(instance.nodeName, 'rootJoint',  type='bool', value=True)
        
    @classmethod
    def _setupGuides_(cls, instance):
        baseName, guideLayer = instance.baseName, instance.guideLayer
        
        rootGuide   = nodes.GuideNode.createRootGuide(baseName, 1, guideLayer)   
        masterGuide = nodes.GuideNode.createBaseGuide(baseName, 'master', 0.7, rootGuide, guideLayer, True)
        offsetGuide = nodes.GuideNode.createBaseGuide(baseName, 'offset', 0.5, masterGuide, guideLayer, True)
        rootGuide.select()
        
    
    @property
    def rootJoint(self) -> bool:
        return cmds.getAttr(f'{self.nodeName}.rootJoint') 
        
        
    @rootJoint.setter
    def rootJoint(self, switch:bool):
        cmds.setAttr(f'{self.nodeName}.rootJoint', switch)
        
        
    def unJointsToWorld(self):
        super().unJointsToWorld()
        
        
    def deleteUnusedJoints(self):
        super().deleteUnusedJoints()    
        
        
    ###################################################### 0 #######################################################  
    def _buildJoint_(self):
        # 1 create joint
        deformLayer = self.deformLayer
        jointTags   = deformLayer.listJointTags()
        
        _joint = None
        if 'master' in jointTags:
            _joint = deformLayer.jointNodeFromTag('master')
        
        if self.rootJoint:
            joint = _joint or nodes.JointNode.create(self.baseName, 'master', deformLayer)
                    
            offsetGuide = self.guideLayer.guideNodeFromTag('offset')
            joint.rotateOrderBy(offsetGuide)
            cmds.matchTransform(joint.nodeName, offsetGuide.nodeName, pos=True, rot=True, scale=False)
            joint.freeze()
            cmds.parent(joint.nodeName, deformLayer.deformGroup)
            
            # add offset tag to meta
            deformLayer.addJointNodeToMeta(joint, 'offset')
        else:
            deformLayer.deleteJointFromTag('master')
            deformLayer.deleteJointFromTag('offset')
                

        
    
    def setupBuild(self):
        super().setupBuild()
        
    ###################################################### 1 #######################################################  
    def _parentJoint_(self):
        super()._parentJoint_(rootJointTag='master')
        
        
    def _buildControl_(self):
        baseName  = self.baseName
        rigLayer  = self.rigLayer
        masterGuide = self.guideLayer.guideNodeFromTag('master')
        offsetGuideNode = self.guideLayer.guideNodeFromTag('offset')
        
        # 0 create masterControl
        masterControl = nodes.ControlNode.create(baseName, 'master', 'MASTER', 1, spaceGroup=True, rigLayer=rigLayer)
        offsetControl = nodes.ControlNode.create(baseName, 'offset', 'MASTER', 0.95, spaceGroup=True, rigLayer=rigLayer)
        
        cmds.parent(offsetControl.topParent, masterControl.nodeName)
        cmds.matchTransform(masterControl.topParent, masterGuide.nodeName, pos=True, rot=True, scale=False)
        cmds.matchTransform(offsetControl.topParent, offsetGuideNode.nodeName, pos=True, rot=True, scale=False)
        
        # 2 to control Group
        cmds.parent(masterControl.topParent, rigLayer.rigGroup)
    
        # 3 add constr 
        # !!! joint -> control -> output -> input -> setspace -> add constr
        if self.rootJoint:
            masterJoint  = self.deformLayer.jointNodeFromTag('master')
            extraNodes = jointBinding.bindJointByMatrix(baseName, 
                                                        masterJoint.jointTag, 
                                                        offsetControl.nodeName, 
                                                        masterJoint.nodeName,
                                                        sourceParent=True)
            masterJoint.addExtraNodestoMeta(extraNodes)
    
    
    def _buildOutput_(self):
        baseName    = self.baseName
        outputLayer = self.outputLayer
        controNodelList = self.rigLayer.listControlNodes()
        
        outputNodeList = []
        outputParent   = None
        for controNode in controNodelList:
            outputNode = nodes.OutputNode.create(baseName, controNode.controlTag, outputLayer)
            outputNode.rotateOrderBy(controNode)
            outputNodeList.append(outputNode)
            
            if outputParent is None:
                outputNode.connectJointDrive(controNode, space=True)
            else:
                cmds.parent(outputNode.nodeName, outputParent.nodeName)  
                outputNode.connectJointDrive(controNode, space=False, offset=True)
            outputParent = outputNode
            
        cmds.parent(outputNodeList[0].nodeName, outputLayer.outputGroup)
        
        
    def _buildInput_(self):
        baseName   = self.baseName
        inputLayer = self.inputLayer
        
        inputNode = nodes.InputNode.create(baseName, 'world', inputLayer)
        cmds.parent(inputNode.nodeName, inputLayer.inputGroup)
        # connect opm
        masterControlNode = self.rigLayer.controlNodeFromTag('master')
        cmds.connectAttr(f'{inputNode.nodeName}.worldMatrix[0]', f'{masterControlNode.topParent}.offsetParentMatrix', f=True)

    
    def build(self):
        super().build()
        
    ###################################################### 2 #######################################################
    
    def _buildParent_(self):
        super()._buildParent_()
        
        
    def _buildSpaceSwitch_(self):
        super()._buildSpaceSwitch_()

    
    def seaming(self):
        super().seaming()
        
    def _componentAttr_(self) -> dict:
         return {'rootJoint'  : self.rootJoint}
        
        
    def _setComponentAttr_(self, data:dict):
        self.rootJoint = data['rootJoint']
        
        
    def duplicate(
                 self, 
                 side:str='', 
                 selectRootGuideNode=True
                 ) -> 'list[Component]':
                    
        return super().duplicate(side=side, 
                                 selectRootGuideNode=selectRootGuideNode)
                                 
                                 
    def _sortGuideNodes_(self, guides):
        return guides
    
    
    def _postMirror_(self):
        pass
        
        
    def mirror(
               self, 
               axis='x', 
               side='R'
               ) -> 'list[Component]':

        return super().mirror(axis=axis, side=side)
    

        

if __name__ == '__main__':
    g = Master.create()
    g.setupBuild()
    g.build()
    g.seaming()    
    #g2 = Master.create()
    #g2.addComponentParent(g.listGuideNodes()[1])
    #g.hideGuidesAxis()
    #g.getData()
    #g.rootJoint = 0
    
    #g.setSide('f')
    #g.setName('woca')
