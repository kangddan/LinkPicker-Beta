'''
All classes inheriting from MetaNode should be imported and registered in this module
to ensure that MetaNode can correctly implement the factory pattern
'''
__all__ = ['Component'
           
           'CharacterManager',
           'ComponentsManager',
           'DeformManager',
           'GeoManager',
           
           'DeformLayer',
           'GuideLayer',
           'InputLayer',
           'OutputLayer',
           'RigLayer',
   
           'FkChain',
           'Master',
           'FkSpine',
           'VChain',
           'Arm',
           'Aim',
           'Leg']
           
           
''' core '''
from ..core.component import Component
           
''' manager nodes '''
from ..core.managerNodes  import CharacterManager
from ..core.managerNodes  import ComponentsManager
from ..core.managerNodes  import DeformManager
from ..core.managerNodes  import GeoManager


''' component layer '''
from ..core.layerNodes  import DeformLayer
from ..core.layerNodes  import GuideLayer
from ..core.layerNodes  import InputLayer
from ..core.layerNodes  import OutputLayer
from ..core.layerNodes  import RigLayer



''' components '''
from .fkChain  import FkChain
from .master   import Master
from .fkSpine  import FkSpine
from .vChain   import VChain
from .arm      import Arm
from .hand     import Hand
from .aim      import Aim
from .leg      import Leg

''' UI DISPLAY'''
COMPONENT_TYPE = {'basic':['Master', 'FkChain', 'FkSpine', 'VChain', 'Aim'],
                  'arm':['Arm', 'Hand'],
                  'leg':['Leg'],
                  'face':['null'],
                  }
