import json
from maya import cmds
from maya.api import OpenMaya as om2
from linkRigger import components

from linkRigger.utils import attrUtils, nodeUtils, guideUtils

from linkRigger.core import nodes
from linkRigger.rig  import jointBinding, twist, bendy


class Arm(components.VChain):
    
    @classmethod
    def _setupAttrs_(cls, instance):
        super()._setupAttrs_(instance)
        attrUtils.addAttr(instance.nodeName, 'twist',  type='bool', value=False)
        attrUtils.addAttr(instance.nodeName, 'bendy',    type='bool', value=False)
        
        attrUtils.addAttr(instance.nodeName, 'uprTwistCount',  type='long', value=5, min=3)
        attrUtils.addAttr(instance.nodeName, 'lwrTwistCount', type='long', value=5, min=3)
        
        attrUtils.addAttr(instance.nodeName, 'uprTwistWeight', type='string', value='[]')
        attrUtils.addAttr(instance.nodeName, 'lwrTwistWeight', type='string', value='[]')
        
                
    @property
    def twist(self) -> bool:
        return cmds.getAttr(f'{self.nodeName}.twist')  
        
        
    @twist.setter
    def twist(self, value:bool):
        cmds.setAttr(f'{self.nodeName}.twist', value)
        
      
    @property
    def bendy(self) -> bool:
        return cmds.getAttr(f'{self.nodeName}.bendy')  
        
        
    @bendy.setter
    def bendy(self, value:bool):
        cmds.setAttr(f'{self.nodeName}.bendy', value)
        
        
    @property
    def uprTwistCount(self) -> int:
        return cmds.getAttr(f'{self.nodeName}.uprTwistCount')  
        
        
    @uprTwistCount.setter
    def uprTwistCount(self, value:int):
        cmds.setAttr(f'{self.nodeName}.uprTwistCount', value)  
        
    
    @property
    def lwrTwistCount(self) -> int:
        return cmds.getAttr(f'{self.nodeName}.lwrTwistCount') 
            
        
    @lwrTwistCount.setter
    def lwrTwistCount(self, value:int):
        cmds.setAttr(f'{self.nodeName}.lwrTwistCount', value)  
        
        
    @property
    def uprTwistWeight(self) -> list:
        return json.loads(cmds.getAttr(f'{self.nodeName}.uprTwistWeight'))
        
        
    @uprTwistWeight.setter
    def uprTwistWeight(self, value:int):
        cmds.setAttr(f'{self.nodeName}.uprTwistWeight', json.dumps(value), type='string')
        
        
    @property
    def lwrTwistWeight(self) -> list:
        return json.loads(cmds.getAttr(f'{self.nodeName}.lwrTwistWeight'))
   
        
    @lwrTwistWeight.setter
    def lwrTwistWeight(self, value:list):
        cmds.setAttr(f'{self.nodeName}.lwrTwistWeight', json.dumps(value), type='string')
   
        
    def _setTwistJointCount(self, value:int, 
                                  twistTag:str,
                                  guideATag:str,
                                  guideBTag:str,
                                  guideNodes:'list[GuideNode]'):
        '''
        Internal method: Automatically add/remove twist joint guides based on target count.
        '''
        guideLayer   = self.guideLayer
        currentCount = len(guideNodes)
        
        if value > currentCount:
            baseName        = self.baseName
            guideNodeA      = guideLayer.guideNodeFromTag(guideATag)
            guideNodeB      = guideLayer.guideNodeFromTag(guideBTag)
        
            for i in range(currentCount, value):
                guideUtils.createTwistGuide(baseName=baseName, 
                                            guideA=guideNodeA, 
                                            guideB=guideNodeB, 
                                            guideTag=f'{twistTag}{i + 1}',
                                            guideLayer=guideLayer)
        else:
            for guide in reversed(guideNodes[value:]):
                guideLayer.deleteGuide(guide)
                
           
    def setUprTwistJointCount(self, value:int) -> bool:
        '''
        Sets the number of upper twist joints (min 3). Returns True if modified.
        '''
        if not self.twist:
            return False
        uprGuideNodes = self.listUprTwistGuideNodes()
        if value == self.uprTwistCount == len(uprGuideNodes) or value < 3:
            return False

        self._setTwistJointCount(value, 'uprTwist', 'upr', 'mid', uprGuideNodes)
        # update attr
        self.uprTwistCount = value
        
        guideUtils.setTwistWeight(self.listUprTwistGuideNodes())
        return True
        
    
    def setLwrTwistJointCount(self, value:int) -> bool:
        '''
        Sets the number of lower twist joints (min 3). Returns True if modified.
        '''
        if not self.twist:
            return False
        lwrGuideNodes = self.listLwrTwistGuideNodes()
        if value == self.lwrTwistCount == len(lwrGuideNodes) or value < 3:
            return False

        self._setTwistJointCount(value, 'lwrTwist', 'mid', 'end', lwrGuideNodes)
        # update attr
        self.lwrTwistCount = value
        
        guideUtils.setTwistWeight(self.listLwrTwistGuideNodes())
        return True
        
        
    def enableTwist(self) -> bool:
        '''
        create twist guide
        '''
        self.twist = True
        result1 = self.setUprTwistJointCount(self.uprTwistCount)
        result2 = self.setLwrTwistJointCount(self.lwrTwistCount)  
        result3 = True
        if self.bendy:
            result3 = self.enableBendy()
        return result1 and result2 and result3
        

    def deleteAllTwistGuideNode(self) -> bool:
        '''
        Delete all twist guide node.
        '''
        twistGuideNodes = self.listAllTwistGuideNodes() + self.listBendyGuideNodes()
        if not twistGuideNodes:
            return False
            
        guideLayer = self.guideLayer
        for guideNode in twistGuideNodes:
            guideLayer.deleteGuide(guideNode)
            
        self.twist = False
        return True
        
    
    def enableBendy(self) -> bool:
        if not self.twist:
            return False
        self.bendy = True
        guideLayer = self.guideLayer
        guideNodeA = guideLayer.guideNodeFromTag('upr')
        guideNodeB = guideLayer.guideNodeFromTag('mid')
        guideNodeC = guideLayer.guideNodeFromTag('end')
        guideUtils.createBendyGuide(self.baseName, guideNodeA, guideNodeB, guideNodeC, guideLayer)
        return True
        
        
    def deleteAllBendyGuideNode(self) -> bool:
        bendyGuideNodes = self.listBendyGuideNodes()
        if not bendyGuideNodes:
            return False
        
        guideLayer = self.guideLayer
        for guideNode in bendyGuideNodes:
            guideLayer.deleteGuide(guideNode)
            
        self.bendy = False
        return True
        
        
        
    def listBendyGuideNodes(self) -> 'list[GuideNode]':
        '''
        Returns bendy guide nodes.
        '''
        return self.listGuideNodesWithTag('Offset')
    
    
    def listAllTwistGuideNodes(self) -> 'list[GuideNode]':
        '''
        Returns all twist guide nodes.
        '''
        return self.listGuideNodesWithTag('Twist')
        
        
    def listUprTwistGuideNodes(self) -> 'list[GuideNode]':
        '''
        Returns all guide nodes tagged with 'uprTwist'.
        '''
        return self.listGuideNodesWithTag('uprTwist')
        
        
    def listLwrTwistGuideNodes(self) -> 'list[GuideNode]':
        '''
        Returns all guide nodes tagged with 'lwrTwist'.
        '''
        return self.listGuideNodesWithTag('lwrTwist')
        
        
    def updateTwistWeights(self):
        '''
        Uniformly set the upr/lwr twist weights
        '''
        uprTwistWeight = []
        lwrTwistWeight = []
        for guide in self.listAllTwistGuideNodes():
            if 'upr' in guide.guideTag:
                uprTwistWeight.append(cmds.getAttr(f'{guide}.weight'))
            else:
                lwrTwistWeight.append(cmds.getAttr(f'{guide}.weight'))
        self.uprTwistWeight = uprTwistWeight
        self.lwrTwistWeight = lwrTwistWeight
        
        
        
    def _componentAttr_(self) -> dict:
        data = super()._componentAttr_()
        
        self.updateTwistWeights() # update twist weight
        
        data.update({
        'twist'          : self.twist, 
        'bendy'          : self.bendy,
        'uprTwistCount'  : self.uprTwistCount,
        'lwrTwistCount'  : self.lwrTwistCount,
        'uprTwistWeight' : self.uprTwistWeight,
        'lwrTwistWeight' : self.lwrTwistWeight})

        return data
        
        
    def _setComponentAttr_(self, data:dict):
        super()._setComponentAttr_(data)
        
        self.twist = data['twist']
        self.bendy = data['bendy']
        self.uprTwistWeight = data['uprTwistWeight']
        self.lwrTwistWeight = data['lwrTwistWeight']
        
        if not self.twist:
            return
        
        self.setUprTwistJointCount(data['uprTwistCount'])
        self.setLwrTwistJointCount(data['lwrTwistCount'])
            
        for uprGuide, weight in zip(self.listUprTwistGuideNodes(), data['uprTwistWeight']):
            cmds.setAttr(f'{uprGuide}.weight', weight)
            
        for lwrGuide, weight in zip(self.listLwrTwistGuideNodes(), data['lwrTwistWeight']):
            cmds.setAttr(f'{lwrGuide}.weight', weight)
        
        if self.bendy:
            self.enableBendy()
        
        
    def _buildJoint_(self):
        super()._buildJoint_()
        
        if not self.twist:
            return
        # 0 save weight
        self.updateTwistWeights()
        
        baseName    = self.baseName
        guideLayer  = self.guideLayer
        deformLayer = self.deformLayer
        jointTags   = deformLayer.listJointTags()
        
        uprJoint = deformLayer.jointNodeFromTag('upr')
        midJoint = deformLayer.jointNodeFromTag('mid')
        
        twistGuideNodes = self.listAllTwistGuideNodes()
        
        uprTwistjointList = []
        lwrTwistJointList = []

        
        # 1 create twist joint
        for guide in twistGuideNodes:
            guideTag = guide.guideTag
            _joint = None
            if guideTag in jointTags:
                _joint = deformLayer.jointNodeFromTag(guideTag)

            joint = _joint or nodes.JointNode.create(baseName, guideTag, deformLayer)
            joint.rotateOrderBy(guide)
            cmds.matchTransform(joint.nodeName, guide.nodeName, pos=True, rot=True, scale=False)
            joint.freeze(makeIdentity=False)
            if 'upr' in guideTag:
                uprTwistjointList.append(joint)
            else:
                lwrTwistJointList.append(joint)
        
        # 2 set parent
        cmds.parent([upr.nodeName for upr in uprTwistjointList], uprJoint.nodeName)
        cmds.parent([lwr.nodeName for lwr in lwrTwistJointList], midJoint.nodeName)
           
        
    def _buildControl_(self):
        super()._buildControl_()
        if not self.twist:
            return
            
        deformLayer = self.deformLayer
        
        if self.bendy:
            bendy.Bendy(self).create()
            # add bendy ctrl outputTag
            uprJoint = deformLayer.jointNodeFromTag('upr')
            for tag in ['uprOffset', 'uprMidOffset', 'midOffset',
                        'midEndOffset', 'endOffset']:
                deformLayer.addJointNodeToMeta(uprJoint, tag)
            
        elif self.twist:
            baseName  = self.baseName
            rigLayer  = self.rigLayer
            jointList = self.deformLayer.listJointNodes()
            
            # 0 CREATE TWIST
            uprBlend = rigLayer.taggedNodeFromTag('upr', asObject=True)
            midBlend = rigLayer.taggedNodeFromTag('mid', asObject=True)
            endBlend = rigLayer.taggedNodeFromTag('end', asObject=True)
            
            # create mid twist system
            # create end twist
            twist.createBaseTwist(baseName, midBlend, endBlend, 
                                  self.aimVector, self.upVector, rigLayer,
                                  aimGroupTag       = 'midTwistAim',
                                  uprTwistTargetTag = 'midUprTwist',
                                  lwrTwistTargetTag = 'midLwrTwist',
                                  lwrbaseGroupTag   = 'midLwrBase')
            # create upr twist                      
            twist.createBaseTwist(baseName, uprBlend, midBlend, 
                                  self.aimVector, self.upVector, rigLayer,
                                  aimGroupTag       = 'uprwistAim',
                                  uprTwistTargetTag = 'uprUprTwist',
                                  lwrTwistTargetTag = 'uprLwrTwist',
                                  lwrbaseGroupTag   = 'uprLwrBase')
                                  
            # set lwr base group parent
            midTwistAimGroup = rigLayer.taggedNodeFromTag('midTwistAim')
            uprTwistAimGroup = rigLayer.taggedNodeFromTag('uprwistAim')
            parentSpaceGroup = rigLayer.taggedNodeFromTag('parentSpace')
            
            midLwrBaseGroup  = rigLayer.taggedNodeFromTag('midLwrBase')
            uprLwrBaseGroup  = rigLayer.taggedNodeFromTag('uprLwrBase')
            
            cmds.parent(midLwrBaseGroup, midTwistAimGroup)
            cmds.parent(uprLwrBaseGroup, parentSpaceGroup)
            

            # 1 CREATE CTRL
            uprTwistControlsList = []
            lwrTwistControlsList = []
            for joint in jointList:
                jointTag = joint.jointTag
                if 'Twist' not in jointTag:
                    continue
                # 0 create twist ctrl
                twistControl = nodes.ControlNode.create(baseName, jointTag, 'TWIST', 0.6, 
                                                        axis='y', spaceGroup=True, rigLayer=rigLayer)
                twistControl.rotateOrderBy(joint)
                cmds.matchTransform(twistControl.topParent, joint.nodeName, pos=True, rot=True, scale=False)
                # 1 set matrix
                extraNodes = jointBinding.bindJointByMatrix(baseName, 
                                                            joint.jointTag, 
                                                            twistControl.nodeName, 
                                                            joint.nodeName,
                                                            sourceParent=True)
                joint.addExtraNodestoMeta(extraNodes)
                # to map
                if 'upr' in jointTag:
                    uprTwistControlsList.append(twistControl)
                else:
                    lwrTwistControlsList.append(twistControl)
            
            # 2 SET PARENT
            cmds.parent([u.topParent for u in uprTwistControlsList], uprTwistAimGroup)
            cmds.parent([l.topParent for l in lwrTwistControlsList], midTwistAimGroup)
            
            # 3 CONNECT BLEND NODE
            # get targets
            uprUprTarget = rigLayer.taggedNodeFromTag('uprUprTwist')
            uprLwrTarget = rigLayer.taggedNodeFromTag('uprLwrTwist')
            
            midUprTarget = rigLayer.taggedNodeFromTag('midUprTwist')
            midLwrTarget  = rigLayer.taggedNodeFromTag('midLwrTwist')

            twist.createBlendTwist(baseName, uprUprTarget, uprLwrTarget, uprTwistControlsList, self.uprTwistWeight, uprTwistAimGroup, rigLayer)
            twist.createBlendTwist(baseName, midUprTarget, midLwrTarget, lwrTwistControlsList, self.lwrTwistWeight, midTwistAimGroup, rigLayer)
        
        
        # create vis attr
        twistNodes = []
        bendyNodes = []
        for ctrl in self.rigLayer.listControlNodes():
            if 'Twist' in ctrl.controlTag:
                twistNodes.append(ctrl.topParent)
            elif 'Offset' in ctrl.controlTag:
                bendyNodes.append(ctrl.topParent)
        
        # add pory attr
        sourceAttrNode = self.rigLayer.taggedNodeFromTag('proxy')
        nodeUtils.createVisAttr(sourceAttrNode, 'twistCtrlVis', twistNodes)
        if self.bendy:
            nodeUtils.createVisAttr(sourceAttrNode, 'bendyCtrlVis', bendyNodes)
        
        
            
    def _buildOutput_(self):
        super()._buildOutput_()
        if not self.twist:
            return
            
 
        baseName    = self.baseName
        rigLayer    = self.rigLayer
        outputLayer = self.outputLayer
        jointList   = self.deformLayer.listJointNodes()

        twistData = {'upr': {'outputs': [], 'joints': []},
                     'lwr': {'outputs': [], 'joints': []}}
        # TODO:
        # The current list-based matching for driving may lead to order mismatches. 
        # A dictionary keyed by tags would be more reliable !      
               
        # 0 create output node
        for joint in jointList:
            jointTag = joint.jointTag
            if 'Twist' not in jointTag:
                continue
            outputNode = nodes.OutputNode.create(baseName, jointTag, outputLayer)
            outputNode.rotateOrderBy(joint)
            
            key = 'upr' if 'upr' in jointTag else 'lwr'
            twistData[key]['outputs'].append(outputNode)
            twistData[key]['joints'].append(joint)
            
        # 1 get output parent
        uprOutputNode = outputLayer.outputNodeFromTag('upr')
        midOutputNode = outputLayer.outputNodeFromTag('mid')
        
        cmds.parent([node.nodeName for node in twistData['upr']['outputs']], uprOutputNode.nodeName)
        cmds.parent( [node.nodeName for node in twistData['lwr']['outputs']], midOutputNode.nodeName)
        
        # 2 add local drive 
        for key in twistData:
            for joint, outputNode in zip(twistData[key]['joints'], twistData[key]['outputs']):
                outputNode.connectJointDrive(joint, space=False)
        
        # create bendy output node 
        # !!!!!!!!!!!!!!!!!!!!!!!!       
        if self.bendy:
            bendyCtrlList  = [rigLayer.controlNodeFromTag(tag) 
                              for tag in ['uprOffset', 'uprMidOffset', 'midOffset',
                                          'midEndOffset', 'endOffset']]
                              
            bendyCtrlOutputNodeList = []
            for ctrl in bendyCtrlList:
                tag = ctrl.controlTag
                outputNode = nodes.OutputNode.create(baseName, tag, outputLayer)
                outputNode.rotateOrderBy(ctrl)
                bendyCtrlOutputNodeList.append(outputNode)
            
            # add bendy output drive        
            for bendyCtrl, bendyOutputNode in zip(bendyCtrlList, bendyCtrlOutputNodeList):
                bendyOutputNode.connectJointDrive(bendyCtrl, space=True)
                # to group
                cmds.parent(bendyOutputNode.nodeName, outputLayer.outputGroup)   
            
                
    
    def seaming(self):
        super().seaming()
        
        if not self.twist:
            return
        
        # update attr
        sourceAttrNode = self.rigLayer.taggedNodeFromTag('proxy')
        ikfkCtrls      = [self.rigLayer.controlNodeFromTag(ctrlTag)
                          for ctrlTag in ['upr', 'mid', 'end', 'uprIk', 'poleIk', 'endIk']]
        
        enableBendy = self.bendy
        for ctrl in ikfkCtrls:
            ctrlNodeName = ctrl.nodeName
            if ctrl.controlTag != 'endIk':
                attrUtils.addAttr(ctrlNodeName, '_______', type='enum', en='VIS', keyable=False)
                cmds.setAttr(f'{ctrlNodeName}._______', cb=True, lock=True)
                
            attrUtils.addAttr(f'{ctrlNodeName}', 'twistCtrlVis', proxy=f'{sourceAttrNode}.twistCtrlVis')
            if enableBendy:
                attrUtils.addAttr(f'{ctrlNodeName}', 'bendyCtrlVis', proxy=f'{sourceAttrNode}.bendyCtrlVis')

   


if __name__ == '__main__':
    ch = components.CharacterManager.create()
    a = Arm.create(parent=ch)
    a.enableBendy()
    #a.enableTwist()
    #a.deleteAllTwistGuideNode()
    #a.uprTwistWeight = [0.3, 2.5, 1]
    #a.deleteAllTwistGuideNode()
    #ch.binding()
    #ch.rebuild()
    #a.showIkGuides()
    #a.symmetrizeComponent()
    #a.duplicate(side='R')
    #a.align([0, 0, -1], [-1, 0, 0])
    #a.mirror()
    #a.deleteAllTwistGuideNode()
    #a.uprTwistCount
    #a.setUprTwistGuides(5)
    #a.twist = True
    #ch.build()
    #ch.rebuild()