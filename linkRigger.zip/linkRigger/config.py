

# META NODE ATTR NAMES
META_NAME          = 'LinkMeta'
NODE_TYPE          = 'network'
CLASS_ATTR_NAME    = 'linkMetaClass'
VERSION_ATTR_NAME  = 'linkVersion'
PARENT_ATTR_NAME   = 'linkMetaParent'
CHILDREN_ATTR_NAME = 'linkMetaChildren'
VERSION_VALUE      = '1.0.0'


# BASE RIG META NODE ATTRS
META_NAME_ATTR_NAME = 'metaName'
META_SUFIX_NAME     = '_Meta'


# CHARACTER ATTR NAMES
HAS_REBUILD_ATTR_NAME = 'hasRebuild'
HAS_BUILD_ATTR_NAME   = 'hasBuild'
CHAR_GRP_ATTR_NAME    = 'characterGroup'
COM_GRP_ATTR_NAME     = 'componentsGroup'
DEFROM_GRP_ATTR_NAME  = 'deformGroup'
GEO_GRP_ATTR_NAME     = 'geoGroup'
# GROUPS SUFFIX NAMES
CHAR_GRP_SUFFIX_NAME   = '_hrc'
COM_GRP_SUFFIX_NAME    = '_component_hrc'
DEFORM_GRP_SUFFIX_NAME = '_deform_hrc'
GEO_GRP_SUFFIX_NAME    = '_geo_hrc'


# COMPONENT ATTR NAMES
EXTRA_NODES_ATTR_NAME = 'extraNodes'
SLIDE_ATTR_NAME = 'slide'

COMPONENT_GROUP_ATTR_NAME = 'componentGroup'
INPUT_GROUP_ATTR_NAME     = 'inputGroup'
OUTPUT_GROUP_ATTR_NAME    = 'outputGroup'
RIG_GROUP_ATTR_NAME       = 'rigGroup'

GUIDE_ATTR_NAME = 'guideInfo'
GUIDE_GROUP_ATTR_NAME = 'guideGroup'
GUIDE_LINE_GROUP_ATTR_NAME = 'guideLineGroup'
GUIDE_ROT_GROUP_ATTR_NAME = 'guideRootGroup'
GUIDE_ROT_NODE_ATTR_NAME = 'guideRootNode'
GUIDE_DATA_ATTR_NAME = 'guideData'
# GROUPS SUFFIX NAMES
GUIDE_GRP_SUFFIX_NAME = '_M_guide_hrc'
INPUT_GRP_SUFFIX_NAME = '_M_input_hrc'
OUTPUT_GRP_SUFFIX_NAME = '_M_output_hrc'
RIG_GRP_SUFFIX_NAME = '_M_rig_hrc'


