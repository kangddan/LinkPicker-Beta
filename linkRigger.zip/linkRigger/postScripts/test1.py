from maya import cmds


def main():
    cmds.joint()


if __name__ == '__main__':
    main()