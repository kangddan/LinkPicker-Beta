from maya import cmds


def main():
    cmds.polyCube()


if __name__ == '__main__':
    main()