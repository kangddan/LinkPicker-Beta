from maya import cmds
from maya.api import OpenMaya as om2

from PySide6 import QtWidgets
from PySide6 import QtGui
from PySide6 import QtCore

from linkRigger.ui import qtUtils

from linkRigger import components
from linkRigger.core import meta



class CustomDelegate(QtWidgets.QStyledItemDelegate):
    def __init__(self, parent=None, itemHeight=30):
        super().__init__(parent)
        self.itemHeight = itemHeight
        
    def sizeHint(self, option, index):
        size = super().sizeHint(option, index)
        size.setHeight(self.itemHeight)
        return size
        
        
class CustomSplitterHandle(QtWidgets.QSplitterHandle):
    def __init__(self, orientation, parent=None):
        super().__init__(orientation, parent)

    def sizeHint(self):
        size = super().sizeHint()
        if self.orientation() == QtCore.Qt.Horizontal:
            size.setWidth(4) 
            self.setCursor(QtCore.Qt.SizeHorCursor)
        else:
            size.setHeight(4)
            self.setCursor(QtCore.Qt.SizeVerCursor )
        return size
         
          
class CustomSplitter(QtWidgets.QSplitter):
    
    def __init__(self, parent=None, handleColor='#373737'):
        super().__init__(parent)
        self.setStyleSheet(f''' 
            QSplitter::handle {{ background-color: {handleColor}; }} 
            QSplitter::handle:hover {{ background-color: #464646; }}
        ''')
        self.setOpaqueResize(True) 
        
    def createHandle(self):
        return CustomSplitterHandle(self.orientation(), self)   
        

class BaseDialog(QtWidgets.QDialog):
    pass
    

class WarningDialog(QtWidgets.QDialog):
    
    GLOBAL_POS = None
    
    def __init__(self, title='Delete', message='abcd', parent=None):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.setWindowFlags(QtCore.Qt.Tool)
        self.resize(350, 100)
                          
        self.setStyleSheet('''
            
            QDialog { background-color: #373737;}

            QPushButton {background: #4B4B4B; color: white; border: none; min-width: 90px; min-height: 35px; border-radius: 15px;}
            QPushButton:hover {background: #5C5C5C;}
            QPushButton:pressed {background: #464646;}
            QPushButton:disabled {color: #A0A0A0;}
     
            ''') 
        
        self._createWidget(message)
        self._createLayouts()
        self._createConnections()
        if WarningDialog.GLOBAL_POS:
            self.move(WarningDialog.GLOBAL_POS)
            
            
    def _createWidget(self, message):
        self.okButton = QtWidgets.QPushButton('Ok')
        self.cancelButton = QtWidgets.QPushButton('Cancel')
        self.okButton.setDefault(True) 
        self.cancelButton.setAutoDefault(False) 
        
        self.warningLabel = QtWidgets.QLabel()
        self.warningLabel.setPixmap(QtGui.QPixmap('linkIcons:warning.png').scaled(
                                    40, 40, QtCore.Qt.KeepAspectRatio, QtCore.Qt.SmoothTransformation))
        self.textLabel = QtWidgets.QLabel(message)
        self.textLabel.setWordWrap(True)
        self.textLabel.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
        
        
    def _createLayouts(self):
        mainLayout = QtWidgets.QVBoxLayout(self) 
        labelLayout = QtWidgets.QHBoxLayout()
        labelLayout.setSpacing(20)
        labelLayout.addWidget(self.warningLabel)
        labelLayout.addWidget(self.textLabel)

        buttonsLayout = QtWidgets.QHBoxLayout()
        buttonsLayout.setSpacing(5)
        buttonsLayout.addStretch()
        buttonsLayout.addWidget(self.okButton)
        buttonsLayout.addWidget(self.cancelButton)
        
        mainLayout.addLayout(labelLayout)
        mainLayout.addLayout(buttonsLayout)
        mainLayout.addStretch()
        
    
    def _createConnections(self):
        self.cancelButton.clicked.connect(self.reject)
        self.okButton.clicked.connect(self.accept)
        
        
    def reject(self):
        self.__class__.GLOBAL_POS = self.pos()
        super().reject()

    def accept(self):
        self.__class__.GLOBAL_POS = self.pos()
        super().accept()

        
    def closeEvent(self, event):
        self.__class__.GLOBAL_POS = self.pos()
        super().closeEvent(event)    
        
        
    def showEvent(self, event):
        super().showEvent(event)
        self.activateWindow()
        self.raise_()
  

class InputDialog(QtWidgets.QDialog):
    
    GLOBAL_POS = None
    
    def __init__(self, baseText='text', title='Title', message='abcd', checkBaseName=True, parent=None):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.setWindowFlags(QtCore.Qt.Tool)
        self.resize(290, 100)
        
        self.setStyleSheet('''
            QDialog { background-color: #373737;}

            QPushButton {background: #4B4B4B; color: white; border: none; min-width: 90px; min-height: 35px; border-radius: 15px;}
            QPushButton:hover {background: #5C5C5C;}
            QPushButton:pressed {background: #464646;}
            QPushButton:disabled {color: #A0A0A0;}
            
            QMenu { background-color: #1A1A1A; border: 2px solid #363636; color: #B4B4B4;}
            QMenu::item { background-color: transparent; }
            QMenu::separator { height: 3px; background: #363636; margin-left: 15px; margin-right: 15px; }
            QMenu::item:selected { background-color: #4D4D4D; color: #F0F0F0;}
            QMenu::right-arrow { border-image: url(linkIcons:menuLeft.png); }
            QMenu::right-arrow:disabled { border-image: url(linkIcons:menuLeftDisabled.png)} 
            QMenu::item:disabled {color: #585858;}        
            
            QLineEdit {selection-background-color: #358ABB; 
                                      height: 25px; 
                                      background-color: #1C1C1C; 
                                      border: none;
                                      border-radius: 0px;
                                      padding: 3px;
                                      padding-left: 8px;
                                      padding-right: 0px; }         
            
            ''')
        self.checkBaseName = checkBaseName
        self.baseText = baseText    
        self._createWidget(message)
        self._createLayouts()
        self._createConnections()
        
        if InputDialog.GLOBAL_POS:
            self.move(InputDialog.GLOBAL_POS)
        
        
    def showEvent(self, event):
        super().showEvent(event)
        QtCore.QTimer.singleShot(0, self.setuptextLineEdit)
  
    
    def setuptextLineEdit(self):
        if self.baseText:
            self.textLineEdit.setText(self.baseText)
            
            self.activateWindow()
            self.raise_()
            self.textLineEdit.setFocus()
            self.textLineEdit.selectAll()  

                       
    def _createWidget(self, message):
        self.messageLabel = QtWidgets.QLabel(message)
        self.textLineEdit = QtWidgets.QLineEdit()
        self.textLineEditAction = self.textLineEdit.addAction(QtGui.QIcon('linkIcons:close.png'), QtWidgets.QLineEdit.TrailingPosition)
        
        nameValidator = QtGui.QRegularExpressionValidator(QtCore.QRegularExpression(r'^[a-zA-Z_][a-zA-Z0-9_]*$'))
        self.textLineEdit.setValidator(nameValidator)
    
        self.okButton = QtWidgets.QPushButton('Ok')
        self.cancelButton = QtWidgets.QPushButton('Cancel')
        self.okButton.setDefault(True) 
        self.cancelButton.setAutoDefault(False) 
        
        
    def _createLayouts(self):
        mainLayout = QtWidgets.QVBoxLayout(self) 
        mainLayout.addWidget(self.messageLabel)
        mainLayout.addWidget(self.textLineEdit)
        buttonsLayout = QtWidgets.QHBoxLayout()
        buttonsLayout.setSpacing(5)
        buttonsLayout.addStretch()
        buttonsLayout.addWidget(self.okButton)
        buttonsLayout.addWidget(self.cancelButton)
        mainLayout.addStretch()
        mainLayout.addLayout(buttonsLayout)
        
        
    def _createConnections(self):
        self.textLineEditAction.triggered.connect(self.textLineEdit.clear)
        self.cancelButton.clicked.connect(self.reject)
        self.okButton.clicked.connect(self.accept)
        
        
    def reject(self):
        self.__class__.GLOBAL_POS = self.pos()
        super().reject()

    def accept(self):
        self.__class__.GLOBAL_POS = self.pos()
        super().accept()

        
    def closeEvent(self, event):
        self.__class__.GLOBAL_POS = self.pos()
        super().closeEvent(event)
        
        
    def exec(self) -> 'str|None':
        if super().exec() == QtWidgets.QDialog.Accepted:
            newText = self.textLineEdit.text()
            if newText:# and self.baseText != newText:
                if self.checkBaseName:
                    if self.baseText != newText:
                        return newText
                else:
                    return newText
        return None  
        
        
class ComboBox(QtWidgets.QComboBox):
    
    def __init__(self, parent=None):
        super().__init__(parent)
        
    def wheelEvent(self, event: QtGui.QWheelEvent):
        event.ignore()
        
        

class _CollapsibleHeader(QtWidgets.QWidget):
    clicked = QtCore.Signal()
    COLLAPSED_PIXMAP = QtGui.QPixmap('linkIcons:leftHoverSource.png').scaled(20, 20)
    EXPANDED_PIXMAP = QtGui.QPixmap('linkIcons:downHoverSource.png').scaled(20, 20)
    
    def __init__(self, text, parent=None):
        super().__init__(parent)

        self.setAttribute(QtCore.Qt.WA_StyledBackground, True) 
        self.setBackgroundColor()
        
        self.createWidgets()
        self.createLayouts()
        self.setText(text)
        self.setExpanded(True) 
    
    def createWidgets(self):
        self.iconLabel = QtWidgets.QLabel()
        self.textLabel = QtWidgets.QLabel()
        self.textLabel.setAttribute(QtCore.Qt.WA_TransparentForMouseEvents)
        
    def createLayouts(self):
        self.mainLayout = QtWidgets.QHBoxLayout(self)
        self.mainLayout.setContentsMargins(4, 4, 4, 4)
        self.mainLayout.addWidget(self.iconLabel)
        self.mainLayout.addWidget(self.textLabel)
        self.mainLayout.addStretch()
        
    def setText(self, text):
        self.textLabel.setText('<b>{0}</b>'.format(text))
        self.textLabel.setStyleSheet('font-size: 14px; color: #D2D2D2;') 
        
    def setBackgroundColor(self, color=None, hoverColor=None):
        self.setObjectName('HeadWidget')
        
        if not color: color = '#4B4B4B'
        if not hoverColor: hoverColor = '#5C5C5C'
            
        
        styleSheet = '''
        #HeadWidget {{
            background-color: {0};
            border-radius: 0px;
        }}
        #HeadWidget:hover {{
            background-color: {1};
        }}
        '''.format(color, hoverColor)
        
        self.setStyleSheet(styleSheet)

  
    def isExpanded(self):
        return self._expanded
        
    def setExpanded(self, expanded):
        self._expanded = expanded
        
        if self._expanded:
            self.iconLabel.setPixmap(self.EXPANDED_PIXMAP)
        else:
            self.iconLabel.setPixmap(self.COLLAPSED_PIXMAP)
            
    def mouseReleaseEvent(self, event):
        if event.button() == QtCore.Qt.LeftButton:
            self.clicked.emit()
        super().mouseReleaseEvent(event)
        
          
    
class CollapsibleWidget(QtWidgets.QWidget):
    
    openClicked = QtCore.Signal()
    
    def __init__(self, text, parent=None):
        super().__init__(parent)
        self.setStyleSheet(''' 
                            #lineShape {border-top: 1px solid #282828;}
                            #bodyWdg { background-color:#3C3C3C; }
                           ''')
        
        self.lineShape = QtWidgets.QFrame()
        self.lineShape.setObjectName('lineShape')
        self.lineShape.setFrameShape(QtWidgets.QFrame.HLine)
        
        self.headerWdg = _CollapsibleHeader(text)
        self.headerWdg.clicked.connect(self.onHeaderClicked)
        
        self.bodyWdg = QtWidgets.QWidget()
        self.bodyWdg.setObjectName('bodyWdg')
        self.bodyWdg.setAttribute(QtCore.Qt.WA_StyledBackground, True) 
        
        self.bodyLayout = QtWidgets.QVBoxLayout(self.bodyWdg)
        self.bodyLayout.setContentsMargins(20, 8, 20, 8)
        self.bodyLayout.setSpacing(3)
        
        self.mainLayout = QtWidgets.QVBoxLayout(self)
        self.mainLayout.setContentsMargins(0, 0, 0, 0)
        self.mainLayout.setSpacing(3)
        self.mainLayout.addWidget(self.headerWdg)
        self.mainLayout.addWidget(self.bodyWdg)
        #self.mainLayout.addWidget(self.lineShape)
     
        
        self.setExpanded(False)
        
    def addWidget(self, widget):
        self.bodyLayout.addWidget(widget)
        
    def addLayout(self, layout):
        self.bodyLayout.addLayout(layout)
        
    def setHeaderBackgroundColor(self, color, hoverColor):
        self.headerWdg.setBackgroundColor(color, hoverColor)    
        
    def setExpanded(self, expanded): 
        self.headerWdg.setExpanded(expanded) 
        self.bodyWdg.setVisible(expanded)
 
    def onHeaderClicked(self):
        value = self.headerWdg.isExpanded()
        self.setExpanded(not value)
        if not value:
            self.openClicked.emit()
        
        
def createBaseQSpinBox(value:int=0, _max=100, _min=0, stretch=True) -> QtWidgets.QSpinBox:
    spinBox = QtWidgets.QSpinBox()
    spinBox.setMinimumWidth(60)
    spinBox.setMinimumHeight(30)
    if stretch:
        spinBox.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
    spinBox.setRange(_min, _max)
    spinBox.setValue(value)
    spinBox.setAlignment(QtCore.Qt.AlignCenter)
    spinBox.setButtonSymbols(QtWidgets.QSpinBox.ButtonSymbols.NoButtons) 
    return spinBox
    
    
    
        
if __name__ == '__main__':
    r = InputDialog(baseText='text', title='Title', message='abcd').exec()
    print(r)
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        

        
    