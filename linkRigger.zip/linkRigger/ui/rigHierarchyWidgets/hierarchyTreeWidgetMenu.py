from PySide6 import QtWidgets
from PySide6 import QtGui
from PySide6 import QtCore
from maya    import cmds

from linkRigger.ui.rigHierarchyWidgets import utils

class HierarchyTreeWidgetMenu(QtWidgets.QMenu):
    
    selectinSceneTriggered = QtCore.Signal()
    selectinTreeTriggered  = QtCore.Signal()
    mirrorTriggered        = QtCore.Signal()
    duplicateTriggered     = QtCore.Signal()
    
    symmetrizeMenuTriggered = QtCore.Signal(QtGui.QAction)

    deleteTriggered  = QtCore.Signal()
    refreshTriggered = QtCore.Signal()
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.treeWidget = parent
        self._createActions()
        self._createConnections()
           
           
    def _createActions(self):
        self.selectinSceneAction = QtGui.QAction(QtGui.QIcon('linkIcons:select.png'), 'Select in Scene', self)
        self.selectinTreeAction  = QtGui.QAction(QtGui.QIcon('linkIcons:selectinTree.png'), 'Select in Tree', self)
        self.mirrorAction        = QtGui.QAction(QtGui.QIcon('linkIcons:mirror.png'), 'Mirror',  self)
        
        self.duplicateAction     = QtGui.QAction(QtGui.QIcon('linkIcons:duplicate.png'), 'Duplicate',  self)
        
        self.symmetrizeXAction = QtGui.QAction('X', self)
        self.symmetrizeXAction.setData('x')
        self.symmetrizeYAction = QtGui.QAction('Y', self)
        self.symmetrizeYAction.setData('y')
        self.symmetrizeZAction = QtGui.QAction('Z', self)
        self.symmetrizeZAction.setData('z')
        
        self.deleteAction        = QtGui.QAction(QtGui.QIcon('linkIcons:delete.png'), 'Delete',  self)
        self.refreshAction       = QtGui.QAction(QtGui.QIcon('linkIcons:refresh.png'), 'Refresh',  self)

        self.addAction(self.selectinSceneAction)
        self.addAction(self.selectinTreeAction)
        self.addSeparator()
        self.addAction(self.mirrorAction)
        self.addAction(self.duplicateAction)

        self.symmetrizeMenu = self.addMenu(QtGui.QIcon('linkIcons:symmetry.png'), 'Symmetrize')
        self.symmetrizeMenu.addAction(self.symmetrizeXAction)
        self.symmetrizeMenu.addAction(self.symmetrizeYAction)
        self.symmetrizeMenu.addAction(self.symmetrizeZAction)
        
        self.addSeparator()
        self.addAction(self.deleteAction)
        self.addSeparator()
        self.addAction(self.refreshAction)
     
    
    def _createConnections(self):
        self.aboutToShow.connect(self._updateActionsState) 
        
        self.selectinSceneAction.triggered.connect(self.selectinSceneTriggered.emit)
        self.selectinTreeAction.triggered.connect(self.selectinTreeTriggered.emit)
        self.mirrorAction.triggered.connect(self.mirrorTriggered.emit)
        self.duplicateAction.triggered.connect(self.duplicateTriggered.emit)
        
        self.symmetrizeMenu.triggered.connect(self.symmetrizeMenuTriggered.emit)
        
        self.deleteAction.triggered.connect(self.deleteTriggered.emit)
        self.refreshAction.triggered.connect(self.refreshTriggered.emit)
        
        
    def _updateActionsState(self):
        if self.treeWidget.characterExists and self.treeWidget.characterManager.hasRebuild:
            hasRebuild = True
        else:
            hasRebuild = False
            
            
        selItems = self.treeWidget.selectedItems()
        isComponentItem:bool = bool(selItems) and all(utils.isComponentItem(item) for item in selItems) and hasRebuild
        
        self.selectinSceneAction.setEnabled(bool(selItems) and hasRebuild)
        self.mirrorAction.setEnabled(isComponentItem)
        self.duplicateAction.setEnabled(isComponentItem)
        self.symmetrizeMenu.setEnabled(isComponentItem)
        self.deleteAction.setEnabled(isComponentItem)
        
        selectedUUIDs = cmds.ls(sl=True, uid=True, type='transform')
        if not selectedUUIDs:
            self.selectinTreeAction.setEnabled(False)
            return
        itemsUUID = {item.data(0, QtCore.Qt.UserRole) for item in self.treeWidget.getAllItems()}
        self.selectinTreeAction.setEnabled(any(uuid in itemsUUID for uuid in selectedUUIDs) and hasRebuild)
        
        
        
        
        

                
        
        
        



