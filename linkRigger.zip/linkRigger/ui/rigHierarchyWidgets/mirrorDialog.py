from maya import cmds
from maya.api import OpenMaya as om2

from PySide6 import QtWidgets
from PySide6 import QtGui
from PySide6 import QtCore

from linkRigger.ui import widgets

MIRROR_SIDE = {'L':'R', 
               'left':'right', 
               'l':'r',
               'Left':'Right',
               'lt':'rt',
               'LEFT':'RIGHT'
               }

class MirrorDialog(QtWidgets.QDialog):
    
    GLOBAL_POS = None
    
    def __init__(self, parent=None, components:list=None):
        super().__init__(parent)
        self.setWindowTitle('Mirror Components')
        self.setWindowFlags(QtCore.Qt.Tool)
        self.resize(290, 100)
        
        self.setAttribute(QtCore.Qt.WA_DeleteOnClose)
                          
        self.setStyleSheet('''
            QDialog { background-color: #373737;}
            
            
            QPushButton {background: #4B4B4B; color: white; border: none; min-width: 90px; min-height: 35px; border-radius: 15px;}
            QPushButton:hover {background: #5C5C5C;}
            QPushButton:pressed {background: #464646;}
            QPushButton:disabled {color: #A0A0A0;}
            
            QMenu { background-color: #1A1A1A; border: 2px solid #363636; color: #B4B4B4;}
            QMenu::item { background-color: transparent; }
            QMenu::separator { height: 3px; background: #363636; margin-left: 15px; margin-right: 15px; }
            QMenu::item:selected { background-color: #4D4D4D; color: #F0F0F0;}
            QMenu::right-arrow { border-image: url(linkIcons:menuLeft.png); }
            QMenu::right-arrow:disabled { border-image: url(linkIcons:menuLeftDisabled.png)} 
            QMenu::item:disabled {color: #585858;}
                           
            QScrollBar:vertical { border: none; width: 10px; margin: 0px 0 0px 0; }
            QScrollBar::handle:vertical { background: #5C5C5C; min-height: 20px; border-radius: 5px; }
            QScrollBar::handle:vertical:hover { background: #656565; }
            QScrollBar::handle:vertical:pressed {background: #6E6E6E; }
            QScrollBar::sub-line:vertical,
            QScrollBar::add-line:vertical { background: none; height: 0; }
            QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {background: #1A1A1A; }
                           
            QComboBox { background-color: #4B4B4B; height: 30px; width: 60px; border-radius: 0px; padding-left: 8px;}
            QComboBox:hover { background-color: #5C5C5C;}
            QComboBox QAbstractItemView { border: 6px solid #1A1A1A; background-color: #1A1A1A; selection-background-color: #4D4D4D; }
            
            QComboBox::drop-down { border: none; background: transparent; width: 25px; }
            QComboBox::down-arrow {border-image: url(linkIcons:downHoverSource.png); width: 20px; height: 20px; }
        
            QComboBox:focus { background-color: #4B4B4B;  padding-left: 8px;}
            ''')
        
        self._createWidget()
        self._createLayouts()
        self._createConnections()
        self.components = components
        self.setupSide()
        
        
        if MirrorDialog.GLOBAL_POS:
            self.move(MirrorDialog.GLOBAL_POS)
            
    def setupSide(self):
        if not self.components:
            return
        setupSide:'str|None' = MIRROR_SIDE.get(self.components[0].side)
        if setupSide:
            self.sideComboBox.setCurrentText(setupSide)
        
        
    def _createWidget(self):
        delegate = widgets.CustomDelegate(self, 30)
        
        self.mirrorAxisComboBox = QtWidgets.QComboBox()
        self.mirrorAxisComboBox.addItems(['x', 'y', 'z'])
        self.mirrorAxisComboBox.setItemDelegate(delegate)
        
        self.sideComboBox = QtWidgets.QComboBox()
        self.sideComboBox.setItemDelegate(delegate)
        self.sideComboBox.addItems(['L', 'left', 'l', 'Left', 'lt', 'LEFT', 'R', 'right', 'r', 'Right', 'rt', 'RIGHT', 'c', 'C', 'm', 'M', 'mid', 'MID', 'Mid'])
        
        #self.duplicateCheckBox = QtWidgets.QCheckBox('Duplicate')
        self.okButton = QtWidgets.QPushButton('Ok')
        self.cancelButton = QtWidgets.QPushButton('Cancel')
        self.okButton.setDefault(True) 
        self.cancelButton.setAutoDefault(False) 
        
        
    def _createLayouts(self):
        mainLayout = QtWidgets.QVBoxLayout(self)
        
        checkBoxLayout = QtWidgets.QHBoxLayout()
        checkBoxLayout.setSpacing(4)
        checkBoxLayout.addWidget(QtWidgets.QLabel('Axis'))
        checkBoxLayout.addWidget(self.mirrorAxisComboBox)
        checkBoxLayout.addWidget(QtWidgets.QLabel('Side'))
        checkBoxLayout.addWidget(self.sideComboBox)
        
        buttonsLayout = QtWidgets.QHBoxLayout()
        buttonsLayout.addStretch()
        buttonsLayout.setSpacing(5)
        buttonsLayout.addWidget(self.okButton)
        buttonsLayout.addWidget(self.cancelButton)
        
        mainLayout.addLayout(checkBoxLayout)
        mainLayout.addStretch()
        mainLayout.addLayout(buttonsLayout)
        
        
    def _createConnections(self):
        self.cancelButton.clicked.connect(self.close)
        self.okButton.clicked.connect(self._mirrorComponents)
        
     
    def _mirrorComponents(self):
        axis = self.mirrorAxisComboBox.currentText()
        side = self.sideComboBox.currentText()

        ComponentTreeWidget = self.parent()
        if ComponentTreeWidget is not None and hasattr(ComponentTreeWidget, 'mirrorSelectedComponents'):
            ComponentTreeWidget.mirrorSelectedComponents(self.components, axis, side)
        self.close()
        
        
    def reject(self):
        self.__class__.GLOBAL_POS = self.pos()
        super().reject()

    def accept(self):
        self.__class__.GLOBAL_POS = self.pos()
        super().accept()

        
    def closeEvent(self, event):
        self.__class__.GLOBAL_POS = self.pos()
        super().closeEvent(event)
        
    def showEvent(self, event):
        super().showEvent(event)
        self.activateWindow()
        self.raise_()
        
        

        
        

if __name__ == '__main__':
    m = MirrorDialog()
    m.show()
