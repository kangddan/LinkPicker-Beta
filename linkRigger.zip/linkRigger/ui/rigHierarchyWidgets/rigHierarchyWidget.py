from maya import cmds
from maya.api import OpenMaya as om2

from PySide6 import QtWidgets
from PySide6 import QtGui
from PySide6 import QtCore

from linkRigger.core import meta
from linkRigger import components
from linkRigger.utils import guideUtils

from linkRigger.ui.rigHierarchyWidgets import hierarchyTreeWidget


class SearchWidget(QtWidgets.QLineEdit):
    
    def __init__(self, parent=None):
        super().__init__(parent)
        
        self.setStyleSheet('''
                           QMenu { background-color: #1A1A1A; border: 2px solid #363636; color: #B4B4B4;}
                           QMenu::item { background-color: transparent; }
                           QMenu::separator { height: 3px; background: #363636; margin-left: 15px; margin-right: 15px; }
                           QMenu::item:selected { background-color: #4D4D4D; color: #F0F0F0;}
                           QMenu::right-arrow { border-image: url(linkIcons:menuLeft.png); }
                           QMenu::right-arrow:disabled { border-image: url(linkIcons:menuLeftDisabled.png)} 
                           QMenu::item:disabled {color: #585858;}
                           
                           QLineEdit {selection-background-color: #358ABB; 
                                      height: 25px; 
                                      background-color: #1C1C1C; 
                                      border: none;
                                      border-radius: 0px;
                                      padding: 3px;
                                      padding-left: 35px;
                                      padding-right: 0px;
                                      font-style: italic;
                                      font-family: Arial; }
                
                           ''')
        self.setPlaceholderText('Search...')
        self.pathLineEditAction = self.addAction(QtGui.QIcon('linkIcons:close.png'), QtWidgets.QLineEdit.TrailingPosition)
        
        self._createWidgets()
        self._createLayouts()
        self._createConnections()
        
    
    def _createWidgets(self):
        self.iconLabel = QtWidgets.QLabel()
        self.iconLabel.setPixmap(QtGui.QPixmap('linkIcons:search.png'))    
        
    def _createLayouts(self):
        mainLayout = QtWidgets.QHBoxLayout(self)
        mainLayout.addWidget(self.iconLabel)
        mainLayout.setContentsMargins(5, 0, 0, 0)
        mainLayout.addStretch()
        
        
    def _createConnections(self):
        self.pathLineEditAction.triggered.connect(self.clear)


class RigHierarchyWidget(QtWidgets.QWidget):
    
    viewModeValue = QtCore.Signal(list)
    
    def __init__(self, parent=None):
        super().__init__(parent)
        
        self.setObjectName('RigHierarchyWidget')
        self.setAttribute(QtCore.Qt.WA_StyledBackground, True) 
        self.setStyleSheet(''' 
                           
                           QMenu { background-color: #1A1A1A; border: 2px solid #363636; color: #B4B4B4;}
                           QMenu::item { background-color: transparent; }
                           QMenu::separator { height: 3px; background: #363636; margin-left: 15px; margin-right: 15px; }
                           QMenu::item:selected { background-color: #4D4D4D; color: #F0F0F0;}
                           QMenu::right-arrow { border-image: url(linkIcons:menuLeft.png); }
                           QMenu::right-arrow:disabled { border-image: url(linkIcons:menuLeftDisabled.png)} 
                           QMenu::item:disabled {color: #585858;}
                           
                           #RigHierarchyWidget { background-color: #373737;} 
                           #rigHierarchyWidgetTitle { font-size: 16px; font-weight: bold; }
                           
                           #panelButton {background: #505050;  border: none;  border-radius: 12px; background-image: url('linkIcons:down.png');}
                           #panelButton:hover {background: #646464; background-image: url('linkIcons:downHight.png');}
                           #panelButton:pressed {background: #545A99; background-image: url('linkIcons:downHight.png');}
                           #panelButton::menu-indicator, #targetButton::menu-indicator { image: none; width: 0px; }
                           
                           #subHierarchyWidgetWidget { background-color: #202020;} 
                           
                           #listModeButton, #treeModeButton, #targetButton, #showAxisButton {background: #2D2D2D;  border: none;  border-radius: 4px; }
                           #listModeButton:hover, #treeModeButton:hover, #targetButton:hover, #showAxisButton:hover {background: #393939; }
                           #listModeButton:pressed, #treeModeButton:pressed, #targetButton:pressed, #showAxisButton:pressed {background: #545A99; }
                           #listModeButton:checked, #treeModeButton:checked, #targetButton:checked, #showAxisButton:checked {background: #545A99; }
                           
                           #viewslider::groove:horizontal {border: none; height: 5px; background-color: #0F0F0F; }
                           #viewslider::handle:horizontal {background-color: #D3D3D3; 
                                                               width: 8px; 
                                                               margin: -4px 0 -4px 0;
                                                               border-radius: 0px;}
                                                               
                           #viewslider::sub-page:horizontal {background-color: #757BC3; }
               
                           

                           ''')
                           
        self._createMenu()
        self._createWidgets()
        self._createLayouts()
        self._createConnections()
        
        
    def _createMenu(self):
        self.panelMenu = QtWidgets.QMenu(self)
                                       
        self.paneActionGroup = QtGui.QActionGroup(self)

        self.view1Action = QtGui.QAction(QtGui.QIcon('linkIcons:view1.png'), 'View 1')
        self.view1Action.setData(1)
        self.view2Action = QtGui.QAction(QtGui.QIcon('linkIcons:view2.png'), 'View 2')
        self.view2Action.setData(2)
        self.view3Action = QtGui.QAction(QtGui.QIcon('linkIcons:view3.png'), 'View 3')
        self.view3Action.setData(3)
        self.panelMenu.addAction(self.view1Action)
        self.panelMenu.addAction(self.view2Action)
        self.panelMenu.addAction(self.view3Action)
        
        self.paneActionGroup.addAction(self.view1Action)
        self.paneActionGroup.addAction(self.view2Action)
        self.paneActionGroup.addAction(self.view3Action)
        
        self.paneActionGroup.triggered.connect(self.updateViewMode)
        
        # alignMenu
        self.alignMenu = QtWidgets.QMenu() 
        #self.alignMenu.setTearOffEnabled(True)
        self.alignMenu.setStyleSheet(self.panelMenu.styleSheet())
        self.alignActionGroup = QtGui.QActionGroup(self) 
        
        for align in ['World Rotation', 'X', 'Y', 'Z', '-X', '-Y', '-Z']:
            alignAction = QtGui.QAction(align)
            if align == 'X':
                self.alignMenu.addSeparator()
            self.alignMenu.addAction(alignAction)
            self.alignActionGroup.addAction(alignAction)

        
        self.alignActionGroup.triggered.connect(self.alignSelectedGuides)
            
            
    def alignSelectedGuides(self, action):
        text = action.text()
        if text == 'World Rotation':
            
            return
        guideUtils.alignSelectedGuides(text.lower())


    def updateViewMode(self, action):
        index = action.data()
        if index == 1:
            self.viewModeValue.emit([200, 600, 0])
        elif index == 2:
            self.viewModeValue.emit([0, 400, 400])
        elif index == 3:
            self.viewModeValue.emit([150, 400, 250])
            
        
    def _createWidgets(self):
        self.rigHierarchyWidgetTitle = QtWidgets.QLabel('HIERARCHY')
        self.rigHierarchyWidgetTitle.setObjectName('rigHierarchyWidgetTitle')
        self.hierarchyTreeWidget = hierarchyTreeWidget.HierarchyTreeWidget()
        
        self.searchWidget = SearchWidget()
        
        self.panelButton = QtWidgets.QPushButton('')
        self.panelButton.setFixedSize(24, 24) 
        self.panelButton.setObjectName('panelButton')
        self.panelButton.setMenu(self.panelMenu)  
        
        
        self.subHierarchyWidgetWidget = QtWidgets.QWidget()
        self.subHierarchyWidgetWidget.setObjectName('subHierarchyWidgetWidget')
        subMainLayout = QtWidgets.QVBoxLayout(self.subHierarchyWidgetWidget)
        subMainLayout.setContentsMargins(0, 0, 0, 0)
        subMainLayout.setSpacing(2)
        subMainLayout.addWidget(self.hierarchyTreeWidget)
        
        # scale value slider
        self.viewslider = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        self.viewslider.setFixedWidth(100) 

        self.viewslider.setObjectName('viewslider')
        self.viewslider.setRange(2, 10)
        self.viewslider.setValue(3) 
        
        
        # guide axis button
        self.showAxisButton = QtWidgets.QPushButton(QtGui.QIcon('linkIcons:axis.png'), '')
        self.showAxisButton.setToolTip('Show/Hide Axis')
        self.showAxisButton.setObjectName('showAxisButton')
        self.showAxisButton.setFixedSize(28, 28)
        
        # guide target button
        self.targetButton = QtWidgets.QPushButton(QtGui.QIcon('linkIcons:guideTarget.png'), '')
        self.targetButton.setToolTip('Align')
        self.targetButton.setObjectName('targetButton')
        self.targetButton.setFixedSize(28, 28)
        self.targetButton.setMenu(self.alignMenu) 
        # view mode buttons 
        self.treeModeButton = QtWidgets.QPushButton(QtGui.QIcon('linkIcons:treeMode.png'), '')
        self.treeModeButton.setToolTip('Tree View')
        self.treeModeButton.setObjectName('treeModeButton')
        self.treeModeButton.setCheckable(True)
        self.treeModeButton.setFixedSize(28, 28)
        
        self.listModeButton = QtWidgets.QPushButton(QtGui.QIcon('linkIcons:listMode.png'), '')
        self.listModeButton.setToolTip('List View')
        self.listModeButton.setObjectName('listModeButton')
        self.listModeButton.setCheckable(True)
        self.listModeButton.setFixedSize(28, 28)

        self.viewModeButtonGroup = QtWidgets.QButtonGroup()
        self.viewModeButtonGroup.setExclusive(True) 
        self.viewModeButtonGroup.addButton(self.treeModeButton, 0)
        self.viewModeButtonGroup.addButton(self.listModeButton, 1)
        
        self.treeModeButton.setChecked(True) # base mode
        
        toolsLayout = QtWidgets.QHBoxLayout()
        toolsLayout.setContentsMargins(2, 0, 5, 2)
        toolsLayout.setSpacing(2)
        toolsLayout.addWidget(self.treeModeButton)
        toolsLayout.addWidget(self.listModeButton)
        spacer = QtWidgets.QSpacerItem(15, 0, QtWidgets.QSizePolicy.Fixed, QtWidgets.QSizePolicy.Minimum)
        toolsLayout.addSpacerItem(spacer)
        toolsLayout.addWidget(self.showAxisButton)
        toolsLayout.addWidget(self.targetButton)
        toolsLayout.addStretch()
        toolsLayout.addWidget(self.viewslider)
        
        
        subMainLayout.addLayout(toolsLayout)
        
        
    def _createLayouts(self):
        mainLayout = QtWidgets.QVBoxLayout(self)
        mainLayout.setContentsMargins(0, 0, 0, 0)
        mainLayout.setSpacing(5)
        titleLayout = QtWidgets.QHBoxLayout()
        titleLayout.setContentsMargins(5, 0, 5, 0)
        titleLayout.addWidget(self.rigHierarchyWidgetTitle)
        titleLayout.addWidget(self.searchWidget)
        titleLayout.addWidget(self.panelButton)
    
        mainLayout.addLayout(titleLayout)
        mainLayout.addWidget(self.subHierarchyWidgetWidget)
        
        
    def _createConnections(self):
        self.searchWidget.textChanged.connect(self.filterListItems)
        self.hierarchyTreeWidget.hierarchyTreeWidgetMenu.refreshTriggered.connect(self.searchWidget.clear)
        self.viewModeButtonGroup.buttonClicked.connect(self.setViewMode)
        self.showAxisButton.clicked.connect(self.showAllGuideAxis)
        self.viewslider.valueChanged.connect(self.setViewItemHight)
        
        
    def setViewItemHight(self, value:int):
        newValue = value * 10
        hierarchyTreeWidget.HierarchyTreeWidget.ITEM_HIGHT = newValue
        #self.hierarchyTreeWidget.setIndentation(26)
        
        if not self.hierarchyTreeWidget.characterExists:
            return
        for item in self.hierarchyTreeWidget.getAllItems(): 
            item.setSizeHint(0, QtCore.QSize(100, newValue))
        
        
        
    def showAllGuideAxis(self):
        
        if self.hierarchyTreeWidget.characterExists:
            components = self.hierarchyTreeWidget.characterManager.componentsManager.listComponentNodes()
            if not components:
                return
            
            isVis = components[0].guideLayer.guideAxisVis
            for c in components:
                if isVis:
                    c.hideGuidesAxis()
                else:
                    c.showGuidesAxis()
                
                

    def setViewMode(self, button:QtWidgets.QPushButton):
        if not self.hierarchyTreeWidget.characterExists or self.hierarchyTreeWidget.characterManager.hasBuild:
            return
        buttonId = self.viewModeButtonGroup.id(button) 

        if buttonId == 0 and self.hierarchyTreeWidget.viewMode == 1:
            self.hierarchyTreeWidget.viewMode = 0
            self.hierarchyTreeWidget.buildTreeWithHierarchy()
        elif buttonId == 1 and self.hierarchyTreeWidget.viewMode == 0:
            self.hierarchyTreeWidget.viewMode = 1
            self.hierarchyTreeWidget.buildTreeFlat()
            
            
    def setViewToolsState(self):
        if not self.hierarchyTreeWidget.characterExists or self.hierarchyTreeWidget.characterManager.hasBuild:
            self.treeModeButton.setEnabled(False)
            self.listModeButton.setEnabled(False)
            self.showAxisButton.setEnabled(False)
            self.targetButton.setEnabled(False)
        elif self.hierarchyTreeWidget.characterExists:
            self.treeModeButton.setEnabled(True)
            self.listModeButton.setEnabled(True)
            self.showAxisButton.setEnabled(True)
            self.targetButton.setEnabled(True)
        
        
    def setCharacterManager(self, characterManager:'CharacterManager'):
        self.hierarchyTreeWidget.setCharacterManager(characterManager)
        '''
        After rebuilding the tree, reapply the current filter to improve user experience.
        '''
        self.filterListItems(self.searchWidget.text())
        self.setViewToolsState()
        
        
        
        
    def filterListItems(self, text):
        '''
        Filter items in hierarchyTreeWidget based on the input text.
        Only matching items remain visible, and their parent items are also shown.
        '''
        text = text.lower()
        items = self.hierarchyTreeWidget.getAllItems()

        if not text:
            for item in items:
                item.setHidden(False)
                item.setSelected(False)
            return

        for item in items:
            match = text in item.text(0).lower()
            item.setHidden(not match)
            item.setSelected(match)

            if match:
                parent = item.parent()
                while parent:
                    parent.setHidden(False) 
                    parent = parent.parent()
    
    
    def insertRefreshHierarchyTree(self):
        '''
        Notify hierarchyTreeWidget to refresh when adding a new component.
        '''
        self.hierarchyTreeWidget.insertRefreshHierarchyTree()
        self.filterListItems(self.searchWidget.text())
        
        
    def refreshHierarchyTreeHandle(self):
        self.hierarchyTreeWidget.refreshHierarchyTree()
        self.setViewToolsState()
        self.filterListItems(self.searchWidget.text())
        
            
        
        
if __name__ == '__main__':
    r = RigHierarchyWidget()
    r.show()
    
    sceneCharacter = meta.listSceneMetaNodes(ofType=components.CharacterManager)[0]
    r.hierarchyTreeWidget.setCharacterManager(sceneCharacter)

    
    