from maya import cmds
from maya.api import OpenMaya as om2

from PySide6 import QtWidgets
from PySide6 import QtGui
from PySide6 import QtCore

from linkRigger.core import meta
from linkRigger import components
from linkRigger.core import nodes

def guideParentMap(component:'Component') -> dict:
    '''
    Returns a mapping of GuideNode's guideTag to its parent's guideTag.
    If the parent is not a guide (e.g., rootGuide), it will be set to None.
    '''
    parentMap  = {}
    guideLayer = component.guideLayer
    guides     = guideLayer.listGuideNodes(includeRoot=True)
    
    for guide in guides:
        guideGroup = guide.groupFromGuideLayer
        parent     = cmds.listRelatives(guideGroup if guideGroup else guide.nodeName, parent=True, path=True) 
        if not parent:
            continue
        if cmds.attributeQuery('guideTag', n=parent[0], ex=True):
            parentMap[guide.guideTag] = cmds.getAttr(f'{parent[0]}.guideTag')  
        else:
            parentMap[guide.guideTag] = None
                
    return parentMap
    
    
def componentParentMap(component:'Component') -> dict:
    '''
    Returns a mapping of the component's parent and its parent guideTag.
    '''
    parentMap  = {}
    guideLayer = component.guideLayer
    
    parent      = component.metaParent()
    parentGuide = guideLayer.parentGuide

    parentMap['parentMetaId'] = parent.metaId if hasattr(parent, 'isComponent') else None
    parentMap['parentGuideTag'] = parentGuide.guideTag if parentGuide is not None else None
    return parentMap


def uuidToMetaNode(uuid:str) -> 'MetaNode|None':
    node = cmds.ls(uuid)
    if node and meta.MetaNode.isMetaNode(node[0]):
        return meta.MetaNode(node[0])
        
        
def uuidToGuideNode(uuid:str) -> 'GuideNode|None':
    node = cmds.ls(uuid)
    if node and cmds.attributeQuery('guideTag', n=node[0], ex=True):
        return nodes.GuideNode(node[0])
        

def isGuideItem(item:QtWidgets.QTreeWidgetItem) -> bool:
    return item.data(0, QtCore.Qt.UserRole + 2) == 'guide'
    
    
def isComponentItem(item:QtWidgets.QTreeWidgetItem) -> bool:
    return item.data(0, QtCore.Qt.UserRole + 2) == 'component'

  

   
    

