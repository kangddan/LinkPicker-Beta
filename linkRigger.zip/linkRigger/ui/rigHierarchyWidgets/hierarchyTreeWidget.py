from maya import cmds
from maya.api import OpenMaya as om2

from functools import partial
from PySide6 import QtWidgets
from PySide6 import QtGui
from PySide6 import QtCore

from linkRigger.ui import qtUtils, getGuideIcon, getComponentIcon
from linkRigger.core import meta
from linkRigger import components
from linkRigger.ui.rigHierarchyWidgets import hierarchyTreeWidgetMenu, utils
from linkRigger.ui.rigHierarchyWidgets import mirrorDialog


# REFACTOR: Plan to implement a custom QTreeWidgetItem class to improve data handling.
class HierarchyTreeWidgetItem(QtWidgets.QTreeWidgetItem):
    pass



class BaseTreeWidget(QtWidgets.QTreeWidget):
    
    itemsParentChanged = QtCore.Signal(QtWidgets.QTreeWidgetItem, list)
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setHeaderHidden(True)
        self.setIndentation(26)
        
        self.setSelectionMode(QtWidgets.QAbstractItemView.ExtendedSelection)
        self.setDragDropMode(QtWidgets.QAbstractItemView.InternalMove)
        self.setItemDelegate(qtUtils.CustomItemDelegate())
        self.setAlternatingRowColors(True)  
        
        self.setStyleSheet('''    
                           
                           /* QLineEdit { selection-background-color: rgba(84, 90, 153, 255); } */
                           
                           QMenu { background-color: #1A1A1A; border: 2px solid #363636; color: #B4B4B4;}
                           QMenu::item { background-color: transparent; }
                           QMenu::separator { height: 3px; background: #363636; margin-left: 15px; margin-right: 15px; }
                           QMenu::item:selected { background-color: #4D4D4D; color: #F0F0F0;}
                           QMenu::right-arrow { border-image: url(linkIcons:menuLeft.png); }
                           QMenu::right-arrow:disabled { border-image: url(linkIcons:menuLeftDisabled.png)} 
                           QMenu::item:disabled {color: #585858;}
                           
        
                           QScrollBar:vertical { border: none; width: 10px; margin: 0px 0 0px 0; }
                           QScrollBar::handle:vertical { background: #5C5C5C; min-height: 20px; border-radius: 5px; }
                           QScrollBar::handle:vertical:hover { background: #656565; }
                           QScrollBar::handle:vertical:pressed {background: #6E6E6E; }
                           QScrollBar::sub-line:vertical,
                           QScrollBar::add-line:vertical { background: none; height: 0; }
                           QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {background: #282828; }

                           QScrollBar:horizontal { border: none; height: 10px; margin: 0 0px 0 0px; }
                           QScrollBar::handle:horizontal { background: #5C5C5C; min-width: 20px; border-radius: 5px; }
                           QScrollBar::handle:horizontal:hover { background: #656565; }
                           QScrollBar::handle:horizontal:pressed {background: #6E6E6E; }
                           QScrollBar::sub-line:horizontal,
                           QScrollBar::add-line:horizontal { background: none; width: 0; }
                           QScrollBar::add-page:horizontal, QScrollBar::sub-page:horizontal {background: #282828; }
                            
                           QAbstractScrollArea::corner { background: #282828; }    
        
        
                           QTreeWidget { border: 0px solid #373737; background-color: #202020; }
                           /* QTreeWidget::item:hover { color: #FFA53F; padding-left: 0px; background-color: transparent;} */
                           QTreeWidget::item:selected { color: #FFA53F; border: none; background: transparent; padding-left: 0px;}
                           
                           QTreeWidget::item:alternate { background-color: #181818; }
                           /* QTreeWidget:focus::item:alternate { background-color: #1C1C1C; } */
                           
                           
                           QTreeWidget::branch:has-siblings:!adjoins-item { border-image: url(linkIcons:branchLine.png); }
                           QTreeWidget::branch:has-siblings:adjoins-item { border-image: url(linkIcons:branchMore.png); }
                           QTreeWidget::branch:!has-children:!has-siblings:adjoins-item { border-image: url(linkIcons:branchEnd.png);}
                           
                           QTreeWidget::branch:has-children:!has-siblings:closed,
                           QTreeWidget::branch:closed:has-children:has-siblings { border-image: none; image: url(linkIcons:leftSource.png); }
                           QTreeWidget::branch:open:has-children:!has-siblings,
                           QTreeWidget::branch:open:has-children:has-siblings { border-image: none; image: url(linkIcons:downSource.png);}  
                           /* 
                           QTreeWidget::branch:has-children:!has-siblings:closed:hover,
                           QTreeWidget::branch:closed:has-children:has-siblings:hover { border-image: none; image: url(linkIcons:leftHoverSource.png); }
                           QTreeWidget::branch:open:has-children:!has-siblings:hover,
                           QTreeWidget::branch:open:has-children:has-siblings:hover { border-image: none; image: url(linkIcons:downHoverSource.png); }
                            */
                          ''') 
        self._createMenu()                  
        self._createWidgets()
        self._createConnections()
        
        # flags
        self.cacheSelectedItems = []
        self.hasUndraggable = False
        self.startPos = None
        self.cacheHighlightedItems = []
        
        '''
        This flag prevents multiple emissions of itemsParentChanged when handling row insertions.
        It ensures that the signal is only emitted once per relevant operation.
        '''
        self.eventHandled = True
        
        
    def _createMenu(self):
        self.hierarchyTreeWidgetMenu = hierarchyTreeWidgetMenu.HierarchyTreeWidgetMenu(self)
     
    @staticmethod 
    def clearItems(items):
        for item in items:
            item.setSelected(False)
            
                    
    def keyPressEvent(self, event):
        if event.key() == QtCore.Qt.Key_F: 
            selectedItems = self.selectedItems()
            if selectedItems:
                self.scrollToItem(selectedItems[0]) 
        else:
            super().keyPressEvent(event)
            
            
    def mousePressEvent(self, event):   
        startPos = event.position().toPoint()
        self.eventHandled = True     
        
        if event.buttons() == QtCore.Qt.MouseButton.RightButton and event.modifiers() == QtCore.Qt.NoModifier:
            '''
            There is some duplicate code here because using super() and calling it again will produce a new result.
            '''
            _clickedItem   = self.itemAt(startPos)
            _selectedItems = self.selectedItems()
            if _clickedItem and _clickedItem not in _selectedItems:
                self.clearSelection()  
                _clickedItem.setSelected(True)
            elif not _clickedItem and _selectedItems:
                self.clearSelection()  
            self.hierarchyTreeWidgetMenu.exec(event.globalPosition().toPoint())
            return  
            
        super().mousePressEvent(event)
        clickedItem = self.itemAt(startPos)
        self.cacheSelectedItems = self.selectedItems()
        self.eventHandled = True   
        
        if clickedItem is None: 
            self.clearSelection()    
            
        self.hasUndraggable = any(not bool(item.flags() & QtCore.Qt.ItemIsDragEnabled) for item in self.selectedItems())
        if event.buttons() == QtCore.Qt.MouseButton.LeftButton and clickedItem is None:
            self.startPos = QtCore.QPoint(startPos.x() + 3, startPos.y() + 3)
            self.selectionBox.setGeometry(QtCore.QRect(self.startPos, QtCore.QSize()))
            self.selectionBox.show()
            
            
    def mouseMoveEvent(self, event):
        if event.buttons() == QtCore.Qt.MouseButton.LeftButton and self.startPos is not None: 
            endPos = event.position().toPoint()
            newEndPos = QtCore.QPoint(endPos.x() + 3, endPos.y() + 3)
            self.selectionBox.setGeometry(QtCore.QRect(self.startPos, newEndPos).normalized())

        if not self.hasUndraggable:
            super().mouseMoveEvent(event)
        else:
            self.setCursor(QtGui.QCursor(QtCore.Qt.ForbiddenCursor))
         
         
    def mouseReleaseEvent(self, event):
        if self.startPos is not None:
            self.selectionBox.hide()
            self.startPos = None
            
        if self.hasUndraggable: 
            self.setCursor(QtGui.QCursor(QtCore.Qt.ArrowCursor))   
            self.hasUndraggable = False 
               
        self.cacheSelectedItems = []
        super().mouseReleaseEvent(event)
                
                          
    def _createWidgets(self):
        self.selectionBox = qtUtils.SelectionBox(parent=self)
        
        self.loadingLabel = QtWidgets.QLabel(self)
        self.loadingLabel.setAlignment(QtCore.Qt.AlignCenter)
        self.loadingLabel.setStyleSheet('background-color: rgba(30, 30, 30, 150);')
        self.loadingLabel.setPixmap(QtGui.QPixmap('linkIcons:loading2.png')) 
        self.loadingLabel.setVisible(False) 

        
    def _createConnections(self):
        self.model().rowsInserted.connect(self._updateItemParent)
        
        self.itemExpanded.connect(self._onItemExpandOrCollapse)
        self.itemCollapsed.connect(self._onItemExpandOrCollapse)
        self.itemSelectionChanged.connect(self.highlightItems)
     
        
    def _updateItemParent(self, index, *args):
        ''' 
        Handles the insertion of new rows in the tree widget.
        '''
        parentItem = self.itemFromIndex(index)
        if self.eventHandled:  
            self.eventHandled = False
            self.itemsParentChanged.emit(parentItem, self.cacheSelectedItems)


    def _calculateItemWidth(self, item, depth):
        '''
        Recursively calculate the width of an item and its expanded children.
        '''
        textWidth = self.fontMetrics().horizontalAdvance(item.text(0)) 

        indentWidth = depth * self.indentation() # Calculate indentation width
        itemWidth = textWidth + indentWidth # Total width = text width + indentation width

        maxChildWidth = 0
        if item.isExpanded():
            for i in range(item.childCount()):
                childItem = item.child(i)
                maxChildWidth = max(maxChildWidth, self._calculateItemWidth(childItem, depth + 1))

        return max(itemWidth, maxChildWidth) # Return the maximum width of the item and its children
    
    
    def updateHorizontalScrollbar(self):
        '''
        Update the column width to ensure proper horizontal scrolling.
        '''
        maxWidth = 0
        for i in range(self.topLevelItemCount()):
            item = self.topLevelItem(i)
            maxWidth = max(maxWidth, self._calculateItemWidth(item, 0))
        self.setColumnWidth(0, maxWidth * 1.15) 
        #self.resizeColumnToContents(0)


    def _onItemExpandOrCollapse(self, item:QtWidgets.QTreeWidgetItem=None):
        ''' 
        Recursively expand or collapse all child items when Shift key is held.
        '''
        self.updateHorizontalScrollbar() # Update scrollbar
        if item and QtWidgets.QApplication.keyboardModifiers() == QtCore.Qt.ShiftModifier:
            self._expandAllItems(item, item.isExpanded())
        
                       
    def _expandAllItems(self, 
                        item:QtWidgets.QTreeWidgetItem, 
                        state:bool):
        ''' 
        Recursively expand or collapse all child items.
        '''
        for row in range(item.childCount()):
            childItem = item.child(row)
            childItem.setExpanded(state) 
            self._expandAllItems(childItem, state)
    
    
    def getAllItems(self) -> list:
        '''
        get all items
        '''
        iterator = QtWidgets.QTreeWidgetItemIterator(self)
        items = []
        while iterator.value():
            items.append(iterator.value())
            iterator += 1 
        return items
            
            
    @staticmethod
    def getItemChildrens(item) -> list:
        '''
        get item childrenItems
        '''
        children = []
        for i in range(item.childCount()):
            child = item.child(i)
            children.append(child)
            children.extend(BaseTreeWidget.getItemChildrens(child))
        return children
        
        
    @staticmethod    
    def getItemParents(item) -> list:
        '''
        get item parentItems
        '''
        parents = []
        parent = item.parent()
        while parent: 
            parents.append(parent)
            parent = parent.parent()
        return parents
    
    
    def setItemsTextColor(self, items:list, color:QtGui.QColor):
        '''
        Set the text color of the given items.
        '''
        for item in items:
            item.setForeground(0, color)
        
            
    def highlightItems(self):
        '''
        Highlight the selected items along with their parent and child items.
        '''
        self.setItemsTextColor(self.cacheHighlightedItems, QtGui.QColor(200, 200, 200))
        selectedItems = self.selectedItems()
        if not selectedItems:
            self.cacheHighlightedItems = []
            return
        newHighlightItems = []
        for item in selectedItems:
            newHighlightItems.extend(self.getItemChildrens(item))
            newHighlightItems.extend(self.getItemParents(item))
        self.setItemsTextColor(newHighlightItems, QtGui.QColor(180, 120, 40, 200))
        self.cacheHighlightedItems = newHighlightItems 
        
        
    def _showLoading(self):
        '''
        Show the loading indicator and process UI events.
        '''
        self.loadingLabel.setGeometry(self.rect())
        self.loadingLabel.setVisible(True)
        QtWidgets.QApplication.processEvents() # update UI


    def _hideLoading(self):
        '''
        Hide the loading indicator and update the scrollbar.
        '''
        self.loadingLabel.setVisible(False)
        self.updateHorizontalScrollbar() # Update scrollbar
        
        
    @staticmethod
    def withLoading(func):
        '''
        Decorator: Show and hide loading indicator around function execution.
        '''
        def wrapper(self, *args, **kwargs):
            self._showLoading()
            try:
                return func(self, *args, **kwargs) 
            finally:
                self._hideLoading() 
        return wrapper
        
    '''
    Item state functions
    '''
    def _getExpandedItems(self) -> set:
        '''
        Return a set of expanded item UUIDs.
        '''
        return {item.data(0, QtCore.Qt.UserRole) for item in self.getAllItems() if item.isExpanded()}
          
          
    def _restoreExpandedItems(self, expandedItems:set):
        '''
        Restore the expanded state of items from a given set of UUIDs.
        '''
        for item in self.getAllItems():
            if item.data(0, QtCore.Qt.UserRole) in expandedItems:
                item.setExpanded(True)
                
                
    def _getScrollPosition(self) -> tuple:
        '''
        Return the current vertical and horizontal scroll position.
        '''
        return self.verticalScrollBar().value(), self.horizontalScrollBar().value()


    def _restoreScrollPosition(self, position):
        '''
        Restore the scroll position from the given tuple.
        '''
        verticalPos, horizontalPos = position
        self.verticalScrollBar().setValue(verticalPos)
        self.horizontalScrollBar().setValue(horizontalPos)
        
        
    def _getSelectedItems(self) -> set:
        '''
        Return a set of selected item UUIDs.
        '''
        return {item.data(0, QtCore.Qt.UserRole) for item in self.selectedItems()}
        
        
    def _restoreSelectedItems(self, selectedItems):
        '''
        Restore the selected state of items from a given set of UUIDs.
        '''
        for item in self.getAllItems():
            if item.data(0, QtCore.Qt.UserRole) in selectedItems:
                item.setSelected(True)
                
                
    @staticmethod            
    def withItemState(func):
        '''
        Decorator: Preserve selected, expanded, and scroll states during function execution.
        '''
        def wrapper(self, *args, **kwargs):
            selectedItems = self._getSelectedItems()
            expandedItems = self._getExpandedItems() 
            scrollPos     = self._getScrollPosition()
            
            result = func(self, *args, **kwargs) 
            
            self._restoreExpandedItems(expandedItems) 
            self._restoreScrollPosition(scrollPos)
            self._restoreSelectedItems(selectedItems)
            return result
        return wrapper

           
            
class HierarchyTreeWidget(BaseTreeWidget):
    
    ITEM_HIGHT = 30
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.characterManager:'CharacterManager' = None
        self.viewMode = 0
        
    
    @property
    def characterExists(self) -> bool:
        return self.characterManager is not None and cmds.objExists(self.characterManager.nodeName)
    
          
    def _createConnections(self):
        super()._createConnections()
        self.itemsParentChanged.connect(self.setComponentParent)
        
        self.hierarchyTreeWidgetMenu.selectinSceneTriggered.connect(self._selectItemsInMaya)
        self.hierarchyTreeWidgetMenu.selectinTreeTriggered.connect(self._selectMayaNodeInItem)
        
        self.hierarchyTreeWidgetMenu.mirrorTriggered.connect(self._openMirrorComponentsDialog)
        self.hierarchyTreeWidgetMenu.duplicateTriggered.connect(self.duplicateSelectedComponents)
        self.hierarchyTreeWidgetMenu.symmetrizeMenuTriggered.connect(self.symmetrizeSelectedComponents)
        
        self.hierarchyTreeWidgetMenu.deleteTriggered.connect(self.deleteSelectedComponents)
        self.hierarchyTreeWidgetMenu.refreshTriggered.connect(self.refreshHierarchyTree)
        

    def _selectItemsInMaya(self):
        '''
        Select corresponding Maya nodes based on selected TreeWidget items
        '''
        nodes = []
        for item in self.selectedItems():
            if item.data(0, QtCore.Qt.UserRole + 2) == 'component':
                component= utils.uuidToMetaNode(item.data(0, QtCore.Qt.UserRole))
                nodes.append(component.guideLayer.guideRootNode.nodeName)
                continue
            
            if item.data(0, QtCore.Qt.UserRole + 2) == 'guide':
                node = cmds.ls(item.data(0, QtCore.Qt.UserRole))
                if node:
                    nodes.append(node[0])
                    
        cmds.select(nodes, ne=True, replace=True)
        
    
    def _selectMayaNodeInItem(self):
        '''
        Select corresponding TreeWidget items based on selected Maya nodes
        '''
        self.clearSelection()
        itemsMap = {item.data(0, QtCore.Qt.UserRole): item for item in self.getAllItems()}
        selectedUUIDs = cmds.ls(sl=True, uid=True, type='transform')
        
        firstItem = None
        for uuid in selectedUUIDs:
            if uuid not in itemsMap:
                continue
            item = itemsMap[uuid]  
            
            # get componentItem
            _parentItem = item.parent() 
            if _parentItem and _parentItem.data(0, QtCore.Qt.UserRole + 2) == 'component':
                item = _parentItem
            
            item.setSelected(True)
            for parentItem in BaseTreeWidget.getItemParents(item):
                parentItem.setExpanded(True) 
                
            if firstItem is None:
                firstItem = item  # cache item
        if firstItem:
            self.scrollToItem(firstItem) 


    @classmethod        
    def createGuideItem(cls, guide:'GuideNode') -> QtWidgets.QTreeWidgetItem:
        '''
        Create a tree widget item for a GuideNode.
        '''
        item = QtWidgets.QTreeWidgetItem([guide.shortName])
        item.setData(0, QtCore.Qt.UserRole, guide.uuid) # Store UUID
        item.setData(0, QtCore.Qt.UserRole + 1, guide.guideTag) # Store guide tag
        item.setData(0, QtCore.Qt.UserRole + 2, 'guide') # Store tag
        
        item.setSizeHint(0, QtCore.QSize(0, cls.ITEM_HIGHT))
        guideType = 'rootGuide' if guide.isRoot else 'baseGuide'
        item.setIcon(0, getGuideIcon(guideType))
        item.setFlags(item.flags() & ~QtCore.Qt.ItemIsDragEnabled) # Disable dragging
        if guideType == 'rootGuide':
            item.setFlags(item.flags() & ~QtCore.Qt.ItemIsDropEnabled) # Disable dropping for root guides
        return item
        
    
    @classmethod
    def createComponentItem(cls, component:'Component') -> QtWidgets.QTreeWidgetItem:
        '''
        Create a tree widget item for a Component.
        '''
        item = QtWidgets.QTreeWidgetItem([component.baseName])
        item.setData(0, QtCore.Qt.UserRole, component.uuid) # Store UUID
        item.setData(0, QtCore.Qt.UserRole + 1, component.metaClass) # Store componentClass
        item.setData(0, QtCore.Qt.UserRole + 2, 'component') # Store tag
        
        item.setSizeHint(0, QtCore.QSize(0, cls.ITEM_HIGHT))
        item.setIcon(0, getComponentIcon(component.metaClass))
        item.setFlags(item.flags() & ~QtCore.Qt.ItemIsDropEnabled) # Disable dropping
        #item.setFlags(item.flags() | QtCore.Qt.ItemIsEditable)
        return item
        
        
    def setCharacterManager(self, characterManager:'CharacterManager'):
        #if self.characterManager == characterManager:
            #return  
        self.characterManager = characterManager
        self.refreshHierarchyTree()
    
    
    def updateViewMode(self):
        if self.viewMode == 0:
            self.buildTreeWithHierarchy()
        elif self.viewMode == 1:
            self.buildTreeFlat()
    
            
    @BaseTreeWidget.withLoading 
    def refreshHierarchyTree(self):
        '''
        Rebuilds the tree and shows a loading indicator during the process.
        
        1: If in Guide mode (hasRebuild), a TreeWidget with a parent-child relationship will be generated based on componentParent.
        2: If in Rig mode (hasBuild), the guideLayer nodes of the components have been deleted, so a parallel-relationship TreeWidget will be generated.
        3: If characterManager is invalid, clear all items.
        '''
        if self.characterExists and self.characterManager.hasRebuild:
            self.updateViewMode()
        elif self.characterExists and self.characterManager.hasBuild:
            self.buildTreeFlat()
        else:
            self.clear() # create build state tree items
        
        
    @BaseTreeWidget.withLoading  
    @BaseTreeWidget.withItemState  
    def insertRefreshHierarchyTree(self):
        '''
        Rebuilds the tree after inserting a new component, 
        while preserving item states (expanded, selected, scroll position) for a smoother user experience.
        '''
        QtWidgets.QApplication.processEvents() # update UI
        self.refreshHierarchyTree()
    
    
    def buildTreeFlat(self):
        '''
        When characterManager is in Rig mode (hasBuild), create TreeWidgetItems with a parallel hierarchy.
        '''
        self.clear()
        self.horizontalScrollBar().setValue(0)  # resetScrollBar
        self.resizeColumnToContents(0)          # updateScrollBar

        if not self.characterExists: 
            return  
        
        components = self.characterManager.componentsManager.listComponentNodes()
        for component in components:
            componentItem = HierarchyTreeWidget.createComponentItem(component)
            self.addTopLevelItem(componentItem)
        
        
         
    def buildTreeWithHierarchy(self):
        '''
        When characterManager is in Guide mode (hasRebuild), create TreeWidgetItems with a parent-child relationship.
        '''
        self.clear()
        if not self.characterExists: 
            return   
        
        components = self.characterManager.componentsManager.listComponentNodes()
        allItemsDataMap = {}
        for component in components:
            componentItem = HierarchyTreeWidget.createComponentItem(component)
            self.addTopLevelItem(componentItem)
            # create guideItems
            guideMap = {}
            guideParentMap = utils.guideParentMap(component)
            for guide in component.listGuideNodes(includeRoot=True):
                guideItem = HierarchyTreeWidget.createGuideItem(guide)
                # key -> guideTag 
                # value -> guideItem
                guideMap[guideItem.data(0, QtCore.Qt.UserRole + 1)] = guideItem 
                
            # set guideParent
            for tag, guideItem in guideMap.items():
                parentTag = guideParentMap.get(tag, None)
                if parentTag is None:
                    componentItem.addChild(guideItem) 
                else:
                    parentTag = guideParentMap[tag] 
                    parentGuideItem = guideMap[parentTag]
                    parentGuideItem.addChild(guideItem) 
            
            # add allItemsDataList        
            itemDataMap = {'componentItem':componentItem,
                           'guidesItemMap':guideMap}
            allItemsDataMap[component.metaId] = itemDataMap
                             
        # set componentItemParent
        for component in components:
            parentMap      = utils.componentParentMap(component)
            parentMetaId   = parentMap['parentMetaId']
            parentGuideTag = parentMap['parentGuideTag']
            
            if parentMetaId is None or parentGuideTag is None:
                continue
                
            componentItem = allItemsDataMap[component.metaId]['componentItem']
            parentGuideItem = allItemsDataMap[parentMetaId]['guidesItemMap'][parentGuideTag]
            
            self.takeTopLevelItem(self.indexOfTopLevelItem(componentItem)) # remove topLeve
            parentGuideItem.addChild(componentItem)
        
        
    @qtUtils.withoutUndo      
    def setComponentParent(self, 
                           parentGuideItem:QtWidgets.QTreeWidgetItem, 
                           selectedItems:list):
        '''
        Set the parent component for the selected items.
        '''    
        
        if self.viewMode == 1: 
            '''
            If it is in list mode, where self.viewMode is 1
            the setParent method should be skipped when dragging componentItem
            '''
            return
            
        if not (self.characterExists and self.characterManager.hasRebuild):
            return
                  
        parentGuideNode = None
        if parentGuideItem is not None:
            parentGuideNode = utils.uuidToGuideNode(parentGuideItem.data(0, QtCore.Qt.UserRole)) 

        for item in selectedItems:
            if item is None:
                continue
            component = utils.uuidToMetaNode(item.data(0, QtCore.Qt.UserRole))
            if parentGuideNode is not None:
                component.addComponentParent(parentGuideNode)
            else:
                component.removeComponentParent()
                
          
    def getSelectedComponentItems(self):
        return [item for item in self.selectedItems() if utils.isComponentItem(item)]
        
        
    def getTopLevelItems(self, items:list) -> list:
        '''
        Return a filtered list containing only top-level items 
        (removing child items if their parent is also in the list).
        '''
        itemSet = set(items) 
        return [item for item in items if not any(parent in itemSet for parent in BaseTreeWidget.getItemParents(item))]
        
        
    def _openMirrorComponentsDialog(self):
        componentItems = self.getTopLevelItems(self.getSelectedComponentItems())
        componentMetaNodes = [utils.uuidToMetaNode(item.data(0, QtCore.Qt.UserRole)) for item in componentItems]
        mirrorDialog.MirrorDialog(self, components=componentMetaNodes).show()
        
        
    @qtUtils.withoutUndo  
    @BaseTreeWidget.withLoading  
    @BaseTreeWidget.withItemState      
    def mirrorSelectedComponents(self, 
                                components:list,
                                axis:str='x',
                                side:str='L'):
        QtWidgets.QApplication.processEvents() # update UI
        for component in components:
            if component is not None:
                component.mirror(axis=axis, side=side)
                
        self.updateViewMode() # update tree
   
        
    @qtUtils.withoutUndo  
    @BaseTreeWidget.withLoading  
    @BaseTreeWidget.withItemState      
    def duplicateSelectedComponents(self):
        componentItems = self.getSelectedComponentItems()
        cleanItems = self.getTopLevelItems(componentItems)
        
        for item in cleanItems:
            component = utils.uuidToMetaNode(item.data(0, QtCore.Qt.UserRole))
            if component is not None:
                component.duplicate()
        
        self.updateViewMode() # update tree
        
            
    @qtUtils.withoutUndo  
    def symmetrizeSelectedComponents(self, action:QtGui.QAction):
        axis:str = action.data()
        componentItems = self.getSelectedComponentItems()
        for item in componentItems:
            component = utils.uuidToMetaNode(item.data(0, QtCore.Qt.UserRole))
            if component is not None:
                component.symmetrizeComponent(axis)
            
    
    @qtUtils.withoutUndo  
    @BaseTreeWidget.withLoading  
    @BaseTreeWidget.withItemState      
    def deleteSelectedComponents(self):      
        componentItems = self.getSelectedComponentItems()                 
        cleanItems     = self.getTopLevelItems(componentItems)
        
        for item in cleanItems:
            component = utils.uuidToMetaNode(item.data(0, QtCore.Qt.UserRole))
            if component is not None:
                component.delete()
        
        self.updateViewMode() # update tree
        
        

  
        
if __name__ == '__main__':
    sceneCharacter = meta.listSceneMetaNodes(ofType=components.CharacterManager)[0]

    win = QtWidgets.QDialog(parent=qtUtils.getMayaMainWindow())
    ly = QtWidgets.QHBoxLayout(win)
    t = HierarchyTreeWidget()
    ly.addWidget(t)
    win.show()
    
    t.setCharacterManager(sceneCharacter)

    #sceneCharacter.rebuild()
    #sceneCharacter.build()



