from maya import cmds
from maya.api import OpenMaya as om2

from PySide6 import QtWidgets
from PySide6 import QtGui
from PySide6 import QtCore

from linkRigger.ui import qtUtils

from linkRigger.core import meta
from linkRigger import components
from linkRigger.ui import globalSignals


class BuildManager(QtWidgets.QWidget):
    
    buildModeClicked = QtCore.Signal()
    
    def __init__(self, parent=None):
        super().__init__(parent)
               
        self.characterManager:'CharacterManager' = None
        self.setObjectName('BuildManager')
        self.setAttribute(QtCore.Qt.WA_StyledBackground, True) 
        
        self._createWidgets()
        self._createLayouts()
        self._createConnections()
        
        self.setStyleSheet('''
            #BuildManager { background-color: #373737;} 
            
            QPushButton {background: #505050;  border: none; border-radius: 13px;}
            QPushButton:hover { background-color: #5A5A5A;}
            QPushButton:pressed { background-color: #545A99; }
            QPushButton:checked { background-color: #545A99; }
     
            ''')
            
    
    @property
    def characterExists(self) -> bool:
        return self.characterManager is not None and cmds.objExists(self.characterManager.nodeName)
            
        
    def setCharacterManager(self, characterManager:'CharacterManager'):
        #if characterManager == self.characterManager:
            #return  
        self.characterManager = characterManager
        self.setButtonsState()
            
        
    def _createWidgets(self):
        
        self.adjustButton = QtWidgets.QPushButton('Adjust')
        self.adjustButton.setFixedSize(100, 27)
        self.adjustButton.setCheckable(True)
        
        self.bindingButton = QtWidgets.QPushButton('Binding')
        self.bindingButton.setFixedSize(100, 27)
        self.bindingButton.setCheckable(True) 
        
        self.animateButton = QtWidgets.QPushButton('Animate')
        self.animateButton.setFixedSize(100, 27)
        self.animateButton.setCheckable(True) 

        self.buttonsGroup = QtWidgets.QButtonGroup()
        self.buttonsGroup.setExclusive(True) 

        self.buttonsGroup.addButton(self.adjustButton, 0)
        self.buttonsGroup.addButton(self.bindingButton, 1)
        self.buttonsGroup.addButton(self.animateButton, 2)
        
        
    def _createLayouts(self):
        mainLayout = QtWidgets.QHBoxLayout(self)
        mainLayout.setContentsMargins(0, 0, 0, 0)

        mainLayout.setSpacing(5)
        mainLayout.addStretch()
        mainLayout.addWidget(self.adjustButton)
        mainLayout.addWidget(self.bindingButton)
        mainLayout.addWidget(self.animateButton)
        mainLayout.addStretch()
        
    def _createConnections(self):
        self.buttonsGroup.buttonClicked.connect(self.buildModel)
        
        
    @qtUtils.withoutUndo      
    def buildModel(self, button:QtWidgets.QPushButton):
        if not self.characterExists:
            return
        buttonId = self.buttonsGroup.id(button) 

        if buttonId == 0:
            result = self.characterManager.rebuild()
            if result:
                self.bindingButton.setDisabled(False) 
                self.buildModeClicked.emit()
            
        elif buttonId == 1:
            self.characterManager.binding()

        elif buttonId == 2:
            result = self.characterManager.build()
            if result:
                self.bindingButton.setDisabled(True) 
                self.buildModeClicked.emit()
                
        globalSignals.buildModeSignal.BuildMode.emit()
       
    
    def setButtonsState(self):
        
        if not self.characterExists:
            self.adjustButton.setDisabled(True) 
            self.bindingButton.setDisabled(True) 
            self.animateButton.setDisabled(True) 
            return
        
        self.adjustButton.setDisabled(False) 
        self.animateButton.setDisabled(False) 
        
 
        if self.characterManager.hasRebuild and self.characterManager.hasBinding:
            self.bindingButton.setDisabled(False) 
            self.bindingButton.setChecked(True) 
            
        elif self.characterManager.hasRebuild:
            self.bindingButton.setDisabled(False) 
            self.adjustButton.setChecked(True) 
            
        elif self.characterManager.hasBuild:
            self.bindingButton.setDisabled(True) 
            self.animateButton.setChecked(True) 
        



if __name__ == '__main__':
    b = BuildManager()
    b.show()