from maya import cmds
from maya.api import OpenMaya as om2

from functools import partial
from PySide6 import QtWidgets
from PySide6 import QtGui
from PySide6 import QtCore

from linkRigger.ui import widgets

from linkRigger import components
from linkRigger.core import meta
from linkRigger.ui.rigHierarchyWidgets import utils          
from linkRigger.ui import globalSignals


class RigManagerWidget(QtWidgets.QWidget):
    
    selectedCharacterManager = QtCore.Signal(object)
    
    def __init__(self, parent=None):
        super().__init__(parent)
        
        self.setStyleSheet('''
            
            QMenu { background-color: #1A1A1A; border: 2px solid #363636; color: #B4B4B4;}
            QMenu::item { background-color: transparent; }
            QMenu::separator { height: 3px; background: #363636; margin-left: 15px; margin-right: 15px; }
            QMenu::item:selected { background-color: #4D4D4D; color: #F0F0F0;}
            QMenu::right-arrow { border-image: url(linkIcons:menuLeft.png); }
            QMenu::right-arrow:disabled { border-image: url(linkIcons:menuLeftDisabled.png)} 
            QMenu::item:disabled {color: #585858;}
                           
            QScrollBar:vertical { border: none; width: 12px; margin: 0px 0 0px 0; }
            QScrollBar::handle:vertical { background: #5C5C5C; min-height: 20px; border-radius: 0px; }
            QScrollBar::handle:vertical:hover { background: #656565; }
            QScrollBar::handle:vertical:pressed {background: #6E6E6E; }
            QScrollBar::sub-line:vertical,
            QScrollBar::add-line:vertical { background: none; height: 0; }
                           
            QComboBox { background-color: #4B4B4B; height: 30px; width: 60px; border-radius: 0px; padding-left: 8px;}
            QComboBox:hover { background-color: #5C5C5C;}
            QComboBox QAbstractItemView { border: 6px solid #1A1A1A; background-color: #1A1A1A; selection-background-color: #4D4D4D; }
            
            QComboBox::drop-down { border: none; background: transparent; width: 25px; }
            QComboBox::down-arrow {border-image: url(linkIcons:downHoverSource.png); width: 20px; height: 20px; }
            QComboBox:focus { background-color: #4B4B4B;  padding-left: 8px;}
            
       
            #rigManagerToolBut {background: #505050;  border: none;  border-radius: 12px; background-image: url('linkIcons:down.png');}
            #rigManagerToolBut:hover {background: #646464; background-image: url('linkIcons:downHight.png');}
            #rigManagerToolBut:pressed {background: #545A99; background-image: url('linkIcons:downHight.png');}
            #rigManagerToolBut::menu-indicator { image: none; width: 0px; }

            ''')
            
        self.characterManager = None
        
        self._createMenu()
        self._createWidgets()
        self._createLayouts()
        self._createConnections()
        self.setupRigCombox()
        

    def _createMenu(self):
        self.createRigMenu = QtWidgets.QMenu(self)
        self.createRigMenu.setObjectName('createRigMenu')
        
        self.createRigAction   = QtGui.QAction(QtGui.QIcon('linkIcons:newScene.png'), 'New Rig')
        self.deleteRigAction   = QtGui.QAction(QtGui.QIcon('linkIcons:delete.png'), 'Delete Rig')
        self.renameRigAction   = QtGui.QAction(QtGui.QIcon('linkIcons:renameRig.png'), 'Rename Rig')
        self.refreshRigsAction = QtGui.QAction(QtGui.QIcon('linkIcons:refresh.png'), 'Refresh Rigs')
        self.createRigMenu.addAction(self.createRigAction)
        self.createRigMenu.addAction(self.renameRigAction)
        self.createRigMenu.addAction(self.deleteRigAction)
        self.createRigMenu.addSeparator()
        self.createRigMenu.addAction(self.refreshRigsAction)
    
        
    def _createWidgets(self):
        self.rigComboBox = widgets.ComboBox()
        self.rigComboBox.setItemDelegate(widgets.CustomDelegate(self, 30))
        
        self.rigManagerToolBut = QtWidgets.QPushButton('')
        self.rigManagerToolBut.setFixedSize(24, 24) 
        self.rigManagerToolBut.setObjectName('rigManagerToolBut')
        self.rigManagerToolBut.setMenu(self.createRigMenu)   

        
    def _createLayouts(self):
        mainLayout = QtWidgets.QHBoxLayout(self)
        mainLayout.setSpacing(5)
        mainLayout.setContentsMargins(0, 0, 5, 0)
        mainLayout.addWidget(self.rigComboBox)
        mainLayout.addWidget(self.rigManagerToolBut)
        
        
    def _createConnections(self):
        self.createRigMenu.aboutToShow.connect(self._updateActionsState)
        self.createRigAction.triggered.connect(self.createRig)
        self.renameRigAction.triggered.connect(self.renameRig)
        self.deleteRigAction.triggered.connect(self.deleteRig)
        self.refreshRigsAction.triggered.connect(self.refreshRigs)
        
        self.rigComboBox.activated.connect(self.selectedRig)
        self.selectedCharacterManager.connect(lambda c: print(f'EMIT -> {c}'))
        

    def emitCharacterManager(self):
        self.selectedCharacterManager.emit(self.characterManager)
        globalSignals.characterManagerSignal.characterSwitched.emit(self.characterManager)
        
    @property
    def characterExists(self) -> bool:
        return self.characterManager is not None and cmds.objExists(self.characterManager.nodeName)
        
        
    def _updateActionsState(self):
        self.deleteRigAction.setEnabled(self.characterExists)
        self.renameRigAction.setEnabled(self.characterExists)

        
        
    def updateRigCombox(self):
        '''
        Rebuild items based on the scene's CharacterManager nodes
        '''
        self.rigComboBox.clear()
        for character in meta.listSceneMetaNodes(ofType='CharacterManager'):
            self.rigComboBox.addItem(character.name, character.node.uuid().asString()) # add uuid    
        

    def setupRigCombox(self):
        '''
        Initialize rigComboBox and emit the selectedCharacterManager signal!
        '''
        self.updateRigCombox()
        if self.rigComboBox.count() > 0:
            characterUUID = self.rigComboBox.currentData() 
            self.characterManager = utils.uuidToMetaNode(characterUUID)
            self.selectedCharacterManager.emit(self.characterManager)
            globalSignals.characterManagerSignal.characterSwitched.emit(self.characterManager)
        else:
            self.selectedCharacterManager.emit(None)
            globalSignals.characterManagerSignal.characterSwitched.emit(None)

    
    def uuidToItemIndex(self, uuid:str) -> int:
        '''
        Find the item index in rigComboBox based on the given CharacterManager UUID.
        Returns -1 if the UUID is not found.
        '''
        for index in range(self.rigComboBox.count()):
            if uuid == self.rigComboBox.itemData(index):
                return index
        return -1
            
            
    def selectedRig(self, index):
        '''
        Select a rig based on the given index and emit the selectedCharacterManager signal
        '''
        if index < -1: 
            return
        characterUUID = self.rigComboBox.itemData(index)
        characterManager = utils.uuidToMetaNode(characterUUID)
        if self.characterManager != characterManager:
            self.characterManager = characterManager
            self.selectedCharacterManager.emit(self.characterManager)
            globalSignals.characterManagerSignal.characterSwitched.emit(self.characterManager)

        
    def createRig(self):
        '''
        Create a new CharacterManager, update rigComboBox, and select the new rig.
        Emits the selectedCharacterManager signal with the newly created rig.
        '''
        self.characterManager = components.CharacterManager.create()
        self.updateRigCombox()
        self.rigComboBox.setCurrentIndex(self.uuidToItemIndex(self.characterManager.node.uuid().asString()))  
        self.selectedCharacterManager.emit(self.characterManager)
        globalSignals.characterManagerSignal.characterSwitched.emit(self.characterManager)
        
             
    def deleteRig(self):
        '''
        Delete the selected rig, rebuild the ComboBox, and emit a signal to update the tree
        '''
        if not self.characterExists:
            return
        result = widgets.WarningDialog(title='Delete Rig',
                                       message=f"Delete '{self.characterManager.name}'?\nThis action cannot be undone."
                                       ).exec()  
        if result:
            self.characterManager.delete()
            self.setupRigCombox()
        
        
    def renameRig(self):
        '''
        Rename the rig, rebuild the ComboBox, and select the renamed item without emitting a signal
        '''
        if not self.characterExists:
            return
        result = widgets.InputDialog(baseText=self.characterManager.name, 
                                     title='Rename Rig', 
                                     message='New Name').exec()
        if isinstance(result, str):
            self.characterManager.setName(result)
            self.updateRigCombox()
            self.rigComboBox.setCurrentIndex(self.uuidToItemIndex(self.characterManager.node.uuid().asString()))  
        
        
    def refreshRigs(self, *args):
        self.setupRigCombox()
        
        
    def selectedCharacterFormComboxItem(self, characterUUID:str=''):
        '''
        Select the ComboBox item by UUID and emit the selectedCharacterManager signal to update the tree. 
        This method is primarily used by the TemplateManagerTree class when calling the loadRigFromTemplate method. 
        If we choose 'Replace', the current rig will be deleted, the template will be imported, and the UI will be refreshed.
        '''
        self.updateRigCombox()
        self.rigComboBox.setCurrentIndex(self.uuidToItemIndex(characterUUID))  
        self.characterManager = utils.uuidToMetaNode(characterUUID)
        self.selectedCharacterManager.emit(self.characterManager)
        globalSignals.characterManagerSignal.characterSwitched.emit(self.characterManager)
        
        
        

if __name__ == '__main__':
    r = RigManagerWidget()
    r.show()
        
    