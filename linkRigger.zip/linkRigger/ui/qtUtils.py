import json
import os
import sys
from functools import wraps
import maya.OpenMayaUI as omui
import maya.cmds as cmds
    
if int(cmds.about(version=True)) >= 2025:
    from shiboken6 import wrapInstance
    from PySide6   import QtWidgets, QtCore, QtGui
else:
    from shiboken2 import wrapInstance
    from PySide2   import QtWidgets, QtCore, QtGui
    

def saveToJson(data: dict, path: str): 
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(data, f, sort_keys=True, ensure_ascii=False, indent=2)
        
        
def loadFromJson(path: str) -> dict:
    with open(path, 'r') as f:
        data = json.load(f)
    return data


def withoutUndo(func):
    @wraps(func)
    def undo(*args, **kwargs):
        #cmds.undoInfo(state=false)
        cmds.undoInfo(stateWithoutFlush=False)
        try:
            func(*args, **kwargs)
        finally:
            cmds.undoInfo(stateWithoutFlush=True)
            #cmds.undoInfo(state=True)
    return undo  


def addUndo(func):
    @wraps(func)
    def undo(*args, **kwargs):
        cmds.undoInfo(openChunk=True)
        try:
            func(*args, **kwargs)
        finally:
            cmds.undoInfo(closeChunk=True)
    return undo  


def getMayaMainWindow() -> QtWidgets.QMainWindow:
    if sys.version_info.major >= 3:
        return wrapInstance(int(omui.MQtUtil.mainWindow()), QtWidgets.QMainWindow)
    return wrapInstance(long(omui.MQtUtil.mainWindow()), QtWidgets.QWidget)
    

            
            
class CustomItemDelegate(QtWidgets.QStyledItemDelegate):

        
    def paint(self, painter, option, index):
        if option.state & QtWidgets.QStyle.State_HasFocus:
            option.state &= ~QtWidgets.QStyle.State_HasFocus  # remove focus
        #option.state &= ~QtWidgets.QStyle.State_Selected
        
            
        super().paint(painter, option, index)
        

        
        
class SelectionBox(QtWidgets.QRubberBand):
    def __init__(self, parent=None, shape=QtWidgets.QRubberBand.Line):
        super().__init__(shape, parent)
        
    def paintEvent(self, event):
        painter = QtGui.QPainter(self)
        painter.setPen(QtGui.QPen(QtGui.QColor(150, 150, 150), 4, QtCore.Qt.SolidLine))
        painter.setBrush(QtGui.QColor(100, 100, 100, 30))
        painter.drawRect(self.rect())
    
    
def __macOpenInExplorer(path: str) -> bool:
    fileInfo = QtCore.QFileInfo(path)
    if fileInfo.isDir():
        return QtGui.QDesktopServices.openUrl(QtCore.QUrl.fromLocalFile(path))
    else:
        return QtGui.QDesktopServices.openUrl(QtCore.QUrl.fromLocalFile(fileInfo.path()))


def __windowsOpenInExplorer(path: str) -> bool:
    fileInfo = QtCore.QFileInfo(path)
    args = []
    if not fileInfo.isDir():
        args.append('/select,')
    args.append(QtCore.QDir.toNativeSeparators(path))
    return QtCore.QProcess.startDetached('explorer', args)


def openPathInExplorer(path: str) -> bool:
  
    if sys.platform.startswith('win'):
        return __windowsOpenInExplorer(path)
    elif sys.platform.startswith('darwin'):
        return __macOpenInExplorer(path)
    return False

