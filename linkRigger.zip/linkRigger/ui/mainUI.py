from maya import cmds
from maya.api import OpenMaya as om2

from PySide6 import QtWidgets
from PySide6 import QtGui
from PySide6 import QtCore

from linkRigger.core import meta
from linkRigger import components

from linkRigger.ui import qtUtils, widgets

from linkRigger.ui.rigManagerWidgets       import rigManagerWidget
from linkRigger.ui.componentManagerWidgets import componentManagerWidget
from linkRigger.ui.templateManagerWidgets  import templateManagerWidget

from linkRigger.ui.rigHierarchyWidgets     import rigHierarchyWidget
from linkRigger.ui.rigManagerWidgets       import buildManagerWidget
from linkRigger.ui.propertiesWidgets       import propertiesWidget
from linkRigger.ui.settingsWidgets         import settingsWidget

from linkRigger.ui import globalSignals



class LinkAutoRiggerUI(QtWidgets.QWidget):
    
    GEOMETRY           = None
    INSTANCE           = None
    SCRIPT_JOB_NUMBERS = []
    
    @classmethod
    def clearCacheInstance(cls):
        cls.INSTANCE = None
        
    
    def checkRig(self):
        '''
        When the UI is closed and we create/open a new scene, if a rig previously existed, 
        it may cause invalid files to remain when reopening the UI next time. Therefore, 
        each time we open the UI, we need to check whether the rig is still valid. If the rig is invalid, 
        we update the scene accordingly.
        '''
        if not self.rigManagerWidget.characterExists:
            self.rigManagerWidget.refreshRigs()
        
        
    def showEvent(self, event):
        
        if LinkAutoRiggerUI.GEOMETRY is not None:
            self.restoreGeometry(LinkAutoRiggerUI.GEOMETRY) 
   
        super().showEvent(event)
        self.setScriptJobEnabled(True)
        self.checkRig()
        
        
    def closeEvent(self, event):
        LinkAutoRiggerUI.GEOMETRY = self.saveGeometry()
        if isinstance(self, LinkAutoRiggerUI):
            super().closeEvent(event)
            self.setScriptJobEnabled(False)
        
    
    def __new__(cls, *args, **kwargs):
        if cls.INSTANCE is None:
            cls.INSTANCE = super(LinkAutoRiggerUI, cls).__new__(cls)
            return cls.INSTANCE
            
        if cls.INSTANCE.isMinimized():
            cls.INSTANCE.showNormal()
        return cls.INSTANCE
        
        
    def setScriptJobEnabled(self, enabled):
        if enabled and not LinkAutoRiggerUI.SCRIPT_JOB_NUMBERS:
            jobMap = {'NewSceneOpened'  : self.rigManagerWidget.refreshRigs,
                      'SceneOpened'     : self.rigManagerWidget.refreshRigs}
            
            for key, value in jobMap.items():
                jobIndex = om2.MEventMessage.addEventCallback(key, value)
                LinkAutoRiggerUI.SCRIPT_JOB_NUMBERS.append(jobIndex)
            
        elif not enabled and LinkAutoRiggerUI.SCRIPT_JOB_NUMBERS:
            try:
                for scriptIndex in LinkAutoRiggerUI.SCRIPT_JOB_NUMBERS:
                    cmds.evalDeferred(f'om2.MMessage.removeCallback({scriptIndex})')
                    #om2.MMessage.removeCallback(scriptIndex)
            except Exception as e:
                om2.MGlobal.displayWarning(f'Error removing callback: {e}')
            LinkAutoRiggerUI.SCRIPT_JOB_NUMBERS = []
        
    
    def __init__(self, parent=qtUtils.getMayaMainWindow()):
        if hasattr(self, '_init') and self._init:
            return
        self._init = True   
        
        super().__init__(parent)
        self.setWindowTitle('Link Auto-Rigger')
        self.setWindowFlags(QtCore.Qt.WindowType.Window)
        self.resize(800, 700)
        self.setFocusPolicy(QtCore.Qt.StrongFocus)
        
        self.setObjectName('LinkAutoRiggerUI')
        
        self.setStyleSheet('''
            #LinkAutoRiggerUI { background-color: #373737;}
            
            ''')
        self._createWidgets()
        self._createLayouts()
        self._createConnections()
        
        
    def _createWidgets(self):
        # left
        self.rigManagerWidget = rigManagerWidget.RigManagerWidget()

        leftWidget = QtWidgets.QWidget()
        leftWidgetLayout = QtWidgets.QVBoxLayout(leftWidget)
        leftWidgetLayout.setContentsMargins(0, 0, 0, 0)
        
        self.leftSplitter = widgets.CustomSplitter()
        self.leftSplitter.setOrientation(QtCore.Qt.Vertical)
        self.componentManagerWidget = componentManagerWidget.ComponentManagerWidget()
        self.templateManagerWidget = templateManagerWidget.TemplateManagerWidget()
        self.leftSplitter.addWidget(self.componentManagerWidget)
        self.leftSplitter.addWidget(self.templateManagerWidget)
        leftWidgetLayout.addWidget(self.rigManagerWidget)
        leftWidgetLayout.addWidget(self.leftSplitter)
        
        # mid
        self.rigHierarchyWidget = rigHierarchyWidget.RigHierarchyWidget()
        
        # right
        self.rightSplitter = widgets.CustomSplitter(handleColor='#323232')
        self.rightSplitter.setOrientation(QtCore.Qt.Vertical)
        self.propertiesWidget = propertiesWidget.PropertiesWidget(hierarchyTreeWidget=self.rigHierarchyWidget.hierarchyTreeWidget) # add tree
        self.buildManagerWidget = buildManagerWidget.BuildManager()
        self.settingsWidget = settingsWidget.SettingsWidget()
        
        self.rightSplitter.addWidget(self.propertiesWidget)
        self.rightSplitter.addWidget(self.settingsWidget)
        self.rightSplitter.setSizes([350, 350])
        
        # add
        self.midSplitter = widgets.CustomSplitter()
        self.midSplitter.addWidget(leftWidget)
        self.midSplitter.addWidget(self.rigHierarchyWidget)
        self.midSplitter.addWidget(self.rightSplitter)
        self.midSplitter.setSizes([200, 600, 0])
        
        
   
    def _createLayouts(self):
        mainLayout = QtWidgets.QVBoxLayout(self)
        mainLayout.setContentsMargins(6, 6, 6, 5)
        mainLayout.setSpacing(5)
        mainLayout.addWidget(self.midSplitter, stretch=1)
        mainLayout.addWidget(self.buildManagerWidget)
        
        
    def _createConnections(self):
        '''
        Component Manager → Hierarchy Tree & Rig Manager
        1. Update the tree when adding a component.
        2. If no character exists, adding a component will create a new CharacterManager.
           At this point, there is only one character object in the scene,
           so setupRigCombox can be called directly to update the global character.
        '''
        self.componentManagerWidget.updateHierarchy.connect(self.rigHierarchyWidget.insertRefreshHierarchyTree)
        self.componentManagerWidget.createCharacterManager.connect(self.rigManagerWidget.setupRigCombox)
        
        '''
        Template Manager → Rig Manager & Hierarchy Tree
        1. If no character exists in the scene, adding a template will create a new CharacterManager
           and call setupRigCombox to update the global character.
        2. If 'Replace' is selected when adding a template:
           - The RigCombox and CharacterManager will be rebuilt.
           - The corresponding character item will be selected in the RigCombox.
        3. If 'Add' is selected when adding a template, only the current tree needs to be updated.
        '''
        self.templateManagerWidget.createCharacterManager.connect(self.rigManagerWidget.setupRigCombox)
        self.templateManagerWidget.selectedUUID.connect(self.rigManagerWidget.selectedCharacterFormComboxItem)
        self.templateManagerWidget.updateHierarchy.connect(self.rigHierarchyWidget.insertRefreshHierarchyTree)

        '''
        Global Signal (characterManagerSignal) → Multiple Widgets
        NOTE: Using global signals may impact future code maintenance,
              making it difficult to trace the source of emitted signals.
              
        # globalSignals.characterManagerSignal.characterSwitched.connect(self.componentManagerWidget.setCharacterManager)
        # globalSignals.characterManagerSignal.characterSwitched.connect(self.templateManagerWidget.setCharacterManager)
        # globalSignals.characterManagerSignal.characterSwitched.connect(self.rigHierarchyWidget.setCharacterManager)
        # globalSignals.characterManagerSignal.characterSwitched.connect(self.buildManagerWidget.setCharacterManager)      
        '''
        
        '''
        Rig Manager → Multiple Widgets
        When the selected character changes, update all related widgets.
        '''
        self.rigManagerWidget.selectedCharacterManager.connect(self.componentManagerWidget.setCharacterManager)
        self.rigManagerWidget.selectedCharacterManager.connect(self.templateManagerWidget.setCharacterManager)
        self.rigManagerWidget.selectedCharacterManager.connect(self.rigHierarchyWidget.setCharacterManager)
        self.rigManagerWidget.selectedCharacterManager.connect(self.buildManagerWidget.setCharacterManager)
        self.rigManagerWidget.selectedCharacterManager.connect(self.settingsWidget.setCharacterManager)

        '''
        Hierarchy Tree → UI Layout
        Adjust layout when view mode changes.
        '''
        self.rigHierarchyWidget.viewModeValue.connect(self.midSplitter.setSizes)

        '''
        Initialize Character Manager
        Setup emit when Rig Manager is initialized.
        '''
        self.rigManagerWidget.emitCharacterManager()
        
        self.buildManagerWidget.buildModeClicked.connect(self.rigHierarchyWidget.refreshHierarchyTreeHandle)
        
if __name__ == '__main__':
    l = LinkAutoRiggerUI()
    l.show()

    # tree = l.rigHierarchyWidget.hierarchyTreeWidget
    # items = tree.getAllItems()
    
    # tree.takeTopLevelItem(tree.indexOfTopLevelItem(items[4]))

    # items[3].addChild(items[4]) 
    #for item in tree.getAllItems(): item.setSizeHint(0, QtCore.QSize(100, 20))
    #tree.setIndentation(26)
        
    # tree.buildTreeFlat()
    # tree.buildTreeWithHierarchy()

    #tree.setEnabled(False)
    #l.midSplitter.setSizes([0 ,600, 200])
    #p = l.propertiesWidget.setEnabled(True)
    
