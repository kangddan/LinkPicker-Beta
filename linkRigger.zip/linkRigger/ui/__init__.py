import os
import maya.cmds as cmds

if int(cmds.about(version=True)) >= 2025:
    from PySide6 import QtCore, QtGui
else:
    from PySide2 import QtCore, QtGui
    

ICONS_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'icons')
QtCore.QDir.addSearchPath('linkIcons', ICONS_PATH)


TEMPLATE_PATH     = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'template')
POST_SCRIPTS_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'postScripts')


CACHE_COMPONENT_ICONS = {}  
CACHE_GUIDE_ICONS     = {'baseGuide' : QtGui.QIcon('linkIcons:baseGuide.png'),
                         'rootGuide' : QtGui.QIcon('linkIcons:rootGuide.png')} 
  
def getComponentIcon(componentType:str) -> QtGui.QIcon:
    icon = CACHE_COMPONENT_ICONS.get(componentType)
    if icon is None:
        icon = QtGui.QIcon(f'linkIcons:{componentType}.png')
        CACHE_COMPONENT_ICONS[componentType] = icon
    return icon
    

def getGuideIcon(guideType:str) -> QtGui.QIcon:
    return CACHE_GUIDE_ICONS.get(guideType)
    
    
CACHE_SCRIPT_ICONS = {'scriptItem': QtGui.QIcon('linkIcons:pythonLogo.png')}    

def getScriptItemIcon() -> QtGui.QIcon:
    return CACHE_SCRIPT_ICONS.get('scriptItem')
    

    
