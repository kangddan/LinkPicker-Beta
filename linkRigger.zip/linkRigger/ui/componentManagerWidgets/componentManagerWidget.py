from maya import cmds
from maya.api import OpenMaya as om2

from functools import partial
from PySide6 import QtWidgets
from PySide6 import QtGui
from PySide6 import QtCore

from linkRigger.ui import qtUtils, getComponentIcon

from linkRigger import components
from linkRigger.core import meta


class ComponentManagerTree(QtWidgets.QTreeWidget):
    
    updateHierarchy = QtCore.Signal()
    createCharacterManager = QtCore.Signal()
    
    def __init__(self, parent=None):
        super().__init__(parent)  
        self.setHeaderHidden(True)
        self.setAlternatingRowColors(True)  
        self.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
        self.setSelectionMode(QtWidgets.QAbstractItemView.ExtendedSelection)
        self.setItemDelegate(qtUtils.CustomItemDelegate())
        self.setIndentation(26)
        
        self.setStyleSheet('''    
                           QMenu { background-color: #1A1A1A; border: 2px solid #363636; color: #B4B4B4;}
                           QMenu::item { background-color: transparent; }
                           QMenu::separator { height: 3px; background: #363636; margin-left: 15px; margin-right: 15px; }
                           QMenu::item:selected { background-color: #4D4D4D; color: #F0F0F0;}
                           QMenu::right-arrow { border-image: url(linkIcons:menuLeft.png); }
                           QMenu::right-arrow:disabled { border-image: url(linkIcons:menuLeftDisabled.png)} 
                           QMenu::item:disabled {color: #585858;}
        
                           QScrollBar:vertical { border: none; width: 10px; margin: 0px 0 0px 0; }
                           QScrollBar::handle:vertical { background: #5C5C5C; min-height: 20px; border-radius: 5px; }
                           QScrollBar::handle:vertical:hover { background: #656565; }
                           QScrollBar::handle:vertical:pressed {background: #6E6E6E; }
                           QScrollBar::sub-line:vertical,
                           QScrollBar::add-line:vertical { background: none; height: 0; }
                            
                            
                           QTreeWidget { border: 0px solid #373737; background-color: #2A2A2A; }
                           /* QTreeWidget::item:hover { color: #FFA53F; padding-left: 0px; background-color: transparent;} */
                           QTreeWidget::item:selected { color: #FFA53F; border: none; background: transparent; padding-left: 0px;}
                           QTreeWidget::item:alternate { background-color: #232323; }
                           
 
                           QTreeWidget::branch:has-siblings:!adjoins-item { border-image: url(linkIcons:branchLine.png); }
                           QTreeWidget::branch:has-siblings:adjoins-item { border-image: url(linkIcons:branchMore.png); }
                           QTreeWidget::branch:!has-children:!has-siblings:adjoins-item { border-image: url(linkIcons:branchEnd.png);}
                           
                           QTreeWidget::branch:has-children:!has-siblings:closed,
                           QTreeWidget::branch:closed:has-children:has-siblings { border-image: none; image: url(linkIcons:leftSource.png); }
                           QTreeWidget::branch:open:has-children:!has-siblings,
                           QTreeWidget::branch:open:has-children:has-siblings { border-image: none; image: url(linkIcons:downSource.png);}  
                           /* 
                           QTreeWidget::branch:has-children:!has-siblings:closed:hover,
                           QTreeWidget::branch:closed:has-children:has-siblings:hover { border-image: none; image: url(linkIcons:leftHoverSource.png); }
                           QTreeWidget::branch:open:has-children:!has-siblings:hover,
                           QTreeWidget::branch:open:has-children:has-siblings:hover { border-image: none; image: url(linkIcons:downHoverSource.png); }
                            */
                          ''') 
                          
        self._createMenu()                  
        self._createConnections()
        self.setupItems()
        self.characterManager:'CharacterManager' = None
        self.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.customContextMenuRequested.connect(self.showComponentManagerTreeMenu)
    
    
    def showComponentManagerTreeMenu(self, point:QtCore.QPoint):
        self.componentManagerTreeMenu.exec(self.mapToGlobal(point))    
        
        
    def _createMenu(self):
        self.componentManagerTreeMenu = QtWidgets.QMenu(self)
        self.componentManagerTreeMenu.setObjectName('componentManagerTreeMenu')
        
        self.expandAction = QtGui.QAction(QtGui.QIcon('linkIcons:expand.png'), 'Expand All')
        self.collapseAction = QtGui.QAction(QtGui.QIcon('linkIcons:collaps.png'), 'Collapse All')
        self.componentManagerTreeMenu.addAction(self.expandAction)
        self.componentManagerTreeMenu.addAction(self.collapseAction)
        
        
    def setupItems(self):
        for folderName, componentNames in components.COMPONENT_TYPE.items():
            folderItem = QtWidgets.QTreeWidgetItem([folderName])
            folderItem.setSizeHint(0, QtCore.QSize(0, 30))
            folderItem.setIcon(0, QtGui.QIcon('linkIcons:folderClose.png'))
            folderItem.setData(0, QtCore.Qt.UserRole, 'folder')
            self.addTopLevelItem(folderItem)
            for componentText in componentNames:
                item = QtWidgets.QTreeWidgetItem([componentText])
                item.setData(0, QtCore.Qt.UserRole, componentText)
                item.setSizeHint(0, QtCore.QSize(0, 30))
                
                iconPath = f'linkIcons:{componentText}.png'
                if QtCore.QFile.exists(iconPath):
                    icon = QtGui.QIcon(iconPath)
                else:
                    icon = QtGui.QIcon('linkIcons:mixComponent.png') 
                item.setIcon(0, icon)
                folderItem.addChild(item)
            
            
    def _createConnections(self):
        self.itemDoubleClicked.connect(self.addComponent)
        self.itemClicked.connect(self.openFolderItem)
        self.itemExpanded.connect(self.onItemExpanded)
        self.itemCollapsed.connect(self.onItemCollapsed)
        
        self.expandAction.triggered.connect(partial(self.setTopItemsExpanded, True))
        self.collapseAction.triggered.connect(partial(self.setTopItemsExpanded, False))
        
        
    def openFolderItem(self, item:QtWidgets.QTreeWidgetItem):
        if item.data(0, QtCore.Qt.UserRole) != 'folder':
            return
        if item.isExpanded():
            item.setExpanded(False)
        else:
            item.setExpanded(True)
  
        
    @qtUtils.withoutUndo      
    def addComponent(self, item:QtWidgets.QTreeWidgetItem, column:int):
        className = item.data(0, QtCore.Qt.UserRole)
        if className == 'folder':
            return
            
        component = getattr(components, className)
        
        if self.characterManager:
            '''
            Emit a signal when creating a component to notify componentTree to update
            '''
            component.create(parent=self.characterManager)
            self.updateHierarchy.emit()
        else:
            '''
            When characterManager does not exist in the scene, 
            creating a component will automatically generate a character as the parent and emit a signal to update the scene.
            '''
            self.characterManager = components.CharacterManager.create()
            component.create(parent=self.characterManager)
            self.createCharacterManager.emit()  
            
            
            
    def onItemExpanded(self, item):
        if item.data(0, QtCore.Qt.UserRole) == 'folder':
            item.setIcon(0, QtGui.QIcon('linkIcons:folderOpen.png')) 


    def onItemCollapsed(self, item):
        if item.data(0, QtCore.Qt.UserRole) == 'folder':
            item.setIcon(0, QtGui.QIcon('linkIcons:folderClose.png')) 
            
            
    def setTopItemsExpanded(self, expand: bool):
        for i in range(self.topLevelItemCount()):
            item = self.topLevelItem(i)
            item.setExpanded(expand)


            
            
class ComponentManagerWidget(QtWidgets.QWidget):
    
    updateHierarchy = QtCore.Signal()
    createCharacterManager = QtCore.Signal()
    
    def __init__(self, parent=None):
        super().__init__(parent)  
        
        self.setObjectName('ComponentManagerWidget')
        self.setAttribute(QtCore.Qt.WA_StyledBackground, True) 
        self.setStyleSheet(''' 
                           #ComponentManagerWidget { background-color: #373737;} 
                           #componentManagerTitle { font-size: 16px; font-weight: bold; }
                           
                           #componentManagerToolBut {background: #505050;  border: none;  border-radius: 12px; background-image: url('linkIcons:down.png');}
                           #componentManagerToolBut:hover {background: #646464; background-image: url('linkIcons:downHight.png');}
                           #componentManagerToolBut:pressed {background: #282828; background-image: url('linkIcons:down.png');}
                           #componentManagerToolBut::menu-indicator { image: none; width: 0px; }
                           ''')
        
        self._createWidgets()
        self._createLayouts()
        self._createConnections()
        

    def _createWidgets(self):
        self.componentManagerTreeWidget = ComponentManagerTree()
        self.componentManagerTitle = QtWidgets.QLabel('COMPONENTS')
        self.componentManagerTitle.setObjectName('componentManagerTitle')
        
        
    def _createLayouts(self):
        mainLayout = QtWidgets.QVBoxLayout(self)
        mainLayout.setContentsMargins(0, 0, 0, 0)
        mainLayout.setSpacing(4)
        titleLayout = QtWidgets.QHBoxLayout()
        titleLayout.setContentsMargins(5, 0, 5, 0)
        titleLayout.addWidget(self.componentManagerTitle)
        titleLayout.addStretch()
        mainLayout.addLayout(titleLayout)
        mainLayout.addWidget(self.componentManagerTreeWidget)
        
        
    def _createConnections(self):
        self.componentManagerTreeWidget.updateHierarchy.connect(self.updateHierarchy)
        self.componentManagerTreeWidget.createCharacterManager.connect(self.createCharacterManager)
        
        
    def setCharacterManager(self, characterManager:'CharacterManager'):
        if characterManager == self.componentManagerTreeWidget.characterManager:
            return  
        self.componentManagerTreeWidget.characterManager = characterManager
        
    
            
if __name__ == '__main__':
    #sceneCharacter = meta.listSceneMetaNodes(ofType=components.CharacterManager)[0]
    c = ComponentManagerWidget()
    c.show()
    #c.setCharacterManager(sceneCharacter)