from maya import cmds
from maya.api import OpenMaya as om2

from PySide6 import QtWidgets
from PySide6 import QtGui
from PySide6 import QtCore

from linkRigger.ui import qtUtils


class FkSpineWidget(QtWidgets.QWidget):
    
    updateTree = QtCore.Signal()
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName('FkSpineWidget')
        self.setFocusPolicy(QtCore.Qt.StrongFocus)
        self.setAttribute(QtCore.Qt.WA_StyledBackground, True) 
        
        self.setStyleSheet('''
            #FkSpineWidget { background-color: #373737;} 
            
            QMenu { background-color: #1A1A1A; border: 2px solid #363636; color: #B4B4B4;}
            QMenu::item { background-color: transparent; }
            QMenu::separator { height: 3px; background: #363636; margin-left: 15px; margin-right: 15px; }
            QMenu::item:selected { background-color: #4D4D4D; color: #F0F0F0;}
            QMenu::right-arrow { border-image: url(linkIcons:menuLeft.png); }
            QMenu::right-arrow:disabled { border-image: url(linkIcons:menuLeftDisabled.png)} 
            QMenu::item:disabled {color: #585858;}

            QSpinBox {selection-background-color: #358ABB; 
                                      background-color: #1C1C1C; 
                                      border: none;
                                   }
                                       
            QCheckBox::indicator { width: 20px; height: 20px;}
            QCheckBox::indicator:unchecked { background: #1C1C1C; }
            QCheckBox::indicator:checked { background: #1C1C1C; border-image: url(linkIcons:hook.png);}   
            
            QCheckBox::indicator:checked:disabled { border-image: url(linkIcons:disabledHook.png); } 
            
             
                               
            ''')
        self.components = []
        self._createWidgets()
        self._createLayouts()
        self._createConnections()
        
        
        
    def _createWidgets(self):
        self.hasCogJointCheckBox = QtWidgets.QCheckBox()
        self.jointCountSpinBox  = QtWidgets.QSpinBox()
        self.jointCountSpinBox.setFixedSize(70, 30)
        self.jointCountSpinBox.setRange(4, 100)
        self.jointCountSpinBox.setAlignment(QtCore.Qt.AlignCenter)
        self.jointCountSpinBox.setButtonSymbols(QtWidgets.QSpinBox.ButtonSymbols.NoButtons) 
        

    def _createLayouts(self):
        mainLayout = QtWidgets.QGridLayout(self)
        mainLayout.setSpacing(10)
        mainLayout.setContentsMargins(0, 0, 0, 0)
        mainLayout.addWidget(QtWidgets.QLabel('Has COG Joint '), 0, 0)
        mainLayout.addWidget(self.hasCogJointCheckBox, 0, 1)
        mainLayout.addWidget(QtWidgets.QLabel('Joint Count '), 1, 0)
        mainLayout.addWidget(self.jointCountSpinBox, 1, 1)
        mainLayout.setAlignment(QtCore.Qt.AlignLeft)

        
    def _createConnections(self):
        self.hasCogJointCheckBox.toggled.connect(self.setHasCogJoint)
        self.jointCountSpinBox.editingFinished.connect(self.setJointCount)
        
    def setData(self, components:'list[Component]'):
        _components = [component for component in components if component.metaClass == 'FkSpine']
        self.components = [component for component in _components if component.hasRebuild]
        if not _components:
            return
        
        self.hasCogJointCheckBox.blockSignals(True) 
        self.jointCountSpinBox.blockSignals(True) 
        self.hasCogJointCheckBox.setChecked(_components[0].hasCogJoint)
        self.jointCountSpinBox.setValue(_components[0].jointCount)
        self.hasCogJointCheckBox.blockSignals(False) 
        self.jointCountSpinBox.blockSignals(False) 
     
     
    @qtUtils.withoutUndo    
    def setHasCogJoint(self, value:bool):
        for component in self.components:
            component.hasCogJoint = value
            
         
    @qtUtils.withoutUndo   
    def setJointCount(self):
        value = self.jointCountSpinBox.value()
        if self.components:
            result = False
            for component in self.components:
                _result = component.setJointCount(value)
                if _result:
                    result = _result
            if result:
                self.updateTree.emit()
        
        
        
if __name__ == '__main__':
    f = FkSpineWidget()
    f.show()
    
    #f.setEnabled(False)