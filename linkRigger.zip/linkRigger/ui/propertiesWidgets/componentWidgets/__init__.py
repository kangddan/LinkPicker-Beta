'''
Widget Naming Convention:
For each component, the corresponding widget class should be named as:
    <ComponentName>Widget
For example, the widget for the FkChain component is named FkChainWidget
'''

from .fkSpineWidget import FkSpineWidget
from .masterWidget  import MasterWidget
from .fkChainWidget import FkChainWidget
from .vChainWidget  import VChainWidget
from .armWidget     import ArmWidget
from .aimWidget     import AimWidget