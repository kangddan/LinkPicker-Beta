from maya import cmds
from maya.api import OpenMaya as om2

from PySide6 import QtWidgets
from PySide6 import QtGui
from PySide6 import QtCore

from linkRigger.ui import qtUtils, layouts, widgets

from linkRigger.ui.propertiesWidgets.componentWidgets import vChainWidget

class ArmWidget(vChainWidget.VChainWidget):
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setStyleSheet(self.styleSheet() + '''
            #twistCheckBox::indicator, #bendyCheckBox::indicator {
                width: 20px;
                height: 20px;
            }
            #twistCheckBox::indicator:unchecked, #bendyCheckBox::indicator:unchecked {
                background: #1C1C1C;
            }
            #twistCheckBox::indicator:checked, #bendyCheckBox::indicator:checked {
                background: #1C1C1C;
                border-image: url(linkIcons:hook.png);
            }
            #twistCheckBox::indicator:checked:disabled, #bendyCheckBox::indicator:checked:disabled {
                border-image: url(linkIcons:disabledHook.png);
            }
        ''')
        
        self.setTwistWidgetsMode(False)
        
        
    def _createWidgets(self):
        super()._createWidgets()
        self.twistCheckBox = QtWidgets.QCheckBox()
        self.twistCheckBox.setObjectName('twistCheckBox')
        
        self.bendyCheckBoxLabel = QtWidgets.QLabel('Bendy (Beta) ')
        self.bendyCheckBox = QtWidgets.QCheckBox()
        self.bendyCheckBox.setObjectName('bendyCheckBox')
        
        self.uprTwistJointCountLabel = QtWidgets.QLabel('Upr Twist Count ')
        self.uprTwistJointCount = widgets.createBaseQSpinBox(5, 99, 3)
        self.lwrTwistJointCountLabel = QtWidgets.QLabel('Lwr Twist Count ')
        self.lwrTwistJointCount = widgets.createBaseQSpinBox(5, 99, 3)
 
  
        
    def _createLayouts(self):
        super()._createLayouts()
        
        self.twistSpinBoxLayer = QtWidgets.QGridLayout()
        self.twistSpinBoxLayer.setContentsMargins(0, 0, 0, 0)
        self.twistSpinBoxLayer.addWidget(QtWidgets.QLabel('Enable Twist '), 0, 0)
        self.twistSpinBoxLayer.addWidget(self.twistCheckBox, 0, 1)
        
        self.twistSpinBoxLayer.addWidget(self.bendyCheckBoxLabel, 1, 0)
        self.twistSpinBoxLayer.addWidget(self.bendyCheckBox, 1, 1)
        
        self.twistSpinBoxLayer.addWidget(self.uprTwistJointCountLabel, 2, 0)
        self.twistSpinBoxLayer.addWidget(self.uprTwistJointCount, 2, 1)
        self.twistSpinBoxLayer.addWidget(self.lwrTwistJointCountLabel, 2, 2)
        self.twistSpinBoxLayer.addWidget(self.lwrTwistJointCount, 2, 3)
        self.twistSpinBoxLayer.setAlignment(QtCore.Qt.AlignLeft)
        self.mainLayout.addLayout(self.twistSpinBoxLayer)
        
        
    def _createConnections(self):
        super()._createConnections()
        self.twistCheckBox.toggled.connect(self.setTwistWidgetsMode)
        self.twistCheckBox.toggled.connect(self.enableTwist)
        self.bendyCheckBox.toggled.connect(self.enableBendy)
        
        self.uprTwistJointCount.editingFinished.connect(self.setUprTwistCount)
        self.lwrTwistJointCount.editingFinished.connect(self.setLwrTwistCount)
    
    def setTwistWidgetsMode(self, value:bool):
        self.uprTwistJointCountLabel.setDisabled(not value) 
        self.uprTwistJointCount.setDisabled(not value) 
        self.lwrTwistJointCountLabel.setDisabled(not value) 
        self.lwrTwistJointCount.setDisabled(not value) 
        self.bendyCheckBox.setDisabled(not value) 
        self.bendyCheckBoxLabel.setDisabled(not value) 
        
        
    def setUprTwistCount(self):
        if not self.components:
            return
        value = self.uprTwistJointCount.value()
        
        result = False
        for component in self.components:
            _result = component.setUprTwistJointCount(value)
            if _result:
                result = _result
        if result:
            self.updateTree.emit()
        
        
    def setLwrTwistCount(self):
        if not self.components:
            return
        value = self.lwrTwistJointCount.value()
        
        result = False
        for component in self.components:
            _result = component.setLwrTwistJointCount(value)
            if _result:
                result = _result
        if result:
            self.updateTree.emit()
        
        
    @qtUtils.withoutUndo         
    def enableTwist(self, value:bool):
        for component in self.components:
            if value:
                if component.enableTwist():
                    self.updateTree.emit()
            else:
                if component.deleteAllTwistGuideNode():
                    self.updateTree.emit()
                    
    @qtUtils.withoutUndo         
    def enableBendy(self, value:bool):
        for component in self.components:
            if value:
                if component.enableBendy():
                    self.updateTree.emit()
            else:
                if component.deleteAllBendyGuideNode():
                    self.updateTree.emit()
  
        
    def setData(self, components:'Component') -> bool:
        value = super().setData(components)
        if not value:
            return
        self.twistCheckBox.blockSignals(True) 
        self.uprTwistJointCount.blockSignals(True) 
        self.uprTwistJointCount.blockSignals(True) 
        self.bendyCheckBox.blockSignals(True) 
        
        self.twistCheckBox.setChecked(self._components[0].twist)
        self.bendyCheckBox.setChecked(self._components[0].bendy)
        self.setTwistWidgetsMode(self._components[0].twist)
        self.uprTwistJointCount.setValue(self._components[0].uprTwistCount)
        self.lwrTwistJointCount.setValue(self._components[0].lwrTwistCount)
        
        self.twistCheckBox.blockSignals(False) 
        self.uprTwistJointCount.blockSignals(False) 
        self.uprTwistJointCount.blockSignals(False) 
        self.bendyCheckBox.blockSignals(False) 
    
if __name__ == '__main__':
    a = ArmWidget()
    a.show()