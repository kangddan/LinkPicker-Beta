from maya import cmds
from maya.api import OpenMaya as om2

from PySide6 import QtWidgets
from PySide6 import QtGui
from PySide6 import QtCore

from linkRigger.ui import qtUtils, layouts, widgets


class AimWidget(QtWidgets.QWidget):
    
    updateTree = QtCore.Signal()
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName('AimWidget')
        self.setFocusPolicy(QtCore.Qt.StrongFocus)
        self.setAttribute(QtCore.Qt.WA_StyledBackground, True) 
        
        self.components  = [] # cache rebuild state component
        self._components = [] # cache all state component
        
        self._createWidgets()
        self._createLayouts()
        self._createConnections()
        
        self.setStyleSheet('''
            #AimWidget { background-color: #373737;} 
            
            QMenu { background-color: #1A1A1A; border: 2px solid #363636; color: #B4B4B4;}
            QMenu::item { background-color: transparent; }
            QMenu::separator { height: 3px; background: #363636; margin-left: 15px; margin-right: 15px; }
            QMenu::item:selected { background-color: #4D4D4D; color: #F0F0F0;}
            QMenu::right-arrow { border-image: url(linkIcons:menuLeft.png); }
            QMenu::right-arrow:disabled { border-image: url(linkIcons:menuLeftDisabled.png)} 
            QMenu::item:disabled {color: #585858;}

            QSpinBox {selection-background-color: #358ABB; 
                              
                                      background-color: #1C1C1C; 
                                      border: none; }  
            
            #alignButton {background: #4B4B4B; color: white; border: none;  border-radius: 15px;}
            #alignButton:hover {background: #5C5C5C;}
            #alignButton:pressed {background: #464646;}
            #alignButton:disabled {color: #A0A0A0;}
                               
            ''')
        
    
    def _createWidgets(self):
        
        self.aimVectorX = widgets.createBaseQSpinBox(1, 1, -1)
        self.aimVectorY = widgets.createBaseQSpinBox(0, 1, -1)
        self.aimVectorZ = widgets.createBaseQSpinBox(0, 1, -1)
        self.aimVectors = [self.aimVectorX , self.aimVectorY , self.aimVectorZ]
        
        self.upVectorX = widgets.createBaseQSpinBox(0, 1, -1)
        self.upVectorY = widgets.createBaseQSpinBox(0, 1, -1)
        self.upVectorZ = widgets.createBaseQSpinBox(-1, 1, -1)
        self.upVectors = [self.upVectorX , self.upVectorY , self.upVectorZ]
        
        self.alignButton = QtWidgets.QPushButton('Align')
        self.alignButton.setObjectName('alignButton')
        self.alignButton.setFixedHeight(30)
        
        
    def _createLayouts(self):
        aimVectorLayout = QtWidgets.QHBoxLayout()
        aimVectorLayout.setContentsMargins(0, 0, 0, 0)
        aimVectorLayout.setSpacing(10)
        aimVectorLayout.addWidget(self.aimVectorX)
        aimVectorLayout.addWidget(self.aimVectorY)
        aimVectorLayout.addWidget(self.aimVectorZ)
        
        upVectorLayout = QtWidgets.QHBoxLayout()
        upVectorLayout.setContentsMargins(0, 0, 0, 0)
        upVectorLayout.setSpacing(10)
        upVectorLayout.addWidget(self.upVectorX)
        upVectorLayout.addWidget(self.upVectorY)
        upVectorLayout.addWidget(self.upVectorZ)


        self.subLayout = QtWidgets.QGridLayout()
        self.subLayout.setSpacing(10)
        self.subLayout.setContentsMargins(0, 0, 0, 0)
        
        self.subLayout.addWidget(QtWidgets.QLabel('Aim Vector '), 0, 0)
        self.subLayout.addLayout(aimVectorLayout, 0, 1)
        self.subLayout.addWidget(QtWidgets.QLabel('Up Vector '), 1, 0)
        self.subLayout.addLayout(upVectorLayout, 1, 1)
        self.subLayout.setAlignment(QtCore.Qt.AlignLeft)
        
        self.mainLayout = QtWidgets.QVBoxLayout(self)
        self.mainLayout.setContentsMargins(0, 0, 0, 0)
        self.mainLayout.addLayout(self.subLayout)
        self.mainLayout.addWidget(self.alignButton)
        
        
    def _createConnections(self):
        self.alignButton.clicked.connect(self.align)
        
        
    @qtUtils.addUndo    
    def align(self):
        for component in self.components:
            component.align(self.aimVector, self.upVector)
            
            
    def setAimVector(self, value:list):
        for aimVector, value in zip(self.aimVectors, value):
            aimVector.setValue(value)
            
    @property        
    def aimVector(self) -> list:
        return [aimVector.value() for aimVector in self.aimVectors]
            
            
    def setUpVector(self, value:list):
        for upVector, value in zip(self.upVectors, value):
            upVector.setValue(value)
            
    @property          
    def upVector(self) -> list:
        return [upVector.value() for upVector in self.upVectors]
    
    
    def setData(self, components:'Component') -> bool:
        metaClassName = self.__class__.__name__.split('Widget')[0]
        self._components = [component for component in components if component.metaClass == metaClassName]
                       
        self.components = [component for component in self._components if component.hasRebuild]
        if not self._components:
            return False

        self.setAimVector(self._components[0].aimVector)
        self.setUpVector(self._components[0].upVector)
        
        return True
        

if __name__ == '__main__':
    a = AimWidget()
    a.show()
        
        
    
        