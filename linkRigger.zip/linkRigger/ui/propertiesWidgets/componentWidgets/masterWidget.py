from maya import cmds
from maya.api import OpenMaya as om2

from PySide6 import QtWidgets
from PySide6 import QtGui
from PySide6 import QtCore

from linkRigger.ui import qtUtils

class MasterWidget(QtWidgets.QWidget):
    
    updateTree = QtCore.Signal()
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName('MasterWidget')
        self.setFocusPolicy(QtCore.Qt.StrongFocus)
        self.setAttribute(QtCore.Qt.WA_StyledBackground, True) 
        
        self.setStyleSheet('''
            #MasterWidget { background-color: #373737;} 
            
            QCheckBox::indicator { width: 20px; height: 20px;}
            QCheckBox::indicator:unchecked { background: #1C1C1C; }
            QCheckBox::indicator:checked { background: #1C1C1C; border-image: url(linkIcons:hook.png);} 
            QCheckBox::indicator:checked:disabled { border-image: url(linkIcons:disabledHook.png); }                        
                               
            ''')
        self.components = []
        self._createWidgets()
        self._createLayouts()
        self._createConnections()
        
        
    def _createWidgets(self):
        self.rootJointCheckBox = QtWidgets.QCheckBox()
        

    def _createLayouts(self):
        mainLayout = QtWidgets.QGridLayout(self)
        mainLayout.setContentsMargins(0, 0, 0, 0)
        mainLayout.addWidget(QtWidgets.QLabel('Root Joint '), 0, 0)
        mainLayout.addWidget(self.rootJointCheckBox, 0, 1)
        mainLayout.setAlignment(QtCore.Qt.AlignLeft)

        
    def _createConnections(self):
        self.rootJointCheckBox.toggled.connect(self.setRootJoint)
 
        
    def setData(self, components:'list[Component]'):  
        _components = [component for component in components if component.metaClass == 'Master']
        self.components = [component for component in _components if component.hasRebuild]
        if not _components:
            return
   
        self.rootJointCheckBox.blockSignals(True) 
        self.rootJointCheckBox.setChecked(_components[0].rootJoint)
        self.rootJointCheckBox.blockSignals(False) 
        
        
    @qtUtils.withoutUndo       
    def setRootJoint(self, value:bool):
        for component in self.components:
            component.rootJoint = value
        
        
    
if __name__ == '__main__':
    g = MasterWidget()
    g.show()