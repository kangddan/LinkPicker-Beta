from PySide6 import QtWidgets
from PySide6 import QtGui
from PySide6 import QtCore

class NullWidget(QtWidgets.QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        
        mainLayout = QtWidgets.QHBoxLayout(self)
        mainLayout.setContentsMargins(20, 0, 20, 0)
        textLable = QtWidgets.QLabel()
        textLable.setAlignment(QtCore.Qt.AlignCenter) 
        textLable.setWordWrap(True)
        textLable.setStyleSheet(''' 
                           QLabel { font-size: 16px; font-weight: bold; }
                           ''')
  
        textLable.setText("<img src='linkIcons:emptyBox.png'><h4>No component selected, select to view or edit</h4>")    
        mainLayout.addWidget(textLable)  