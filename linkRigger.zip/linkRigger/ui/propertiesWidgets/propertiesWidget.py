from collections import OrderedDict
from maya import cmds
from maya.api import OpenMaya as om2

from PySide6 import QtWidgets
from PySide6 import QtGui
from PySide6 import QtCore

from linkRigger.ui.rigHierarchyWidgets import utils

from linkRigger.ui.propertiesWidgets import nullWidget
from linkRigger.ui.propertiesWidgets import componentEditor
        


class PropertiesWidget(QtWidgets.QWidget):
    selectedComponents = QtCore.Signal(list)
    
    def __init__(self, parent=None, hierarchyTreeWidget=None):
        super().__init__(parent)
        
        self.setObjectName('PropertiesWidget')
        self.setAttribute(QtCore.Qt.WA_StyledBackground, True) 
        self.setStyleSheet(''' 
                           #PropertiesWidget { background-color: #373737;} 
                           #propertiesWidgetTitle { font-size: 16px; font-weight: bold; }
                           ''')
        
        self.hierarchyTreeWidget = hierarchyTreeWidget       
        self._createWidgets()
        self._createLayouts()
        self._createConnections()
        
        
    def _createWidgets(self):
        self.propertiesWidgetTitle = QtWidgets.QLabel('ATTRIBUTES')
        self.propertiesWidgetTitle.setObjectName('propertiesWidgetTitle')
        
        self.componentEditorWidget = componentEditor.ComponentEditor(hierarchyTreeWidget=self.hierarchyTreeWidget) # add hierarchyTreeWidget
        self.componentEditorWidget.hide()
        self.nullWidget = nullWidget.NullWidget()
        
        self.spacerItem  = QtWidgets.QSpacerItem(0, 0, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.spacerItem2 = QtWidgets.QSpacerItem(0, 0, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding) 
            
            
    def _createLayouts(self):
        self.mainLayout = QtWidgets.QVBoxLayout(self)
        self.mainLayout.setContentsMargins(0, 0, 0, 0)
        self.mainLayout.setSpacing(10)
        titleLayout = QtWidgets.QHBoxLayout()
        titleLayout.setContentsMargins(5, 5, 5, 0)
        titleLayout.addWidget(self.propertiesWidgetTitle)
        titleLayout.addStretch()
        
        self.mainLayout.addLayout(titleLayout)                # index = 0
        self.mainLayout.addWidget(self.componentEditorWidget) # index = 1
        self.mainLayout.addItem(self.spacerItem)              # index = 2
        self.mainLayout.addWidget(self.nullWidget)            # index = 3
        self.mainLayout.addItem(self.spacerItem2)             # index = 4
        
          
    def _createConnections(self):
        if self.hierarchyTreeWidget is not None:
            self.hierarchyTreeWidget.itemSelectionChanged.connect(self.showComponentWidgets)
            
        # Forward the selectedComponents signal from PropertiesWidget to ComponentEditorWidget
        self.selectedComponents.connect(self.componentEditorWidget.selectedComponents.emit) 
        
        
    def showComponentWidgets(self):
        '''
        Handle component selection, show or hide the corresponding widget, and emit a signal.
        '''
        selItems = self.hierarchyTreeWidget.selectedItems()

        components = list(filter(None, [self.selectedItemToComponent(item) for item in selItems]))
        '''
        Emit selected component! 
        Pay attention to deduplication, as guideItem and componentItem are considered a single unit
        '''
        self.selectedComponents.emit(list(OrderedDict.fromkeys(components)))
 
        # show component attrs widget
        if selItems:
            self.nullWidget.hide()
            self.componentEditorWidget.show() 
            '''
            Remove the spacer to prevent componentEditorWidget's editScrollArea from being compressed
            '''
            self.mainLayout.removeItem(self.spacerItem) 
            self.mainLayout.removeItem(self.spacerItem2) 
        else:
            self.componentEditorWidget.hide()
            self.nullWidget.show()
            '''
            Re-add the spacer to center the nullWidget
            '''
            self.mainLayout.insertItem(2, self.spacerItem)
            self.mainLayout.insertItem(4, self.spacerItem2) 
            
    
    def selectedItemToComponent(self, item:QtWidgets.QTreeWidgetItem=None) -> 'Component|None':
        '''
        Get the corresponding component object based on the selected TreeWidgetItem
        '''
        if item is None:
            return None
            
        component = None
        uuid      = item.data(0, QtCore.Qt.UserRole )    
        itemType  = item.data(0, QtCore.Qt.UserRole + 2)
        
        if itemType == 'guide':
            guideNode = utils.uuidToGuideNode(uuid)
            if guideNode:
                component = guideNode.guideLayer.metaParent()
        elif itemType == 'component':
            component = utils.uuidToMetaNode(uuid)
  
        return component
        
        
        
        
        
        
        
if __name__ == '__main__':
    p = PropertiesWidget()
    p.show()