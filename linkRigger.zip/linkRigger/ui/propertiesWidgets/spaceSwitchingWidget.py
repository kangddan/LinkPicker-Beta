from maya import cmds
from maya.api import OpenMaya as om2
from functools import partial

from PySide6 import QtWidgets
from PySide6 import QtGui
from PySide6 import QtCore

from linkRigger.ui import widgets, qtUtils, getComponentIcon, getGuideIcon
from linkRigger.ui.rigHierarchyWidgets import utils
from linkRigger.core import nodes


        
class SpaceSwitchTargetWidget(QtWidgets.QWidget):
    CACHE_DATA = {}
    
    @classmethod
    def clearCacheData(cls):
        cls.CACHE_DATA = {}
        
    
    def __init__(self, parent=None, 
                       parentLayout=None,
                       component:'Component'=None):
        super().__init__(parent)
        self.setFocusPolicy(QtCore.Qt.StrongFocus)
        self.setObjectName('SpaceSwitchTargetWidget')
        
        self.setStyleSheet('''
            #SpaceSwitchTargetWidget { background-color: #373737;} 
            
            QLineEdit {selection-background-color: #358ABB;  height: 25px;  background-color: #1C1C1C; 
                       border: none; border-radius: 0px; padding: 2px; padding-left: 10px; padding-right: 0px; } 
            
            QMenu { background-color: #1A1A1A; border: 2px solid #363636; color: #B4B4B4;}
            QMenu::item { background-color: transparent; }
            QMenu::separator { height: 3px; background: #363636; margin-left: 15px; margin-right: 15px; }
            QMenu::item:selected { background-color: #4D4D4D; color: #F0F0F0;}
            QMenu::right-arrow { border-image: url(linkIcons:menuLeft.png); }
            QMenu::right-arrow:disabled { border-image: url(linkIcons:menuLeftDisabled.png)} 
            QMenu::item:disabled {color: #585858;}
            
            QCheckBox::indicator { width: 20px; height: 20px;}
            QCheckBox::indicator:unchecked { background: #1C1C1C; }
            QCheckBox::indicator:checked { background: #1C1C1C; border-image: url(linkIcons:hook.png);}   
            QCheckBox::indicator:checked:disabled { border-image: url(linkIcons:disabledHook.png); } 
            
            QScrollBar:vertical { border: none; width: 10px; margin: 0px 0 0px 0; }
            QScrollBar::handle:vertical { background: #5C5C5C; min-height: 20px; border-radius: 5px; }
            QScrollBar::handle:vertical:hover { background: #656565; }
            QScrollBar::handle:vertical:pressed {background: #6E6E6E; }
            QScrollBar::sub-line:vertical,
            QScrollBar::add-line:vertical { background: none; height: 0; }
            QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {background: #1A1A1A; }
            
            QComboBox { background-color: #4B4B4B; height: 28px; border-radius: 0px; padding-left: 8px;}
            QComboBox:hover { background-color: #5C5C5C;}
            QComboBox QAbstractItemView { border: 6px solid #1A1A1A; background-color: #1A1A1A; selection-background-color: #4D4D4D; }
            QComboBox::drop-down { border: none; background: transparent; width: 32px; }
            QComboBox::down-arrow {border-image: url(linkIcons:downHoverSource.png); width: 20px; height: 20px; }
            QComboBox::down-arrow:disabled { border-image: url(linkIcons:downHoverSourceDisabled.png); width: 20px; height: 20px;} 
            QComboBox:focus { background-color: #4B4B4B;  padding-left: 8px;}
            
            #pCheckBox { color: #F0E68C; }
            
            #lineShape {border-top: 1px solid #606060;}

            
            #deleteButton {background: #4B4B4B; color: white; border: none; border-radius: 3px;}
            #deleteButton:hover {background: #5C5C5C;}
            #deleteButton:pressed {background: #464646;}
            #deleteButton:disabled {color: #A0A0A0;}
            

            ''')
        
        self.parentLayout = parentLayout
        self.component = component
        self._createWidgets()
        self._createLayouts()
        self._createConnections()
        
        self.setupComponentItems()

        
    
    def _createWidgets(self):
        self.tCheckBox = QtWidgets.QCheckBox('T')
        self.tCheckBox.setChecked(True)
        self.tCheckBox.setLayoutDirection(QtCore.Qt.RightToLeft) 
        self.rCheckBox = QtWidgets.QCheckBox('R')
        self.rCheckBox.setChecked(True)
        self.rCheckBox.setLayoutDirection(QtCore.Qt.RightToLeft) 
        self.sCheckBox = QtWidgets.QCheckBox('S')
        self.sCheckBox.setChecked(True)
        self.sCheckBox.setLayoutDirection(QtCore.Qt.RightToLeft) 
        self.trsCheckboxs = [self.tCheckBox, self.rCheckBox, self.sCheckBox]
        
        self.pCheckBox = QtWidgets.QCheckBox('P') # parent
        self.pCheckBox.setObjectName('pCheckBox')
        self.pCheckBox.setChecked(False)
        self.pCheckBox.setLayoutDirection(QtCore.Qt.RightToLeft) 
        self.pCheckBox.setToolTip('Automatically find the optimal parent object')
        
        self.nameLineEdit = QtWidgets.QLineEdit()
        self.nameLineEdit.setValidator(QtGui.QRegularExpressionValidator(QtCore.QRegularExpression(r'^[a-zA-Z_][a-zA-Z0-9_]*$')))
        
        self.deleteButton = QtWidgets.QPushButton(QtGui.QIcon('linkIcons:delete.png'), '')
        self.deleteButton.setObjectName('deleteButton')
        self.deleteButton.setToolTip('Delete Space Switch')
        self.deleteButton.setFixedSize(24, 24)
        
        
        delegate = widgets.CustomDelegate(self, 32)
        self.componentComboBox = widgets.ComboBox()
        self.componentComboBox.setItemDelegate(delegate)
        self.componentComboBox.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
        self.targetGuideComboBox = widgets.ComboBox()
        self.targetGuideComboBox.setItemDelegate(delegate)
        self.targetGuideComboBox.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
        
        self.lineShape = QtWidgets.QFrame()
        self.lineShape.setFrameShape(QtWidgets.QFrame.HLine)
        self.lineShape.setObjectName('lineShape')
        
        
    def _createLayouts(self):
        mainLayout = QtWidgets.QVBoxLayout(self)
        #mainLayout.setContentsMargins(0, 0, 0, 0)
        mainLayout.setSpacing(5)
        checkBoxLayout = QtWidgets.QHBoxLayout()
        checkBoxLayout.setSpacing(15)
        checkBoxLayout.addWidget(self.tCheckBox)
        checkBoxLayout.addWidget(self.rCheckBox)
        checkBoxLayout.addWidget(self.sCheckBox)
        checkBoxLayout.addWidget(self.pCheckBox)
        
        nameEditLayout = QtWidgets.QHBoxLayout()
        nameEditLayout.setContentsMargins(0, 0, 0, 0)
        nameEditLayout.setSpacing(5)
        nameEditLayout.addWidget(QtWidgets.QLabel('Name'))
        nameEditLayout.addWidget(self.nameLineEdit)
        nameEditLayout.addWidget(self.deleteButton)
        
        targetComboBoxLayout = QtWidgets.QHBoxLayout()
        targetComboBoxLayout.setContentsMargins(0, 0, 0, 0)
        targetComboBoxLayout.setSpacing(5)
        targetComboBoxLayout.addWidget(QtWidgets.QLabel('Comp'))
        targetComboBoxLayout.addWidget(self.componentComboBox)
        targetComboBoxLayout.addSpacerItem(
                                        QtWidgets.QSpacerItem(15, 0, 
                                        QtWidgets.QSizePolicy.Fixed,
                                        QtWidgets.QSizePolicy.Minimum))
        targetComboBoxLayout.addWidget(QtWidgets.QLabel('Targ'))
        targetComboBoxLayout.addWidget(self.targetGuideComboBox)
        
        checkBoxLayout.addLayout(nameEditLayout)
        mainLayout.addLayout(checkBoxLayout)
        mainLayout.addLayout(targetComboBoxLayout)
        mainLayout.addWidget(self.lineShape)
        
        
    def _createConnections(self):
        self.componentComboBox.activated.connect(self.showGuideItems)
        self.deleteButton.clicked.connect(self.deleteSelf)
        self.pCheckBox.toggled.connect(self.setTRSState)
        
        
    def setTRSState(self, value:bool, parentAttrName=''):
        '''
        Reset TRS state, primarily preparing for automatic parenting
        '''
        # 0 set TRS checkboxs state
        newValue = not value
        for c in self.trsCheckboxs:
            c.setChecked(newValue)
            c.setEnabled(newValue)
        
        # 1 set parentAttr name
        self.nameLineEdit.setText(parentAttrName or 'parent' if value else '')
        
        # 3 reset component and targetGuide Comboboxs and state
        if value:
            self.showGuideItems(0)
            self.componentComboBox.setCurrentIndex(0)
            
        self.componentComboBox.setEnabled(newValue)
        self.targetGuideComboBox.setEnabled(newValue)
            
        
    
    def deleteSelf(self):
        self.parentLayout.removeWidget(self)
        self.deleteLater()
        
        
    def setupComponentItems(self):
        '''
        Retrieve all components in guide mode from componentsManager and add them as items
        '''
        if not self.component:
            return
        self.componentComboBox.clear()
        if self.component.hasBuild:
            return
            
        # Add default "None" option
        self.componentComboBox.addItem('None', None)  
        for component in self.component.componentsManager.listComponentNodes():
            '''
            Ensure that we only retrieve guides in guide mode. For example, 
            when switching to rig mode, new components may still be added, 
            but they can only be attached to the guides of components in guide mode
            '''
            if component.hasBuild:
                continue
            icon = getComponentIcon(component.metaClass)
            text = component.baseName
            UUID = component.node.uuid().asString()
            self.componentComboBox.addItem(icon, text, UUID)   
            
            
    
    def showGuideItems(self, index:int):
        '''
        Display the guide node of the selected component
        '''
        self.targetGuideComboBox.clear()
        data:'UUID|None' = self.componentComboBox.itemData(index)
        if data is None:
            return
        component = utils.uuidToMetaNode(data)
        if component is None:
            return
        
        guides = component.listGuideNodes(includeRoot=False)
        for guide in guides:
            # add uuid to data
            icon = getGuideIcon('baseGuide')
            text = guide.shortName
            UUID = om2.MFnDependencyNode(guide.node.node()).uuid().asString()
            self.targetGuideComboBox.addItem(icon, text, UUID)  
    
        
    def setCurrentComponentItemFromUUID(self, uuid:str):
        '''
        Select the component item based on UUID
        '''
        for index in range(self.componentComboBox.count()):
            if uuid == self.componentComboBox.itemData(index, QtCore.Qt.UserRole):
                self.componentComboBox.setCurrentIndex(index)
                '''
                Manually update targetGuide when selecting a componentItem
                '''
                self.showGuideItems(index)
                return
            
            
    def setCurrentTargetGuideItemFromUUID(self, uuid:str):
        '''
        Select the targetGuide item based on UUID
        '''
        for index in range(self.targetGuideComboBox.count()):
            if uuid == self.targetGuideComboBox.itemData(index, QtCore.Qt.UserRole):
                self.targetGuideComboBox.setCurrentIndex(index)
                return

       
    def setData(self, data:dict): 
        
        self.tCheckBox.setChecked(data['p'])
        self.rCheckBox.setChecked(data['r'])
        self.sCheckBox.setChecked(data['s'])
        self.setCurrentComponentItemFromUUID(data['targetComponentUUID'])
        self.setCurrentTargetGuideItemFromUUID(data['targetGuideNodeUUID'])
        
        
        isParent = data['isParent']
        self.pCheckBox.blockSignals(True) 
        self.pCheckBox.setChecked(isParent)
        if isParent:
            self.setTRSState(True, data['attrName'])
        else:
            self.nameLineEdit.setText(data['attrName'])
        self.pCheckBox.blockSignals(False) 
        
        
    @property    
    def isValidSwitch(self) -> bool:
        '''
        Check if the basic inputs for space switching are valid
        (component selected AND at least one TRS checkbox checked)
        '''
        basicValid = (self.componentComboBox.currentData() is not None 
                      and any(cb.isChecked() for cb in self.trsCheckboxs))
        
        # check parent        
        return basicValid or self.pCheckBox.isChecked()
        
        
    def getData(self) -> dict:
        data = {}
        if not self.isValidSwitch:
            return data
        data['targetGuideNode'] = utils.uuidToGuideNode(self.targetGuideComboBox.currentData())
        data['attrName']        = self.nameLineEdit.text() or 'spaceSwitch'
        data['useTranslate']    = self.tCheckBox.isChecked()
        data['useRotate']       = self.rCheckBox.isChecked()
        data['useScale']        = self.sCheckBox.isChecked()
        data['useShear']        = True
        data['isParent']        = self.pCheckBox.isChecked()
        return data


class SpaceSwitchingWidget(QtWidgets.QWidget):

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName('SpaceSwitchingWidget')
        self.setFocusPolicy(QtCore.Qt.StrongFocus)
        self.setAttribute(QtCore.Qt.WA_StyledBackground, True) 
        
        self.setStyleSheet('''
            #SpaceSwitchingWidget { background-color: #373737;} 
            
            #spaceSwitchingWidgetTitle { color: white;}
            
            QScrollBar:vertical { border: none; width: 10px; margin: 0px 0 0px 0; }
            QScrollBar::handle:vertical { background: #5C5C5C; min-height: 20px; border-radius: 5px; }
            QScrollBar::handle:vertical:hover { background: #656565; }
            QScrollBar::handle:vertical:pressed {background: #6E6E6E; }
            QScrollBar::sub-line:vertical,
            QScrollBar::add-line:vertical { background: none; height: 0; }
            QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {background: #1A1A1A; }
            
            QComboBox { background-color: #4B4B4B; height: 28px; border-radius: 0px; padding-left: 8px;}
            QComboBox:hover { background-color: #5C5C5C;}
            QComboBox QAbstractItemView { border: 6px solid #1A1A1A; background-color: #1A1A1A; selection-background-color: #4D4D4D; }
            QComboBox::drop-down { border: none; background: transparent; width: 32px; }
            QComboBox::down-arrow {border-image: url(linkIcons:downHoverSource.png); width: 20px; height: 20px; }
            QComboBox::down-arrow:disabled { border-image: url(linkIcons:downHoverSourceDisabled.png); width: 20px; height: 20px;} 
            QComboBox:focus { background-color: #4B4B4B;  padding-left: 8px;}
            
            #addButton,  #updateButton {background: #4B4B4B; color: white; border: none; border-radius: 15px;}
            #addButton:hover, #updateButton:hover {background: #5C5C5C;}
            #addButton:pressed, #updateButton:pressed {background: #464646;}
            #addButton:disabled, #updateButton:disabled {color: #A0A0A0;}
            ''')
        self.cacheComponent = None
            
        self._createWidgets()
        self._createLayouts()
        self._createConnections()
        
    def _createWidgets(self):
        self.spaceSwitchingWidgetTitle = QtWidgets.QLabel('Space Switching')
        self.spaceSwitchingWidgetTitle.setObjectName('spaceSwitchingWidgetTitle')
        
        delegate = widgets.CustomDelegate(self, 32)
        self.guideComboBox = widgets.ComboBox()
        self.guideComboBox.setItemDelegate(delegate)
        
        self.addButton = QtWidgets.QPushButton('Add')
        self.addButton.setObjectName('addButton')
        self.addButton.setFixedHeight(30)
        
        self.updateButton = QtWidgets.QPushButton('Apply')
        self.updateButton.setObjectName('updateButton')
        self.updateButton.setFixedHeight(30)
        

    
    def _createLayouts(self):
        mainLayout = QtWidgets.QVBoxLayout(self)
        mainLayout.setSpacing(5)
        mainLayout.setContentsMargins(5, 0, 5, 0)
        mainLayout.addWidget(self.spaceSwitchingWidgetTitle)
        mainLayout.addWidget(self.guideComboBox)

        subLayout = QtWidgets.QHBoxLayout()
        subLayout.addWidget(self.addButton)
        subLayout.addWidget(self.updateButton)
        
        self.targetsLayout = QtWidgets.QVBoxLayout()
        self.targetsLayout.setSpacing(0)
        self.targetsLayout.setContentsMargins(0, 0, 0, 0)
 
        mainLayout.addLayout(subLayout)
        mainLayout.addLayout(self.targetsLayout)
            

    def _createConnections(self):
        self.addButton.clicked.connect(self.addSpaceSwitchTarget)
        self.guideComboBox.activated.connect(self.showCurrentGuideSpaceSwitch)
        self.updateButton.clicked.connect(self.updateSpaceSwitch)
        
        self.addButton.clicked.connect(partial(self.setUpdateButtonText, 'Apply*'))
        self.updateButton.clicked.connect(partial(self.setUpdateButtonText, 'Apply'))
        
        
    def setUpdateButtonText(self, text):
        self.updateButton.setText(text)    

        
        
    @qtUtils.addUndo
    def updateSpaceSwitch(self):
        if self.cacheComponent is None or self.cacheComponent.hasBuild:
            return
        # 0 get drivenGuideNode
        drivenGuideNode = utils.uuidToGuideNode(self.guideComboBox.currentData())
        if drivenGuideNode is None:
            return
        # 1 delete space attr 
        self.cacheComponent.rigLayer.deleteDrivenGuideSpaceSwitch(drivenGuideNode)
        
        for targetWidget in self.getTargetWidgets():
            data = targetWidget.getData()
            if not data:
                continue
            data['drivenGuideNode'] = drivenGuideNode
            self.cacheComponent.rigLayer.addSpaceSwitch(**data)
            
              

    def getGuideSpaceData(self, guideNode:'GuideNode') -> 'list[dict]':
        '''
        Retrieve the space switch data of the specified guideNode from rigLayer
        '''
        dataList = []
        path = f'{self.cacheComponent.rigLayer.nodeName}.spaceSwitchTargets'
        for index in range((cmds.getAttr(path, mi=True) or [0])[-1] + 1):
            basePath      = f'{path}[{index}]' 
            guideNodeName = cmds.listConnections(f'{basePath}.drivenGuideNode', d=False, s=True, fnn=True) or []
            if not guideNodeName or guideNodeName[0] != guideNode.nodeName:
                continue

            targetGuideNode = nodes.GuideNode(cmds.listConnections(f'{basePath}.targetGuideNode', d=False, s=True)[0])
            
            data = {'p'                  : cmds.getAttr(f'{basePath}.useTranslate'),
                    'r'                  : cmds.getAttr(f'{basePath}.useRotate'),
                    's'                  : cmds.getAttr(f'{basePath}.useScale'),
                    'attrName'           : cmds.getAttr(f'{basePath}.attrName'),
                    'targetComponentUUID': targetGuideNode.guideLayer.metaParent().node.uuid().asString(),
                    'targetGuideNodeUUID': om2.MFnDependencyNode(targetGuideNode.node.node()).uuid().asString(),
                    'isParent'           : cmds.getAttr(f'{basePath}.isParent')}

            dataList.append(data)
            
        return dataList
                
        
    def showCurrentGuideSpaceSwitch(self, index:int):
        '''
        Display the space switch information of the selected guide
        '''
        self.deleteAllSpaceSwitchTarget()
        data:'UUID' = self.guideComboBox.itemData(index)
        guideNode = utils.uuidToGuideNode(data)
        if guideNode is None:
            return
            
        datas = self.getGuideSpaceData(guideNode)
        for _data in datas:
            targetWidget = self.addSpaceSwitchTarget()
            targetWidget.setData(_data)
            
   
    def addSpaceSwitchTarget(self) -> 'SpaceSwitchTargetWidget':
        '''
        Add a new SpaceSwitchTargetWidget to targetsLayout
        '''
        count = self.targetsLayout.count()
        targetWidget = SpaceSwitchTargetWidget(parentLayout=self.targetsLayout, 
                                               component=self.cacheComponent)
        
        if count > 0:
            self.targetsLayout.insertWidget(count-1, targetWidget)
        else:
            self.targetsLayout.addWidget(targetWidget)
            self.targetsLayout.addStretch()
        return targetWidget
    
    
    def deleteLastSpaceSwitchTarget(self):
        '''
        Delete the last SpaceSwitchTargetWidget from targetsLayout
        '''
        targetWidgets = self.getTargetWidgets()
        if not targetWidgets:
            return
        self.targetsLayout.removeWidget(targetWidgets[-1])
        targetWidgets[-1].deleteLater()
    
    
    def deleteAllSpaceSwitchTarget(self):
        '''
        Delete all SpaceSwitchTargetWidgets
        '''
        targetWidgets = self.getTargetWidgets()
        if not targetWidgets:
            return
        for targetWidget in targetWidgets:
            self.targetsLayout.removeWidget(targetWidget)
            targetWidget.deleteLater()
    
    
    def getTargetWidgets(self) -> 'list[SpaceSwitchTargetWidget]':
        '''
        Get all SpaceSwitchTargetWidgets
        '''
        return [self.targetsLayout.itemAt(i).widget() for i in range(self.targetsLayout.count()-1)]
        
        
    
    def setupComponentGuidesItem(self):
        '''
        Update cacheComponent guide items
        '''
        self.guideComboBox.clear()
        
        if self.cacheComponent.hasBuild:
            '''
            If the component is in rig mode, clear all items as we have already deleted the guide layer
            '''
            self.guideComboBox.addItem(QtGui.QIcon('linkIcons:lockParent.png'), 'Unavailable')
            return
        
        
        for guide in self.cacheComponent.listGuideNodes(includeRoot=False):
            icon = getGuideIcon('baseGuide')
            text = guide.shortName
            UUID = om2.MFnDependencyNode(guide.node.node()).uuid().asString()
            self.guideComboBox.addItem(icon, text, UUID)  
        
        
        
    def setData(self, components:'list[Component]'):
        '''
        Display space switch data based on the selected component
        '''
        self.deleteAllSpaceSwitchTarget()
        if not components or len(components) != 1:
            return
        elif components[0].hasBuild:
            self.setEnabled(False)
        elif components[0].hasRebuild:
            self.setEnabled(True)
            '''
            Only during the guide stage, clear/update invalid spaceSwitch data each time a component is clicked
            '''
            components[0].rigLayer.updateSpaceSwitchInfo()
            
            
        self.cacheComponent = components[0]
        self.setupComponentGuidesItem()
        # Manually activate the space switch data of the first guide item
        self.showCurrentGuideSpaceSwitch(0)
        
        
        
        
if __name__ == '__main__':
    s = SpaceSwitchingWidget()
    s.show()
    # s = SpaceSwitchTargetWidget()
    # s.show()   