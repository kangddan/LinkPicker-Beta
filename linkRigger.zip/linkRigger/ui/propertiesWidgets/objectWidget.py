from maya import cmds
from maya.api import OpenMaya as om2

from PySide6 import QtWidgets
from PySide6 import QtGui
from PySide6 import QtCore

from linkRigger.ui.propertiesWidgets import componentWidgets


class ObjectWidget(QtWidgets.QWidget):
    
    updateTree = QtCore.Signal()
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName('ObjectWidget')
        self.setFocusPolicy(QtCore.Qt.StrongFocus)
        self.setAttribute(QtCore.Qt.WA_StyledBackground, True) 
        
        self.setStyleSheet('''
            #ObjectWidget { background-color: #373737;} 
            
            #objectWidgetTitle { color: white;}
            ''')
            
            
        self._createWidgets()
        self._createLayouts()
        self._createConnections()
        
        self.cacheComponentWidget   = {}
        self.currentComponentWidget = None 
        
    
    def _createWidgets(self):
        self.objectWidgetTitle = QtWidgets.QLabel('Object Properties')
        self.objectWidgetTitle.setObjectName('objectWidgetTitle')
        
        self.componentLayout = QtWidgets.QVBoxLayout() 
        self.componentLayout.setContentsMargins(0, 0, 0, 0)
    
        

    def _createLayouts(self):
        mainLayout = QtWidgets.QVBoxLayout(self)
        mainLayout.setSpacing(10)
        mainLayout.setContentsMargins(5, 0, 5, 0)
        mainLayout.addWidget(self.objectWidgetTitle)
        # add component Widget
        mainLayout.addLayout(self.componentLayout)
 

    def _createConnections(self):
        pass
        
    
    def removeCurrentComponentWidget(self):
        '''
        Remove the component widget from the component layout. 
        It is worth noting that we are only removing it, not deleting it.
        '''
        if self.currentComponentWidget:
            self.componentLayout.removeWidget(self.currentComponentWidget)
            self.currentComponentWidget.setParent(None) 
            self.currentComponentWidget = None
        
        
    def swicthComponentWidget(self, components:'list[Component]'=None):
        '''
        Generate the corresponding widget based on the component.
        '''
        if not components:
            return   
            
        component = components[0]   
        self.setEnabled(not component.hasBuild)
                
        # 0 get componentWidget className
        className = f'{component.metaClass}Widget'
        # 1 Check if the current widget needs to be updated
        if self.currentComponentWidget is not None:
            if len(self.currentComponentWidget.components) == len(components) == 1 and component == self.currentComponentWidget.components[0]: # Same component, no update needed
                print('同一个')
                return
            if className == f'{self.currentComponentWidget.__class__.__name__}': # Update existing widget data
                self.currentComponentWidget.setData(components)
                print('同类型')
                return
        # 2 Remove the current component widget    
        self.removeCurrentComponentWidget()
        
        # 3 # Retrieve the widget from the cache
        newWidget = self.cacheComponentWidget.get(className)
        
        if newWidget is None:
            componentClass = getattr(componentWidgets, className, None)
            if componentClass is None:
                om2.MGlobal.displayWarning(f'Could not find the corresponding component widget: {className}')
                return
            newWidget = componentClass() 
            newWidget.updateTree.connect(self.updateTree.emit)
            self.cacheComponentWidget[className] = newWidget 
        
        newWidget.setParent(self)
        newWidget.setData(components)
        self.componentLayout.addWidget(newWidget)
        self.currentComponentWidget = newWidget 

if __name__ == '__main__':
    o = ObjectWidget()
    o.show()