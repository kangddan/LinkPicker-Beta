from maya import cmds
from maya.api import OpenMaya as om2

from PySide6 import QtWidgets
from PySide6 import QtGui
from PySide6 import QtCore

from linkRigger.ui import widgets, qtUtils, getComponentIcon
from linkRigger.ui.rigHierarchyWidgets import utils


class BasicWidget(QtWidgets.QWidget):
    updateTree = QtCore.Signal()
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName('BasicWidget')
        self.setAttribute(QtCore.Qt.WA_StyledBackground, True) 
        
        self.setStyleSheet('''
            #BasicWidget { background-color: #373737;} 
            
            #basicWidgetTitle { color: white;}
            #parentComboBoxLabel { color: #F0E68C; }

            
            QMenu { background-color: #1A1A1A; border: 2px solid #363636; color: #B4B4B4;}
            QMenu::item { background-color: transparent; }
            QMenu::separator { height: 3px; background: #363636; margin-left: 15px; margin-right: 15px; }
            QMenu::item:selected { background-color: #4D4D4D; color: #F0F0F0;}
            QMenu::right-arrow { border-image: url(linkIcons:menuLeft.png); }
            QMenu::right-arrow:disabled { border-image: url(linkIcons:menuLeftDisabled.png)} 
            QMenu::item:disabled {color: #585858;}
                           
            QScrollBar:vertical { border: none; width: 10px; margin: 0px 0 0px 0; }
            QScrollBar::handle:vertical { background: #5C5C5C; min-height: 20px; border-radius: 5px; }
            QScrollBar::handle:vertical:hover { background: #656565; }
            QScrollBar::handle:vertical:pressed {background: #6E6E6E; }
            QScrollBar::sub-line:vertical,
            QScrollBar::add-line:vertical { background: none; height: 0; }
            QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {background: #1A1A1A; }
                           
            QComboBox { background-color: #4B4B4B; height: 28px; border-radius: 0px; padding-left: 8px;}
            QComboBox:hover { background-color: #5C5C5C;}
            QComboBox QAbstractItemView { border: 6px solid #1A1A1A; background-color: #1A1A1A; selection-background-color: #4D4D4D; }
            
            QComboBox::drop-down { border: none; background: transparent; width: 32px; }
            QComboBox::down-arrow {border-image: url(linkIcons:downHoverSource.png); width: 20px; height: 20px; }
            QComboBox::down-arrow:disabled { border-image: url(linkIcons:downHoverSourceDisabled.png); width: 20px; height: 20px;} 
            QComboBox:focus { background-color: #4B4B4B;  padding-left: 8px;}
            
            QLineEdit {selection-background-color: #358ABB; 
                                      height: 25px; 
                                      background-color: #1C1C1C; 
                                      border: none;
                                      border-radius: 0px;
                                      padding: 3px;
                                      padding-left: 8px;
                                      padding-right: 0px; }         
            
            ''')
        self.cacheComponents = []
        
        self._createWidgets()
        self._createLayouts()
        self._createConnections()
        
    
    def _createWidgets(self): 
        self.basicWidgetTitle = QtWidgets.QLabel('Basic Properties')
        self.basicWidgetTitle.setObjectName('basicWidgetTitle')
        
        delegate = widgets.CustomDelegate(self, 32)
        
        self.nameLineEdit = QtWidgets.QLineEdit()
        #self.nameLineEditAction = self.nameLineEdit.addAction(QtGui.QIcon('linkIcons:close.png'), QtWidgets.QLineEdit.TrailingPosition)
        self.nameLineEdit.setValidator(QtGui.QRegularExpressionValidator(QtCore.QRegularExpression(r'^[a-zA-Z_][a-zA-Z0-9_]*$')))
        
        self.sideComboBox = widgets.ComboBox()
        self.sideComboBox.setItemDelegate(delegate)
        self.sideComboBox.addItems(['L', 'left', 'l', 'Left', 'lt', 'LEFT', 'R', 'right', 'r', 'Right', 'rt', 'RIGHT', 'c', 'C', 'm', 'M', 'mid', 'MID', 'Mid'])
        
        self.parentComboBox = widgets.ComboBox()
        self.parentComboBox.setItemDelegate(delegate)
        
        self.parentComboBoxLabel = QtWidgets.QLabel('Parent ')
        self.parentComboBoxLabel.setObjectName('parentComboBoxLabel')
        

    def _createLayouts(self):
        mainLayout = QtWidgets.QVBoxLayout(self)
        mainLayout.setSpacing(10)
        mainLayout.setContentsMargins(5, 0, 5, 0)
        basicAttrLayout = QtWidgets.QGridLayout()
        basicAttrLayout.setContentsMargins(0, 0, 0, 0)
        basicAttrLayout.addWidget(QtWidgets.QLabel('Name '), 0, 0)
        basicAttrLayout.addWidget(self.nameLineEdit, 0, 1)
        basicAttrLayout.addWidget(QtWidgets.QLabel('Side '), 1, 0)
        basicAttrLayout.addWidget(self.sideComboBox, 1, 1)
        basicAttrLayout.addWidget(self.parentComboBoxLabel, 2, 0)
        basicAttrLayout.addWidget(self.parentComboBox, 2, 1)
        #basicAttrLayout.setRowStretch(3, 1) 
        mainLayout.addWidget(self.basicWidgetTitle)
        mainLayout.addLayout(basicAttrLayout)

        
    def _createConnections(self):
        #self.nameLineEditAction.triggered.connect(self.nameLineEdit.clear)
        self.nameLineEdit.editingFinished.connect(self.setName)
        self.sideComboBox.activated.connect(self.setSide)
        self.parentComboBox.activated.connect(self.addParent)
        
        
    @qtUtils.addUndo    
    def setName(self):
        if not self.cacheComponents:
            return

        newName  = self.nameLineEdit.text()
        oldNames = [component.name for component in self.cacheComponents]
        if all(newName == oldName for oldName in oldNames):
            return
        
        for component in self.cacheComponents:
            component.setName(newName)
        self.updateTree.emit()
            
    
    @qtUtils.addUndo    
    def setSide(self, index:int):
        newSide = self.sideComboBox.itemText(index) 
        if not self.cacheComponents or not newSide:
            return
            
        oldSides = [component.side for component in self.cacheComponents]
        if all(newSide == oldSide for oldSide in oldSides):
            return
        
        for component in self.cacheComponents:
            component.setSide(newSide)
        self.updateTree.emit()
                   
            
    @qtUtils.withoutUndo
    def addParent(self, index:int):
        if not self.cacheComponents:
            return
        
        data:'UUID|None|Unavailable' = self.parentComboBox.itemData(index)
        if data == 'Unavailable':
            return
        
        if data is None and self.cacheComponents[0].removeComponentParent():
            self.updateTree.emit()
            
        else: # uuid
            parentGuide = utils.uuidToGuideNode(data)
            if parentGuide and self.cacheComponents[0].addComponentParent(parentGuide):
                self.updateTree.emit()

  
    def _updateParentGuideItems(self, component:'Component'):
        '''
        Update the selected component's parent guide item
        '''
        self.parentComboBox.clear()
        
        if component.hasBuild:
            '''
            If the component is in rig mode, clear all items as we have already deleted the guide layer
            '''
            self.parentComboBox.addItem(QtGui.QIcon('linkIcons:lockParent.png'), 'Unavailable')
            self.parentComboBox.setEnabled(False)
            return
        else:
            self.parentComboBox.setEnabled(True)
        
        
        self.parentComboBox.addItem('None', None)    

        componentsManager = component.componentsManager
        components = [_component for _component in componentsManager.listComponentNodes() if _component.metaId !=component.metaId]
        
        for _component in components:
            '''
            Ensure that we only retrieve guides in guide mode. For example, 
            when switching to rig mode, new components may still be added, 
            but they can only be attached to the guides of components in guide mode
            '''
            if _component.hasBuild:
                continue
            guides = _component.listGuideNodes(includeRoot=False)
            for guide in guides:
                # add uuid to data
                icon = getComponentIcon(_component.metaClass)
                text = f'[{_component.baseName}]  {guide.shortName}'
                UUID = om2.MFnDependencyNode(guide.node.node()).uuid().asString()
                self.parentComboBox.addItem(icon, text, UUID)  

        # selected parentItem
        parentGuideNode = component.guideLayer.parentGuide
        if parentGuideNode is None:
            self.parentComboBox.setCurrentText('None')
        else:
            parentComponent = parentGuideNode.guideLayer.metaParent()
            self.parentComboBox.setCurrentText(f'[{parentComponent.baseName}]  {parentGuideNode.shortName}')
    

                
    def setData(self, components:'list[Component]'=None):
        '''
        Update basic data based on the selected component.
        '''
        if not components:
            return 
        print('aadd')    

        self.cacheComponents = components or []
        self.nameLineEdit.setText(components[0].name)
        self.sideComboBox.setCurrentText(components[0].side)
        
        if len(components) > 1:
            '''
            If multiple components are selected, clear parentItems. 
            The current design only allows setting a parent when a single component is selected.
            '''
            self.parentComboBox.clear()
            self.parentComboBox.addItem(QtGui.QIcon('linkIcons:lockParent.png'), 'Unavailable', 'Unavailable')
        else:
            self._updateParentGuideItems(components[0])
        
        
        

        
if __name__ == '__main__':
    b = BasicWidget()
    b.show()