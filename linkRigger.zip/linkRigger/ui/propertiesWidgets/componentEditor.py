from PySide6 import QtWidgets
from PySide6 import QtGui
from PySide6 import QtCore

from linkRigger.ui import layouts
from linkRigger.ui.propertiesWidgets import basicWidget
from linkRigger.ui.propertiesWidgets import objectWidget
from linkRigger.ui.propertiesWidgets import spaceSwitchingWidget


class ComponentEditor(QtWidgets.QWidget):
    selectedComponents = QtCore.Signal(list)
    
    def __init__(self, parent=None, hierarchyTreeWidget=None):
        super().__init__(parent)
        self.setObjectName('ComponentEditor')
        self.setAttribute(QtCore.Qt.WA_StyledBackground, True) 
        self.setStyleSheet(''' 
                            #ComponentEditor, #attributesWidget { background-color: #373737;} 
                            
                            #basicButton {color: #F0E68C; background: #505050;  border: none;  border-radius: 5px;}
                            #basicButton:hover {background: #646464; }
                            #basicButton:pressed  {color: #000000; background: #F0E68C;}
                            #basicButton:checked {color: #000000; background: #F0E68C;}
                            #basicButton:checked:hover {color: #000000; background: #F0E68C;}
                            
                            #objectButton, #spaceSwitchButton {background: #505050;  border: none;  border-radius: 5px; }
                            #objectButton:hover, #spaceSwitchButton:hover {background: #646464; }
                            #objectButton:pressed, #spaceSwitchButton:pressed {background: #545A99;}
                            #objectButton:checked, #spaceSwitchButton:checked {background: #545A99;}
                            
                            QMenu { background-color: #1A1A1A; border: 2px solid #363636; color: #B4B4B4;}
                            QMenu::item { background-color: transparent; }
                            QMenu::separator { height: 3px; background: #363636; margin-left: 15px; margin-right: 15px; }
                            QMenu::item:selected { background-color: #4D4D4D; color: #F0F0F0;}
                            QMenu::right-arrow { border-image: url(linkIcons:menuLeft.png); }
                            QMenu::right-arrow:disabled { border-image: url(linkIcons:menuLeftDisabled.png)} 
                            QMenu::item:disabled {color: #585858;}
            
                            QScrollBar:vertical { border: none; width: 10px; margin: 0px 0 0px 0; }
                            QScrollBar::handle:vertical { background: #5C5C5C; min-height: 20px; border-radius: 5px; }
                            QScrollBar::handle:vertical:hover { background: #656565; }
                            QScrollBar::handle:vertical:pressed {background: #6E6E6E; }
                            QScrollBar::sub-line:vertical,
                            QScrollBar::add-line:vertical { background: none; height: 0; }
                            QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {background: #373737; }
                            
                            QScrollBar:horizontal { border: none; height: 10px; margin: 0 0px 0 0px; }
                            QScrollBar::handle:horizontal { background: #5C5C5C; min-width: 20px; border-radius: 5px; }
                            QScrollBar::handle:horizontal:hover { background: #656565; }
                            QScrollBar::handle:horizontal:pressed {background: #6E6E6E; }
                            QScrollBar::sub-line:horizontal,
                            QScrollBar::add-line:horizontal { background: none; width: 0; }
                            QScrollBar::add-page:horizontal, QScrollBar::sub-page:horizontal {background: #373737; }
                            
                            QAbstractScrollArea::corner { background: #373737; }  
                           ''')
        
        self.hierarchyTreeWidget = hierarchyTreeWidget 
        self._createWidgets()
        self._createLayouts()
        self._createConnections()
        
        
        
    
    def _createWidgets(self): 
        self.componentIconLabel = QtWidgets.QLabel('')
        
        self.basicButton = QtWidgets.QPushButton('Basic')
        self.basicButton.setObjectName('basicButton')
        self.basicButton.setFixedSize(72, 28)
        self.basicButton.setCheckable(True)
        self.basicButton.setChecked(True)

        self.objectButton = QtWidgets.QPushButton('Object')
        self.objectButton.setObjectName('objectButton')
        self.objectButton.setFixedSize(84, 28)
        self.objectButton.setCheckable(True)

        self.spaceSwitchButton = QtWidgets.QPushButton('Space Switching')
        self.spaceSwitchButton.setObjectName('spaceSwitchButton')
        self.spaceSwitchButton.setFixedSize(165, 28)
        self.spaceSwitchButton.setCheckable(True)
        
        self.buttons = [self.basicButton, self.objectButton, self.spaceSwitchButton]
        self.buttonsGroup = QtWidgets.QButtonGroup()
        self.buttonsGroup.setExclusive(False)  
        for index, button in enumerate(self.buttons):
            self.buttonsGroup.addButton(button, index)
            
        buttonsLayout = layouts.FlowLayout()
        buttonsLayout.setSpacing(5)
        for button in self.buttons:
            buttonsLayout.addWidget(button)

        
        # add attrs widget    
        self.attributesScrollArea = QtWidgets.QScrollArea()
        self.attributesScrollArea.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.attributesScrollArea.setWidgetResizable(True)

        attributesWidget = QtWidgets.QWidget()
        attributesWidget.setObjectName('attributesWidget')
        attributesWidget.setAttribute(QtCore.Qt.WA_StyledBackground, True) 
        attributesLayout = QtWidgets.QVBoxLayout(attributesWidget)
        attributesLayout.setContentsMargins(0, 0, 0, 0)
        
        self.basicWidget       = basicWidget.BasicWidget()                   # 0 basic
        self.objectWidget      = objectWidget.ObjectWidget()                 # 1 object
        self.spaceSwitchWidget = spaceSwitchingWidget.SpaceSwitchingWidget() # 2 space
        
        attributesLayout.addWidget(self.componentIconLabel)
        attributesLayout.addLayout(buttonsLayout)
        attributesLayout.addWidget(self.basicWidget)
        attributesLayout.addWidget(self.objectWidget)
        attributesLayout.addWidget(self.spaceSwitchWidget)
        attributesLayout.addStretch()
        self.attributesScrollArea.setWidget(attributesWidget)
        
        # add button map
        self.buttonMenuMap = {self.basicButton:       self.basicWidget,
                              self.objectButton:      self.objectWidget,
                              self.spaceSwitchButton: self.spaceSwitchWidget}
        
        self.showSelectedWidget()
 
 
    def _createLayouts(self):
        mainLayout = QtWidgets.QVBoxLayout(self)
        mainLayout.setContentsMargins(0, 0, 0, 0)
        mainLayout.addWidget(self.attributesScrollArea)
        
           
    def _createConnections(self):
        self.buttonsGroup.buttonClicked.connect(self._handleButtonClick)
        
        self.selectedComponents.connect(self.setData) # update componentAttrWidgets
        if self.hierarchyTreeWidget is not None:
            self.basicWidget.updateTree.connect(self.hierarchyTreeWidget.insertRefreshHierarchyTree)
            self.objectWidget.updateTree.connect(self.hierarchyTreeWidget.insertRefreshHierarchyTree)
        
    
    def setData(self, components:'list[Component]'):
        self.updateComponentTab(components)
        self.basicWidget.setData(components)
        self.objectWidget.swicthComponentWidget(components)
        self.spaceSwitchWidget.setData(components)
    
    
    def updateComponentTab(self, components:list):
        if not components:
            return
        
        # 0 update label
        refMetaClass = components[0].metaClass
        isSame = all(component.metaClass == refMetaClass for component in components)
        count  = len(components)
        if isSame:
            iconPath = f'linkIcons:{refMetaClass}.png'
            text1 = f'{refMetaClass} ({count} Elements)' if count > 1 else refMetaClass
        else:
            iconPath = f'linkIcons:mixComponent2.png'
            text1 = f'{len(components)} Elements'    
        componentNames = f"[{', '.join(component.baseName for component in components)}]"
        self.componentIconLabel.setText(
        f'<table><tr>'
        f'<td><img src="{iconPath}" width="30" height="30"></td>'
        f'<td style="vertical-align: middle;"> {text1} {componentNames}</td>'
        f'</tr></table>')
        
        # 1 show tab
        if isSame and count > 1:
            self.objectButton.show()
            self.spaceSwitchButton.hide()
            self.spaceSwitchButton.setChecked(False) 
            if not self.objectButton.isChecked():
                self.basicButton.setChecked(True)    
        elif not isSame:
            self.objectButton.hide()
            self.spaceSwitchButton.hide()
            self.objectButton.setChecked(False) 
            self.spaceSwitchButton.setChecked(False) 
            self.basicButton.setChecked(True) 
        else:
            self.objectButton.show()
            self.spaceSwitchButton.show()
        self.showSelectedWidget()
        

    def _handleButtonClick(self, button):
        '''
        Switch between different widgets using buttons, supporting multi-selection and deselection
        '''
        modifiers = QtWidgets.QApplication.keyboardModifiers()

        if modifiers == QtCore.Qt.ShiftModifier:
            button.setChecked(True)
        elif modifiers == QtCore.Qt.ControlModifier:
            button.setChecked(False)
        else:
            for _button in self.buttons:
                _button.setChecked(_button == button)
                
        # Always ensure that at least one button remains active        
        if not any(_button.isChecked() for _button in self.buttons):
            self.basicButton.setChecked(True) 
        
        self.showSelectedWidget()
        
    
    def showSelectedWidget(self):
        for button, widget in self.buttonMenuMap.items():
            widget.setVisible(button.isChecked()) 
        
        
    
        
if __name__ == '__main__':
    c = ComponentEditor()
    c.show()
    # c.basicWidget.setEnabled(False)
    # c.basicButton.setEnabled(False)