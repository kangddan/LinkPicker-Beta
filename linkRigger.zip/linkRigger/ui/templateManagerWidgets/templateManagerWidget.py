import os
import shutil
import json
from maya import cmds
from maya.api import OpenMaya as om2

from functools import partial
from PySide6 import QtWidgets
from PySide6 import QtGui
from PySide6 import QtCore

from linkRigger.ui import widgets, qtUtils, TEMPLATE_PATH
from linkRigger.ui.templateManagerWidgets import templateSelectedDialog

from linkRigger import components
from linkRigger.core import buildManager, meta



class TemplateManagerTreeMenu(QtWidgets.QMenu):
    
    saveToTemplateTriggered   = QtCore.Signal()
    revealInExplorerTriggered = QtCore.Signal()
    newFolderTriggered        = QtCore.Signal()
    renameTriggered           = QtCore.Signal()
    deleteTriggered           = QtCore.Signal()
    refreshTriggered          = QtCore.Signal()
    expandTriggered           = QtCore.Signal()
    collapseTriggered         = QtCore.Signal()
    
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.templateManagerTree = parent

        self._createActions()
        self._createConnections()
        
        
    def _createActions(self):
        self.saveToTemplateAction = QtGui.QAction(QtGui.QIcon('linkIcons:saveToTemplate.png'), 'Save to Template')
        self.revealInExplorerAction = QtGui.QAction(QtGui.QIcon('linkIcons:revealInExplorer.png'), 'Reveal in Explorer')
        self.newFolderAction = QtGui.QAction(QtGui.QIcon('linkIcons:newFolder.png'), 'New Folder')
        self.renameAction = QtGui.QAction(QtGui.QIcon('linkIcons:renameRig.png'), 'Rename')
        self.deleteAction = QtGui.QAction(QtGui.QIcon('linkIcons:delete.png'), 'Delete')
        
        self.refreshAction = QtGui.QAction(QtGui.QIcon('linkIcons:refresh.png'), 'Refresh')
        self.expandAction = QtGui.QAction(QtGui.QIcon('linkIcons:expand.png'), 'Expand All')
        self.collapseAction = QtGui.QAction(QtGui.QIcon('linkIcons:collaps.png'), 'Collapse All')
        
        self.addAction(self.saveToTemplateAction)
        self.addAction(self.revealInExplorerAction)
        self.addSeparator()
        self.addAction(self.newFolderAction)
        self.addAction(self.renameAction)
        self.addAction(self.deleteAction)
        self.addSeparator()
        self.addAction(self.expandAction)
        self.addAction(self.collapseAction)
        self.addAction(self.refreshAction)
        
        
    def _createConnections(self):
        self.aboutToShow.connect(self._updateActionsState) 
        self.saveToTemplateAction.triggered.connect(self.saveToTemplateTriggered.emit)
        self.revealInExplorerAction.triggered.connect(self.revealInExplorerTriggered.emit)
        self.newFolderAction.triggered.connect(self.newFolderTriggered.emit)
        self.renameAction.triggered.connect(self.renameTriggered.emit)
        self.deleteAction.triggered.connect(self.deleteTriggered.emit)
        self.refreshAction.triggered.connect(self.refreshTriggered.emit)
        self.expandAction.triggered.connect(self.expandTriggered.emit)
        self.collapseAction.triggered.connect(self.collapseTriggered.emit)
        
        
    def _updateActionsState(self):
        hasSelection = bool(self.templateManagerTree.selectedItems())
        
        self.deleteAction.setEnabled(hasSelection)
        self.renameAction.setEnabled(hasSelection)
        
        self.saveToTemplateAction.setEnabled(self.templateManagerTree.characterExists)


class TemplateManagerTree(QtWidgets.QTreeWidget):
    
    ITEM_TYPES = {'.json'}
    
    updateHierarchy = QtCore.Signal()
    createCharacterManager = QtCore.Signal()
    selectedUUID = QtCore.Signal(str)
    
    def __init__(self, parent=None):
        super().__init__(parent)  
        self.setHeaderHidden(True)
        self.setAlternatingRowColors(True)  
        self.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
        self.setSelectionMode(QtWidgets.QAbstractItemView.ExtendedSelection)
        self.setItemDelegate(qtUtils.CustomItemDelegate())
        self.setIndentation(26)
        
        self.setStyleSheet('''    
                           QMenu { background-color: #1A1A1A; border: 2px solid #363636; color: #B4B4B4;}
                           QMenu::item { background-color: transparent; }
                           QMenu::separator { height: 3px; background: #363636; margin-left: 15px; margin-right: 15px; }
                           QMenu::item:selected { background-color: #4D4D4D; color: #F0F0F0;}
                           QMenu::right-arrow { border-image: url(linkIcons:menuLeft.png); }
                           QMenu::right-arrow:disabled { border-image: url(linkIcons:menuLeftDisabled.png)} 
                           QMenu::item:disabled {color: #585858;}
        
                           QScrollBar:vertical { border: none; width: 10px; margin: 0px 0 0px 0; }
                           QScrollBar::handle:vertical { background: #5C5C5C; min-height: 20px; border-radius: 5px; }
                           QScrollBar::handle:vertical:hover { background: #656565; }
                           QScrollBar::handle:vertical:pressed {background: #6E6E6E; }
                           QScrollBar::sub-line:vertical,
                           QScrollBar::add-line:vertical { background: none; height: 0; }
                            
                            
                           QTreeWidget { border: 0px solid #373737; background-color: #2A2A2A; }
                           /* QTreeWidget::item:hover { color: #FFA53F; padding-left: 0px; background-color: transparent;} */
                           QTreeWidget::item:selected { color: #FFA53F; border: none; background: transparent; padding-left: 0px;}
                           QTreeWidget::item:alternate { background-color: #232323; }
                           
 
                           QTreeWidget::branch:has-siblings:!adjoins-item { border-image: url(linkIcons:branchLine.png); }
                           QTreeWidget::branch:has-siblings:adjoins-item { border-image: url(linkIcons:branchMore.png); }
                           QTreeWidget::branch:!has-children:!has-siblings:adjoins-item { border-image: url(linkIcons:branchEnd.png);}
                           
                           QTreeWidget::branch:has-children:!has-siblings:closed,
                           QTreeWidget::branch:closed:has-children:has-siblings { border-image: none; image: url(linkIcons:leftSource.png); }
                           QTreeWidget::branch:open:has-children:!has-siblings,
                           QTreeWidget::branch:open:has-children:has-siblings { border-image: none; image: url(linkIcons:downSource.png);}  
                           /* 
                           QTreeWidget::branch:has-children:!has-siblings:closed:hover,
                           QTreeWidget::branch:closed:has-children:has-siblings:hover { border-image: none; image: url(linkIcons:leftHoverSource.png); }
                           QTreeWidget::branch:open:has-children:!has-siblings:hover,
                           QTreeWidget::branch:open:has-children:has-siblings:hover { border-image: none; image: url(linkIcons:downHoverSource.png); }
                            */
                          ''') 
                          
        self.characterManager:'CharacterManager' = None                  
        self._createMenu()                  
        self._createConnections()
        self.setupItems(None, TEMPLATE_PATH)
        self.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.customContextMenuRequested.connect(self.showTemplateManagerTreeMenu)
    
    
    def showTemplateManagerTreeMenu(self, point:QtCore.QPoint):
        self.templateManagerTreeMenu.exec(self.mapToGlobal(point))    
        
        
    def _createMenu(self):
        self.templateManagerTreeMenu = TemplateManagerTreeMenu(self)
        
        
    def _createConnections(self):
        self.itemDoubleClicked.connect(self.loadRigFromTemplate)
        self.itemClicked.connect(self.openFolderItem)
        
        self.itemExpanded.connect(self.onItemExpanded)
        self.itemCollapsed.connect(self.onItemCollapsed)
        
        self.templateManagerTreeMenu.expandTriggered.connect(partial(self.setFolderItemsExpanded, True))
        self.templateManagerTreeMenu.collapseTriggered.connect(partial(self.setFolderItemsExpanded, False))
        self.templateManagerTreeMenu.refreshTriggered.connect(self._refreshTempleat)
        self.templateManagerTreeMenu.deleteTriggered.connect(self.deleteItem)
        self.templateManagerTreeMenu.revealInExplorerTriggered.connect(self._revealInExplorer)    
        self.templateManagerTreeMenu.renameTriggered.connect(self.renameTemplateOrDir)
        self.templateManagerTreeMenu.newFolderTriggered.connect(self.createFolder)
        self.templateManagerTreeMenu.saveToTemplateTriggered.connect(self.saveRigAsTemplate)
        
    
    def openFolderItem(self, item:QtWidgets.QTreeWidgetItem):
        if item.data(0, QtCore.Qt.UserRole) != 'folder':
            return
        if item.isExpanded():
            item.setExpanded(False)
        else:
            item.setExpanded(True)
        
        
    def setupItems(self, parentItem, directory):

        for item in sorted(os.listdir(directory)):
            itemPath = os.path.join(directory, item)
            isDir    = os.path.isdir(itemPath)
            if not isDir and os.path.splitext(item)[1] not in TemplateManagerTree.ITEM_TYPES:
                continue
             
            itemName = os.path.splitext(item)[0] if not isDir else item
            childItem = QtWidgets.QTreeWidgetItem([itemName])
            childItem.setSizeHint(0, QtCore.QSize(0, 30))
            childItem.setIcon(0, QtGui.QIcon(f"linkIcons:{'folderClose' if isDir else 'baseComponent'}.png"))
            childItem.setData(0, QtCore.Qt.UserRole, 'folder' if isDir else 'template')
            childItem.setData(0, QtCore.Qt.UserRole + 1, itemPath)  
            if parentItem:
                parentItem.addChild(childItem)
            else:
                self.addTopLevelItem(childItem)
            if isDir:
                self.setupItems(childItem, itemPath)
    
    
    def _revealInExplorer(self):
        selItems = self.selectedItems()
        itemPath = TEMPLATE_PATH if not selItems else selItems[-1].data(0, QtCore.Qt.UserRole + 1)
        if not os.path.exists(itemPath):
            return
        qtUtils.openPathInExplorer(itemPath)
    
        
    def _refreshTempleat(self):
        self.clear()
        self.setupItems(None, TEMPLATE_PATH)
  
        
    @qtUtils.withoutUndo      
    def loadRigFromTemplate(self, item:QtWidgets.QTreeWidgetItem, column:int):
        className = item.data(0, QtCore.Qt.UserRole)
        if className == 'folder':
            return
        selectedTemplatePath = item.data(0, QtCore.Qt.UserRole + 1)
        if not os.path.exists(selectedTemplatePath):
            return om2.MGlobal.displayWarning('Invalid template')
        try:
            rigData = qtUtils.loadFromJson(selectedTemplatePath)
        except Exception:
            return om2.MGlobal.displayWarning('Invalid template')
        
        # no character
        if not self.characterExists:
            buildManager.BuildManager.loadRigFromTemplate(rigData)
            '''
            When characterManager does not exist in the scene, 
            creating a component will automatically generate a character as the parent and emit a signal to update the scene.
            '''
            self.createCharacterManager.emit()
        else:
             # add:1 replace:2 cancel:0
            result:int = templateSelectedDialog.TepleateSelectedDialog().exec()
            if not result:
                return
                
            add = True if result == 1 else False
            
            value:tuple = buildManager.BuildManager.loadRigFromTemplate(
                                                          rigData,
                                                          add=add,
                                                          characterManager=self.characterManager)
            '''
            Emit a signal when creating a component to notify componentTree to update
            '''
            if value[0] and not add:
                #self.createCharacterManager.emit()  
                self.selectedUUID.emit(value[1])
            elif value[0] and add:
                self.updateHierarchy.emit()

            
            
            
    def onItemExpanded(self, item:QtWidgets.QTreeWidgetItem):
        '''
        Change folder icon when expanded
        '''
        if item.data(0, QtCore.Qt.UserRole) == 'folder':
            item.setIcon(0, QtGui.QIcon('linkIcons:folderOpen.png')) 


    def onItemCollapsed(self, item:QtWidgets.QTreeWidgetItem):
        '''
        Change folder icon when collapsed.
        '''
        if item.data(0, QtCore.Qt.UserRole) == 'folder':
            item.setIcon(0, QtGui.QIcon('linkIcons:folderClose.png')) 
    
    
    def getAllItems(self) -> 'list[QtWidgets.QTreeWidgetItem]':
        '''
        Get all items in the QTreeWidget.
        '''
        iterator = QtWidgets.QTreeWidgetItemIterator(self)
        items = []
        while iterator.value():
            items.append(iterator.value())
            iterator += 1 
        return items        
            
            
    def setFolderItemsExpanded(self, expand:bool):
        '''
        Expand or collapse all folder items.
        '''
        for item in self.getAllItems():
            if item.data(0, QtCore.Qt.UserRole) == 'folder':
                item.setExpanded(expand)
       
                
    '''
    state funcs
    '''
    def _getItemsExpandedState(self) -> set:
        '''
        Retrieve paths of all expanded folder items
        '''
        expandedFolders = set()
        for item in self.getAllItems():
            if item.data(0, QtCore.Qt.UserRole) == 'folder' and item.isExpanded():
                itemPath = item.data(0, QtCore.Qt.UserRole + 1)
                expandedFolders.add(itemPath)
        return expandedFolders
        
    
    def _setItemsExpandedState(self, expandedFolders: set):
        '''
        Restore expanded state for folders based on stored paths
        '''
        for item in self.getAllItems():
            if item.data(0, QtCore.Qt.UserRole) == 'folder':
                itemPath = item.data(0, QtCore.Qt.UserRole + 1)
                if itemPath in expandedFolders:
                    item.setExpanded(True)
                    
    
    @staticmethod            
    def withItemState(func):
        def wrapper(self, *args, **kwargs):
            expandedFolders = self._getItemsExpandedState()

            result = func(self, *args, **kwargs) 
            
            self._setItemsExpandedState(expandedFolders) 
            return result
        return wrapper

        
        
    @withItemState
    def deleteItem(self):
        '''
        delete selected template or dir
        '''
        items = self.selectedItems()
        if not items:
            return
        deleteItem = items[-1]
        deletePath = deleteItem.data(0, QtCore.Qt.UserRole + 1)
        
        if not os.path.exists(deletePath):
            return
            
        fileType = deleteItem.data(0, QtCore.Qt.UserRole)

        result = widgets.WarningDialog(title=f'Delete {fileType.capitalize()}',
                                       message=f"Delete '{deleteItem.text(0)}'?\nThis action cannot be undone."
                                       ).exec()  
               
        if not result:
            return
        
        if os.path.isfile(deletePath):
            os.remove(deletePath) 
        elif os.path.isdir(deletePath):
            shutil.rmtree(deletePath) 

        self._refreshTempleat()
        
        
    @withItemState
    def renameTemplateOrDir(self):
        '''
        rename selected template or dir
        '''
        items = self.selectedItems()
        if not items:
            return
        renameItem = items[-1]
        renamePath = renameItem.data(0, QtCore.Qt.UserRole + 1)
        
        if not os.path.exists(renamePath):
            return
        
        fileType = renameItem.data(0, QtCore.Qt.UserRole)
        newName  = widgets.InputDialog(baseText=renameItem.text(0), 
                                     title=f'Rename {fileType.capitalize()}', 
                                     message='New Name'
                                       ).exec()  
        if not isinstance(newName, str):
            return

        newPath = f"{os.path.join(os.path.dirname(renamePath), newName)}{'' if fileType == 'folder' else '.json'}"
        if os.path.exists(newPath):
            return om2.MGlobal.displayWarning(f"Error: '{newPath}' already exists in this directory.")
        
        try:
            os.rename(renamePath, newPath) 
            self._refreshTempleat()
        except Exception as e:
            om2.MGlobal.displayWarning(f'Error renaming file: {e}')
                 
    @property
    def savePath(self) -> str:
        items = self.selectedItems() 
        basePath = TEMPLATE_PATH
        
        if items:
            selectedItem = items[-1]      
            if selectedItem.data(0, QtCore.Qt.UserRole) == 'folder':
                basePath = selectedItem.data(0, QtCore.Qt.UserRole + 1)
            elif selectedItem.parent():
                basePath = os.path.dirname(selectedItem.data(0, QtCore.Qt.UserRole + 1))
        return basePath
        
            
    @withItemState        
    def createFolder(self): 
        folderName = widgets.InputDialog(baseText='Folder', 
                                         title='New Folder', 
                                         message='Folder Name',
                                         checkBaseName=False
                                         ).exec()  
        if not isinstance(folderName, str):
            return
        
        newPath = f'{os.path.join(self.savePath, folderName)}'
        if os.path.exists(newPath):
            return om2.MGlobal.displayWarning(f"Error: '{newPath}' already exists in this directory.")
        
        try:
            os.makedirs(newPath) 
            self._refreshTempleat() 
        except Exception as e:
            om2.MGlobal.displayWarning(f'Error creating folder: {e}')
    
    
    @property
    def characterExists(self) -> bool:
        return self.characterManager is not None and cmds.objExists(self.characterManager.nodeName)        
            
            
    @withItemState   
    def saveRigAsTemplate(self):
        if not self.characterExists:
            return
        elif self.characterManager.hasBuild:
            return om2.MGlobal.displayWarning('Please switch to guide mode.')
        elif len(self.characterManager.componentsManager.listComponentNodes(recursive=False)) == 0:
            return om2.MGlobal.displayWarning('No component found.')
        
        rigName = widgets.InputDialog(baseText=self.characterManager.name, 
                                      title='New Template', 
                                      message='Template Name',
                                      checkBaseName=False
                                      ).exec()  
        if not isinstance(rigName, str):
            return
            
        # get path 
        newPath = f'{os.path.join(self.savePath, rigName)}.json'
        if os.path.exists(newPath):
            return om2.MGlobal.displayWarning(f"Error: '{newPath}' already exists in this directory.")
        
        rigData = buildManager.BuildManager.saveRigAsTemplate(
                                            characterManager=self.characterManager, 
                                            rigName=rigName)
        qtUtils.saveToJson(rigData, newPath)
        self._refreshTempleat() 
        
                
            
class TemplateManagerWidget(QtWidgets.QWidget):
    
    updateHierarchy = QtCore.Signal()
    createCharacterManager = QtCore.Signal()
    selectedUUID = QtCore.Signal(str)
    
    def __init__(self, parent=None):
        super().__init__(parent)  
        
        self.setObjectName('TemplateManagerWidget')
        self.setAttribute(QtCore.Qt.WA_StyledBackground, True) 
        self.setStyleSheet(''' 
                           #TemplateManagerWidget { background-color: #373737;} 
                           #componentManagerTitle { font-size: 16px; font-weight: bold; }
                           
                           #componentManagerToolBut {background: #505050;  border: none;  border-radius: 12px; background-image: url('linkIcons:down.png');}
                           #componentManagerToolBut:hover {background: #646464; background-image: url('linkIcons:downHight.png');}
                           #componentManagerToolBut:pressed {background: #282828; background-image: url('linkIcons:down.png');}
                           #componentManagerToolBut::menu-indicator { image: none; width: 0px; }
                           ''')
        
        self._createWidgets()
        self._createLayouts()
        self._createConnections()
        

    def _createWidgets(self):
        self.templateManagerTreeWidget = TemplateManagerTree()
        self.componentManagerTitle = QtWidgets.QLabel('TEMPLATES')
        self.componentManagerTitle.setObjectName('componentManagerTitle')
        
        
    def _createLayouts(self):
        mainLayout = QtWidgets.QVBoxLayout(self)
        mainLayout.setContentsMargins(0, 0, 0, 0)
        mainLayout.setSpacing(4)
        titleLayout = QtWidgets.QHBoxLayout()
        titleLayout.setContentsMargins(5, 0, 5, 0)
        titleLayout.addWidget(self.componentManagerTitle)
        titleLayout.addStretch()
        mainLayout.addLayout(titleLayout)
        mainLayout.addWidget(self.templateManagerTreeWidget)
        
        
    def _createConnections(self):
        self.templateManagerTreeWidget.updateHierarchy.connect(self.updateHierarchy)
        self.templateManagerTreeWidget.createCharacterManager.connect(self.createCharacterManager)
        self.templateManagerTreeWidget.selectedUUID.connect(self.selectedUUID)
        
        
    def setCharacterManager(self, characterManager:'CharacterManager'):
        if characterManager == self.templateManagerTreeWidget.characterManager:
            return  
        self.templateManagerTreeWidget.characterManager = characterManager
        
    
            
if __name__ == '__main__':
    #sceneCharacter = meta.listSceneMetaNodes(ofType=components.CharacterManager)[0]
    t = TemplateManagerWidget()
    t.show()
    #c.setCharacterManager(sceneCharacter)