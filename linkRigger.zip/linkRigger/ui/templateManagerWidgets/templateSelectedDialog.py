from maya import cmds
from maya.api import OpenMaya as om2

from PySide6 import QtWidgets
from PySide6 import QtGui
from PySide6 import QtCore

from linkRigger.ui import widgets



class TepleateSelectedDialog(QtWidgets.QDialog):
    
    GLOBAL_POS = None
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle('Choose Action')
        self.setWindowFlags(QtCore.Qt.Tool)
        self.resize(290, 100)
                          
        self.setStyleSheet('''
            QDialog { background-color: #2B2B2B;}
            
            QPushButton {background: #414141; color: white; border: none; min-width: 90px; min-height: 35px; border-radius: 15px;}
            QPushButton:hover {background: #4D4D4D;}
            QPushButton:pressed {background: #3B3B3B;}
            ''')
        self.selectedOption = 0
        self._createWidget()
        self._createLayouts()
        self._createConnections()

        
        if TepleateSelectedDialog.GLOBAL_POS:
            self.move(TepleateSelectedDialog.GLOBAL_POS)
        
        
    def _createWidget(self):
        self.questionLabel = QtWidgets.QLabel()
        self.questionLabel.setPixmap(QtGui.QPixmap('linkIcons:question.png').scaled(
                                    40, 40, QtCore.Qt.KeepAspectRatio, QtCore.Qt.SmoothTransformation))
        self.textLabel = QtWidgets.QLabel('Add to the current rig or replace it?')
        self.textLabel.setWordWrap(True)
        self.textLabel.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
        self.addButton = QtWidgets.QPushButton('Add')
        self.replaceButton = QtWidgets.QPushButton('Replace')
        self.cancelButton = QtWidgets.QPushButton('Cancel')
        
        
    def _createLayouts(self):
        mainLayout = QtWidgets.QVBoxLayout(self)
        
        labelLayout = QtWidgets.QHBoxLayout()
        labelLayout.setSpacing(20)
        labelLayout.addWidget(self.questionLabel)
        labelLayout.addWidget(self.textLabel)

        buttonsLayout = QtWidgets.QHBoxLayout()
        buttonsLayout.addStretch()
        buttonsLayout.setSpacing(5)
        buttonsLayout.addWidget(self.addButton)
        buttonsLayout.addWidget(self.replaceButton)
        buttonsLayout.addWidget(self.cancelButton)
        
        mainLayout.addLayout(labelLayout)
        mainLayout.addStretch()
        mainLayout.addLayout(buttonsLayout)
        
        
    def _createConnections(self):
        self.cancelButton.clicked.connect(self.close)
        self.addButton.clicked.connect(self._selectAdd)
        self.replaceButton.clicked.connect(self._selectReplace)
        
        
    def _selectAdd(self):
        self.selectedOption = 1 
        self.accept()


    def _selectReplace(self):
        self.selectedOption = 2
        self.accept()
        
            
    def reject(self):
        self.__class__.GLOBAL_POS = self.pos()
        self.selectedOption = 0
        super().reject()

    def accept(self):
        self.__class__.GLOBAL_POS = self.pos()
        super().accept()

        
    def closeEvent(self, event):
        self.__class__.GLOBAL_POS = self.pos()
        super().closeEvent(event)
        
        
    def showEvent(self, event):
        super().showEvent(event)
        self.activateWindow()
        self.raise_()
        
        
    def exec(self):
        super().exec()
        return self.selectedOption 
        
      

if __name__ == '__main__':
    m = TepleateSelectedDialog().exec()
    print(m)
