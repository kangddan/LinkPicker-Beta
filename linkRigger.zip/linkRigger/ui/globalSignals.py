from PySide6 import QtCore


class CharacterManagerSignal(QtCore.QObject):
    characterSwitched = QtCore.Signal(object)
    
    def __repr__(self):
        return f'< CharacterManagerSignal at {hex(id(self))}>'
     
class BuildModeSignal(QtCore.QObject):
    BuildMode = QtCore.Signal()
    
    def __repr__(self):
        return f'< BuildModeSignal at {hex(id(self))}>'        

        
characterManagerSignal = CharacterManagerSignal()
buildModeSignal        = BuildModeSignal()
