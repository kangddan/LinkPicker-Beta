import maya.cmds         as cmds
import maya.api.OpenMaya as om2
import maya.OpenMayaUI   as omui
from functools import partial

from shiboken6 import wrapInstance
from PySide6 import QtWidgets
from PySide6 import QtGui
from PySide6 import QtCore


def indexToQtColor(index:int) -> QtGui.QColor:
    rgb = [int(channel * 255) for channel in cmds.colorIndex(index, q=True)]
    return QtGui.QColor(*rgb)
    
    
def buttonTextColor(BGColor:QtGui.QColor) -> QtGui.QColor:
    value = (BGColor.red() * 299 + BGColor.green() * 587 + BGColor.blue() * 114) / 1000
    return QtGui.QColor(QtCore.Qt.black) if value > 128 else QtGui.QColor(QtCore.Qt.white)
    

def mayaRGBColorToQtColor(color:list) -> QtGui.QColor:
    newColor = cmds.colorManagementConvert(toDisplaySpace=color) 
    return QtGui.QColor(newColor[0] * 255, newColor[1] * 255, newColor[2] * 255)
    

class IndexColorPicker(QtWidgets.QDialog):
    mayaIndex = QtCore.Signal(int)
    qtColor   = QtCore.Signal(QtGui.QColor)
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName('IndexColorPicker')
        
        self.setFixedSize(400, 240)
        self.setWindowFlags(QtCore.Qt.Popup)
        self.setAttribute(QtCore.Qt.WA_StyledBackground, True) 
        self.setMouseTracking(True)
        self.extendedRect = self.rect().adjusted(-60, -60, 60, 60)
        self.setStyleSheet('QDialog#IndexColorPicker {border: 1px solid #292929;}')
        
        self._createWidgets()
        self._createLayouts()
        self._createConnections()
        
    
    def mouseMoveEvent(self, mouseEvent):
        super().mouseMoveEvent(mouseEvent)
        globalPos = self.mapToGlobal(mouseEvent.position().toPoint())
        localPos  = self.mapFromGlobal(globalPos)
        if not self.extendedRect.contains(localPos):
            self.hide()
        
        
    def _createWidgets(self):
        colors:'list[QtGui.QColor]' = [indexToQtColor(i) for i in range(0, 32)]
        self.buttonGroup = QtWidgets.QButtonGroup(self)

        self.buttons = []
        for index, color in enumerate(colors):
            button = QtWidgets.QPushButton(str(index))
            button.setFixedSize(45, 45)
            self.setButtonColor(button, color)
            self.buttonGroup.addButton(button, index)
            self.buttons.append(button)
            
    
    def _createLayouts(self):
        gridLayout = QtWidgets.QGridLayout()
        gridLayout.setVerticalSpacing(0) 
        gridLayout.setSpacing(0)
        
        maxWidth = self.width()
        buttonWidth = 45 + gridLayout.spacing() 
        buttonsPerRow = maxWidth // buttonWidth
        
        for index, button in enumerate(self.buttons):
            row = index // buttonsPerRow
            col = index % buttonsPerRow
            gridLayout.addWidget(button, row, col)
            
        spacer = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        gridLayout.addItem(spacer, row + 1, 0, 1, buttonsPerRow)
        # ------------------------------------
        mainLayout = QtWidgets.QVBoxLayout(self)  
        mainLayout.setContentsMargins(5, 5, 5, 5) 
        groupBox   = QtWidgets.QGroupBox('Color Index')
        groupBox.setLayout(gridLayout)
        mainLayout.addWidget(groupBox)
        
        
    def _createConnections(self):
        self.buttonGroup.buttonClicked.connect(self.getColor)
        
    
    def getColor(self, button:QtWidgets.QPushButton):
        index = self.buttonGroup.id(button)  
        self.mayaIndex.emit(index)
        self.qtColor.emit(indexToQtColor(index))
            
        
    def setButtonColor(self, button, color):
        textColor = buttonTextColor(color)
        palette = button.palette()
        palette.setColor(QtGui.QPalette.ButtonText, textColor)
        palette.setColor(QtGui.QPalette.Button, color)
        button.setAutoFillBackground(True)
        button.setPalette(palette)
        
        

class RGBColorPicker(QtCore.QObject):
    mayaRGBColor  = QtCore.Signal(list)
    qtColor       = QtCore.Signal(QtGui.QColor)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.baseColor = [1.0, 1.0, 1.0] 
        self.colorLabel  = None
        
        self.parenLayout = QtWidgets.QHBoxLayout(parent)
        self._getMayaColorLabel()


    def _getMayaColorLabel(self):
        window = cmds.window()
        self.colorSliderObject = omui.MQtUtil.findControl(cmds.colorSliderGrp())
        
        if self.colorSliderObject is not None:
            self.colorSliderWidget = wrapInstance(int(self.colorSliderObject), QtWidgets.QWidget) 
            self.colorSliderWidget.hide()
            self.parenLayout.addWidget(self.colorSliderWidget)                                  
            self.colorLabel = self.colorSliderWidget.findChild(QtWidgets.QLabel, 'port')   
            cmds.colorSliderGrp(self._colorSliderFullPathName(), e=True, cc=partial(self._getColor))
        cmds.deleteUI(window, window=True)
        
        
    def _colorSliderFullPathName(self):
        return omui.MQtUtil.fullName(int(self.colorSliderObject))
    
      
    def _getColor(self, *args):
        color: list = self.get()
        self.mayaRGBColor.emit(color)
        self.qtColor.emit(mayaRGBColorToQtColor(color))


    def set(self, color:list):
        cmds.colorSliderGrp(self._colorSliderFullPathName(), e=True, rgbValue=(color)) # set picker color
        
        
    def get(self) -> list:
        return cmds.colorSliderGrp(self._colorSliderFullPathName(), q=True, rgb=True)
        
        
class ColorWidget(QtWidgets.QLabel):
    runColor = QtCore.Signal(object) 
    
    def __init__(self, parent=None, size=[70, 30]):
        super().__init__(parent)
        self.setObjectName('ColorWidget')
        self.setFixedSize(*size)
        
        self.isRGB = True
        self.pixmap  = QtGui.QPixmap(self.size()) 
        self.pixmap.fill(QtGui.QColor(245, 236, 112))
        self.setPixmap(self.pixmap) 
        
        self._createWidgets()
        self._createConnections()
        
    def setColorMode(self, value:int):
        self.isRGB = False if value == 0 else True
        
        
    def setColor(self, color:QtGui.QColor):
        self.pixmap.fill(color)
        self.setPixmap(self.pixmap) 
            
        
    def _createWidgets(self):
        self.indexColorPicker = IndexColorPicker(self)
        self.rgbColorUI       = RGBColorPicker(self)
        self.rgbColorLabel    = self.rgbColorUI.colorLabel
        
        
    def _createConnections(self):
        # update color label
        self.indexColorPicker.qtColor.connect(self.setColor)
        self.rgbColorUI.qtColor.connect(self.setColor)
        # emit 
        self.indexColorPicker.mayaIndex.connect(self.runColor.emit)
        self.rgbColorUI.mayaRGBColor.connect(self.runColor.emit)

        
    
    def _showRGBColorPicker(self):
        localPos = self.rgbColorLabel.rect().center()
        globalPos = self.rgbColorLabel.mapToGlobal(localPos)

        localPosF = QtCore.QPointF(localPos)
        globalPosF = QtCore.QPointF(globalPos)

        event = QtGui.QMouseEvent(
            QtCore.QEvent.MouseButtonRelease,
            localPosF,
            globalPosF,
            QtCore.Qt.LeftButton,
            QtCore.Qt.LeftButton,
            QtCore.Qt.NoModifier)

        QtWidgets.QApplication.postEvent(self.rgbColorLabel, event)
        
        
    def mouseReleaseEvent(self, event):
        if event.button() == QtCore.Qt.LeftButton:
            if self.isRGB:
                # show rgb ColorPicker
                self._showRGBColorPicker()
            else:
                # show index ColorPicker
                pos = self.mapToGlobal(event.position().toPoint())
                x = pos.x() - (self.indexColorPicker.width() // 2)
                y = pos.y() - (self.indexColorPicker.height() // 2)
                self.indexColorPicker.move(x, y)
                self.indexColorPicker.show()
        else:
            super().mouseReleaseEvent(event)
            
    
    def set(self, color:'int|list'):
        newColor = None
        if isinstance(color, int):
            newColor = indexToQtColor(color)
        elif isinstance(color, list):
            newColor = mayaRGBColorToQtColor(color)
        if newColor is not None:
            self.setColor(newColor)

    
        

if __name__ == '__main__':
    i = ColorWidget()
    i.show()

