from maya import cmds
from maya.api import OpenMaya as om2
from functools import partial

from PySide6 import QtWidgets
from PySide6 import QtGui
from PySide6 import QtCore
from linkRigger.ui import globalSignals, qtUtils, layouts

from linkRigger.ui.settingsWidgets import colorWidget
from linkRigger.rig import ColorManager 

from linkRigger.utils import curveUtils


class ControlsWidget(QtWidgets.QWidget):
    
    def __init__(self, parent=None, characterManager=None):
        super().__init__(parent)
        
        self.setStyleSheet('''
            
            #colorTypeLabel { color: #F0E68C; }
            #HideHistoryButton, #showHistoryButton, #clearShapeCacheButton, #enableXRayButton, #disableXRayButton {background: #505050; color: white; border: none;  border-radius: 15px;}
            #HideHistoryButton:hover, #showHistoryButton:hover, #clearShapeCacheButton:hover, #enableXRayButton:hover, #disableXRayButton:hover {background: #5C5C5C;}
            #HideHistoryButton:pressed, #showHistoryButton:pressed, #clearShapeCacheButton:pressed, #enableXRayButton:pressed, #disableXRayButton:pressed {background: #464646;}
            #HideHistoryButton:disabled, #showHistoryButton:disabled, #clearShapeCacheButton:disabled, #enableXRayButton:disabled, #disableXRayButton:disabled {color: #A0A0A0;}
            
            #rgbColorButton, #indexColorButton {background: #505050;  border: none;  border-radius: 5px; }
            #rgbColorButton:hover, #indexColorButton:hover {background: #646464; }
            #rgbColorButton:pressed, #indexColorButton:pressed {background: #545A99;}
            #rgbColorButton:checked, #indexColorButton:checked {background: #545A99;}
            
            QCheckBox::indicator { width: 20px; height: 20px;}
            QCheckBox::indicator:unchecked { background: #1C1C1C; }
            QCheckBox::indicator:checked { background: #1C1C1C; border-image: url(linkIcons:hook.png);}   
            QCheckBox::indicator:checked:disabled { border-image: url(linkIcons:disabledHook.png); } 
            
            #ctrlScaleSlider::groove:horizontal {border: none; height: 5px; background-color: #0F0F0F; }
            #ctrlScaleSlider::handle:horizontal {background-color: #D3D3D3; 
                                               width: 8px; 
                                               margin: -4px 0 -4px 0;
                                               border-radius: 0px;}
                                               
            #ctrlScaleSlider::sub-page:horizontal {background-color: #757BC3; }
                           ''')

        
        self.characterManager = characterManager
        self.selectedPointsData = {}

        self._createWidgets()
        self._createLayouts()
        self._createConnections()
        
        self.setData()
        
        
    @property
    def characterExists(self) -> bool:
        return self.characterManager is not None and cmds.objExists(self.characterManager.nodeName)
           
        
    def setCharacterManager(self, characterManager:'CharacterManager'):
        self.characterManager = characterManager
    
  
    def _createWidgets(self):
        self.colorTypeLabel = QtWidgets.QLabel('Color Type ')
        self.colorTypeLabel.setObjectName('colorTypeLabel')
        
        self.rgbColorButton = QtWidgets.QPushButton('RGB')
        self.rgbColorButton.setFixedHeight(28)
        self.rgbColorButton.setMinimumWidth(60)
        self.rgbColorButton.setObjectName('rgbColorButton')
        self.rgbColorButton.setCheckable(True)
        self.rgbColorButton.setChecked(True)
        
        self.indexColorButton = QtWidgets.QPushButton('Index')
        self.indexColorButton.setFixedHeight(28)
        self.indexColorButton.setMinimumWidth(60)
        self.indexColorButton.setObjectName('indexColorButton')
        self.indexColorButton.setCheckable(True)
        
        self.rgbColorButton.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
        self.indexColorButton.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
        
        self.colorButtonsGroup = QtWidgets.QButtonGroup()
        self.colorButtonsGroup.setExclusive(True)  
        self.colorButtonsGroup.addButton(self.indexColorButton, 0)
        self.colorButtonsGroup.addButton(self.rgbColorButton, 1)
        
        self.overrideColorCheckBox = QtWidgets.QCheckBox()
        
        self.leftColorLabel  = colorWidget.ColorWidget(size=[60, 25])
        self.midColorLabel   = colorWidget.ColorWidget(size=[60, 25])
        self.rightColorLabel = colorWidget.ColorWidget(size=[60, 25])
        self.colorLabels = [self.leftColorLabel, self.midColorLabel, self.rightColorLabel]
            
         
        self.clearShapeCacheButton = QtWidgets.QPushButton('Clear Cached Curves')
        self.clearShapeCacheButton.setObjectName('clearShapeCacheButton')
        self.clearShapeCacheButton.setFixedSize(200, 30)
        
        self.HideHistoryButton = QtWidgets.QPushButton('Hide History')
        self.HideHistoryButton.setObjectName('HideHistoryButton')
        self.HideHistoryButton.setFixedSize(140, 30)
        
        self.showHistoryButton = QtWidgets.QPushButton('Show History')
        self.showHistoryButton.setObjectName('showHistoryButton')
        self.showHistoryButton.setFixedSize(140, 30)
        
        self.enableXRayButton = QtWidgets.QPushButton('Enable XRay')
        self.enableXRayButton.setObjectName('enableXRayButton')
        self.enableXRayButton.setFixedSize(140, 30)
        self.disableXRayButton = QtWidgets.QPushButton('Disable XRay')
        self.disableXRayButton.setObjectName('disableXRayButton')
        self.disableXRayButton.setFixedSize(140, 30)
        
        self.ctrlScaleSlider = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        self.ctrlScaleSlider.setObjectName('ctrlScaleSlider')
        self.ctrlScaleSlider.setRange(-100, 100)
        self.ctrlScaleSlider.setValue(0)
        
        
    def _createLayouts(self):
        mainLayout = QtWidgets.QVBoxLayout(self)
        mainLayout.setContentsMargins(0, 0, 0, 0)
        
        colorButtonLayout = QtWidgets.QHBoxLayout()
        colorButtonLayout.setContentsMargins(0, 0, 0, 0)
        colorButtonLayout.setSpacing(3)
        colorButtonLayout.addWidget(self.rgbColorButton)
        colorButtonLayout.addWidget(self.indexColorButton)

        subLayout = QtWidgets.QGridLayout()
        subLayout.setContentsMargins(0, 0, 0, 0)
        subLayout.addWidget(self.colorTypeLabel, 0, 0)
        subLayout.addLayout(colorButtonLayout, 0, 1)
        
        subLayout.addWidget(QtWidgets.QLabel('Override Color'), 1, 0)
        subLayout.addWidget(self.overrideColorCheckBox, 1, 1)
        subLayout.addWidget(QtWidgets.QLabel('Left'), 2, 0)
        subLayout.addWidget(self.leftColorLabel, 2, 1)
        subLayout.addWidget(QtWidgets.QLabel('Mid'), 3, 0)
        subLayout.addWidget(self.midColorLabel, 3, 1)
        subLayout.addWidget(QtWidgets.QLabel('Right'), 4, 0)
        subLayout.addWidget(self.rightColorLabel, 4, 1)
        subLayout.addWidget(QtWidgets.QLabel('Scale'), 5, 0)
        subLayout.addWidget(self.ctrlScaleSlider, 5, 1)
        subLayout.setColumnStretch(0, 0) 
        subLayout.setColumnStretch(1, 1) 

        buttonLayout = layouts.FlowLayout()
        buttonLayout.setSpacing(10)
        buttonLayout.addWidget(self.HideHistoryButton)
        buttonLayout.addWidget(self.showHistoryButton)
        buttonLayout.addWidget(self.enableXRayButton)
        buttonLayout.addWidget(self.disableXRayButton)
        buttonLayout.addWidget(self.clearShapeCacheButton)
        
        mainLayout.addLayout(subLayout)
        mainLayout.addLayout(buttonLayout)
        

      
    def _createConnections(self):
        self.colorButtonsGroup.buttonClicked.connect(self.updateColorType)
        self.overrideColorCheckBox.toggled.connect(self.updateOverride)
        
        self.HideHistoryButton.clicked.connect(partial(self.visHistory, False))
        self.showHistoryButton.clicked.connect(partial(self.visHistory, True))
        self.clearShapeCacheButton.clicked.connect(self.clearCacheShapes)
        
        self.enableXRayButton.clicked.connect(partial(self.setXRay, True))
        self.disableXRayButton.clicked.connect(partial(self.setXRay, False))
        
        self.leftColorLabel.runColor.connect(partial(self.updateColor, 'left'))
        self.midColorLabel.runColor.connect(partial(self.updateColor, 'mid'))
        self.rightColorLabel.runColor.connect(partial(self.updateColor, 'right'))
        
        
        self.ctrlScaleSlider.sliderPressed.connect(self._getSelectedSplinePoints)
        self.ctrlScaleSlider.sliderPressed.connect(self._sliderClicked)
        self.ctrlScaleSlider.sliderMoved.connect(self._setScale)
        self.ctrlScaleSlider.sliderReleased.connect(self._reseteSlider)
        
        
    # -----------------------------------------------------------------------    
    def _getSelectedSplinePoints(self):
        cmds.undoInfo(openChunk=True)
        sel = cmds.ls(sl=True, type='transform')
        
        for node in sel:
            points = curveUtils.getSplinePoints(node)
            for point in points:
                self.selectedPointsData[point] = om2.MVector(cmds.xform(point, q=True, t=True, ws=False))
    
    def _sliderClicked(self):  
        self._setScale(self.ctrlScaleSlider.value() * 0.2)
        
    def _setScale(self, value):
        for point, vector in self.selectedPointsData.items():
            cmds.xform(point, t=vector * (1 + value*0.02), ws=False)

        
    def _reseteSlider(self):
        self.ctrlScaleSlider.setValue(0)
        self.selectedPointsData.clear()
        cmds.undoInfo(closeChunk=True)
        
    # -----------------------------------------------------------------------    
    
        
    def updateColorType(self, button:QtWidgets.QPushButton):
        index = self.colorButtonsGroup.id(button)

        isRGB:bool = index == 1
        ColorManager.updateColorSetting('isRGB', index)

        for colorLabel in self.colorLabels:
            colorLabel.setColorMode(index)

        sideText = ['left', 'mid', 'right']
        cacheRGBColors = [[1, 0, 0], [1, 1, 0], [0, 0, 1]]
        cacheIndexColors = [13, 17, 6]
        
        colorData = cacheRGBColors if isRGB else cacheIndexColors

        for colorLabel, color, side in zip(self.colorLabels, colorData, sideText):
            colorLabel.set(color)
            if isRGB:
                colorLabel.rgbColorUI.set(color)
            self.updateColor(side, color)
            
        
    def updateOverride(self, value:bool):
        ColorManager.updateColorSetting('override', value)
        
    
    def updateColor(self, side: str, color: 'int|list'):
        ColorManager.updateColorSetting(side, color)
        
        
    def setData(self):
        data = ColorManager.getData()
        
        self.overrideColorCheckBox.setChecked(data['override'])
        isRGB = data['isRGB']
        self.colorButtonsGroup.button(isRGB).setChecked(True)
        
        for colorLabel, color in zip(self.colorLabels, [data['left'], data['mid'], data['right']]):
            colorLabel.setColorMode(isRGB)
            colorLabel.set(color)
            if isRGB == 1:
                colorLabel.rgbColorUI.set(color)
        
        
    @qtUtils.addUndo    
    def visHistory(self, value:bool):
        if not self.characterExists:
            return
        allNodes = []
        for component in self.characterManager.componentsManager.listComponentNodes(recursive=True):
            allNodes.extend(component.getAllNodes())
        for node in allNodes:
            if not cmds.objExists(node):
                continue
            nodes = cmds.listRelatives(node, children=True, shapes=True, fullPath=True) or []
            nodes.append(node)
            for _node in nodes:
                cmds.setAttr(f'{_node}.ihi', value)
        sel = cmds.ls(sl=True)
        if sel:
            cmds.select(sel, replace=True)
            
            
    @qtUtils.addUndo
    def clearCacheShapes(self):
        if not self.characterExists:
            return
        for component in self.characterManager.componentsManager.listComponentNodes(recursive=True):
            component.rigLayer.clearAllShapeData()
            
            
    @qtUtils.addUndo  
    def setXRay(self, value:bool):
        if not self.characterExists:
            return
        for component in self.characterManager.componentsManager.listComponentNodes(recursive=True):
            for controlNode in component.rigLayer.listControlNodes():
                for shape in controlNode.listShapes():
                    cmds.setAttr(f'{shape}.alwaysDrawOnTop', value)
                
        
        
 
        

        
if __name__ == '__main__':
    c = ControlsWidget()
    c.show()

    