from maya import cmds
from maya.api import OpenMaya as om2

from functools import partial
from PySide6 import QtWidgets
from PySide6 import QtGui
from PySide6 import QtCore
from linkRigger.ui import widgets, POST_SCRIPTS_PATH
from linkRigger.ui.settingsWidgets.postScriptWidgets import scriptListWidget
from linkRigger.ui.settingsWidgets.postScriptWidgets import scriptManagerWidget



class ResizableHandle(QtWidgets.QWidget):

    heightChanged = QtCore.Signal(int) 

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedHeight(4) 
        self.setCursor(QtCore.Qt.SizeVerCursor) 
        self.setAttribute(QtCore.Qt.WA_StyledBackground, True) 

        
        self.setStyleSheet('''
            QWidget { background-color: #606060; 
                      background-image: url(linkIcons:scaleHandle.png); 
                      background-repeat: no-repeat;
                      background-position: center;}
            QWidget:hover { background-color: #545A99; }
            
            QWidget:disabled { background-image: url(linkIcons:scaleHandleLocked.png); 
            background-color: #4B4B4B; }
            ''')
        
        self.dragging = False
        self.startY = 0


    def mousePressEvent(self, event: QtGui.QMouseEvent):
        if event.button() == QtCore.Qt.LeftButton:
            self.dragging = True
            
            self.startY = event.globalPosition().y() 
            event.accept() 
        else:
            event.ignore() 
            
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event: QtGui.QMouseEvent):
        super().mouseMoveEvent(event)
        
        if self.dragging:
            startY = event.globalPosition().y() - self.startY
            self.heightChanged.emit(startY)
            self.startY = event.globalPosition().y()
            event.accept()
        else:
            event.ignore()

    def mouseReleaseEvent(self, event: QtGui.QMouseEvent):
        if event.button() == QtCore.Qt.LeftButton and self.dragging:
            self.dragging = False
            event.accept()
        else:
            event.ignore()
        
        super().mouseReleaseEvent(event)
            
            

class PostScriptWidget(QtWidgets.QWidget):
    
    def __init__(self, parent=None, characterManager=None):
        super().__init__(parent)
        
        self.setStyleSheet(''' 
                           QPushButton {background: #4B4B4B; color: white; border: none; border-radius: 3px;}
                           QPushButton:hover {background: #5C5C5C;}
                           QPushButton:pressed {background: #464646;}
                           QPushButton:disabled {color: #A0A0A0;}
                            ''')
        self.characterManager = characterManager
        self._createWidgets()
        self._createLayouts()
        self._createConnections()
        
 
        
    @property
    def characterExists(self) -> bool:
        return self.characterManager is not None and cmds.objExists(self.characterManager.nodeName)
           
        
    def setCharacterManager(self, characterManager:'CharacterManager'):
        self.characterManager = characterManager
        self.scriptListWidget.setCharacterManager(characterManager)
        
        self.setEnabled(False if characterManager is None else True)

    
    
    def _createWidgets(self):
        
        self.newScriptButton = QtWidgets.QPushButton(QtGui.QIcon('linkIcons:newScene.png'), '')
        self.newScriptButton.setToolTip('Creates a new script')
        self.newScriptButton.setFixedSize(28, 28)
        
        self.scriptManagetButton = QtWidgets.QPushButton(QtGui.QIcon('linkIcons:pythonEditLogo.png'), '')
        self.scriptManagetButton.setToolTip('Opens the Script Manager')
        self.scriptManagetButton.setFixedSize(28, 28)
        
        self.deleteScriptButton = QtWidgets.QPushButton(QtGui.QIcon('linkIcons:delete.png'), '')
        self.deleteScriptButton.setFixedSize(28, 28)
        self.deleteScriptButton.setToolTip('Delete script from Post Script')
        
        self.renameScriptButton = QtWidgets.QPushButton(QtGui.QIcon('linkIcons:renameRig.png'), '')
        self.renameScriptButton.setFixedSize(28, 28)
        self.renameScriptButton.setToolTip('Rename selected script')
        
        self.refreshScriptsButton = QtWidgets.QPushButton(QtGui.QIcon('linkIcons:refresh.png'), '')
        self.refreshScriptsButton.setFixedSize(28, 28)
        self.refreshScriptsButton.setToolTip('Refresh post scripts')
        
        self.scriptListWidget = scriptListWidget.ScriptListWidget()
        self.scriptListWidget.setFixedHeight(150) 
        self.resizeHandle = ResizableHandle()

        
    def _createLayouts(self):
        mainLayout = QtWidgets.QVBoxLayout(self)
        mainLayout.setContentsMargins(0, 0, 0, 0)
        mainLayout.setSpacing(0)
        
        buttonLayer = QtWidgets.QHBoxLayout()
        buttonLayer.setContentsMargins(0, 0, 0, 0)
        buttonLayer.setSpacing(2)
        buttonLayer.addWidget(self.newScriptButton)
        buttonLayer.addWidget(self.renameScriptButton)
        buttonLayer.addWidget(self.scriptManagetButton)
        buttonLayer.addSpacerItem(QtWidgets.QSpacerItem(15, 0, QtWidgets.QSizePolicy.Fixed, QtWidgets.QSizePolicy.Minimum))
        buttonLayer.addWidget(self.deleteScriptButton)
        buttonLayer.addWidget(self.refreshScriptsButton)
        buttonLayer.addStretch()
        
        mainLayout.addLayout(buttonLayer)
        mainLayout.addSpacerItem(QtWidgets.QSpacerItem(0, 2, QtWidgets.QSizePolicy.Fixed, QtWidgets.QSizePolicy.Minimum))
        mainLayout.addWidget(self.scriptListWidget)
        mainLayout.addWidget(self.resizeHandle)
        mainLayout.addStretch()

        
    def _createConnections(self):
        self.scriptListWidget.itemsScriptUpdate.connect(self.updateRigPostScript)
        self.scriptListWidget.showScriptManager.connect(self.openScriptManager)
        self.resizeHandle.heightChanged.connect(self.updateScriptListHeight)
        
        self.newScriptButton.clicked.connect(self.scriptListWidget.createNewScriptItem)
        self.deleteScriptButton.clicked.connect(self.scriptListWidget._deleteSelectedItems)
        self.renameScriptButton.clicked.connect(self.scriptListWidget._renameSelectedItem)
        self.refreshScriptsButton.clicked.connect(self.scriptListWidget.refreshScriptItems)
        self.scriptManagetButton.clicked.connect(self.openScriptManager)

        
    def updateRigPostScript(self, data:list):
        if not self.characterExists:
            return
        
        print('setData')
        self.characterManager.componentsManager.postScript = data
        
        
    def updateScriptListHeight(self, deltaY: int):
        self.scriptListWidget.setFixedHeight(max(self.scriptListWidget.height() + deltaY, 150))
        
        
    def openScriptManager(self):
        selItems = self.scriptListWidget.selectedItems()
        if not selItems:
            return
        selItem    = selItems[0]
        
        # 0 cache old script
        oldScript  = selItem.data(QtCore.Qt.UserRole)
        # 1 show script manager
        scriptManager = scriptManagerWidget.ScriptWidget(self, selItem).exec()  
        
        # 2 check script
        if oldScript != selItem.data(QtCore.Qt.UserRole):
            # update 
            self.scriptListWidget.emitItemsScriptUpdate()
        
 
        
     
if __name__ == '__main__':
    p = PostScriptWidget()
    p.show()
    #for i in range(10):
        #s.createNewScriptItem()
        