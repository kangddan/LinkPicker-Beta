import json
from maya import cmds
from maya.api import OpenMaya as om2

from PySide6 import QtWidgets
from PySide6 import QtGui
from PySide6 import QtCore

from linkRigger.ui import qtUtils, widgets, getScriptItemIcon

class ScriptListWidgetMenu(QtWidgets.QMenu):
    
    editScriptTriggered = QtCore.Signal()
    renameItemTriggered = QtCore.Signal()
    deleteItemTriggered  = QtCore.Signal()

    createItemTriggered = QtCore.Signal()
    refreshTriggered    = QtCore.Signal()
    
    def __init__(self, parent=None):
        super().__init__(parent)
        
        self.listWidget = parent
        self._createActions()
        self._createConnections()
        
    
    def _createActions(self):
        self.editScriptAction = QtGui.QAction(QtGui.QIcon('linkIcons:pythonEditLogo.png'), 'Edit Script', self)
        
        self.renameItemAction = QtGui.QAction(QtGui.QIcon('linkIcons:renameRig.png'), 'Rename', self)
        self.deleteItemAction = QtGui.QAction(QtGui.QIcon('linkIcons:delete.png'), 'Delete', self)
        
        self.createItemAction = QtGui.QAction(QtGui.QIcon('linkIcons:newScene.png'), 'New Script', self)
        self.refreshAction    = QtGui.QAction(QtGui.QIcon('linkIcons:refresh.png'), 'Refresh',  self)
        
        self.addAction(self.editScriptAction)
        self.addAction(self.renameItemAction)
        self.addAction(self.deleteItemAction)
        self.addSeparator()
        self.addAction(self.createItemAction)
        self.addAction(self.refreshAction)
        
        
    def _createConnections(self):
        self.aboutToShow.connect(self._updateActionsState) 
        
        self.editScriptAction.triggered.connect(self.editScriptTriggered.emit)
        self.renameItemAction.triggered.connect(self.renameItemTriggered.emit)
        self.deleteItemAction.triggered.connect(self.deleteItemTriggered.emit)
        self.createItemAction.triggered.connect(self.createItemTriggered.emit)
        self.refreshAction.triggered.connect(self.refreshTriggered.emit)
        
        
    def _updateActionsState(self):
        hasSelection = bool(self.listWidget.selectedItems())
        
        self.editScriptAction.setEnabled(hasSelection)
        self.renameItemAction.setEnabled(hasSelection)
        self.deleteItemAction.setEnabled(hasSelection)
           
    


class BaseScriptListWidget(QtWidgets.QListWidget):
    
    itemsScriptUpdate = QtCore.Signal(list)
    showScriptManager = QtCore.Signal()
    
    def __init__(self, parent=None):
        super().__init__(parent)
        
        self.setSelectionMode(QtWidgets.QAbstractItemView.ExtendedSelection)
        self.setDragDropMode(QtWidgets.QAbstractItemView.InternalMove)
        
        self.setItemDelegate(qtUtils.CustomItemDelegate())
        self.setAlternatingRowColors(True)  
        self.setObjectName('BaseScriptListWidget')
        
        self.setStyleSheet('''              
    
                           QMenu { background-color: #1A1A1A; border: 2px solid #363636; color: #B4B4B4;}
                           QMenu::item { background-color: transparent; }
                           QMenu::separator { height: 3px; background: #363636; margin-left: 15px; margin-right: 15px; }
                           QMenu::item:selected { background-color: #4D4D4D; color: #F0F0F0;}
                           QMenu::right-arrow { border-image: url(linkIcons:menuLeft.png); }
                           QMenu::right-arrow:disabled { border-image: url(linkIcons:menuLeftDisabled.png)} 
                           QMenu::item:disabled {color: #585858;}
                           
        
                           QScrollBar:vertical { border: none; width: 10px; margin: 0px 0 0px 0; }
                           QScrollBar::handle:vertical { background: #5C5C5C; min-height: 20px; border-radius: 5px; }
                           QScrollBar::handle:vertical:hover { background: #656565; }
                           QScrollBar::handle:vertical:pressed {background: #6E6E6E; }
                           QScrollBar::sub-line:vertical,
                           QScrollBar::add-line:vertical { background: none; height: 0; }
                           QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {background: #282828; }

                           QScrollBar:horizontal { border: none; height: 10px; margin: 0 0px 0 0px; }
                           QScrollBar::handle:horizontal { background: #5C5C5C; min-width: 20px; border-radius: 5px; }
                           QScrollBar::handle:horizontal:hover { background: #656565; }
                           QScrollBar::handle:horizontal:pressed {background: #6E6E6E; }
                           QScrollBar::sub-line:horizontal,
                           QScrollBar::add-line:horizontal { background: none; width: 0; }
                           QScrollBar::add-page:horizontal, QScrollBar::sub-page:horizontal {background: #282828; }
                            
                           QAbstractScrollArea::corner { background: #282828; }    
        
        
                           
                           QListWidget { border: 0px solid #373737; background-color: #2A2A2A;}
                           QListWidget::item:selected { color: #FFA53F; border: none; background: transparent; padding-left: 0px;}
                           QListWidget::item:alternate { background-color: #232323;}
                           

                          ''') 
                          
        self._createMenu()   
        self._createWidgets()
        self._createConnections()
        self.startPos = None
        
        self.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.customContextMenuRequested.connect(self.showScriptListWidgetMenu)
    
    
    def showScriptListWidgetMenu(self, point:QtCore.QPoint):
        self.scriptListWidgetMenu.exec(self.mapToGlobal(point))    
    
    def _createMenu(self):
        self.scriptListWidgetMenu = ScriptListWidgetMenu(self)    
    
    def _createWidgets(self):
        self.selectionBox = qtUtils.SelectionBox(parent=self)
         
        
    def _createConnections(self):
        self.scriptListWidgetMenu.deleteItemTriggered.connect(self._deleteSelectedItems)
        self.scriptListWidgetMenu.renameItemTriggered.connect(self._renameSelectedItem)
        self.scriptListWidgetMenu.editScriptTriggered.connect(self.showScriptManager.emit)
        
            
    def _deleteSelectedItems(self):
        selectedItems = self.selectedItems()
        if not selectedItems:
            rowCount = self.count()
            if rowCount > 0:
                lastRowIndex = rowCount - 1
                itemToDelete = self.item(lastRowIndex)
                self.takeItem(lastRowIndex)
                del itemToDelete
            else:
                return # No items to delete
        else:
        
            '''
            TODO:
            When deleting items from a list, always iterate backward. 
            Deleting from the end ensures that the indices of earlier items don't change. 
            If you delete from index 0 (forward), the item at original index 1 becomes index 0. 
            Then, when the loop tries to delete at index 1, it will skip the item that was originally at index 1, 
            deleting what was originally at index 2 instead
            '''
            itemsToDelete = sorted(selectedItems, key=lambda item: self.row(item), reverse=True)
            for item in selectedItems:
                self.takeItem(self.row(item))
                del item
            
        # update post script
        self.emitItemsScriptUpdate()
        
        
    def _renameSelectedItem(self):
        items = self.selectedItems()
        if not items:
            return
        renameItem = items[-1]
        
        newName = widgets.InputDialog(baseText=renameItem.text(), 
                                     title=f'Rename', 
                                     message='New Name'
                                       ).exec()  
        if not isinstance(newName, str):
            return
        renameItem.setText(newName)
        # update post script
        self.emitItemsScriptUpdate()
        
        
    def dropEvent(self, event):
        '''
        When an item is moved and released, a data signal is emitted. 
        This signal contains the name and script string for each item, 
        based on their current order.
        '''
        super().dropEvent(event) 
        
        self.emitItemsScriptUpdate()
        event.accept()

    
    def mousePressEvent(self, event):   
        startPos = event.position().toPoint()
        super().mousePressEvent(event)
        clickedItem = self.itemAt(startPos)
        
        if clickedItem is None: 
            self.clearSelection()    
            
        if event.buttons() == QtCore.Qt.MouseButton.LeftButton and clickedItem is None:
            self.startPos = QtCore.QPoint(startPos.x() + 3, startPos.y() + 3)
            self.selectionBox.setGeometry(QtCore.QRect(self.startPos, QtCore.QSize()))
            self.selectionBox.show()
            
            
    def mouseMoveEvent(self, event):
        if event.buttons() == QtCore.Qt.MouseButton.LeftButton and self.startPos is not None: 
            endPos = event.position().toPoint()
            newEndPos = QtCore.QPoint(endPos.x() + 3, endPos.y() + 3)
            self.selectionBox.setGeometry(QtCore.QRect(self.startPos, newEndPos).normalized())

        super().mouseMoveEvent(event)

         
    def mouseReleaseEvent(self, event):
        if self.startPos is not None:
            self.selectionBox.hide()
            self.startPos = None
        super().mouseReleaseEvent(event)
        
    
    def getAllItems(self) -> list:
        '''
        get all items
        '''
        return [self.item(i) for i in range(self.count())]
        
        
    def getAllItemsData(self) -> 'list[dict]':
        '''
        get all scrtpt items data
        '''
        dataList = []
        for item in self.getAllItems():
            data         = {}
            sctiptName   = item.text()
            scriptString = item.data(QtCore.Qt.UserRole)
            data[sctiptName] = scriptString
            dataList.append(data)    
        return dataList
        
        
    def emitItemsScriptUpdate(self):
        scriptData:list = self.getAllItemsData()
        self.itemsScriptUpdate.emit(scriptData) 
            

class ScriptListWidget(BaseScriptListWidget):
    BASIC_SCRIPT_TEXT = '''from maya import cmds
from maya.api import OpenMaya as om2
from linkRigger import components
from linkRigger.core.rig import Rig

def main():
    rig = Rig() # Main rig interface to access all rig components
    
    om2.MGlobal.displayInfo('Hello World!')
'''
    
    def __init__(self, parent=None):
        super().__init__(parent)
        
        self.characterManager:'CharacterManager' = None
        self.setObjectName('ScriptListWidget')

        
    @property
    def characterExists(self) -> bool:
        return self.characterManager is not None and cmds.objExists(self.characterManager.nodeName)
        
        
    def setCharacterManager(self, characterManager:'CharacterManager'):
        self.characterManager = characterManager
        self.setupScriptItems()
        
    
    def _createConnections(self):
        super()._createConnections()
        self.scriptListWidgetMenu.createItemTriggered.connect(self.createNewScriptItem)
        self.scriptListWidgetMenu.refreshTriggered.connect(self.refreshScriptItems)
        self.doubleClicked.connect(self.showScriptManager)
            
            
    def setupScriptItems(self):
        '''
        Retrieve postScript data from the componentsManager and rebuild the item
        '''
        self.clear()
        if not self.characterExists: 
            return   
        
        scriptData:list = self.characterManager.componentsManager.postScript
        if not scriptData:
            return
        
        for data in scriptData:
            name, scriptString = next(iter(data.items()))
            item = QtWidgets.QListWidgetItem(name)
            item.setData(QtCore.Qt.UserRole, scriptString) # add script
            
            item.setSizeHint(QtCore.QSize(0, 30))
            item.setIcon(getScriptItemIcon())
            self.addItem(item)
            
    
    def _getNextName(self) -> str:
        prefix = 'Untitled '
        items = [name[:-1] if name and name[-1] == '*' else name for name in [item.text() for item in self.getAllItems()]]
        
        suffixNumbers = []
        
        for item in items:
            if not item.startswith(prefix):
                continue
            suffix = item[len(prefix):] 
            if suffix.isdigit():
                suffixNumbers.append(int(suffix))  
 
        maxSuffix = max(suffixNumbers) if suffixNumbers else 0
        return f'{prefix}{maxSuffix + 1}*'
                
                
    def createNewScriptItem(self):
        item = QtWidgets.QListWidgetItem(self._getNextName())
        item.setData(QtCore.Qt.UserRole, ScriptListWidget.BASIC_SCRIPT_TEXT)

        item.setSizeHint(QtCore.QSize(0, 30))
        item.setIcon(getScriptItemIcon())
        self.addItem(item)
        
        self.emitItemsScriptUpdate()
        
        
    def refreshScriptItems(self):
        '''
        update items
        '''
        self.setupScriptItems()
        
        
            


    
if __name__ == '__main__':
    s = ScriptListWidget()
    s.show()
    #for i in range(10):
        #s.createNewScriptItem()