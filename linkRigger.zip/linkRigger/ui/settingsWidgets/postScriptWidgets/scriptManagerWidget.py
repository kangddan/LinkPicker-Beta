import os
import glob

from maya import cmds
from maya.api import OpenMaya as om2

from PySide6 import QtWidgets
from PySide6 import QtGui
from PySide6 import QtCore

from linkRigger.ui import widgets, POST_SCRIPTS_PATH, getScriptItemIcon



class PythonHighlighter(QtGui.QSyntaxHighlighter):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.highlightingRules = []
        
        # QTextCharFormat, QColor, QFont are in QtGui
        keywordFormat = QtGui.QTextCharFormat() 
        keywordFormat.setForeground(QtGui.QColor(197, 134, 192)) 
        
        keywords = [
            "False", "None", "True", "and", "as", "assert", "async", "await", 
            "break", "class", "continue", "def", "del", "elif", "else", "except", 
            "finally", "for", "from", "global", "if", "import", "in", "is", 
            "lambda", "nonlocal", "not", "or", "pass", "raise", "return", 
            "try", "while", "with", "yield"
        ]

        for keyword in keywords:
            pattern = r"\b" + keyword + r"\b"
            self.highlightingRules.append((
                QtCore.QRegularExpression(pattern), keywordFormat
            ))
        
        # 1 str
        stringFormat = QtGui.QTextCharFormat()
        stringFormat.setForeground(QtGui.QColor(206, 145, 120)) 
        self.highlightingRules.append((QtCore.QRegularExpression(r'\".*\"'), stringFormat))
        self.highlightingRules.append((QtCore.QRegularExpression(r'\'.*\''), stringFormat))
        
        # 2 number
        numberFormat = QtGui.QTextCharFormat()
        numberFormat.setForeground(QtGui.QColor(181, 206, 168)) 
        self.highlightingRules.append((QtCore.QRegularExpression(r'\b[0-9]+\b'), numberFormat))

        # 3 func
        functionCallFormat = QtGui.QTextCharFormat()
        functionCallFormat.setForeground(QtGui.QColor(86, 156, 214))
        self.highlightingRules.append((
            QtCore.QRegularExpression(r'\b\w+(?=\s*\()'), functionCallFormat
        ))
        self.highlightingRules.append((
            QtCore.QRegularExpression(r'\.\s*\w+(?=\s*\()'), functionCallFormat
        ))
        
        # 4 class
        classNameFormat = QtGui.QTextCharFormat()
        classNameFormat.setForeground(QtGui.QColor(102, 201, 135))
        self.highlightingRules.append((
            QtCore.QRegularExpression(r'\bclass\s+([A-Za-z_][A-Za-z0-9_]*)'), classNameFormat
        ))
        
        
        # 5 self and cls
        selfFormat = QtGui.QTextCharFormat()
        selfFormat.setForeground(QtGui.QColor(156, 220, 254)) 
 
        
        for word in ['self', 'cls']:
            pattern = QtCore.QRegularExpression(rf'\b{word}\b')
            self.highlightingRules.append((pattern, selfFormat))

        # 6 super 
        superFormat = QtGui.QTextCharFormat()
        superFormat.setForeground(QtGui.QColor(220, 220, 170))
        superFormat.setFontItalic(True)
        self.highlightingRules.append((
            QtCore.QRegularExpression(r'\bsuper\b'), superFormat
        ))
        
        # 7 proper
        decoratorFormat = QtGui.QTextCharFormat()
        decoratorFormat.setForeground(QtGui.QColor(102, 201, 135)) 

        self.highlightingRules.append((
            QtCore.QRegularExpression(r'@\w+'), decoratorFormat
        ))
        
        # 8 comment
        commentFormat = QtGui.QTextCharFormat()
        commentFormat.setForeground(QtGui.QColor(96, 139, 78)) 
        commentFormat.setFontItalic(True)
        self.highlightingRules.append((QtCore.QRegularExpression(r'#[^\n]*'), commentFormat))
        
        

    def highlightBlock(self, text):
        for pattern, fmt in self.highlightingRules:
            matches = pattern.globalMatch(text)
            while matches.hasNext():
                match = matches.next()
                if pattern.pattern() in [r'\bdef\s+([A-Za-z_][A-Za-z0-9_]*)', r'\bclass\s+([A-Za-z_][A-Za-z0-9_]*)']:
                    self.setFormat(match.capturedStart(1), len(match.captured(1)), fmt)
                else:
                    self.setFormat(match.capturedStart(), match.capturedLength(), fmt)

                
                
class LineNumberArea(QtWidgets.QWidget):
    def __init__(self, editor):
        super().__init__(editor)
        self.codeEditor = editor 

    def sizeHint(self):
        return QtCore.QSize(self.codeEditor.lineNumberAreaWidth(), 0)

    def paintEvent(self, event):
        painter = QtGui.QPainter(self)
        painter.fillRect(event.rect(), QtGui.QColor(32, 32, 32, 255))

        block       = self.codeEditor.firstVisibleBlock()
        blockNumber = block.blockNumber()
        top         = 0
        bottom      = top + int(self.codeEditor.blockBoundingRect(block).height())

        painter.setFont(self.codeEditor.font())

        while block.isValid() and top <= event.rect().bottom():
            if block.isVisible() and bottom >= event.rect().top():
                number = str(blockNumber + 1)
                painter.setPen(QtCore.Qt.GlobalColor.darkGray) 
                painter.drawText(0, top, self.width(), self.codeEditor.fontMetrics().height(), 
                                 QtCore.Qt.AlignmentFlag.AlignRight | QtCore.Qt.AlignmentFlag.AlignVCenter,
                                 number)

            block = block.next()
            top = bottom
            bottom = top + int(self.codeEditor.blockBoundingRect(block).height())
            blockNumber += 1
            

class CodeEditor(QtWidgets.QPlainTextEdit):
    
    cursorPositionChangedSignal = QtCore.Signal(int, int)
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName('CodeEditor')
        self.setLineWrapMode(QtWidgets.QPlainTextEdit.LineWrapMode.NoWrap)
        self.setStyleSheet('''
                          #CodeEditor { background-color: #202020; 
                                        border: 0px; 
                                        selection-background-color: #358ABB;} 
                          ''')
                          
        self.highlighter = PythonHighlighter(self.document())
        self._createWidgets()
        self._createConnections()

        self.updateLineNumberAreaWidth(0) 
        self.highlightCurrentLine()
        
        self.textSize = 10
        self.setTextSize(self.textSize) 
        self.setTabStopDistance(self.fontMetrics().horizontalAdvance(' ') * 4)
        
        
    def _createWidgets(self):
        self.lineNumberArea = LineNumberArea(self) 
        
        
    def _createConnections(self):
        self.blockCountChanged.connect(self.updateLineNumberAreaWidth)
        self.updateRequest.connect(self.updateLineNumberArea)
        self.cursorPositionChanged.connect(self.highlightCurrentLine)
        self.cursorPositionChanged.connect(self._emitCursorPositionChanged)
        
    def _emitCursorPositionChanged(self):
        cursor = self.textCursor()
        line = cursor.blockNumber() + 1 
        column = cursor.positionInBlock() + 1 
        self.cursorPositionChangedSignal.emit(line, column)
            
        
    def setTextSize(self, value):
        font = QtGui.QFont('Consolas')
        font.setPointSize(value) 
        font.setFixedPitch(True)
        self.setFont(font)
        
        self.setTabStopDistance(self.fontMetrics().horizontalAdvance(' ') * 4)
        self.updateLineNumberAreaWidth(0) 
        self.lineNumberArea.update()


    def lineNumberAreaWidth(self):
        digits = 1
        max_num = max(1, self.blockCount())
        while max_num >= 10:
            max_num /= 10
            digits += 1

        width = self.fontMetrics().horizontalAdvance(' ') * digits + 5
        return width


    def updateLineNumberAreaWidth(self, newBlockCount):
        self.setViewportMargins(self.lineNumberAreaWidth(), 0, 0, 0)


    def updateLineNumberArea(self, rect, dy):
        if dy:
            self.lineNumberArea.scroll(0, dy)
        else:
            self.lineNumberArea.update(0, rect.y(), self.lineNumberArea.width(), rect.height())

        if rect.contains(self.viewport().rect()):
            self.updateLineNumberAreaWidth(0)


    def wheelEvent(self, event: QtGui.QWheelEvent):
        if event.modifiers() & QtCore.Qt.ControlModifier:
            if event.angleDelta().y()  > 0:
                self.textSize += 2
            else:
                self.textSize -= 2

            self.textSize = max(10, min(self.textSize, 400))
            self.setTextSize(self.textSize)
            event.accept()
        else:
            super().wheelEvent(event)
            

    def resizeEvent(self, event):
        super().resizeEvent(event)
        cr = self.contentsRect()
        self.lineNumberArea.setGeometry(QtCore.QRect(cr.left(), cr.top(), self.lineNumberAreaWidth(), cr.height()))


    def highlightCurrentLine(self):
        extraSelections = []

        if not self.isReadOnly():
            selection = QtWidgets.QTextEdit.ExtraSelection()
            lineColor = QtGui.QColor(45, 45, 45, 255)
            selection.format.setBackground(lineColor)
            selection.format.setProperty(QtGui.QTextFormat.FullWidthSelection, True)
            selection.cursor = self.textCursor()
            selection.cursor.clearSelection()
            extraSelections.append(selection)
        self.setExtraSelections(extraSelections)
                        
        
        
class ScriptWidget(QtWidgets.QDialog):
    
    GLOBAL_POS = None
    
    def __init__(self, parent=None, selItem:QtWidgets.QListWidgetItem=None):
        super().__init__(parent)
        
        self.setAttribute(QtCore.Qt.WA_StyledBackground, True) 
        self.setObjectName('ScriptWidget')
        self.setStyleSheet('''
            #ScriptWidget { background-color: #373737;} 
            
            QMenu { background-color: #1A1A1A; border: 2px solid #363636; color: #B4B4B4;}
            QMenu::item { background-color: transparent; }
            QMenu::separator { height: 3px; background: #363636; margin-left: 15px; margin-right: 15px; }
            QMenu::item:selected { background-color: #4D4D4D; color: #F0F0F0;}
            QMenu::right-arrow { border-image: url(linkIcons:menuLeft.png); }
            QMenu::right-arrow:disabled { border-image: url(linkIcons:menuLeftDisabled.png)} 
            QMenu::item:disabled {color: #585858;}

            QScrollBar:vertical { border: none; width: 10px; margin: 0px 0 0px 0; }
            QScrollBar::handle:vertical { background: #5C5C5C; min-height: 20px; border-radius: 5px; }
            QScrollBar::handle:vertical:hover { background: #656565; }
            QScrollBar::handle:vertical:pressed {background: #6E6E6E; }
            QScrollBar::sub-line:vertical,
            QScrollBar::add-line:vertical { background: none; height: 0; }
            QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {background: #373737; }

            QScrollBar:horizontal { border: none; height: 10px; margin: 0 0px 0 0px; }
            QScrollBar::handle:horizontal { background: #5C5C5C; min-width: 20px; border-radius: 5px; }
            QScrollBar::handle:horizontal:hover { background: #656565; }
            QScrollBar::handle:horizontal:pressed {background: #6E6E6E; }
            QScrollBar::sub-line:horizontal,
            QScrollBar::add-line:horizontal { background: none; width: 0; }
            QScrollBar::add-page:horizontal, QScrollBar::sub-page:horizontal {background: #373737; }

            QAbstractScrollArea::corner { background: #373737; } 
            
            QComboBox { background-color: #4B4B4B; height: 28px; border-radius: 0px; padding-left: 8px;}
            QComboBox:hover { background-color: #5C5C5C;}
            QComboBox QAbstractItemView { border: 6px solid #1A1A1A; background-color: #1A1A1A; selection-background-color: #4D4D4D; }
            QComboBox::drop-down { border: none; background: transparent; width: 32px; }
            QComboBox::down-arrow {border-image: url(linkIcons:downHoverSource.png); width: 20px; height: 20px; }
            QComboBox::down-arrow:disabled { border-image: url(linkIcons:downHoverSourceDisabled.png); width: 20px; height: 20px;} 
            QComboBox:focus { background-color: #4B4B4B;  padding-left: 8px;}
            
            
            QPushButton {background: #4B4B4B; color: white; border: none; border-radius: 15px;}
            QPushButton:hover {background: #5C5C5C;}
            QPushButton:pressed {background: #464646;}
            QPushButton:disabled {color: #A0A0A0;}
            ''')
        
        self.selItem       = selItem
        self.newScriptName = selItem.text()                   if selItem else ''
        self.newScript     = selItem.data(QtCore.Qt.UserRole) if selItem else ''
        
        self.setWindowTitle('Script Manager')
        self.resize(700, 800)
        
        self._createWidgets()
        self._createLayouts()
        self._createConnections()
        
        self.setupPostScriptsItems(self.newScriptName, self.newScript)
        
        if ScriptWidget.GLOBAL_POS is not None:
            self.move(ScriptWidget.GLOBAL_POS)
        
        
    def _createWidgets(self):
        
        delegate = widgets.CustomDelegate(self, 32)
        self.scriptsComboBox = widgets.ComboBox()
        self.scriptsComboBox.setItemDelegate(delegate)
        
        self.codeIconLabel = QtWidgets.QLabel('')
        scaledPixmap = QtGui.QPixmap('linkIcons:pythonLogo.png').scaled(40, 40, QtCore.Qt.KeepAspectRatio, QtCore.Qt.SmoothTransformation)
        self.codeIconLabel.setPixmap(scaledPixmap)
        
        self.codeEditor = CodeEditor(self)
        self.codeInfoLabel = QtWidgets.QLabel('Line 0, Pos 0')
        
        self.saveButton = QtWidgets.QPushButton('Save')
        self.saveButton.setFixedSize(90, 30)
        
        self.executeButton = QtWidgets.QPushButton('Execute')
        self.executeButton.setFixedSize(90, 30)
        
        self.cancelButton = QtWidgets.QPushButton('Cancel')
        self.cancelButton.setFixedSize(90, 30)
        
        
    def _createConnections(self):
        self.codeEditor.cursorPositionChangedSignal.connect(self.updateCodeInfoLabel)
        self.cancelButton.clicked.connect(self.close)
        self.scriptsComboBox.activated.connect(self.setScriptText)
        self.saveButton.clicked.connect(self.updateItemData)
        
        
    def _createLayouts(self):
        mainLayout = QtWidgets.QVBoxLayout(self)
        mainLayout.setSpacing(5)
        mainLayout.setContentsMargins(10, 5, 10, 5)
        
        codeLayout = QtWidgets.QHBoxLayout()
        codeLayout.setSpacing(5)
        codeLayout.setContentsMargins(0, 0, 0, 0)
        codeLayout.addWidget(self.codeIconLabel)
        codeLayout.addWidget(QtWidgets.QLabel('Post Scripts'))
        codeLayout.addWidget(self.scriptsComboBox, 1)
        
        buttonLayout = QtWidgets.QHBoxLayout()
        buttonLayout.setSpacing(5)
        buttonLayout.setContentsMargins(0, 0, 0, 0)
        buttonLayout.addWidget(self.codeInfoLabel)
        buttonLayout.addStretch()
        buttonLayout.addWidget(self.executeButton)
        buttonLayout.addWidget(self.saveButton)
        buttonLayout.addSpacerItem(QtWidgets.QSpacerItem(20, 0, QtWidgets.QSizePolicy.Fixed, QtWidgets.QSizePolicy.Minimum))
        
        buttonLayout.addWidget(self.cancelButton)
        
        mainLayout.addLayout(codeLayout)
        mainLayout.addWidget(self.codeEditor)
        mainLayout.addLayout(buttonLayout)
        
    
    def reject(self):
        self.__class__.GLOBAL_POS = self.pos()
        super().reject()

    def accept(self):
        self.__class__.GLOBAL_POS = self.pos()
        super().accept()

        
    def closeEvent(self, event):
        self.__class__.GLOBAL_POS = self.pos()
        super().closeEvent(event) 
        
        
    def updateCodeInfoLabel(self, line, column):
        self.codeInfoLabel.setText(f'Line {line}, Pos {column}')
        
        
    def setupPostScriptsItems(self, name:str, script:str):
        
        # add sel script item
        self.scriptsComboBox.clear()
        self.scriptsComboBox.addItem(getScriptItemIcon(), name, script)    
   
        # add save scripts
        pyFiles = [f for f in glob.glob(os.path.join(POST_SCRIPTS_PATH, '*.py')) 
                     if os.path.basename(f) != '__init__.py']
        
        codeBlocks = []
        for filePath in pyFiles:
            try:
                with open(filePath, 'r', encoding='utf-8') as f:
                    code = f.read()
                    name = os.path.splitext(os.path.basename(filePath))[0]
                    codeBlocks.append({name:code})
            except Exception as e:
                print(f"Failed to read {filePath}: {e}")
        
        for data in codeBlocks:
            name, scriptString = next(iter(data.items()))
            icon = getScriptItemIcon()
            self.scriptsComboBox.addItem(icon, name, scriptString)
            
        # update text
        self.codeEditor.setPlainText(script)
            
    
    def setScriptText(self, index):
        data = self.scriptsComboBox.itemData(index)
        if data is None:
            return
        
        self.codeEditor.setPlainText(data)
        

    def updateItemData(self):
        if self.selItem is None:
            return
        
        scriptString = self.codeEditor.toPlainText()
        newName      = self.selItem.text().split('*')[0]
        
        # 0 update QListWidget item data
        self.selItem.setData(QtCore.Qt.UserRole, scriptString)
        # update name
        self.selItem.setText(newName)
        
        # 1 update scriptsComboBox item Data
        self.scriptsComboBox.setItemData(0, scriptString, role=QtCore.Qt.UserRole)
        # update name
        self.scriptsComboBox.setItemText(0, newName)
        
        

if __name__ == '__main__':
    s = ScriptWidget()
    s.show()
