from maya import cmds
from maya.api import OpenMaya as om2

from PySide6 import QtWidgets
from PySide6 import QtGui
from PySide6 import QtCore

from linkRigger.ui import layouts, widgets

from linkRigger.ui.settingsWidgets import jointsWidget
from linkRigger.ui.settingsWidgets import controlsWidget
from linkRigger.ui.settingsWidgets.postScriptWidgets import postScriptWidget

class SettingsWidget(QtWidgets.QWidget):
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName('SettingsWidget')
        self.setAttribute(QtCore.Qt.WA_StyledBackground, True) 
        self.setStyleSheet(''' 
                           #SettingsWidget, #subSettingsWidget { background-color: #373737;} 
                           #settingsWidgetTitle { font-size: 16px; font-weight: bold; }
                           
                            QMenu { background-color: #1A1A1A; border: 2px solid #363636; color: #B4B4B4;}
                            QMenu::item { background-color: transparent; }
                            QMenu::separator { height: 3px; background: #363636; margin-left: 15px; margin-right: 15px; }
                            QMenu::item:selected { background-color: #4D4D4D; color: #F0F0F0;}
                            QMenu::right-arrow { border-image: url(linkIcons:menuLeft.png); }
                            QMenu::right-arrow:disabled { border-image: url(linkIcons:menuLeftDisabled.png)} 
                            QMenu::item:disabled {color: #585858;}
            
                            QScrollBar:vertical { border: none; width: 10px; margin: 0px 0 0px 0; }
                            QScrollBar::handle:vertical { background: #5C5C5C; min-height: 20px; border-radius: 5px; }
                            QScrollBar::handle:vertical:hover { background: #656565; }
                            QScrollBar::handle:vertical:pressed {background: #6E6E6E; }
                            QScrollBar::sub-line:vertical,
                            QScrollBar::add-line:vertical { background: none; height: 0; }
                            QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {background: #373737; }
                            
                            QScrollBar:horizontal { border: none; height: 10px; margin: 0 0px 0 0px; }
                            QScrollBar::handle:horizontal { background: #5C5C5C; min-width: 20px; border-radius: 5px; }
                            QScrollBar::handle:horizontal:hover { background: #656565; }
                            QScrollBar::handle:horizontal:pressed {background: #6E6E6E; }
                            QScrollBar::sub-line:horizontal,
                            QScrollBar::add-line:horizontal { background: none; width: 0; }
                            QScrollBar::add-page:horizontal, QScrollBar::sub-page:horizontal {background: #373737; }
                            
                            QAbstractScrollArea::corner { background: #373737; } 
                            
                            #lineShape1 {border-top: 2px solid #282828;}
                            #lineShape2 {border-top: 1px solid #282828;}

                           ''')
        self.characterManager = None
        self._createSubWidgets()
        self._createHeaderWidgets()
        self._createWidgets()
        self._createLayouts()
        self._createConnections()
        
    @property
    def characterExists(self) -> bool:
        return self.characterManager is not None and cmds.objExists(self.characterManager.nodeName)
            
        
    def setCharacterManager(self, characterManager:'CharacterManager'):
        self.characterManager = characterManager
        self.postScriptWidget.setCharacterManager(characterManager)
        self.jointsWidget.setCharacterManager(characterManager)
        self.controlsWidget.setCharacterManager(characterManager)
    
    
    def _createSubWidgets(self):
        self.jointsWidget     = jointsWidget.JointsWidget()
        self.controlsWidget   = controlsWidget.ControlsWidget()
        self.postScriptWidget = postScriptWidget.PostScriptWidget()
        
        
    def _createHeaderWidgets(self):
        self.postScriptHeaderWidget = widgets.CollapsibleWidget('POST SCRIPT')
        self.jointsHeaderWidget     = widgets.CollapsibleWidget('JOINTS') 
        self.controlsHeaderWidget   = widgets.CollapsibleWidget('CONTROLS')
        
        self.extraHeaderWidget    = widgets.CollapsibleWidget('EXTRA')
        self.exportHeaderWidget   = widgets.CollapsibleWidget('EXPORT')
        
        # add to header
        self.postScriptHeaderWidget.addWidget(self.postScriptWidget)
        self.jointsHeaderWidget.addWidget(self.jointsWidget)
        self.jointsHeaderWidget.openClicked.connect(self.jointsWidget.setJointScaleValue)
        self.controlsHeaderWidget.addWidget(self.controlsWidget)
        
        
    def _createWidgets(self):
        
        self.lineShape1 = QtWidgets.QFrame()
        self.lineShape1.setObjectName('lineShape1')
        self.lineShape1.setFrameShape(QtWidgets.QFrame.HLine)
        
        # self.lineShape2 = QtWidgets.QFrame()
        # self.lineShape2.setObjectName('lineShape2')
        # self.lineShape2.setFrameShape(QtWidgets.QFrame.HLine)
        
        self.settingsWidgetTitle = QtWidgets.QLabel('SETTINGS')
        self.settingsWidgetTitle.setObjectName('settingsWidgetTitle')   
          
        # add  scrollArea widget    
        self.settingsScrollArea = QtWidgets.QScrollArea()
        self.settingsScrollArea.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.settingsScrollArea.setWidgetResizable(True)

        subSettingsWidget = QtWidgets.QWidget()
        subSettingsWidget.setObjectName('subSettingsWidget')
        subSettingsWidget.setAttribute(QtCore.Qt.WA_StyledBackground, True) 
        
        subSettingsWidgetLayout = QtWidgets.QVBoxLayout(subSettingsWidget)
        subSettingsWidgetLayout.setContentsMargins(5, 0, 5, 0)
        subSettingsWidgetLayout.setSpacing(3)
        #subSettingsWidgetLayout.addWidget(self.lineShape2)
        subSettingsWidgetLayout.addWidget(self.postScriptHeaderWidget)
        subSettingsWidgetLayout.addWidget(self.jointsHeaderWidget)
        subSettingsWidgetLayout.addWidget(self.controlsHeaderWidget)
        
        subSettingsWidgetLayout.addWidget(self.extraHeaderWidget)
        subSettingsWidgetLayout.addWidget(self.exportHeaderWidget)
        subSettingsWidgetLayout.addStretch()
        
        self.settingsScrollArea.setWidget(subSettingsWidget)
            
    def _createLayouts(self):
        mainLayout = QtWidgets.QVBoxLayout(self)
        mainLayout.setContentsMargins(0, 0, 0, 0)
        mainLayout.setSpacing(0)
        titleLayout = QtWidgets.QHBoxLayout()
        titleLayout.setContentsMargins(5, 5, 5, 10)
        titleLayout.addWidget(self.settingsWidgetTitle)
        titleLayout.addStretch()
        
        #mainLayout.addWidget(self.lineShape1)
        mainLayout.addLayout(titleLayout)
        
        mainLayout.addWidget(self.settingsScrollArea)
        
    def _createConnections(self):
        pass
        
if __name__ == '__main__':
    p = SettingsWidget()
    p.show()
        
          
