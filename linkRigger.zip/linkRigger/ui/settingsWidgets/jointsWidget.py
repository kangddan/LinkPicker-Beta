from maya import cmds
from maya.api import OpenMaya as om2

from PySide6 import QtWidgets
from PySide6 import QtGui
from PySide6 import QtCore
from linkRigger.ui import globalSignals, qtUtils, layouts

from linkRigger.rig import rigGroup

class JointsWidget(QtWidgets.QWidget):
    
    def __init__(self, parent=None, characterManager=None):
        super().__init__(parent)
        
        self.setStyleSheet('''

            QCheckBox::indicator { width: 20px;  height: 20px; }
            QCheckBox::indicator:unchecked { image: url(linkIcons:hide.png); }
            QCheckBox::indicator:checked { image: url(linkIcons:show.png); }
            
            #jointScaleSlider::groove:horizontal {border: none; height: 5px; background-color: #0F0F0F; }
            #jointScaleSlider::handle:horizontal {background-color: #D3D3D3; 
                                               width: 8px; 
                                               margin: -4px 0 -4px 0;
                                               border-radius: 0px;}
                                               
            #jointScaleSlider::sub-page:horizontal {background-color: #757BC3; }
            
            QPushButton {background: #505050; color: white; border: none;  border-radius: 15px;}
            QPushButton:hover {background: #5C5C5C;}
            QPushButton:pressed {background: #464646;}
            QPushButton:disabled {color: #A0A0A0;}
                           ''')
        
        self.characterManager = characterManager

        self._createWidgets()
        self._createLayouts()
        self._createConnections()
        
    @property
    def characterExists(self) -> bool:
        return self.characterManager is not None and cmds.objExists(self.characterManager.nodeName)
           
        
    def setCharacterManager(self, characterManager:'CharacterManager'):
        self.characterManager = characterManager
        self.setData()
        
        
    def _createWidgets(self):
        
        self.visJointCheckBox = QtWidgets.QCheckBox()
        self.visJointCheckBox.setChecked(False)
        
        self.displayAxisCheckBox = QtWidgets.QCheckBox()
        self.displayAxisCheckBox.setChecked(False)
        
        self.jointScaleSlider = QtWidgets.QSlider(QtCore.Qt.Horizontal)

        self.jointScaleSlider.setObjectName('jointScaleSlider')
        self.jointScaleSlider.setRange(1, 2000)
        
        self.createRigGroupButton = QtWidgets.QPushButton('Create Rig Group')
        self.createRigGroupButton.setObjectName('createRigGroupButton')
        self.createRigGroupButton.setFixedSize(155, 30)
        
        self.deleteRigGroupButton = QtWidgets.QPushButton('Delete Rig Group')
        self.deleteRigGroupButton.setObjectName('deleteRigGroupButton')
        self.deleteRigGroupButton.setFixedSize(155, 30)
        
        
        self.setMirrorLabelButton = QtWidgets.QPushButton('Set Mirror Labels')
        self.setMirrorLabelButton.setObjectName('setMirrorLabelButton')
        self.setMirrorLabelButton.setFixedSize(155, 30)
        
        self.clearMirrorLabelButton = QtWidgets.QPushButton('Clear Mirror Labels')
        self.clearMirrorLabelButton.setObjectName('clearMirrorLabelButton')
        self.clearMirrorLabelButton.setFixedSize(155, 30)
        
        
    def _createLayouts(self):
        mainLayout = QtWidgets.QVBoxLayout(self)
        mainLayout.setContentsMargins(0, 0, 0, 0)
        subLayout = QtWidgets.QGridLayout()
        subLayout.setContentsMargins(0, 0, 0, 0)
        subLayout.addWidget(QtWidgets.QLabel('Visibility '), 0, 0)
        subLayout.addWidget(self.visJointCheckBox, 0, 1)
        subLayout.addWidget(QtWidgets.QLabel('Local Axis '), 1, 0)
        subLayout.addWidget(self.displayAxisCheckBox, 1, 1)
        subLayout.addWidget(QtWidgets.QLabel('Scale '), 2, 0)
        subLayout.addWidget(self.jointScaleSlider, 2, 1)
        
        buttonLayout = layouts.FlowLayout()
        buttonLayout.addWidget(self.createRigGroupButton)
        buttonLayout.addWidget(self.deleteRigGroupButton)
        buttonLayout.addWidget(self.setMirrorLabelButton)
        buttonLayout.addWidget(self.clearMirrorLabelButton)
        buttonLayout.setSpacing(10)
        
        mainLayout.addLayout(subLayout)
        mainLayout.addLayout(buttonLayout)
    
        
    def _createConnections(self):
        self.jointScaleSlider.valueChanged.connect(self.updateJointScale)
        self.visJointCheckBox.toggled.connect(self.visDeformGroup)
        self.displayAxisCheckBox.toggled.connect(self.displayJointsLocalAxis)
        
        globalSignals.buildModeSignal.BuildMode.connect(self.setData)
        
        self.createRigGroupButton.clicked.connect(self.createRigGroup)
        self.deleteRigGroupButton.clicked.connect(self.deleteRigGroup)
        
        self.setMirrorLabelButton.clicked.connect(self.setMirrorLabels)
        self.clearMirrorLabelButton.clicked.connect(self.clearMirrorLabels)
    
    
    @qtUtils.addUndo
    def setMirrorLabels(self):
        if not self.characterExists:
            return
        self.characterManager.deformManager.setMirrorLabels()
        
    
    @qtUtils.addUndo
    def clearMirrorLabels(self):
        if not self.characterExists:
            return
        self.characterManager.deformManager.clearMirrorLabels()
        
        
    @qtUtils.addUndo
    def createRigGroup(self):
        rigGroup.createRigGroup()
        
        
    @qtUtils.addUndo
    def deleteRigGroup(self):
        rigGroup.deleteRigGroup()
    
    
    
    def visDeformGroup(self, value:bool):
        if not self.characterExists:
            return
        self.characterManager.deformManager.deformGroupVis = value
        
        # view show joint
        panel = cmds.getPanel(withFocus=True)
        if cmds.modelEditor(panel, query=True, exists=True):
            cmds.modelEditor(panel, edit=True, joints=True)
    
        
    def updateJointScale(self, value:float):
        cmds.jointDisplayScale(value * 0.01)
        
    
    def displayJointsLocalAxis(self, value:bool):
        if not self.characterExists:
            return
        self.characterManager.deformManager.localAxisVis = value
        
        
    def setData(self):
        if self.characterExists:
            self.visJointCheckBox.setChecked(self.characterManager.deformManager.deformGroupVis)
            self.displayAxisCheckBox.setChecked(self.characterManager.deformManager.localAxisVis)
            
            
    def setJointScaleValue(self):
        value = cmds.jointDisplayScale(q=True)
        self.jointScaleSlider.setValue(value * 100)
        
if __name__ == '__main__':
    j = JointsWidget()
    j.show()
    