from maya import cmds


def findMissingIndexs(indexs: 'list[int]') -> 'list[int]':
    '''
    Finds the missing indices in a sorted sequence.

    Args:
        indexs (list[int]): A list of integers in ascending order.

    Returns:
        list[int]: A list of missing integers in the sequence.

    Example:
        findMissingIndexs([0, 2, 3, 7, 8])  
        # Returns [1, 4, 5, 6].

    Notes:
        - Assumes `indexs` is sorted and contains unique integers.
        - Handles both positive and negative integers.
        - If `indexs` is empty, the result will also be an empty list.
    '''
    if not indexs:
        return []
    minVal = min(indexs)
    maxVal = max(indexs)
    
    fullRange = set(range(minVal, maxVal + 1))
    return sorted(fullRange - set(indexs))


def getInvalidIndexs(basePath:str, targetAttr:str) -> 'list[int]':
    indexs = []
    for attrIndex in range((cmds.getAttr(basePath, mi=True) or [0])[-1] + 1):
        if not cmds.listConnections(f'{basePath}[{attrIndex}]{targetAttr}', d=False, s=True):
            indexs.append(attrIndex)
    return indexs
    
    
def getValidIndexs(basePath:str, targetAttr:str) -> 'list[int]':
    '''
    Retrieves the indices of a multi-attribute array that have valid connections.

    Args:
        basePath (str): Path to the multi-attribute array, e.g., 'node.arrayAttr'.
        targetAttr (str): The specific attribute within the indexed array to check connections for.

    Returns:
        list[int]: A list of valid indices where connections exist.

    Example:
        getValidIndexs('God_M_guide_meta.guideNodes', '.guideNode')  
        # Retrieves indices where God_M_guide_meta.guideNodes[index].guideNode has a connection.

    Notes:
        - Iterates through all indices of the attribute array up to the last used index.
        - Indices without connections are skipped.

    '''
    indexs = []
    for attrIndex in range((cmds.getAttr(basePath, mi=True) or [0])[-1] + 1):
        if cmds.listConnections(f'{basePath}[{attrIndex}]{targetAttr}', d=False, s=True) is not None:
            indexs.append(attrIndex)
    return indexs
        


def getConnectedNodes(basePath: str = '', targetAttr: str = '') -> list:
    '''
    Retrieves all nodes connected to a specific attribute in an indexed attribute array.

    Args:
        basePath (str): Path to the attribute array, e.g., 'node.arrayAttr'.
        targetAttr (str): The specific attribute within the indexed array to check connections for.

    Returns:
        list: A list of node names connected to the specified attribute.

    Example:
        getConnectedNodes('God_M_guide_meta.guideNodes', '.guideNode')  
        # Retrieves nodes connected to God_M_guide_meta.guideNodes[index].guideNode

    Notes:
        - This function iterates through all indices of the attribute array and collects connected nodes.
        - Unconnected indices are skipped.

    '''
    nodes = []
    for attrIndex in range((cmds.getAttr(basePath, mi=True) or [0])[-1] + 1):
        node = cmds.listConnections(f'{basePath}[{attrIndex}]{targetAttr}', d=False, s=True)
        if not node:
            continue
        nodes.extend(node)
    return nodes    
    
    
def getIndexByLongName(basePath:str='', targetAttr:str='', longName='') -> int: 
    '''
    Retrieve the index of the given long name within the multi-attribute array.

    Args:
        basePath (str): The base path of the attribute array (e.g., "nodeName.attributeName").
        targetAttr (str): The target attribute to look for connections.
        longName (str): The long name of the node to match.

    Returns:
        int: The index of the matching attribute.

    Raises:
        ValueError: If no matching long name is found in the attribute array.
    '''
    for attrIndex in range((cmds.getAttr(basePath, mi=True) or [0])[-1] + 1):
        node = cmds.listConnections(f'{basePath}[{attrIndex}].{targetAttr}', d=False, s=True) 
        if node and cmds.ls(node[0], long=True)[0] == longName:
            return attrIndex  
            
    raise ValueError(f"No matching node found for longName '{longName}' in '{basePath}'.")


def getIndexsByLongName(basePath:str='', targetAttr:str='', longName='') -> 'list[int]':
    '''
    Return a valid index based on the specified object name
    '''
    indexs = []
    for attrIndex in range((cmds.getAttr(basePath, mi=True) or [0])[-1] + 1):
        node = cmds.listConnections(f'{basePath}[{attrIndex}].{targetAttr}', d=False, s=True) 
        if node and cmds.ls(node[0], long=True)[0] == longName:
            indexs.append(attrIndex)
    return indexs
    

def getIndexByTag(basePath:str='', tagAttr:str='', tag='') -> int:
    '''
    Finds the index of an attribute in an array that matches a specific tag.

    Args:
        basePath (str): Path to the attribute array, e.g., 'node.arrayAttr'.
        tagAttr (str): Sub-attribute to match, e.g., '.guideTag'.
        tag (str): Tag value to search for.

    Returns:
        int: The index of the matching entry.
        
    Example:
        getIndexByTag('God_M_guide_meta.guideNodes', 'guideTag', 'fk01')  # God_M_guide_meta.guideNodes[index].guideTag

    Raises:
        ValueError: If no matching tag is found.
    '''
    for attrIndex in range((cmds.getAttr(basePath, mi=True) or [0])[-1] + 1):
        if cmds.getAttr(f'{basePath}[{attrIndex}]{tagAttr}') == tag:
            return attrIndex  
    #raise ValueError(f"Tag '{tag}' not found in '{basePath}[...].{tagAttr}'.")
    return -1
    
    
def getNodeByTag(basePath:str='', 
                 nodeAttr:str='', 
                 tagAttr:str='', 
                 tag='') -> 'str|None':
                    
    for attrIndex in range((cmds.getAttr(basePath, mi=True) or [0])[-1] + 1):
        if cmds.getAttr(f'{basePath}[{attrIndex}]{tagAttr}') != tag:
            continue
        node = cmds.listConnections(f'{basePath}[{attrIndex}]{nodeAttr}', d=False, s=True)
        if node:
            return node[0]
    return None        
           
    
def findEmptyIndex(basePath:str='', attr:str='', d=False, s=True) -> int:
    '''
    Searches for the first unconnected index in an attribute array.

    Args:
        basePath (str): Base path of the attribute array, e.g., 'node.arrayAttr'.
        attr (str): Optional attribute name for deeper inspection.

    Returns:
        int: Index of the first unconnected entry.

    Example:
        findEmptyIndex('God_M_guide_meta.guideNodes', 'guideNode')  # God_M_guide_meta.guideNodes[index].guideNode
        findEmptyIndex('God_M_meta.metaChildren')                   # God_M_meta.metaChildren[index]
    '''
    maxIndex = (cmds.getAttr(basePath, mi=True) or [0])[-1] + 1
    if attr:
        baseIndexPlugList = [item for i in range(maxIndex) 
                            for item in (cmds.listConnections(f'{basePath}[{i}].{attr}', d=d, s=s, p=True, c=True) or [])]
    else:
        baseIndexPlugList = cmds.listConnections(basePath, d=d, s=s, p=True, c=True) or []
    
    newIndexList = {int(baseIndexPlugList[i].split('[')[1].split(']')[0]) for i in range(0, len(baseIndexPlugList), 2)}

    newIndex = next((i for i in range(maxIndex) if i not in newIndexList), maxIndex)
    return newIndex
    
 
def connectMultiAttr(outputAttr:str, inputAttr:str) -> 'tuple(outputAttrPlug, inputAttrPlug)':
    '''
    Connect the next available indices of two multi-attributes.

    Args:
        outputAttr (str): Output multi-attribute (e.g., "node.attr").
        inputAttr (str): Input multi-attribute (e.g., "node.attr").

    Returns:
        tuple: The connected plugs.

    Example:
        connectMultiAttr("pCube1.attrA", "pSphere1.attrB")
    '''
    outputIndex = findEmptyIndex(outputAttr, d=True, s=False)
    inputIndex  = findEmptyIndex(inputAttr,  d=False, s=True)
    
    cmds.connectAttr(f'{outputAttr}[{outputIndex}]', f'{inputAttr}[{inputIndex}]', f=True)
    return f'{outputAttr}[{outputIndex}]', f'{inputAttr}[{inputIndex}]'
    

def addAttr(nodeName:str, attrName:str, **kwargs) -> 'plug':
    '''
    Add a custom attribute to a Maya node.

    Args:
        nodeName (str): Node name.
        attrName (str): Attribute name.
        **kwargs: Options (e.g., typ/type for attribute type, v/value for default value, lock/l to lock the attribute).

    Returns:
        str: The full attribute plug.

    Example:
        addAttribute("pCube1", "myAttr", typ="string", value="default", lock=True)
        addAttribute("pCube1", "myMessageAttr", typ="message")
    '''
    ATTR_NAME = f'{nodeName}.{attrName}'
    
    attrType  = kwargs.pop('typ', kwargs.pop('type', None))
    value     = kwargs.pop('v', kwargs.pop('value', None))
    lockState = kwargs.pop('lock', kwargs.pop('l', None))
    
    if attrType is not None:
        dataTypeAttrs = ('string', 'stringArray', 'matrix', 'reflectanceRGB', 'spectrumRGB', 'doubleArray', 'floatArray',
                         'Int32Array', 'vectorArray', 'nurbsCurve', 'nurbsSurface', 'mesh', 'lattice', 'pointArray')
        kwargs['dataType' if attrType in dataTypeAttrs else 'attributeType'] = attrType
    
    cmds.addAttr(nodeName, ln=attrName, **kwargs)
    if value is not None:
        try:
            cmds.setAttr(ATTR_NAME, value, type=attrType)
        except Exception:
            cmds.setAttr(ATTR_NAME, value)
    if lockState is not None and lockState == True:
        cmds.setAttr(ATTR_NAME, lock=True)
    return ATTR_NAME
    
    
def setAttr(nodeAttrName:str, *args, check=False, **kwargs):
    if check:
        nodeName = nodeAttrName.rsplit('.', 1)[0]
        nodeLockState = cmds.lockNode(nodeName, query=True, lock=True)[0]
        if nodeLockState:
            cmds.lockNode(nodeName, lock=False)
            
        attrLockState = cmds.getAttr(nodeAttrName, lock=True)
        if attrLockState:
            cmds.setAttr(nodeAttrName, lock=False)
        
        
    cmds.setAttr(nodeAttrName, *args, **kwargs)
    
    if check:
        if nodeLockState:
            cmds.lockNode(nodeName, lock=True)
        if attrLockState:
            cmds.setAttr(nodeAttrName, lock=True)
            

def addInt3Attribute(nodeName:str, attrName:str):
    addAttr(nodeName, attrName, type='compound', nc=3)
    addAttr(nodeName, f'{attrName}X', type='long', parent=attrName, max=1, min=-1)
    addAttr(nodeName, f'{attrName}Y', type='long', parent=attrName, max=1, min=-1)
    addAttr(nodeName, f'{attrName}Z', type='long', parent=attrName, max=1, min=-1)
    
    
def lockBaseAttr(nodeName:str, attrs:list=None, vis=True):
    
    for attr in attrs:
        if not vis:
            cmds.setAttr(f'{nodeName}.{attr}', lock=True, keyable=False, channelBox=False)
        else:
            cmds.setAttr(f'{nodeName}.{attr}', lock=True)

