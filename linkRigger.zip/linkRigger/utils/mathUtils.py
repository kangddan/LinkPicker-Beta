from maya import cmds
from maya.api import OpenMaya as om2


def distance(node1: str, node2: str) -> float:
    '''
    Calculates the world space distance between two nodes
    '''
    vec1 = om2.MPoint(cmds.xform(node1, q=True, t=True, ws=True))
    vec2 = om2.MPoint(cmds.xform(node2, q=True, t=True, ws=True))
    return vec1.distanceTo(vec2)
    

def mixNumber(v1: float, v2: float, weight: float) -> float:
    '''
    Linearly interpolates between two float values
    '''
    return v1 + (v2 - v1) * weight
        
        
def mixVector(v1:list, v2:list, weight: float) -> list:
    '''
    Mixes the two vectors together
    '''   
    return [mixNumber(n1, n2, weight) for n1, n2 in zip(v1, v2)]


def placeNodeInBetween(targetA:str, targetB:str, sourceNode:str, weight=0.5):
    '''
    Places sourceNode between targetA and targetB based on weight
    '''
    posA   = cmds.xform(targetA, q=True, ws=True, t=True)
    posB   = cmds.xform(targetB, q=True, ws=True, t=True)
    midPos = mixVector(posA, posB, weight)
    cmds.xform(sourceNode, ws=True, t=midPos)
    
    
def globalToLocal(parentNode:str, sourceNode:str) -> list: 
    '''
    Returns the local position of sourceNode relative to parentNode
    '''
    globalPos    = om2.MPoint(cmds.xform(sourceNode, q=True, ws=True, t=True))
    globalMatrix = om2.MMatrix(cmds.xform(parentNode, q=True, ws=True, m=True))
    localPos     = globalPos * globalMatrix.inverse()
    return list(localPos)[0:3]
    
    

    








    

    
