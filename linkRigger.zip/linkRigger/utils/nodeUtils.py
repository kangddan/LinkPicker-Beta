from maya import cmds
from maya.api import OpenMaya as om2
from linkRigger.utils import attrUtils

def createNode(nodeType:str, 
               nodeName:str, 
               lockAttr:bool=False, 
               lockNode:bool=False,
               parent:str=None): 
            
    node = cmds.createNode(nodeType, n=nodeName, parent=parent, ss=True)
    if lockAttr:
        for attr in ('t', 'r', 's'):
            cmds.setAttr(f'{node}.{attr}', lock=True)
    if lockNode:
        cmds.lockNode(node, lock=True)
            
    return node
    
    
def toWorldSpace(nodes:'list[str]'):   
    '''
    Remove the specified node from its parent.
    '''
    cmds.parent([node 
                for node in nodes 
                if cmds.listRelatives(node, p=True)], 
                w=True)
                

def resetPSR(nodes:'str|list'):
    if isinstance(nodes, str):
        nodes = [nodes]
    
    for node in nodes:
        cmds.setAttr(f'{node}.translate', 0, 0, 0)
        cmds.setAttr(f'{node}.rotate', 0, 0, 0)
        cmds.setAttr(f'{node}.scale', 1, 1, 1)
        cmds.setAttr(f'{node}.offsetParentMatrix', list(om2.MMatrix()), type='matrix')


def updateAttr(nodeName:str, attrName:str):
    if not cmds.attributeQuery(attrName, node=nodeName, ex=True):
        return
    fullPath = f'{nodeName}.{attrName}'
    srcConns = cmds.listConnections(fullPath, plugs=True, source=True, destination=False) or []
    dstConns = cmds.listConnections(fullPath, plugs=True, source=False, destination=True) or []
    
    attrType  = cmds.getAttr(fullPath, type=True)
    attrValue = cmds.getAttr(fullPath)
    iskeyable = cmds.getAttr(fullPath, keyable=True)
    
    enumNames = ''
    if attrType == 'enum':
        enumNames = cmds.addAttr(fullPath, query=True, enumName=True)
    
    # disconnect
    if srcConns:
        for src in srcConns:
            cmds.disconnectAttr(src, fullPath)
    if dstConns:
        for dst in dstConns:
            cmds.disconnectAttr(fullPath, dst)
    
    cmds.deleteAttr(fullPath)        
    
    if attrType == 'enum':
        attrUtils.addAttr(nodeName, attrName, type=attrType, en=enumNames)
    else:
        attrUtils.addAttr(nodeName, attrName, type=attrType)

    cmds.setAttr(fullPath, cb=True)
    cmds.setAttr(fullPath, keyable=iskeyable)
    cmds.setAttr(fullPath, attrValue)
    
    for src in srcConns:
        cmds.connectAttr(src, fullPath, force=True)
    for dst in dstConns:
        cmds.connectAttr(fullPath, dst, force=True)
        
        
def createVisAttr(nodeName:str, attrName:str, visNodes:list):
    attrUtils.addAttr(nodeName, attrName, type='bool')
    
    fullPath = f'{nodeName}.{attrName}'
    cmds.setAttr(fullPath, keyable=False)
    cmds.setAttr(fullPath, cb=True)
    
    for node in visNodes:
        cmds.connectAttr(fullPath, f'{node}.visibility', f=True)
    

if __name__ == '__main__':
    updateAttr('VChain_L_endIk_ctrl', 'upperLength')
    
    createVisAttr('pCube1', 'sb', ['pCube1'])

        
        
        
        
        
        
        
        
        
        
        
