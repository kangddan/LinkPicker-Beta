from maya import cmds


def uniqueName(name=''):
    startNum = 0; newName = name
    while cmds.objExists(newName):
        startNum += 1
        newName = '{}{:03d}'.format(name, startNum)
    
    return newName
    
 
def rename(nodeName:str, newName:str):
    lockState = cmds.lockNode(nodeName, query=True, lock=True)[0]
    if lockState:
        cmds.lockNode(nodeName, lock=False)
    name = cmds.rename(nodeName, newName)
    if lockState:
        cmds.lockNode(name, lock=True)
        

def getTail(inputStr: str) -> str:
    '''
    Get the part of the string after the first underscore, including the underscore.

    Args:
        inputStr (str): The input string.

    Returns:
        str: The substring starting from the first underscore, or an empty string if no underscore exists.
        
    Example:
        getTail('LinkRig_component_hrc')
        # Result: _component_hrc #   
    '''
    try:
        return inputStr[inputStr.index('_'):]
    except ValueError:
        return ''
   
    
def uniqNameSuffix(baseName='', suffix='', filterType=''):
    '''
    Generate a unique name with a numeric suffix and optional suffix in the current scene.

    Args:
        baseName (str): 
            The base name for the new node.
        suffix (str, optional): 
            An additional string to append to the name (e.g., '_suffix').
        filterType (str, optional): 
            A filter to match existing node names.

    Returns:
        str: A unique name based on the base name, numeric suffix, and optional suffix.

    Example:
        uniqNameSuffix('MetaNode')
        uniqNameSuffix('MetaNode', '_Meta', '*_Meta')
    '''

    newName = baseName + suffix
    if not cmds.objExists(newName):
        return newName

    nodes = cmds.ls(filterType) if filterType else cmds.ls()

    existingNumbers = set()
    
    for existingName in nodes:
        if existingName.startswith(baseName) and existingName.endswith(suffix):
            middlePart = existingName[len(baseName):-len(suffix)] if suffix else existingName[len(baseName):]
            
            if middlePart.isdigit():
                existingNumbers.add(int(middlePart))
            elif not middlePart: 
                existingNumbers.add(0)

    current = 0
    while current in existingNumbers:
        current += 1

    newName = f'{baseName}{suffix}' if current == 0 else f'{baseName}{current:03d}{suffix}'
    return newName

