# -*- coding: utf-8 -*-
"""
Utilities for creating, updating, and manipulating NURBS curves in Maya.

Functions:
    - getData(name): Extracts shape and color data from a NURBS curve.
    - create(name, data, scale=1, axis='y'): Creates a curve with optional scaling and orientation.
    - update(name, data): Updates an existing curve's shape with new data.

Example:
    import curveHelpers
    data = curveHelpers.getData('curve1')
    curveHelpers.create('newCurve', data, scale=2, axis='x')
    curveHelpers.update('existingCurve', data)
"""
import uuid
from maya import cmds
from maya.api import OpenMaya as om2
from linkRigger.utils import nameUtils
    

def _getSplineShapes(node: 'str|om2.MObject|om2.MDagPath') -> 'list[om2.MObject]':
    """
    Retrieve the shape objects (specifically curves) of a node and return them as a list of MObjects.

    Args:
        node (str | MObject | MDagPath): The node, which can be a node name (str), MObject, or MDagPath.

    Returns:
        list[MObject]: A list of MObjects representing the curve shapes of the node.

    Raises:
        TypeError: If the provided MObject is not a valid DAG node.
    """
    if isinstance(node, str):
        node = om2.MDagPath.getAPathTo(om2.MGlobal.getSelectionListByName(node).getDependNode(0))
    elif isinstance(node, om2.MObject):
        if node.hasFn(om2.MFn.kDagNode):
            node = om2.MDagPath.getAPathTo(node)
        else:
            raise TypeError(f'The provided MObject is not a valid DAG node: {node}')
    
    shapes = []
    for i in range(node.childCount()):
        child = node.child(i)
        if child.hasFn(om2.MFn.kShape) and child.hasFn(om2.MFn.kCurve):
            shapes.append(child)
    return shapes
            
                
def _getShapeColor(fnNode: om2.MFnDependencyNode) -> list:
    """
    Get shape node color.

    Args:
        fnNode (MFnDependencyNode): The function set for the node.

    Returns:
        list: [isRGB, colorValue], where:
            - isRGB (bool): True for RGB, False for index.
            - colorValue: RGB tuple or index value.
    """
    
    colorData = [None, None] 
    if fnNode.findPlug('overrideEnabled', True).asBool():
        isRGB = fnNode.findPlug('overrideRGBColors', True).asBool()
        colorData[0] = isRGB
        if isRGB:
            colorData[1] = (
                fnNode.findPlug("overrideColorR", True).asFloat(),
                fnNode.findPlug("overrideColorG", True).asFloat(),
                fnNode.findPlug("overrideColorB", True).asFloat()
            )
        else:
            colorData[1] = fnNode.findPlug("overrideColor", True).asInt()
    return colorData
    

def _setShapeColor(shapeNode: str, colorData: list):
    """
    Set the override color of a shape node.

    Args:
        shapeNode (str): The shape node to apply the color to.
        colorData (list): A list containing [isRGB, colorValue], where:
            - isRGB (bool): True for RGB, False for index.
            - colorValue: RGB tuple or index value.
    """
    if colorData[0] is None:
        return
    
    isRGB = colorData[0]
    cmds.setAttr(f'{shapeNode}.overrideEnabled', True)
    cmds.setAttr(f'{shapeNode}.overrideRGBColors', isRGB)
    if isRGB:
        cmds.setAttr(f'{shapeNode}.overrideColorRGB', *colorData[1])
    else:
        cmds.setAttr(f'{shapeNode}.overrideColor',     colorData[1])
    

def _getSplineSize(nodeName: str) -> float:
    """
    Calculate the maximum bounding box size of a spline.

    Args:
        nodeName (str): The name of the DAG node.

    Returns:
        float: The largest size (extent) of the spline's bounding box.
    """

    shapes: list[om2.MObject] = _getSplineShapes(nodeName)
    maxSize = 0
    for shape in shapes:
        shapeFn = om2.MFnDagNode(shape)
        minPoint, maxPoint = shapeFn.boundingBox.min, shapeFn.boundingBox.max
        currentSize = max(maxPoint.x-minPoint.x, maxPoint.y-minPoint.y, maxPoint.z-minPoint.z)
        
        if currentSize > maxSize:
            maxSize = currentSize
    return maxSize
        
   
    
def _selectedShapesPoints(splineName: str) -> 'list[str]':
    """
    Get the control vertices (CVs) of all shape nodes of a spline.

    Args:
        splineName (str): The name of the spline transform node.

    Returns:
        list[str]: A list of CVs for each shape node of the spline.
    """
    shapes = _getSplineShapes(splineName)
    return [cmds.ls(f'{om2.MDagPath.getAPathTo(shape).fullPathName()}.cv[*]')[0] for shape in shapes] 
    

def getSplinePoints(splineName:str) -> list:
    shapes = _getSplineShapes(splineName)
    points = []
    for shape in shapes:
        points.extend(cmds.ls(f'{om2.MDagPath.getAPathTo(shape).fullPathName()}.cv[*]', flatten=True))    
    return points
    

def _scaleSpline(splineName: str, scaleFactor: float):
    """
    Scale the spline's control vertices (CVs) uniformly by a factor.

    Args:
        splineName (str): The name of the spline transform node.
        scaleFactor (float): The scaling factor to apply.
    """
    points = _selectedShapesPoints(splineName)
    cmds.scale(scaleFactor, scaleFactor, scaleFactor, points, r=1, ocp=1) 


def _rotateSpline(splineName: str, axis: str='y'):
    """
    Rotate the spline's control vertices (CVs) around a specified axis.

    Args:
        splineName (str): The name of the spline transform node.
        axis (str, optional): The axis to rotate around ('y', '-y', 'x', '-x', 'z', '-z'). Default is 'y'.
    """
    rotationMap = {'-y': (180, 0,   0),
                   'x' : (-90, 0,   0),
                   '-x': (90,  0,   0),
                   'z' : (0,   0,  90),
                   '-z': (0,   0, -90)}
    
    rotation = rotationMap.get(axis.lower(), None)
    if rotation is None:
        return
    points = _selectedShapesPoints(splineName)
    cmds.rotate(*rotation, points, r=1, ocp=1)  
    
    
def _setTemplate(splineName:str):
    shapes = _getSplineShapes(splineName)
    for shape in shapes:
        shapeName = om2.MDagPath.getAPathTo(shape).fullPathName()
        cmds.setAttr(f'{shapeName}.overrideEnabled', True)
        cmds.setAttr(f'{shapeName}.overrideDisplayType', 1)
        
 
def _create(name: str, data: dict) -> str:
    """
    Create NURBS curve shapes based on provided shape data.

    Args:
        name (str): The curve name.
        data (dict): A dictionary representing shape data structured as:
            {
                'shape': {
                    'periodic': bool,
                    'degree'  : int,
                    'points'  : List[List[float, float, float]],
                    'knot'    : List[int],
                    'isRGB'   : bool,
                    'color'   : Union[Tuple[float, float, float], int]
                }
            }

    Returns:
        str: The parent transform node of the generated shapes.
    """
    name = name.rpartition('|')[-1]
    parentTransform = None 
    for shape in data.values():
        try:
            transform = cmds.curve(per = shape['periodic'], 
                                   d   = shape['degree'], 
                                   p   = shape['points'], 
                                   k   = shape['knot'], 
                                   n   = name)
        except Exception as e:
            import traceback
            traceback.print_exc() 
            om2.MGlobal.displayWarning(f'{shape}: Incorrect curve data. \n{str(e)}')
            continue
        
        shapeNode = cmds.rename(om2.MDagPath.getAPathTo(_getSplineShapes(transform)[0]).fullPathName(), f"{name}Shape{'#'}")
        # Set color
        _setShapeColor(shapeNode, [shape['isRGB'], shape['color']])
        
        if parentTransform is None:
            parentTransform = transform
        else:
            cmds.parent(shapeNode, parentTransform, s=True, add=True, nis=False)
            cmds.delete(transform)
        
    cmds.select(cl=True)
    return parentTransform
    

def getData(dagPath: 'om2.MDagPath|str', space='local') -> dict:
    """
    Get NURBS curve shape and color data.

    Args:
        name  (str): The DAG node name.
        space (str): Either 'local' for local point space pos or 'global' for world point space pos.

    Returns:
        str: A dictionary representing shape and color data structured as:
            {
                'shape': {
                    'periodic': bool,
                    'degree'  : int,
                    'points'  : List[List[float, float, float]],
                    'knot'    : List[int],
                    'isRGB'   : bool,
                    'color'   : Union[Tuple[float, float, float], int]
                }
            }
    """
    
    spaceMap = {'local' :om2.MSpace.kObject,
                'global':om2.MSpace.kWorld}
                
    dagPath = om2.MGlobal.getSelectionListByName(dagPath).getDagPath(0) if isinstance(dagPath, str) else dagPath
    
    shapes = []; colors = []
    for index in range(dagPath.childCount()):
        child = dagPath.child(index)
        
        if not child.hasFn(om2.MFn.kCurve):
            continue
        childDagPath = om2.MDagPath.getAPathTo(child)
        shape        = om2.MFnNurbsCurve(childDagPath)
        shapes.append(shape)  
        # add color
        fnNode = om2.MFnDependencyNode(child)
        colors.append(_getShapeColor(fnNode))
    # -------------------------------------------------------         
    shapesData = {}
    for index, shape in enumerate(shapes):
        shape = {'periodic': True if shape.form > 2 else False,
                 'degree'  : shape.degree,
                 'points'  : [[p.x, p.y, p.z] for p in shape.cvPositions(spaceMap.get(space, om2.MSpace.kObject))], # get point local pos
                 'knot'    : [int(index) for index in list(shape.knots())],
                 'isRGB'   : colors[index][0],
                 'color'   : colors[index][1]}
        shapesData[f"shape{index if index != 0 else ''}"] = shape
    return shapesData
   
                               
def create(name: str, data: dict, scale: float=1, axis: str='y', template=False, color=None) -> str:
    """
    Create a NURBS curve with optional scaling and orientation.

    Args:
        name (str): The curve name.
        data (dict): Shape data.
        scale (float, optional): Scale factor. Default is 1.
        axis (str, optional): Axis orientation ('y', '-y', 'x', '-x', 'z', '-z').

    Returns:
        str: The parent transform node of the curve.
    """
    splineNode = _create(name, data)
    cmds.setAttr(f'{splineNode}.rotateOrder', cb=True) # show rotateOrder
    cmds.setAttr(f'{splineNode}.visibility', k=False, cb=False) # hide visibility
    
    if scale != 1:
        _scaleSpline(name, scale)
    if axis.lower() != 'y':
        _rotateSpline(name, axis)   
    if template:  
        _setTemplate(name)
    if color:
        shapes = cmds.listRelatives(splineNode, shapes=True, fullPath=True) or []
        for shape in shapes:
            _setShapeColor(shape, color)
    return splineNode


def update(splineName: str, data: dict) -> str:
    """
    Update the curve shape while keeping the original transform node.

    Args:
        splineName (str): The curve to update.
        data (str): New shape data.

    Returns:
        str: The updated spline name.
    """
    colorData = [None, None]
    cacheSize = _getSplineSize(splineName) # target size
        
    shapes: 'list[om2.MObject]'  = _getSplineShapes(splineName)
    if shapes: 
        colorData = _getShapeColor(om2.MFnDependencyNode(shapes[0])) # get color data
        cmds.delete([om2.MDagPath.getAPathTo(node).fullPathName()  for node in shapes])
    
    tempTransform = _create(f'{splineName}_{uuid.uuid4().hex[:8]}', data)
    updateShapes: list[om2.MObject] = _getSplineShapes(tempTransform)
    for shape in updateShapes:
        shapeName = om2.MDagPath.getAPathTo(shape).fullPathName()
        _setShapeColor(shapeName, colorData) # set color
        
        # set shape unique name
        shapeNewName = nameUtils.uniqueName(f"{splineName.rpartition('|')[-1]}Shape")
        cmds.parent(cmds.rename(shapeName, shapeNewName), splineName, s=True, add=True, nis=True)
    cmds.delete(tempTransform)
    
    newSize = _getSplineSize(splineName) # new size
    if abs(cacheSize - newSize) > 1e-10  and newSize != 0: 
        scaleFactor = cacheSize / newSize
        _scaleSpline(splineName, scaleFactor)
        
    return splineName
 

def setJointShapes(jointNode: str, data: dict):
    splineNode = _create(nameUtils.uniqueName(jointNode), data)
    shapes: 'list[om2.MObject]'  = _getSplineShapes(splineNode)
    
    for shape in shapes:
        name = om2.MDagPath.getAPathTo(shape).fullPathName()
        shapeNewName = nameUtils.uniqueName(f"{jointNode.rpartition('|')[-1]}Shape")
        cmds.parent(cmds.rename(name, shapeNewName), jointNode, s=True, add=True, nis=True)
    cmds.delete(splineNode)
        
