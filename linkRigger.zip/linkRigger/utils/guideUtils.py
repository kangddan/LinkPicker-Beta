import math
from maya import cmds
from maya.api import OpenMaya as om2

from linkRigger.core import nodes
from linkRigger.utils import nameUtils, attrUtils


def createVChainPoleSystem(
                           baseName  : str,
                           rootGuide : 'GuideNode',
                           uprGuide  : 'GuideNode', 
                           midGuide  : 'GuideNode', 
                           endGuide  : 'GuideNode', 
                           poleGuide : 'GuideNode',
                           offset    : float
                           ) -> None:
    rootGuideName               = rootGuide.nodeName                        
    uprGuideName,  uprGuideTag  = uprGuide.nodeName,  uprGuide.guideTag
    midGuideName,  midGuideTag  = midGuide.nodeName,  midGuide.guideTag
    endGuideName,  endGuideTag  = endGuide.nodeName,  endGuide.guideTag
    poleGuideName, poleGuideTag = poleGuide.nodeName, poleGuide.guideTag
    
    uprGuideGlobalPos = cmds.createNode('decomposeMatrix', name=nameUtils.uniqNameSuffix(f'{baseName}', f'_{uprGuideTag}_globalPos'))
    midGuideGlobalPos = cmds.createNode('decomposeMatrix', name=nameUtils.uniqNameSuffix(f'{baseName}', f'_{midGuideTag}_globalPos'))
    endGuideGlobalPos = cmds.createNode('decomposeMatrix', name=nameUtils.uniqNameSuffix(f'{baseName}', f'_{endGuideTag}_globalPos'))
    cmds.connectAttr(f'{uprGuideName}.worldMatrix[0]', f'{uprGuideGlobalPos}.inputMatrix', f=True)
    cmds.connectAttr(f'{midGuideName}.worldMatrix[0]', f'{midGuideGlobalPos}.inputMatrix', f=True)
    cmds.connectAttr(f'{endGuideName}.worldMatrix[0]', f'{endGuideGlobalPos}.inputMatrix', f=True)
    
    uprLength = cmds.createNode('plusMinusAverage', name=nameUtils.uniqNameSuffix(f'{baseName}', f'_{uprGuideTag}_length'))
    midLength = cmds.createNode('plusMinusAverage', name=nameUtils.uniqNameSuffix(f'{baseName}', f'_{midGuideTag}_length'))
    cmds.setAttr(f'{uprLength}.operation', 2); cmds.setAttr(f'{midLength}.operation', 2)
    cmds.connectAttr(f'{midGuideGlobalPos}.outputTranslate', f'{uprLength}.input3D[0]', f=True)
    cmds.connectAttr(f'{uprGuideGlobalPos}.outputTranslate', f'{uprLength}.input3D[1]', f=True)
    cmds.connectAttr(f'{endGuideGlobalPos}.outputTranslate', f'{midLength}.input3D[0]', f=True)
    cmds.connectAttr(f'{midGuideGlobalPos}.outputTranslate', f'{midLength}.input3D[1]', f=True)
    
    uprNormaLength = cmds.createNode('vectorProduct', name=nameUtils.uniqNameSuffix(f'{baseName}', f'_{uprGuideTag}_normaLength'))
    midNormaLength = cmds.createNode('vectorProduct', name=nameUtils.uniqNameSuffix(f'{baseName}', f'_{midGuideTag}_normaLength'))
    cmds.setAttr(f'{uprNormaLength}.operation', 0); cmds.setAttr(f'{uprNormaLength}.normalizeOutput', 1)
    cmds.setAttr(f'{midNormaLength}.operation', 0); cmds.setAttr(f'{midNormaLength}.normalizeOutput', 1)
    cmds.connectAttr(f'{uprLength}.output3D', f'{uprNormaLength}.input1', f=True)
    cmds.connectAttr(f'{midLength}.output3D', f'{midNormaLength}.input1', f=True)
    
    inverMidNormaLength = cmds.createNode('multiplyDivide', name=nameUtils.uniqNameSuffix(f'{baseName}', f'_{uprGuideTag}_inverMidNorma'))
    cmds.setAttr(f'{inverMidNormaLength}.operation', 1); cmds.setAttr(f'{inverMidNormaLength}.input2', -1, -1, -1)
    cmds.connectAttr(f'{midNormaLength}.output', f'{inverMidNormaLength}.input1', f=True)
    
    mixPosNode = cmds.createNode('pairBlend', name=nameUtils.uniqNameSuffix(f'{baseName}', f'_{uprGuideTag}_{midGuideTag}_mixPos'))
    cmds.setAttr(f'{mixPosNode}.weight', 0.5)
    cmds.connectAttr(f'{uprNormaLength}.output', f'{mixPosNode}.inTranslate1', f=True)
    cmds.connectAttr(f'{inverMidNormaLength}.output', f'{mixPosNode}.inTranslate2', f=True)
    
    mixPosNorma = cmds.createNode('vectorProduct', name=nameUtils.uniqNameSuffix(f'{baseName}', f'_{poleGuideTag}_mixPosNorma'))
    cmds.setAttr(f'{mixPosNorma}.operation', 0); cmds.setAttr(f'{mixPosNorma}.normalizeOutput', 1)
    cmds.connectAttr(f'{mixPosNode}.outTranslate', f'{mixPosNorma}.input1', f=True)
    
    offsetPosNode = cmds.createNode('multiplyDivide', name=nameUtils.uniqNameSuffix(f'{baseName}', f'_{poleGuideTag}_offsetMaxPos'))
    cmds.setAttr(f'{offsetPosNode}.operation', 1)
    cmds.connectAttr(f'{mixPosNorma}.output', f'{offsetPosNode}.input1', f=True)
    
    poleMatrixOffset = cmds.createNode('plusMinusAverage', name=nameUtils.uniqNameSuffix(f'{baseName}', f'_{poleGuideTag}_matrixOffset'))
    cmds.setAttr(f'{poleMatrixOffset}.operation', 1)
    cmds.connectAttr(f'{offsetPosNode}.output', f'{poleMatrixOffset}.input3D[0]', f=True)
    cmds.connectAttr(f'{midGuideGlobalPos}.outputTranslate', f'{poleMatrixOffset}.input3D[1]', f=True)
    
    matrixVector3Base = cmds.createNode('plusMinusAverage', name=nameUtils.uniqNameSuffix(f'{baseName}', f'_{poleGuideTag}_matrixVector3Base'))
    cmds.setAttr(f'{matrixVector3Base}.operation', 2)
    cmds.connectAttr(f'{poleMatrixOffset}.output3D', f'{matrixVector3Base}.input3D[0]', f=True)
    cmds.connectAttr(f'{midGuideGlobalPos}.outputTranslate', f'{matrixVector3Base}.input3D[1]', f=True)
    
    matrixVector3BaseInver = cmds.createNode('multiplyDivide', name=nameUtils.uniqNameSuffix(f'{baseName}', f'_{poleGuideTag}_matrixVector3BaseInver'))
    cmds.connectAttr(f'{matrixVector3Base}.output3D', f'{matrixVector3BaseInver}.input1', f=True)
    cmds.setAttr(f'{matrixVector3BaseInver}.input2', -1, -1, -1)
    
    v3 = cmds.createNode('vectorProduct', name=nameUtils.uniqNameSuffix(f'{baseName}', f'_{poleGuideTag}_v3'))
    cmds.setAttr(f'{v3}.operation', 0); cmds.setAttr(f'{v3}.normalizeOutput', 1)
    cmds.connectAttr(f'{matrixVector3BaseInver}.output', f'{v3}.input1', f=True)
    
    v2 = cmds.createNode('vectorProduct', name=nameUtils.uniqNameSuffix(f'{baseName}', f'_{poleGuideTag}_v2'))
    cmds.setAttr(f'{v2}.operation', 2); cmds.setAttr(f'{v2}.normalizeOutput', 1)
    cmds.connectAttr(f'{v3}.output', f'{v2}.input1', f=True)
    cmds.connectAttr(f'{uprNormaLength}.output', f'{v2}.input2', f=True)
    
    v1 = cmds.createNode('vectorProduct', name=nameUtils.uniqNameSuffix(f'{baseName}', f'_{poleGuideTag}_v1'))
    cmds.setAttr(f'{v1}.operation', 2); cmds.setAttr(f'{v1}.normalizeOutput', 1)
    cmds.connectAttr(f'{v2}.output', f'{v1}.input1', f=True)
    cmds.connectAttr(f'{v3}.output', f'{v1}.input2', f=True)
    
    vectorToMatrix = cmds.createNode('fourByFourMatrix', name=nameUtils.uniqNameSuffix(f'{baseName}', f'_{poleGuideTag}_vectorToMatrix'))
    cmds.connectAttr(f'{v1}.outputX', f'{vectorToMatrix}.in00', f=True)
    cmds.connectAttr(f'{v1}.outputY', f'{vectorToMatrix}.in01', f=True)
    cmds.connectAttr(f'{v1}.outputZ', f'{vectorToMatrix}.in02', f=True)
    cmds.connectAttr(f'{v2}.outputX', f'{vectorToMatrix}.in10', f=True)
    cmds.connectAttr(f'{v2}.outputY', f'{vectorToMatrix}.in11', f=True)
    cmds.connectAttr(f'{v2}.outputZ', f'{vectorToMatrix}.in12', f=True)
    cmds.connectAttr(f'{v3}.outputX', f'{vectorToMatrix}.in20', f=True)
    cmds.connectAttr(f'{v3}.outputY', f'{vectorToMatrix}.in21', f=True)
    cmds.connectAttr(f'{v3}.outputZ', f'{vectorToMatrix}.in22', f=True)
    cmds.connectAttr(f'{poleMatrixOffset}.output3Dx', f'{vectorToMatrix}.in30', f=True)
    cmds.connectAttr(f'{poleMatrixOffset}.output3Dy', f'{vectorToMatrix}.in31', f=True)
    cmds.connectAttr(f'{poleMatrixOffset}.output3Dz', f'{vectorToMatrix}.in32', f=True)
    
    offsetMatrixMult = cmds.createNode('multMatrix', name=nameUtils.uniqNameSuffix(f'{baseName}', f'_{poleGuideTag}_offsetMatrixMult'))
    cmds.connectAttr(f'{vectorToMatrix}.output', f'{offsetMatrixMult}.matrixIn[0]', f=True)
    cmds.connectAttr(f'{rootGuideName}.worldInverseMatrix[0]', f'{offsetMatrixMult}.matrixIn[1]', f=True)
    
    poleGuideGroup = poleGuide.groupFromGuideLayer
    linkNode = poleGuideGroup if poleGuideGroup else poleGuideName
    cmds.connectAttr(f'{offsetMatrixMult}.matrixSum', f'{linkNode}.offsetParentMatrix', f=True)
    
    # link scale
    poleGlobalScale = cmds.createNode('decomposeMatrix', name=nameUtils.uniqNameSuffix(f'{baseName}', f'_{poleGuideTag}_globalScale'))
    cmds.connectAttr(f'{rootGuideName}.worldMatrix[0]', f'{poleGlobalScale}.inputMatrix', f=True)
    cmds.connectAttr(f'{poleGlobalScale}.outputScale', f'{linkNode}.scale', f=True)
    
    # auto offset
    uprAndMidDistance = cmds.createNode('distanceBetween', name=nameUtils.uniqNameSuffix(f'{baseName}', f'_{uprGuideTag}_{midGuideTag}_distance'))
    cmds.connectAttr(f'{uprGuideGlobalPos}.outputTranslate', f'{uprAndMidDistance}.point1', f=True)
    cmds.connectAttr(f'{midGuideGlobalPos}.outputTranslate', f'{uprAndMidDistance}.point2', f=True)
    
    midAndendDistance = cmds.createNode('distanceBetween', name=nameUtils.uniqNameSuffix(f'{baseName}', f'_{midGuideTag}_{endGuideTag}_distance'))
    cmds.connectAttr(f'{midGuideGlobalPos}.outputTranslate', f'{midAndendDistance}.point1', f=True)
    cmds.connectAttr(f'{endGuideGlobalPos}.outputTranslate', f'{midAndendDistance}.point2', f=True)
    
    sumLength = cmds.createNode('sum', name=nameUtils.uniqNameSuffix(f'{baseName}', f'_{uprGuideTag}_{midGuideTag}_sumLength'))
    cmds.connectAttr(f'{uprAndMidDistance}.distance', f'{sumLength}.input[0]', f=True)
    cmds.connectAttr(f'{midAndendDistance}.distance', f'{sumLength}.input[1]', f=True)
    
    sumLengthOffset = cmds.createNode('multiply', name=nameUtils.uniqNameSuffix(f'{baseName}', f'_{uprGuideTag}_{midGuideTag}_sumLengthOffset'))
    cmds.connectAttr(f'{sumLength}.output', f'{sumLengthOffset}.input[0]', f=True)
    cmds.setAttr(f'{sumLengthOffset}.input[1]', offset)
    cmds.connectAttr(f'{sumLengthOffset}.output', f'{offsetPosNode}.input2X', f=True)
    cmds.connectAttr(f'{sumLengthOffset}.output', f'{offsetPosNode}.input2Y', f=True)
    cmds.connectAttr(f'{sumLengthOffset}.output', f'{offsetPosNode}.input2Z', f=True)
    
    extraNodes = [
                    uprGuideGlobalPos, midGuideGlobalPos, endGuideGlobalPos, 
                    uprLength, midLength, uprNormaLength, midNormaLength, 
                    inverMidNormaLength, mixPosNode, mixPosNorma, offsetPosNode, 
                    poleMatrixOffset, matrixVector3Base, matrixVector3BaseInver, 
                    v3, v2, v1, vectorToMatrix, offsetMatrixMult, 
                    poleGlobalScale, uprAndMidDistance, midAndendDistance, 
                    sumLength, sumLengthOffset
                    ]
    poleGuide.addExtraNodes(extraNodes)
    

def _alignGuide_(axis:str='x', guide:str=None):
    childs = cmds.listRelatives(guide, children=True, type='transform', path=True)
    if not childs:
        return
        
    childGuides = []
    for child in childs:
        childGuide = cmds.listRelatives(child, children=True, type='transform', path=True)
        if childGuide:
            childGuides.append(childGuide[0])
    if not childGuides:
        return
      
    childMatrixs = [cmds.xform(child, q=True, m=True, ws=True) for child in childGuides]
    
    guideMatrix = om2.MMatrix(cmds.xform(guide, q=True, m=True, ws=True))
    rotateOrder = cmds.getAttr(f'{guide}.rotateOrder')

    childPos = om2.MVector(childMatrixs[0][-4], childMatrixs[0][-3], childMatrixs[0][-2])
    guidePos = om2.MVector(guideMatrix[-4], guideMatrix[-3], guideMatrix[-2])
    direction = (childPos - guidePos).normalize() 

    oldX = om2.MVector(guideMatrix[0], guideMatrix[1], guideMatrix[2])
    oldY = om2.MVector(guideMatrix[4], guideMatrix[5], guideMatrix[6])
    oldZ = om2.MVector(guideMatrix[8], guideMatrix[9], guideMatrix[10])

    if axis in ['x', '-x']:
        xAxis = direction
        zAxis = (oldZ - (oldZ * xAxis) * xAxis).normalize()
        yAxis = zAxis ^ xAxis 
        zAxis = xAxis ^ yAxis
    elif axis in ['y', '-y']:
        yAxis = direction
        xAxis = (oldX - (oldX * yAxis) * yAxis).normalize()
        zAxis = xAxis ^ yAxis 
        xAxis = yAxis ^ zAxis
    elif axis in ['z', '-z']:
        zAxis = direction
        yAxis = (oldY - (oldY * zAxis) * zAxis).normalize()
        xAxis = yAxis ^ zAxis  
        yAxis = zAxis ^ xAxis

    newMatrix = om2.MMatrix([xAxis.x, xAxis.y, xAxis.z, 0,
                             yAxis.x, yAxis.y, yAxis.z, 0,
                             zAxis.x, zAxis.y, zAxis.z, 0,
                             guidePos.x, guidePos.y, guidePos.z, 1 ])

    offsetRotMap = {'-z':[math.pi, 0, 0],
                    '-x':[0, math.pi, 0],
                    '-y':[0, 0, math.pi]}
                    
    mt = om2.MTransformationMatrix(newMatrix).rotateBy(om2.MEulerRotation(offsetRotMap.get(axis, [0, 0, 0]), rotateOrder), om2.MSpace.kObject)
    ro = mt.rotation(asQuaternion=False).reorder(rotateOrder)

    cmds.xform(guide, ro=[om2.MAngle(angle).asDegrees() for angle in (ro.x, ro.y, ro.z)], ws=True)
    
    for child, matrix in zip(childGuides, childMatrixs):
        cmds.xform(child, m=matrix, ws=True)


def alignSelectedGuides(axis:str='x'):
    cmds.undoInfo(openChunk=True)
    for node in cmds.ls(sl=True, type='transform'):
        if not cmds.attributeQuery('guideTag', n=node, ex=True):
            continue
        _alignGuide_(axis, node)
        _alignGuide_(axis, node)
    cmds.undoInfo(closeChunk=True)


def createTwistGuide(baseName:str,
                     guideA:'GuideNode', 
                     guideB:'GuideNode', 
                     guideTag:str,
                     guideLayer=None):  
                        
    guideNode, blendMatrixNode = createGuideFromParent(baseName, guideA, guideB, 0.2, 0, guideTag, 'GUIDE_BASE', guideLayer)
    attrUtils.addAttr(f'{guideNode}', 'weight', type='double', value=0, min=0, max=1, k=False) # add attr
    cmds.setAttr(f'{guideNode}.weight', channelBox=True)
    cmds.connectAttr(f'{guideNode}.weight', f'{blendMatrixNode}.envelope')
    
    
def setTwistWeight(guideNodes:'list[GuideNode]'):
    '''
    "Automatically distributes evenly spaced weight values to each guide node's blendMatrix
    '''
    if not guideNodes:
        return
    
    count = len(guideNodes)
    weights = [i / (count - 1) for i in range(count)] if count > 1 else [1.0]
    
    for guideNode, weight in zip(guideNodes, weights):
        cmds.setAttr(f'{guideNode.nodeName}.weight', weight)
        
        
def createGuideFromParent(baseName:str,
                          guideA:'GuideNode', 
                          guideB:'GuideNode',
                          size:float,
                          weight:float,
                          guideTag:str,
                          shape='',
                          guideLayer=None) -> str:
                            
    guideNode      = nodes.GuideNode.createBaseGuide(baseName, guideTag, size, guideA, guideLayer, True, shape)
    guideNodeGroup = guideNode.groupFromGuideLayer
    linkNode       = guideNodeGroup if guideNodeGroup else guideNode.nodeName
    
    blendMatrixNode = cmds.createNode('blendMatrix', n=f'{baseName}_{guideTag}_blendMatrix')
    multMatrixNode  = cmds.createNode('multMatrix', n=f'{baseName}_{guideTag}_offsetMatrix')
    
    cmds.connectAttr(f'{guideA.nodeName}.worldMatrix[0]', f'{blendMatrixNode}.inputMatrix')
    cmds.connectAttr(f'{guideB.nodeName}.worldMatrix[0]', f'{blendMatrixNode}.target[0].targetMatrix')
    cmds.setAttr(f'{blendMatrixNode}.target[0].rotateWeight', 0)
    
    cmds.connectAttr(f'{blendMatrixNode}.outputMatrix', f'{multMatrixNode}.matrixIn[0]')
    cmds.connectAttr(f'{guideA.nodeName}.worldInverseMatrix[0]', f'{multMatrixNode}.matrixIn[1]')
    cmds.connectAttr(f'{multMatrixNode}.matrixSum', f'{linkNode}.offsetParentMatrix')
    # set weight
    cmds.setAttr(f'{blendMatrixNode}.envelope', weight)
    
    # reset base attr
    cmds.setAttr(f'{linkNode}.t', 0, 0, 0)
    cmds.setAttr(f'{linkNode}.r', 0, 0, 0)
    guideNode.addExtraNodes([blendMatrixNode, multMatrixNode])
    attrUtils.lockBaseAttr(guideNode.nodeName, ['tx', 'ty', 'tz', 'rx', 'ry', 'rz', 'sx', 'sy','sz'], vis=False)
    return guideNode.nodeName, blendMatrixNode
    
          
def createBendyGuide(baseName:str,
                     uprGuide:'GuideNode', 
                     midGuide:'GuideNode', 
                     lwrGuide:'GuideNode', 
                     guideLayer=None):
    createGuideFromParent(baseName, uprGuide, midGuide, 0.8, 0,   'uprOffset',    'BENDY', guideLayer)
    createGuideFromParent(baseName, uprGuide, midGuide, 0.8, 0.5, 'uprMidOffset', 'BENDY', guideLayer)
    createGuideFromParent(baseName, midGuide, lwrGuide, 0.8, 0,   'midOffset',    'BENDY', guideLayer)
    createGuideFromParent(baseName, midGuide, lwrGuide, 0.8, 0.5, 'midEndOffset', 'BENDY', guideLayer)
    createGuideFromParent(baseName, midGuide, lwrGuide, 0.8, 1,   'endOffset',    'BENDY', guideLayer)
    

if __name__ == '__main__':
    alignSelectedGuides(axis='x') 
    
    



    
    
  
    
    