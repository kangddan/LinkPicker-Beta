import maya.cmds as cmds
import maya.api.OpenMaya as om2
from linkRigger.utils import nameUtils
from linkRigger.utils import pathUtils

def getLocalMatrix(parent:str, child:str) -> list:
    childWorldMatrix  = om2.MMatrix(cmds.getAttr(f'{child}.worldMatrix[0]'))
    parentinverMatrix = om2.MMatrix(cmds.getAttr(f'{parent}.worldInverseMatrix[0]'))
    localMatrix = childWorldMatrix * parentinverMatrix
    return list(localMatrix)
    
    
def getOffset(node:str, target:str) -> 'list[Matrix]':     
    '''
    Very similar to getLocalMatrix, but it records the current local transformation 
    so that no additional reset of the local transformation is needed when the matrix is connected to the offsetParentMatrix
    '''
    return list(om2.MMatrix(cmds.getAttr(f'{node}.worldMatrix[0]'))
              * om2.MMatrix(cmds.getAttr(f'{node}.matrix')).inverse()
              * om2.MMatrix(cmds.getAttr(f'{target}.worldInverseMatrix[0]')))
              

def offsetParentMatrixSet(node:'BaseNode', target:'BaseNode'):
    offsetMatrix = getOffset(node.nodeName, target.nodeName)
    multNode = cmds.createNode('multMatrix', name=f'{node.shortName}_offsetMatrix')
    cmds.setAttr(f'{multNode}.matrixIn[0]', offsetMatrix, type='matrix')
    cmds.connectAttr(f'{target.nodeName}.worldMatrix[0]', f'{multNode}.matrixIn[1]', f=True)
    cmds.connectAttr(f'{multNode}.matrixSum', f'{node.nodeName}.offsetParentMatrix', f=True)
    return multNode

    
def createSpaceSwitch(baseName:str='', ctrl:str='', spaceGroup:str='', targets:dict=None) -> 'list[space nodes]':
    ctrlTag = cmds.getAttr(f'{ctrl}.controlTag')
    
    blendMatrixNodeAttrs = {'useScale':     ('useScale',     'scaleWeight'),
                            'useTranslate': ('useTranslate', 'translateWeight'),
                            'useShear':     ('useShear',     'shearWeight'),
                            'useRotate':    ('useRotate',    'rotateWeight')}
    
    nodes = []; attrNames = []
    blendMatrixNode = cmds.createNode('blendMatrix', name=nameUtils.uniqNameSuffix(f'{baseName}', f'_{ctrlTag}_space_mixMatrix'))
    nodes.append(blendMatrixNode)
    
    for index, (target, spaceInfo) in enumerate(targets.items()):
        # check parent
        if spaceInfo['isParent']:
            attrNames.append(spaceInfo['attrName'])
            cmds.setAttr(f'{blendMatrixNode}.target[{index}].targetMatrix', list(om2.MMatrix()), type='matrix')
        else:
            offset = getOffset(spaceGroup, target)
            multMatrixNode = cmds.createNode('multMatrix', name=nameUtils.uniqNameSuffix(f'{baseName}', f"_{ctrlTag}_{spaceInfo['attrName']}_space_offsetMatrix"))
            nodes.append(multMatrixNode)
            cmds.setAttr(f'{multMatrixNode}.matrixIn[0]', offset, type='matrix')
            cmds.connectAttr(f'{target}.worldMatrix[0]', f'{multMatrixNode}.matrixIn[1]', f=True)
            
            parent = cmds.listRelatives(spaceGroup, parent=True, path=True)
            if parent: cmds.connectAttr(f'{parent[0]}.worldInverseMatrix[0]', f'{multMatrixNode}.matrixIn[2]', f=True)   
              
            cmds.connectAttr(f'{multMatrixNode}.matrixSum', f'{blendMatrixNode}.target[{index}].targetMatrix', f=True)
            attrNames.append(spaceInfo['attrName'])
            for key, value in spaceInfo.items():
                if key not in blendMatrixNodeAttrs:
                    continue
                # Check the attr name of blendMatrix, as it has changed in the new version
                oldAttr, newAttr = blendMatrixNodeAttrs[key]
                finalAttr = oldAttr if cmds.attributeQuery(oldAttr, node=blendMatrixNode, ex=True) else newAttr
                cmds.setAttr(f'{blendMatrixNode}.target[{index}].{finalAttr}', value)
                     
    cmds.connectAttr(f'{blendMatrixNode}.outputMatrix', f'{spaceGroup}.offsetParentMatrix', f=True)
    
    # Add enum attr
    cmds.addAttr(ctrl, ln='space', at='enum', en=':'.join(attrNames), keyable=True)
    # Add condition node
    for index, attrName in enumerate(attrNames):
        condNode = cmds.createNode('condition', name=nameUtils.uniqNameSuffix(f'{baseName}', f'_{ctrlTag}_{attrName}_space_condition'))
        nodes.append(condNode)
        cmds.setAttr(f'{condNode}.colorIfTrueR', 1)
        cmds.setAttr(f'{condNode}.colorIfFalseR', 0)
        cmds.setAttr(f'{condNode}.secondTerm', index)
        cmds.connectAttr(f'{ctrl}.space', f'{condNode}.firstTerm', f=True)
        cmds.connectAttr(f'{condNode}.outColorR', f'{blendMatrixNode}.target[{index}].weight', f=True)
        
    return nodes
            
if __name__ == '__main__':    
    targets = {'spine_M_2_out':{'attrName':'chest', 'useScale':True, 'useTranslate':True, 'useShear':True, 'useRotate':True},
               'cog_M_0_out':{'attrName':'cog', 'useScale':True, 'useTranslate':True, 'useShear':True, 'useRotate':True},
               'god_M_offset_out':{'attrName':'global', 'useScale':True, 'useTranslate':True, 'useShear':True, 'useRotate':True},
               }


    createSpaceSwitch('arm_L_ik_ctrl', 'arm_L_ik_space', targets)
    
    
    
    
    
    
    
    