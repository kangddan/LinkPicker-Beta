from maya import cmds
from maya.api import OpenMaya as om2
import math

from linkRigger.utils import nameUtils

def bindJointByMatrix(
                      baseName:str,
                      tag:str,
                      control:str, 
                      joint:str,
                      sourceParent=False
                      ) -> 'tuple[ndoes]':
                        
    parent = cmds.listRelatives(joint, parent=True, path=True)
    
    multMGNode  = cmds.createNode('multMatrix', name=nameUtils.uniqNameSuffix(f'{baseName}_{tag}_inverMatrixOffset'))
    MGToDecNode = cmds.createNode('decomposeMatrix', name=nameUtils.uniqNameSuffix(f'{baseName}_{tag}_globalOffsetScale'))
    MGToRoDecNode = cmds.createNode('decomposeMatrix', name=nameUtils.uniqNameSuffix(f'{baseName}_{tag}_globalRotation'))
    roMultNode = cmds.createNode('multMatrix', name=nameUtils.uniqNameSuffix(f'{baseName}_{tag}_rotationMatrixOffset'))
    
    cmds.connectAttr(f'{control}.worldMatrix[0]', f'{multMGNode}.matrixIn[0]')
    if parent and sourceParent:
        cmds.connectAttr(f'{parent[0]}.worldInverseMatrix[0]', f'{multMGNode}.matrixIn[1]')
        cmds.connectAttr(f'{parent[0]}.worldInverseMatrix[0]', f'{roMultNode}.matrixIn[1]')
    else:
        cmds.connectAttr(f'{joint}.parentInverseMatrix[0]', f'{multMGNode}.matrixIn[1]')
        cmds.connectAttr(f'{joint}.parentInverseMatrix[0]', f'{roMultNode}.matrixIn[1]')
        
    cmds.connectAttr(f'{multMGNode}.matrixSum', f'{MGToDecNode}.inputMatrix', f=True)
    cmds.connectAttr(f'{MGToDecNode}.outputTranslate', f'{joint}.translate', f=True)
    cmds.connectAttr(f'{MGToDecNode}.outputScale', f'{joint}.scale', f=True)
    
    cmds.connectAttr(f'{control}.rotateOrder', f'{MGToDecNode}.inputRotateOrder', f=True)
    #cmds.connectAttr(f'{MGToDecNode}.inputRotateOrder', f'{joint}.rotateOrder', f=True)

    cmds.setAttr(f'{joint}.segmentScaleCompensate', False)
    jointOrient = cmds.getAttr(f'{joint}.jointOrient')[0]
    rotateOrder = cmds.getAttr(f'{joint}.rotateOrder')
    localMatrix = om2.MEulerRotation((math.radians(i) for i in jointOrient), rotateOrder).asMatrix().inverse()
    
    cmds.connectAttr(f'{control}.rotateOrder', f'{MGToRoDecNode}.inputRotateOrder', f=True)
    cmds.connectAttr(f'{control}.worldMatrix[0]', f'{roMultNode}.matrixIn[0]')
    cmds.setAttr(f'{roMultNode}.matrixIn[2]', localMatrix, type='matrix')
    
    cmds.connectAttr(f'{roMultNode}.matrixSum', f'{MGToRoDecNode}.inputMatrix')
    cmds.connectAttr(f'{MGToRoDecNode}.outputRotate', f'{joint}.rotate')
    
    return multMGNode, MGToDecNode, MGToRoDecNode, roMultNode

   
    
def bindJointByConstraint(driveNodes:'list[TaggedNode]', 
                          joints:'list[JointNode]', 
                          rigLayer:'RigLayer'=None
                          ) -> None:                    
    for driveNode, joint in zip(driveNodes, joints):
        extraNodes = []  
        orientConstraint = cmds.orientConstraint(driveNode.nodeName, joint.nodeName, mo=False)[0]
        cmds.setAttr(f'{orientConstraint}.interpType', 2)
        extraNodes.append(orientConstraint)
        extraNodes.append(cmds.pointConstraint(driveNode.nodeName, joint.nodeName, mo=False)[0])
        extraNodes.append(cmds.scaleConstraint(driveNode.nodeName, joint.nodeName, mo=False)[0])
    
        joint.addExtraNodestoMeta(extraNodes)
        