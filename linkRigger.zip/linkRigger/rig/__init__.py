import os

SHAPES_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'controlShapes')
COLOR_SETTING_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'colorSetting.json')

from linkRigger.rig.shapesManager import ShapesManager
from linkRigger.rig.shapesManager import ColorManager