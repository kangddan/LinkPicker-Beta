import json
import os
from maya import cmds
from pprint import pprint
from linkRigger.utils import curveUtils
from linkRigger.rig import SHAPES_PATH

from linkRigger.rig import COLOR_SETTING_PATH 

class ShapesMeta(type):
    
    def __getitem__(cls, shapeName: str) -> dict:
        return cls.loadFromJson(shapeName)

    def __setitem__(cls, shapeName: str, data: dict):
        cls.saveToJson(shapeName, data)
        
        
class ShapesManager(metaclass=ShapesMeta):
    
    CACHE_SHAPE = {}
    
    @classmethod
    def removeCacheShape(cls):
        cls.CACHE_SHAPE.clear()
    
    
    @classmethod
    def saveToJson(cls,
                   shapeName:str,
                   data:dict): 
                    
        filePath = os.path.join(SHAPES_PATH, f'{shapeName}.json')
        with open(filePath, 'w', encoding='utf-8') as f:
            json.dump(data, f, sort_keys=True, ensure_ascii=False, indent=2)
            
            
    @classmethod 
    def loadFromJson(cls,
                     shapeName:str) -> dict:
        data = cls.CACHE_SHAPE.get(shapeName, None)
        if data is not None:
            return data
        
        filePath = os.path.join(SHAPES_PATH, f'{shapeName}.json')
        if not os.path.exists(filePath):
            raise FileNotFoundError(f'The shape does not exist：{filePath}')
            
        with open(filePath, 'r') as f:
            data = json.load(f)
        
        cls.CACHE_SHAPE[shapeName] = data
        return data
        
    @classmethod
    def getSelectedShapeData(cls):
        sel = cmds.ls(sl=True, type='transform')
        if not sel:
            return
        shapeData = curveUtils.getData(sel[0])
        #pprint(shapeData)
        return shapeData
        

class ColorManager(object):

    LEFT_KEYS = {'L', 'left', 'l', 'Left', 'lt', 'LEFT'}
    RIGHT_KEYS = {'R', 'right', 'r', 'Right', 'rt', 'RIGHT'}
    MID_KEYS = {'c', 'C', 'm', 'M', 'mid', 'MID', 'Mid'}
    
    @classmethod
    def runColor(cls, nodeName:str) -> 'list|None':
        '''
        Get the corresponding color through the side
        '''
        side = nodeName.rsplit('_', 1)[-1]  
        if side in cls.LEFT_KEYS:
            return [cls.isRGB(), cls.getData()['left']]
        elif side in cls.RIGHT_KEYS:
            return [cls.isRGB(), cls.getData()['right']]
        elif side in cls.MID_KEYS:
            return [cls.isRGB(), cls.getData()['mid']]
        return None  
        
        
    @classmethod
    def updateColorSetting(cls, key:str, value:'int|list|bool'):
        data = cls.getData()
        data[key] = value
        with open(COLOR_SETTING_PATH, 'w') as f:
            json.dump(data, f, indent=4) 
            
            
    @classmethod
    def getData(cls) -> dict:
        with open(COLOR_SETTING_PATH, 'r') as f:
            data = json.load(f) 
        return data
        
    @classmethod
    def isRGB(cls) -> int:
        return cls.getData()['isRGB']
        
    @classmethod
    def override(cls) -> bool:
        return cls.getData()['override']
        
        

if __name__ == '__main__':
    #ShapesManager['GUIDE_ROOT']
    #ShapesManager['POLE'] = POLE
    #ShapesManager.removeCacheShape()
    data = ShapesManager.getSelectedShapeData()
    
    ShapesManager['AIM_UPVECTOR'] = data
    
    #ColorManager.updateColorSetting('left', [1, 2, 3])
    #ColorManager.runColor('add_R')
