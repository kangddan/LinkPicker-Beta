from maya import cmds
from maya.api import OpenMaya as om2

from linkRigger.utils import attrUtils
from linkRigger.utils import nameUtils


def isJointNode(node:str) -> bool:
    return cmds.attributeQuery('jointTag', n=node, ex=True)
    

def isRigGroup(node:str) -> bool:
    return cmds.attributeQuery('groupTarget', n=node, ex=True)


def createRigGroup():
    selJoints = cmds.ls(sl=True, type='joint')
    if not selJoints:  
        return om2.MGlobal.displayWarning('Please select a Link-Auot-Rigger Joint.')

    for node in selJoints:
        if not isJointNode(node):
            om2.MGlobal.displayWarning(f'{node} is not a Link-Auot-Rigger Joint, skipping.')
            continue
  
        targetGroup = cmds.createNode('transform', name=nameUtils.uniqueName(f'{node}_target_RigGroup'), ss=True, parent=node)
        rigGroup    = cmds.createNode('transform', name=nameUtils.uniqueName(f'{node}_RigGroup'), ss=True)
        
        attrUtils.addAttr(targetGroup, 'groupTarget', type='message')
        attrUtils.addAttr(rigGroup, 'groupTarget', type='message')
        
        cmds.connectAttr(f'{targetGroup}.message', f'{rigGroup}.groupTarget', f=True)
        cmds.connectAttr(f'{rigGroup}.message', f'{targetGroup}.groupTarget', f=True)
        
        parentConstraint = cmds.parentConstraint(targetGroup, rigGroup)[0]
        cmds.setAttr(f'{parentConstraint}.interpType', 2)
        cmds.scaleConstraint(targetGroup, rigGroup)
    
    
def deleteRigGroup():
    selNodes = cmds.ls(sl=True, type='transform')  
    if not selNodes:  
        return om2.MGlobal.displayWarning('Please select a rigGroup.')
    for node in selNodes:
        if not cmds.objExists(node):
            continue
        if not isRigGroup(node):
            om2.MGlobal.displayWarning(f'{node} is not a rig group, skipping.')
            continue
        target = cmds.listConnections(f'{node}.groupTarget')
        cmds.delete(node)
        if target and cmds.objExists(target[0]):
            cmds.delete(target[0])
        
         
if __name__ == '__main__':
    
    createRigGroup()   

    
    
    
