from maya import cmds
from maya.api import OpenMaya as om2


def mirrorMatrix(
                 matrix:list, 
                 axis:str='x'
                 ) -> 'list[float * 16]':
                    
    offX, offY, offZ = matrix[-4], matrix[-3], matrix[-2]
    matrix = om2.MMatrix(matrix)

    if axis.lower() == 'x':
        mirror = om2.MMatrix([
            1,  0,  0,  0,
            0, -1,  0,  0,
            0,  0, -1,  0,
            0,  0,  0,  1
        ])
        offX = -offX 
    elif axis.lower() == 'y':
        mirror = om2.MMatrix([
            -1,  0,  0,  0,
             0,  1,  0,  0,
             0,  0, -1,  0,
             0,  0,  0,  1
        ])
        offY = -offY 
    elif axis.lower() == 'z':
        mirror = om2.MMatrix([
            -1,  0,  0,  0,
             0, -1,  0,  0,
             0,  0,  1,  0,
             0,  0,  0,  1
        ])
        offZ = -offZ 
    
    mirroredMatrix = matrix * mirror
    mirroredMatrix[-4] = offX
    mirroredMatrix[-3] = offY
    mirroredMatrix[-2] = offZ
    return list(mirroredMatrix)
    
if __name__ == '__main__':
    l1 = cmds.getAttr('l1.worldMatrix[0]')
    l2 = cmds.getAttr('l2.worldMatrix[0]')

    l1m = mirrorMatrix(l1, 'X')
    l2m = mirrorMatrix(l2, 'X')

    cmds.xform('r1', m=l1m, ws=True)
    cmds.xform('r2', m=l2m, ws=True)