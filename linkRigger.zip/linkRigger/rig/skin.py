from maya import cmds
from maya.api import OpenMaya as om2


def getSkinClusters(joints:'str|list') -> list:
    if isinstance(joints, str):
        joints = [joints]
        
    skinClusters = set()
    for joint in joints:
        _skinClusters = cmds.listConnections(joint, type='skinCluster', d=True, s=False)
        if _skinClusters:
            skinClusters.update(_skinClusters)

    return list(skinClusters)
    

def skinMeshByJoints(joints:'str|list') -> list:
    skinClusters = getSkinClusters(joints)
    skinMeshs    = set()

    for skinCluster in skinClusters:
        skinMesh = cmds.skinCluster(skinCluster, q=True, geometry=True)
        if skinMesh:
            skinMeshs.update(skinMesh)
    
    return list(skinMeshs)
        
    
def setBindPose(skinClusters:'str|list') -> None:
    '''
    https://syntetik.blogspot.com/2010/10/bindprematrix-in-skincluster.html
    
    To reset the skin shape to its original state, 
    directly use the inverse matrix of the joints to offset the transformation. 
    It's worth noting that you should use getAttr to retrieve the index values of the matrix attribute and then match them one-to-one with the joints. 
    This is crucial because if a joint is deleted, 
    it would cause an index mismatch, so you cannot simply use enumerate to get the index values of the joint list
    
    '''
    if isinstance(skinClusters, str):
        skinClusters = [skinClusters]
    
    for skinCluster in skinClusters:
        joints = cmds.listConnections(f'{skinCluster}.matrix', type='joint', d=True) or []
        indexs = cmds.getAttr(f'{skinCluster}.matrix', mi=True) or [] # get jointMatrix index
        for joint, index in zip(joints, indexs):
            worldInverMatrix = cmds.getAttr(f'{joint}.worldInverseMatrix')
            cmds.setAttr(f'{skinCluster}.bindPreMatrix[{index}]', worldInverMatrix, type='matrix')
        cmds.dagPose(joints, cmds.listConnections(f'{skinCluster}.bindPose', type='dagPose'), reset=True)



if __name__ == '__main__':
    setBindPose('skinCluster1')
    setBindPose(getSkinClusters(cmds.ls(sl=True)))
    testJoints = ['fkChain_M_00_jnt', 'fkChain_M_01_jnt']
    skinMeshByJoints(testJoints)
    getSkinClusters(testJoints)
    setBindPose('skinCluster1')
    cmds.delete('joint3')
    
    #cmds.listConnections('joint1.worldMatrix[0]', type='skinCluster', d=True, s=False)
