import math
from maya import cmds
from maya.api import OpenMaya as om2

from linkRigger.core import nodes
from linkRigger.utils import attrUtils, mathUtils, nodeUtils


def relativeWorldRotation(upr:str,
                          mid:str, 
                          end:str, 
                          targetNode:str):

    jointsPos = VChainSystem.getIkJointsPos([upr, mid, end])
    polePos   = VChainSystem.getPolePos(jointsPos)
    # get pole Z direction
    zDirection = '-z' if jointsPos[1].z > polePos.z else 'z'
    xDirection = 'x' if jointsPos[-1].x > 0 else '-x'
    
    newMatrix = VChainSystem.getMatrix(jointsPos[-1], 
                                       jointsPos[1], 
                                       jointsPos[2], 
                                       polePos, 
                                       xDirection, 
                                       zDirection)
    cmds.xform(targetNode, m=list(newMatrix), ws=True)



class VChainSystem(object):
    
    def vectorToDirection(vector: list) -> str:
        mapping = {
            (1, 0, 0): 'x', (-1, 0, 0): '-x',
            (0, 1, 0): 'y', (0, -1, 0): '-y',
            (0, 0, 1): 'z', (0, 0, -1): '-z'
        }
        return mapping.get(tuple(vector), 'x') 
    
    @classmethod
    def getIkJointsPos(cls, jointList:list=None) -> 'list[om2.MVector]':
        return [om2.MVector(cmds.xform(joint, q=True, t=True, ws=True)) for joint in jointList]
        
    @classmethod
    def getPolePos(cls, jointPos:'list[om2.MVector]') -> om2.MVector:
        offset = ((jointPos[1] - jointPos[0]).length() + (jointPos[2] - jointPos[1]).length())
        midPos = ((jointPos[1] - jointPos[0]).normal() + ((jointPos[2] - jointPos[1]).normal() * -1)) * 0.5
        polePos = (midPos.normal() * offset) + jointPos[1]
        return polePos

    @classmethod
    def getMatrix(cls, pos:om2.MVector,
                       startPos:om2.MVector,
                       endPos:om2.MVector,
                       polePos:om2.MVector,
                       aim:str='x',
                       up:str='z') -> om2.MMatrix:
        matrix = None
        v1 = (endPos - startPos).normalize() 
        if aim.startswith('-'):
            v1 *= -1
   
        if aim in ('x', '-x'):
            if up in ('-z', 'y'):
                v2 = (v1 ^ (polePos - startPos)).normalize()
            elif up in ('z', '-y'):
                v2 = ((polePos - startPos) ^ v1).normalize()
        
            if up in ('z', '-z'):
                v3 = (v1 ^ v2)
                matrix = om2.MMatrix(((v1.x, v1.y, v1.z, 0), (v2.x, v2.y, v2.z, 0), (v3.x, v3.y, v3.z, 0), (pos.x, pos.y, pos.z, 1)))  
            elif up in ('y', '-y'):
                v3 = (v2 ^ v1)
                matrix = om2.MMatrix(((v1.x, v1.y, v1.z, 0), (v3.x, v3.y, v3.z, 0), (v2.x, v2.y, v2.z, 0), (pos.x, pos.y, pos.z, 1)))  
          
        elif aim in ('y', '-y'):
            if up in ('x', '-z'):
                v2 = ((polePos - startPos) ^ v1).normalize()
            elif up in ('-x', 'z'):
                v2 = (v1 ^ (polePos - startPos)).normalize()
                           
            if up in ('z', '-z'):
                v3 = (v2 ^ v1)
                matrix = om2.MMatrix(((v2.x, v2.y, v2.z, 0), (v1.x, v1.y, v1.z, 0), (v3.x, v3.y, v3.z, 0), (pos.x, pos.y, pos.z, 1))) 
            elif up in ('x', '-x'):
                v3 = (v1 ^ v2)
                matrix = om2.MMatrix(((v3.x, v3.y, v3.z, 0), (v1.x, v1.y, v1.z, 0), (v2.x, v2.y, v2.z, 0), (pos.x, pos.y, pos.z, 1)))  
                
        elif aim in ('z', '-z'):
            if up in ('x', '-y'):
                v2 = (v1 ^ (polePos - startPos)).normalize()
            elif up in ('-x', 'y'):
                v2 = ((polePos - startPos) ^ v1).normalize()
            
            if up in ('x', '-x'):
                v3 = (v2 ^ v1)        
                matrix = om2.MMatrix(((v3.x, v3.y, v3.z, 0), (v2.x, v2.y, v2.z, 0), (v1.x, v1.y, v1.z, 0), (pos.x, pos.y, pos.z, 1)))
            elif up in ('y', '-y'):
                v3 = (v1 ^ v2)        
                matrix = om2.MMatrix(((v2.x, v2.y, v2.z, 0), (v3.x, v3.y, v3.z, 0), (v1.x, v1.y, v1.z, 0), (pos.x, pos.y, pos.z, 1)))

        return matrix or om2.MMatrix()
        
    @classmethod
    def setAlign(cls, jointList:list=None, aim='x', up='z', skipEndJointAlign=False):
        aim, up = aim.lower(), up.lower()
        jointsPos = cls.getIkJointsPos(jointList)
        polePos = cls.getPolePos(jointsPos)

        matrixList = []
        for index, pos in enumerate(jointsPos):
            if index < 2:
                matrixList.append(cls.getMatrix(pos, jointsPos[index], jointsPos[index + 1], polePos, aim, up))
            elif index == 2 and not skipEndJointAlign:
                matrixList.append(cls.getMatrix(pos, jointsPos[index-1], jointsPos[index], polePos, aim, up))
            else:
                matrixList.append(cmds.xform(jointList[index], q=True, m=True, ws=True))
  
  
        for joint, matrix in zip(jointList, matrixList):
            cmds.xform(joint, m=matrix, ws=True)
            
            
def createBaseIk(baseName:str,
                 startJoint:str, 
                 midJoint:str,
                 endJoint:str, 
                 poleIkCtrl:str,
                 endIkCtrl:str,
                 wristBreak:bool,
                 rigLayer:'RigLayer'=None) -> list:
    '''
    Create basic IK, with the option to add wristBreak functionality
    '''              
    ikhandles = cmds.ikHandle(n=f'{baseName}_ikhandle', sj=startJoint, ee=endJoint, sol='ikRPsolver') 
    pvConstraint = cmds.poleVectorConstraint(poleIkCtrl, ikhandles[0])
    
    if wristBreak and rigLayer:
        # 0 create wrist Ctrl
        attrUtils.addAttr(endIkCtrl, 'wristBreak', type='double', dv=0, min=0, max=1, k=True)
        wristBreakControl = nodes.ControlNode.create(baseName, 'wristBreak', 'POLE', 0.7, axis='y', spaceGroup=True, rigLayer=rigLayer)
        attrUtils.lockBaseAttr(wristBreakControl.nodeName, ['tx', 'ty', 'tz', 'sx', 'sy','sz'], vis=False)
        wristBreakControl.rotateOrderBy(endIkCtrl)
        cmds.parent(wristBreakControl.topParent, endIkCtrl)
        cmds.matchTransform(wristBreakControl.topParent, endIkCtrl, pos=True, rot=True, scale=False)
        orConstraint:list = cmds.orientConstraint(wristBreakControl.nodeName, endJoint, mo=True)
        
        # 1 create joint loc
        jointOrient      = nodes.TaggedNode.create('transform', baseName, 'jointOrient', 'target', rigLayer)
        jointOrientGroup = nodes.TaggedNode.create('transform', baseName, 'jointOrientGroup', 'srt', rigLayer)
        cmds.parent(jointOrient.nodeName, jointOrientGroup.nodeName)
        cmds.parent(jointOrientGroup.nodeName, midJoint)
        cmds.matchTransform(jointOrientGroup.nodeName, endJoint, pos=True, rot=True, scale=False)
        cmds.matchTransform(jointOrient.nodeName, endIkCtrl, pos=True, rot=True, scale=False)
        
        # 2 create blend nodes
        multMatrixNode = cmds.createNode('multMatrix', n=f'{baseName}_breakRot_offsetMatrixMult')
        blendMatrixNode = cmds.createNode('blendMatrix', n=f'{baseName}_breakRot_blend')
        cmds.connectAttr(f'{jointOrient.nodeName}.worldMatrix[0]', f'{multMatrixNode}.matrixIn[0]')
        cmds.connectAttr(f'{wristBreakControl.topParent}.worldInverseMatrix[0]', f'{multMatrixNode}.matrixIn[1]')
        cmds.connectAttr(f'{multMatrixNode}.matrixSum', f'{blendMatrixNode}.target[0].targetMatrix')
        cmds.connectAttr(f'{blendMatrixNode}.outputMatrix', f'{wristBreakControl.spaceParent}.offsetParentMatrix')
        cmds.connectAttr(f'{endIkCtrl}.wristBreak', f'{blendMatrixNode}.envelope')
        
        # 3 vis ctrl
        # vis ctrlShapes
        for shape in wristBreakControl.listShapes(): 
            cmds.connectAttr(f'{endIkCtrl}.wristBreak', f'{shape}.visibility', f=True) 
        # vis group
        ikfkVisNode = rigLayer.taggedNodeFromTag('ikfkVisNode')
        if ikfkVisNode is not None:
            cmds.connectAttr(f'{ikfkVisNode}.outFloat', f'{wristBreakControl.topParent}.visibility', f=True)
            
        # 5 add ikfk proxy attr
        sourceAttrNode = rigLayer.taggedNodeFromTag('proxy')
        if sourceAttrNode is not None:
            attrUtils.addAttr(f'{wristBreakControl.nodeName}', 'ikfk', proxy=f'{sourceAttrNode}.ikfk')
 
        # 6 to meta
        orConstraint.append(multMatrixNode)
        orConstraint.append(blendMatrixNode)
        
     
    else:
        orConstraint = cmds.orientConstraint(endIkCtrl, endJoint, mo=True)
        
    cmds.setAttr(f'{orConstraint[0]}.interpType', 2)
    cmds.connectAttr(f'{endIkCtrl}.scale', f'{endJoint}.scale', f=True)  
    
    if rigLayer:
        ikhandles.extend(pvConstraint)
        ikhandles.extend(orConstraint)
        rigLayer.addExtraNodesToMeta(ikhandles)
        rigLayer.addTaggedNodetoMeta(ikhandles[0], 'ikhandle')
        
    cmds.setAttr(f'{ikhandles[0]}.visibility', False)
    cmds.parent(ikhandles[0], endIkCtrl)
    cmds.rename(ikhandles[1], f'{baseName}_effector')
    return ikhandles
    
    
def createIkFkSwitch(baseName:str,
                     fkCtrls:'list[ControlNode]', 
                     ikCtrls:'list[ControlNode]', 
                     ikJoints:'list[JointNode]', 
                     blendNodes:'list[TaggedNode]',
                     deformJoints:'list[JointNode]',
                     rigLayer:'RigLayer'=None):
                        
    sourceAttrNode = cmds.createNode('network', name=f'{baseName}_sourceProxy')
    attrUtils.addAttr(sourceAttrNode, 'ikfk', type='double', dv=0, min=0, max=1, k=True)
    '''
    The only reason for adding this attribute is that we want the node to have an input port. 
    If there is no input connection, the node will be automatically deleted when we remove the keyframes.
    '''
    attrUtils.addAttr(sourceAttrNode, 'noDelete', type='message')
    cmds.connectAttr(f'{rigLayer.nodeName}.message', f'{sourceAttrNode}.noDelete')
    
    rigLayer.addTaggedNodetoMeta(sourceAttrNode, 'proxy')
    
    floatMathNode = cmds.createNode('floatMath', name=f'{baseName}_ikVisSwitch')
    rigLayer.addTaggedNodetoMeta(floatMathNode, 'ikfkVisNode')
    cmds.setAttr(f'{floatMathNode}.floatA', 1); cmds.setAttr(f'{floatMathNode}.operation', 1)
    cmds.connectAttr(f'{sourceAttrNode}.ikfk', f'{floatMathNode}.floatB', f=True)
    
    blendMatrixNodes = []
    multMatrixNodes  = []
    
    for fkCtrl, ikCtrl, ikJoint, blendNode in zip(fkCtrls, ikCtrls, ikJoints, blendNodes):
        tag = blendNode.taggedTag
        blendMatrixNode = cmds.createNode('blendMatrix', name=f'{baseName}_{tag}IkFk_blend')
        blendMatrixNodes.append(blendMatrixNode)
        cmds.connectAttr(f'{ikJoint.nodeName}.worldMatrix[0]', f'{blendMatrixNode}.inputMatrix', f=True)
        cmds.connectAttr(f'{fkCtrl.nodeName}.worldMatrix[0]', f'{blendMatrixNode}.target[0].targetMatrix', f=True)
        cmds.connectAttr(f'{sourceAttrNode}.ikfk', f'{blendMatrixNode}.target[0].weight')
        parent = cmds.listRelatives(blendNode.nodeName, parent=True, path=True)
        if parent:
            offsetMultNode = cmds.createNode('multMatrix', name=f'{baseName}_{tag}_OffsetMatrix')
            multMatrixNodes.append(offsetMultNode)
            cmds.connectAttr(f'{blendMatrixNode}.outputMatrix', f'{offsetMultNode}.matrixIn[0]', f=True)
            cmds.connectAttr(f'{parent[0]}.worldInverseMatrix[0]', f'{offsetMultNode}.matrixIn[1]', f=True)
            cmds.connectAttr(f'{offsetMultNode}.matrixSum', f'{blendNode.nodeName}.offsetParentMatrix', f=True)
        else:
            cmds.connectAttr(f'{blendMatrixNode}.outputMatrix', f'{blendNode.nodeName}.offsetParentMatrix', f=True)
        
        # add proxy attr
        attrUtils.addAttr(f'{fkCtrl.nodeName}', 'ikfk', proxy=f'{sourceAttrNode}.ikfk')
        attrUtils.addAttr(f'{ikCtrl.nodeName}', 'ikfk', proxy=f'{sourceAttrNode}.ikfk')
        # set ikfk ctrl vis
        for ikShape in ikCtrl.listShapes(): cmds.connectAttr(f'{floatMathNode}.outFloat', f'{ikShape}.visibility', f=True)
        for fkShape in fkCtrl.listShapes(): cmds.connectAttr(f'{sourceAttrNode}.ikfk', f'{fkShape}.visibility', f=True)
        
    # pointConstraint by uprIkCtrl
    uprIkCtrl = ikCtrls[0]
    uprJoint = ikJoints[0]
    poConstraint = cmds.pointConstraint(uprIkCtrl.nodeName, uprJoint.nodeName)
    uprJoint.addExtraNodestoMeta(poConstraint)
    
    # create line
    guideLine, startVectorNode, endVectorNode = nodes.GuideNode.createGuideLine(baseName, 
                                                startNode = deformJoints[1].nodeName, 
                                                endNode = ikCtrls[1].nodeName, 
                                                guideTag='pole')
    rigLayer.addTaggedNodetoMeta(guideLine, 'poleLine')
    cmds.parent(guideLine, rigLayer.rigGroup)
    cmds.connectAttr(f'{floatMathNode}.outFloat', f'{guideLine}.visibility', f=True)
    
    # to meta
    blendMatrixNodes.extend(multMatrixNodes)
    blendMatrixNodes.extend(poConstraint)
    blendMatrixNodes.append(floatMathNode)
    blendMatrixNodes.append(startVectorNode)
    blendMatrixNodes.append(endVectorNode)
    rigLayer.addExtraNodesToMeta(blendMatrixNodes)
    
    endIkCtrl = ikCtrls[-1].nodeName
    
    nodeUtils.createVisAttr(endIkCtrl, 'ikUprCtrlVis', [uprIkCtrl.nodeName])
    # attrUtils.addAttr(endIkCtrl, 'ikUprCtrlVis', type='bool', value=False)
    # cmds.setAttr(f'{endIkCtrl}.ikUprCtrlVis', k=False, cb=True)
    # cmds.connectAttr(f'{endIkCtrl}.ikUprCtrlVis', f'{uprIkCtrl.nodeName}.visibility', f=True)                 
       
       
def getAxisValues(node:str) -> tuple:
    translateValues = cmds.getAttr(f'{node}.translate')[0]
    components = {'translateX': translateValues[0], 
                  'translateY': translateValues[1], 
                  'translateZ': translateValues[2]}
    
    dominant = max(components, key=lambda k: abs(components[k]))
    isPositive = components[dominant] > 0
    
    return dominant, isPositive
    
    
def strecth(baseName:str, 
            startJoint:str, 
            midJoint:str, 
            endJoint:str, 
            
            uprIkCtrl:str, 
            poleIkCtrl:str,
            endIkCtrl:str, 
            ikHandle:str,
            rigLayer:'RigLayer'=None):
                
    joint1Length = mathUtils.distance(startJoint, midJoint)
    joint2Length = mathUtils.distance(midJoint, endJoint)
    
    # create controlBaseAttr
    attrUtils.addAttr(endIkCtrl, 'stretch', type='double', dv=0, min=0, max=1, k=True)
    attrUtils.addAttr(endIkCtrl, 'soft', type='double', dv=0, min=0, max=1, k=True)
    attrUtils.addAttr(endIkCtrl, 'slide', type='double', dv=0, min=-1, max=1, k=True)
    attrUtils.addAttr(endIkCtrl, 'upperLength', type='double', dv=1, min=0.001, max=10, k=True)
    attrUtils.addAttr(endIkCtrl, 'lowerLength', type='double', dv=1, min=0.001, max=10, k=True)
    attrUtils.addAttr(poleIkCtrl,'pin', type='double', dv=0, min=0, max=1, k=True)  
    
    
    ikCtrlGlobalPosNode = cmds.createNode('pointMatrixMult', name=f'{baseName}_endIk_globalPos')
    baseCtrlGlobalPosNode = cmds.createNode('decomposeMatrix', name=f'{baseName}_uprIk_globalPos')
    poleGlobalPosNode = cmds.createNode('pointMatrixMult', name=f'{baseName}_poleIk_globalPos')
    cmds.connectAttr(f'{endIkCtrl}.worldMatrix[0]', f'{ikCtrlGlobalPosNode}.inMatrix', f=True) 
    cmds.connectAttr(f'{uprIkCtrl}.worldMatrix[0]', f'{baseCtrlGlobalPosNode}.inputMatrix', f=True) 
    cmds.connectAttr(f'{poleIkCtrl}.worldMatrix[0]', f'{poleGlobalPosNode}.inMatrix', f=True) 
    
    ikBaseDistanceNode = cmds.createNode('distanceBetween', name=f'{baseName}_ikUprEnd_distance')
    cmds.connectAttr(f'{ikCtrlGlobalPosNode}.output', f'{ikBaseDistanceNode}.point1', f=True)  
    cmds.connectAttr(f'{baseCtrlGlobalPosNode}.outputTranslate', f'{ikBaseDistanceNode}.point2', f=True)
    
    scaleIkBaseDistanceNode = cmds.createNode('divide', name=f'{baseName}_scaleIkUpr_distance')
    cmds.connectAttr(f'{ikBaseDistanceNode}.distance', f'{scaleIkBaseDistanceNode}.input1', f=True)  
    cmds.connectAttr(f'{baseCtrlGlobalPosNode}.outputScaleY', f'{scaleIkBaseDistanceNode}.input2', f=True)
    
    upperJointLengthMultNode = cmds.createNode('multiply', name=f'{baseName}_upperLength_mult')
    cmds.connectAttr(f'{endIkCtrl}.upperLength', f'{upperJointLengthMultNode}.input[0]', f=True) 
    cmds.setAttr(f'{upperJointLengthMultNode}.input[1]', joint1Length)
    
    lowerJointLengthMultNode = cmds.createNode('multiply', name=f'{baseName}_lowerLength_mult')
    cmds.connectAttr(f'{endIkCtrl}.lowerLength', f'{lowerJointLengthMultNode}.input[0]', f=True) 
    cmds.setAttr(f'{lowerJointLengthMultNode}.input[1]', joint2Length)
    
    jointsLengthNode = cmds.createNode('sum', name=f'{baseName}_jointsLength')
    cmds.connectAttr(f'{upperJointLengthMultNode}.output', f'{jointsLengthNode}.input[0]', f=True) 
    cmds.connectAttr(f'{lowerJointLengthMultNode}.output', f'{jointsLengthNode}.input[1]', f=True) 
    
    softInputNode = cmds.createNode('multiply', name=f'{baseName}_softInput')
    cmds.connectAttr(f'{endIkCtrl}.soft', f'{softInputNode}.input[0]', f=True) 
    cmds.connectAttr(f'{jointsLengthNode}.output', f'{softInputNode}.input[1]', f=True) 
    
    softMinValueNode = cmds.createNode('clamp', name=f'{baseName}_softMin_value')
    cmds.setAttr(f'{softMinValueNode}.minR', 0.001)
    cmds.setAttr(f'{softMinValueNode}.maxR', 99999)
    cmds.connectAttr(f'{softInputNode}.output', f'{softMinValueNode}.inputR', f=True) 
    
    slideAddNode = cmds.createNode('sum', name=f'{baseName}_slideAdd')
    cmds.setAttr(f'{slideAddNode}.input[0]', 1)
    cmds.connectAttr(f'{endIkCtrl}.slide', f'{slideAddNode}.input[1]', f=True) 
    
    slideSubNode = cmds.createNode('subtract', name=f'{baseName}_slideSub')
    cmds.setAttr(f'{slideSubNode}.input1', 1)
    cmds.connectAttr(f'{endIkCtrl}.slide', f'{slideSubNode}.input2', f=True) 
    
    upperLengthCurrentNode = cmds.createNode('multiply', name=f'{baseName}_upperLength_current')
    cmds.connectAttr(f'{upperJointLengthMultNode}.output', f'{upperLengthCurrentNode}.input[0]', f=True) 
    cmds.connectAttr(f'{slideAddNode}.output', f'{upperLengthCurrentNode}.input[1]', f=True) 
    
    lowerLengthCurrentNode = cmds.createNode('multiply', name=f'{baseName}_lowerLength_current')
    cmds.connectAttr(f'{lowerJointLengthMultNode}.output', f'{lowerLengthCurrentNode}.input[0]', f=True) 
    cmds.connectAttr(f'{slideSubNode}.output', f'{lowerLengthCurrentNode}.input[1]', f=True) 
    
    lengthCurrentNode = cmds.createNode('sum', name=f'{baseName}_lengthCurrent')
    cmds.connectAttr(f'{upperLengthCurrentNode}.output', f'{lengthCurrentNode}.input[0]', f=True) 
    cmds.connectAttr(f'{lowerLengthCurrentNode}.output', f'{lengthCurrentNode}.input[1]', f=True)
    
    trigDistNode = cmds.createNode('subtract', name=f'{baseName}_trigDist')
    cmds.connectAttr(f'{lengthCurrentNode}.output', f'{trigDistNode}.input1', f=True) 
    cmds.connectAttr(f'{softInputNode}.output', f'{trigDistNode}.input2', f=True) 
    
    softTriggerValueNode = cmds.createNode('subtract', name=f'{baseName}_softTrigger_value')
    cmds.connectAttr(f'{trigDistNode}.output', f'{softTriggerValueNode}.input1', f=True) 
    cmds.connectAttr(f'{scaleIkBaseDistanceNode}.output', f'{softTriggerValueNode}.input2', f=True) 
    
    softValueDivideNode = cmds.createNode('divide', name=f'{baseName}_softValue_divide')
    cmds.connectAttr(f'{softTriggerValueNode}.output', f'{softValueDivideNode}.input1', f=True)  
    cmds.connectAttr(f'{softMinValueNode}.outputR', f'{softValueDivideNode}.input2', f=True) 
    
    softExpNode = cmds.createNode('power', name=f'{baseName}_softExp')
    cmds.setAttr(f'{softExpNode}.input', math.e)
    cmds.connectAttr(f'{softValueDivideNode}.output', f'{softExpNode}.exponent', f=True) 
    
    softMultNode = cmds.createNode('multiply', name=f'{baseName}_softMult')
    cmds.connectAttr(f'{softMinValueNode}.outputR', f'{softMultNode}.input[0]', f=True) 
    cmds.connectAttr(f'{softExpNode}.output', f'{softMultNode}.input[1]', f=True)
    
    ##
    softSubNode = cmds.createNode('subtract', name=f'{baseName}_softSub')
    cmds.connectAttr(f'{lengthCurrentNode}.output', f'{softSubNode}.input1', f=True) 
    cmds.connectAttr(f'{softMultNode}.output', f'{softSubNode}.input2', f=True)
    
    adjustedDistanceNode = cmds.createNode('condition', name=f'{baseName}_adjusted_distance') 
    cmds.connectAttr(f'{softSubNode}.output', f'{adjustedDistanceNode}.colorIfFalseR', f=True) 
    cmds.connectAttr(f'{scaleIkBaseDistanceNode}.output', f'{adjustedDistanceNode}.colorIfTrueR', f=True) 
    cmds.connectAttr(f'{scaleIkBaseDistanceNode}.output', f'{adjustedDistanceNode}.firstTerm', f=True) 
    cmds.connectAttr(f'{trigDistNode}.output', f'{adjustedDistanceNode}.secondTerm', f=True)
    cmds.setAttr(f'{adjustedDistanceNode}.operation', 5)
    
    ikGoalBlendNode = cmds.createNode('lerp', name=f'{baseName}_ikGoal_blend')
    cmds.connectAttr(f'{endIkCtrl}.stretch', f'{ikGoalBlendNode}.weight', f=True) 
    cmds.connectAttr(f'{adjustedDistanceNode}.outColorR', f'{ikGoalBlendNode}.input1', f=True) 
    cmds.connectAttr(f'{scaleIkBaseDistanceNode}.output', f'{ikGoalBlendNode}.input2', f=True) 
    
    ikGoalBlendScaleNode = cmds.createNode('multiply', name=f'{baseName}_ik_goalBlend_scale')
    cmds.connectAttr(f'{ikGoalBlendNode}.output', f'{ikGoalBlendScaleNode}.input[0]', f=True) 
    cmds.connectAttr(f'{baseCtrlGlobalPosNode}.outputScaleY', f'{ikGoalBlendScaleNode}.input[1]', f=True) 
    
    aimVectorNode = cmds.createNode('plusMinusAverage', name=f'{baseName}_aim_vector')
    cmds.connectAttr(f'{ikCtrlGlobalPosNode}.output', f'{aimVectorNode}.input3D[0]', f=True) 
    cmds.connectAttr(f'{baseCtrlGlobalPosNode}.outputTranslate', f'{aimVectorNode}.input3D[1]', f=True) 
    cmds.setAttr(f'{aimVectorNode}.operation', 2)
    
    aimVectorNormalizeNode = cmds.createNode('normalize', name=f'{baseName}_aim_vector_normalize')
    cmds.connectAttr(f'{aimVectorNode}.output3D', f'{aimVectorNormalizeNode}.input', f=True) 
    
    ikGoalMultNode = cmds.createNode('multiplyDivide', name=f'{baseName}_ik_goal_mult')
    cmds.connectAttr(f'{aimVectorNormalizeNode}.output', f'{ikGoalMultNode}.input1', f=True) 
    cmds.connectAttr(f'{ikGoalBlendScaleNode}.output', f'{ikGoalMultNode}.input2X', f=True) 
    cmds.connectAttr(f'{ikGoalBlendScaleNode}.output', f'{ikGoalMultNode}.input2Y', f=True) 
    cmds.connectAttr(f'{ikGoalBlendScaleNode}.output', f'{ikGoalMultNode}.input2Z', f=True) 
    cmds.setAttr(f'{ikGoalMultNode}.operation', 1)
    
    ikGoalPosNode = cmds.createNode('plusMinusAverage', name=f'{baseName}_ik_goalPos')
    cmds.connectAttr(f'{baseCtrlGlobalPosNode}.outputTranslate', f'{ikGoalPosNode}.input3D[0]', f=True) 
    cmds.connectAttr(f'{ikGoalMultNode}.output', f'{ikGoalPosNode}.input3D[1]', f=True) 
    
    outputIkGoalPosNode = cmds.createNode('pairBlend', name=f'{baseName}_output_ikGoalGlobalPos')
    cmds.connectAttr(f'{poleIkCtrl}.pin', f'{outputIkGoalPosNode}.weight', f=True) 
    cmds.connectAttr(f'{ikGoalPosNode}.output3D', f'{outputIkGoalPosNode}.inTranslate1', f=True) 
    cmds.connectAttr(f'{ikCtrlGlobalPosNode}.output', f'{outputIkGoalPosNode}.inTranslate2', f=True) 
    
    '''
    set ikHandle local pos
    localPos = parentInverseMatrix * globalPos
    '''
    ikHandleLocalPosNode = cmds.createNode('pointMatrixMult', name=f'{baseName}_ikHandle_localPos')
    cmds.setAttr(f'{ikHandleLocalPosNode}.vectorMultiply', 0)
    cmds.connectAttr(f'{outputIkGoalPosNode}.outTranslate', f'{ikHandleLocalPosNode}.inPoint', f=True) 
    cmds.connectAttr(f'{ikHandle}.parentInverseMatrix[0]', f'{ikHandleLocalPosNode}.inMatrix', f=True) 
    cmds.connectAttr(f'{ikHandleLocalPosNode}.output', f'{ikHandle}.translate', f=True)
    # end soft ik
    
    
    checkStretchNode = cmds.createNode('divide', name=f'{baseName}_check_stretch')
    cmds.connectAttr(f'{scaleIkBaseDistanceNode}.output', f'{checkStretchNode}.input1', f=True) 
    cmds.connectAttr(f'{adjustedDistanceNode}.outColorR', f'{checkStretchNode}.input2', f=True) 
    
    stretchValueNode = cmds.createNode('condition', name=f'{baseName}_stretch_value') 
    cmds.connectAttr(f'{checkStretchNode}.output', f'{stretchValueNode}.colorIfTrueR', f=True) 
    cmds.setAttr(f'{stretchValueNode}.colorIfFalseR', 1)
    cmds.setAttr(f'{stretchValueNode}.operation', 2)
    cmds.connectAttr(f'{scaleIkBaseDistanceNode}.output', f'{stretchValueNode}.firstTerm', f=True) 
    cmds.connectAttr(f'{adjustedDistanceNode}.outColorR', f'{stretchValueNode}.secondTerm', f=True) 
    
    upperMultNode = cmds.createNode('multiply', name=f'{baseName}_upperMult') 
    cmds.connectAttr(f'{upperLengthCurrentNode}.output', f'{upperMultNode}.input[1]', f=True) 
    cmds.connectAttr(f'{stretchValueNode}.outColorR', f'{upperMultNode}.input[2]', f=True) 
    
    lowerMultNode = cmds.createNode('multiply', name=f'{baseName}_lowerMult') 
    cmds.connectAttr(f'{lowerLengthCurrentNode}.output', f'{lowerMultNode}.input[1]', f=True) 
    cmds.connectAttr(f'{stretchValueNode}.outColorR', f'{lowerMultNode}.input[2]', f=True) 
    
    upperJointLengthNode = cmds.createNode('lerp', name=f'{baseName}_upper_jointLength_blend') 
    cmds.connectAttr(f'{endIkCtrl}.stretch', f'{upperJointLengthNode}.weight', f=True) 
    cmds.connectAttr(f'{upperLengthCurrentNode}.output', f'{upperJointLengthNode}.input1', f=True) 
    cmds.connectAttr(f'{upperMultNode}.output', f'{upperJointLengthNode}.input2', f=True) 
    
    lowerJointLengthNode = cmds.createNode('lerp', name=f'{baseName}_lower_jointLength_blend') 
    cmds.connectAttr(f'{endIkCtrl}.stretch', f'{lowerJointLengthNode}.weight', f=True) 
    cmds.connectAttr(f'{lowerLengthCurrentNode}.output', f'{lowerJointLengthNode}.input1', f=True) 
    cmds.connectAttr(f'{lowerMultNode}.output', f'{lowerJointLengthNode}.input2', f=True) 

    poleBaseDistanceNode = cmds.createNode('distanceBetween', name=f'{baseName}_poleBase_distance') 
    cmds.connectAttr(f'{baseCtrlGlobalPosNode}.outputTranslate', f'{poleBaseDistanceNode}.point1', f=True)  
    cmds.connectAttr(f'{poleGlobalPosNode}.output', f'{poleBaseDistanceNode}.point2', f=True)
    
    poleIkCtrlDistanceNode = cmds.createNode('distanceBetween', name=f'{baseName}_poleIk_distance') 
    cmds.connectAttr(f'{ikCtrlGlobalPosNode}.output', f'{poleIkCtrlDistanceNode}.point1', f=True)  
    cmds.connectAttr(f'{poleGlobalPosNode}.output', f'{poleIkCtrlDistanceNode}.point2', f=True)
    
    poleBaseDistanceScaleNode = cmds.createNode('divide', name=f'{baseName}_pole_baseDistance_scale') 
    cmds.connectAttr(f'{poleBaseDistanceNode}.distance', f'{poleBaseDistanceScaleNode}.input1', f=True)  
    cmds.connectAttr(f'{baseCtrlGlobalPosNode}.outputScaleY', f'{poleBaseDistanceScaleNode}.input2', f=True)  
    
    poleIkCtrlDistanceScaleNode = cmds.createNode('divide', name=f'{baseName}_pole_ikDistance_scale') 
    cmds.connectAttr(f'{poleIkCtrlDistanceNode}.distance', f'{poleIkCtrlDistanceScaleNode}.input1', f=True)  
    cmds.connectAttr(f'{baseCtrlGlobalPosNode}.outputScaleY', f'{poleIkCtrlDistanceScaleNode}.input2', f=True) 

    outputUpperJointLength = cmds.createNode('lerp', name=f'{baseName}_output_upperJoint_length_blend') 
    cmds.connectAttr(f'{poleIkCtrl}.pin', f'{outputUpperJointLength}.weight', f=True) 
    cmds.connectAttr(f'{upperJointLengthNode}.output', f'{outputUpperJointLength}.input1', f=True) 
    cmds.connectAttr(f'{poleBaseDistanceScaleNode}.output', f'{outputUpperJointLength}.input2', f=True) 
    
    outputLowerJointLength = cmds.createNode('lerp', name=f'{baseName}_output_lowerJoint_length_blend') 
    cmds.connectAttr(f'{poleIkCtrl}.pin', f'{outputLowerJointLength}.weight', f=True) 
    cmds.connectAttr(f'{lowerJointLengthNode}.output', f'{outputLowerJointLength}.input1', f=True) 
    cmds.connectAttr(f'{poleIkCtrlDistanceScaleNode}.output', f'{outputLowerJointLength}.input2', f=True) 
    
    midJointAlign, midJointIsReverse = getAxisValues(midJoint)
    endJointAlign, endJointIsReverse = getAxisValues(endJoint)  
    
    if midJointIsReverse:
        cmds.connectAttr(f'{outputUpperJointLength}.output', f'{midJoint}.{midJointAlign}',  f=True)
    else:
        upperReverseOutputNode = cmds.createNode('multiply', name=f'{baseName}_upperOutput_reverse') 
        cmds.connectAttr(f'{outputUpperJointLength}.output', f'{upperReverseOutputNode}.input[0]', f=True) 
        cmds.setAttr(f'{upperReverseOutputNode}.input[1]', -1)
        cmds.connectAttr(f'{upperReverseOutputNode}.output', f'{midJoint}.{midJointAlign}',  f=True)
    
    # connect wristBreak group
    wristBreakGroup = rigLayer.taggedNodeFromTag('jointOrientGroup')
        
    if endJointIsReverse:
        cmds.connectAttr(f'{outputLowerJointLength}.output', f'{endJoint}.{endJointAlign}', f=True)
        if wristBreakGroup is not None:
            cmds.connectAttr(f'{outputLowerJointLength}.output', f'{wristBreakGroup}.{endJointAlign}', f=True)
    else:
        lowerReverseOutputNode = cmds.createNode('multiply', name=f'{baseName}_lowerOutput_reverse') 
        cmds.connectAttr(f'{outputLowerJointLength}.output', f'{lowerReverseOutputNode}.input[0]', f=True) 
        cmds.setAttr(f'{lowerReverseOutputNode}.input[1]', -1)
        cmds.connectAttr(f'{lowerReverseOutputNode}.output', f'{endJoint}.{endJointAlign}', f=True) 
        if wristBreakGroup is not None:
            cmds.connectAttr(f'{lowerReverseOutputNode}.output', f'{wristBreakGroup}.{endJointAlign}', f=True)
        
    
    extraNodes = [
    ikCtrlGlobalPosNode, baseCtrlGlobalPosNode, poleGlobalPosNode,
    ikBaseDistanceNode, scaleIkBaseDistanceNode, upperJointLengthMultNode,
    lowerJointLengthMultNode, jointsLengthNode, softInputNode, softMinValueNode,
    slideAddNode, slideSubNode, upperLengthCurrentNode, lowerLengthCurrentNode,
    lengthCurrentNode, trigDistNode, softTriggerValueNode, softValueDivideNode,
    softExpNode, softMultNode, softSubNode, adjustedDistanceNode, ikGoalBlendNode,
    ikGoalBlendScaleNode, aimVectorNode, aimVectorNormalizeNode, ikGoalMultNode,
    ikGoalPosNode, outputIkGoalPosNode, ikHandleLocalPosNode,
    checkStretchNode, stretchValueNode, upperMultNode, lowerMultNode,
    upperJointLengthNode, lowerJointLengthNode, poleBaseDistanceNode,
    poleIkCtrlDistanceNode, poleBaseDistanceScaleNode, poleIkCtrlDistanceScaleNode,
    outputUpperJointLength, outputLowerJointLength
    ]
    if not midJointIsReverse:
        extraNodes.append(upperReverseOutputNode)
    if not endJointIsReverse:
        extraNodes.append(lowerReverseOutputNode)
    
    if rigLayer:
        rigLayer.addExtraNodesToMeta(extraNodes)
        
if __name__ == '__main__':
    strecth('VChain_L', 'joint1', 'joint2', 'joint3', 
            'uprIk_ctrl', 'poleIk_ctrl', 'endIk_ctrl', 'ikHandle_space')
