from maya import cmds
from maya.api import OpenMaya as om2
from linkRigger.core import nodes


def aimVectorToXYZ(aimVector:list) -> str:
    '''
    Determine the direction based on vector values.
    '''
    for v, string in zip(aimVector, ['x', 'y', 'z']):
        if v != 0:
            return string


def createTwistNode(multMatrixNodeName:str, 
                    decomposeNodeName:str, 
                    quatToEulerNodeName:str, 
                    baseGroup:str, 
                    offsetGroup:str, 
                    targetGroup:str,
                    xyzStr:str) -> 'list[nodeName]':
    '''
    Create a basic twist system.
    '''
    multMatrixNode  = cmds.createNode('multMatrix', name=multMatrixNodeName)
    decomposeNode   = cmds.createNode('decomposeMatrix', name=decomposeNodeName)
    quatToEulerNode = cmds.createNode('quatToEuler', name=quatToEulerNodeName)
    
    cmds.connectAttr(f'{baseGroup}.worldMatrix[0]', f'{multMatrixNode}.matrixIn[0]')
    cmds.connectAttr(f'{offsetGroup}.worldInverseMatrix[0]', f'{multMatrixNode}.matrixIn[1]')
    cmds.connectAttr(f'{multMatrixNode}.matrixSum', f'{decomposeNode}.inputMatrix')
    cmds.connectAttr(f'{decomposeNode}.outputQuat{xyzStr.upper()}', f'{quatToEulerNode}.inputQuat{xyzStr.upper()}')
    cmds.connectAttr(f'{decomposeNode}.outputQuatW', f'{quatToEulerNode}.inputQuatW')
    cmds.connectAttr(f'{quatToEulerNode}.outputRotate{xyzStr.upper()}', f'{targetGroup}.rotate{xyzStr.upper()}')
    return [multMatrixNode, decomposeNode, quatToEulerNode]
        

def createBaseTwist(baseName:str, 
                    blendNodeA:'TaggedNode', 
                    blendNodeB:'TaggedNode', 
                    aimVector:list, 
                    upVector:list,
                    rigLayer:'RigLayer'=None,
                    aimGroupTag:str='',
                    uprTwistTargetTag:str='',
                    lwrTwistTargetTag:str='',
                    lwrbaseGroupTag:str=''):
    '''
    Create a complete twist setup suitable for simple twist systems.
    '''
                         
    # CREATE UPR TWIST
    xyzStr = aimVectorToXYZ(aimVector)
    # 0 create aim groups
    aimGroup = cmds.createNode('transform', name=f'{baseName}_{blendNodeA.taggedTag}_twistAim_hrc')
    cmds.parent(aimGroup, blendNodeA)
    cmds.matchTransform(aimGroup, blendNodeA)
    aimConstraint:list = cmds.aimConstraint(blendNodeB.nodeName, aimGroup, aim=aimVector, u=upVector, w=1, wut='none')
    
    # 1 create upr twist group
    twistUprBaseGroup = cmds.createNode('transform', name=f'{baseName}_{blendNodeA.taggedTag}_twistUprBase_hrc')
    twistUprOffsetGroup = cmds.createNode('transform', name=f'{baseName}_{blendNodeA.taggedTag}_twistUprOffset_hrc')
    cmds.parent(twistUprOffsetGroup, aimGroup)
    cmds.parent(twistUprBaseGroup, blendNodeB.nodeName)
    cmds.matchTransform(twistUprBaseGroup, blendNodeB, pos=True, rot=False, scale=False)
    cmds.matchTransform(twistUprBaseGroup, blendNodeA, pos=False, rot=True, scale=False)
    cmds.matchTransform(twistUprOffsetGroup, twistUprBaseGroup, pos=False, rot=True, scale=False)
    
    # 2 create upr target group
    uprTwistTargetGroup = cmds.createNode('transform', name=f'{baseName}_{blendNodeA.taggedTag}_uprTarget_hrc')
    cmds.parent(uprTwistTargetGroup, aimGroup)
    cmds.matchTransform(uprTwistTargetGroup, twistUprBaseGroup, pos=False, rot=True, scale=False)
    
    # 3 create blend Nodes
    uprBlendMatrixNode = cmds.createNode('blendMatrix', name=f'{baseName}_{blendNodeA.taggedTag}_twistUprBlendMatrix')
    uprmultMatrixNode  = cmds.createNode('multMatrix', name=f'{baseName}_{blendNodeA.taggedTag}_twistUprMultMatrix')
    cmds.connectAttr(f'{aimGroup}.worldMatrix[0]', f'{uprBlendMatrixNode}.inputMatrix')
    cmds.connectAttr(f'{blendNodeB}.worldMatrix[0]', f'{uprBlendMatrixNode}.target[0].targetMatrix')
    cmds.setAttr(f'{uprBlendMatrixNode}.target[0].rotateWeight', 0)
    cmds.setAttr(f'{uprBlendMatrixNode}.target[0].shearWeight', 0)
    cmds.setAttr(f'{uprBlendMatrixNode}.target[0].scaleWeight', 0)
    cmds.connectAttr(f'{uprBlendMatrixNode}.outputMatrix', f'{uprmultMatrixNode}.matrixIn[0]')
    cmds.connectAttr(f'{aimGroup}.worldInverseMatrix[0]', f'{uprmultMatrixNode}.matrixIn[1]')
    cmds.connectAttr(f'{uprmultMatrixNode}.matrixSum', f'{twistUprOffsetGroup}.offsetParentMatrix')
    cmds.connectAttr(f'{uprmultMatrixNode}.matrixSum', f'{uprTwistTargetGroup}.offsetParentMatrix')
    cmds.xform(twistUprOffsetGroup, m=list(om2.MMatrix()), ws=False)
    cmds.xform(uprTwistTargetGroup, m=list(om2.MMatrix()), ws=False)

    # 4 create upr twist Nodes
    uprTwistNodes = createTwistNode(multMatrixNodeName  = f'{baseName}_{blendNodeA.taggedTag}_uprTwist_offsetMultMatrix',
                                    decomposeNodeName   = f'{baseName}_{blendNodeA.taggedTag}_uprTwist_decompose',
                                    quatToEulerNodeName = f'{baseName}_{blendNodeA.taggedTag}_uprTwist_quatToEuler',
                                    baseGroup           = twistUprBaseGroup,
                                    offsetGroup         = twistUprOffsetGroup,
                                    targetGroup         = uprTwistTargetGroup,
                                    xyzStr              = xyzStr)
    
    # CREATE LWR TWIST
    # 0 create lwr twist group
    twistLwrBaseGroup = cmds.createNode('transform', name=f'{baseName}_{blendNodeA.taggedTag}_twistLwrBase_hrc')
    twistLwrOffsetGroup = cmds.createNode('transform', name=f'{baseName}_{blendNodeA.taggedTag}_twistLwrOffset_hrc')
    cmds.parent(twistLwrOffsetGroup, aimGroup)
    cmds.matchTransform(twistLwrBaseGroup, aimGroup, pos=True, rot=True, scale=False)
    cmds.matchTransform(twistLwrOffsetGroup, aimGroup, pos=True, rot=True, scale=False)
    
    # 1 create lwr target group
    lwrTwistTargetGroup = cmds.createNode('transform', name=f'{baseName}_{blendNodeA.taggedTag}_lwrTarget_hrc')
    cmds.parent(lwrTwistTargetGroup, aimGroup)
    cmds.matchTransform(lwrTwistTargetGroup, aimGroup, pos=True, rot=True, scale=False)
    
    # 2 create lwr twist Nodes
    lwrTwistNodes = createTwistNode(multMatrixNodeName  = f'{baseName}_{blendNodeA.taggedTag}_lwrTwist_offsetMultMatrix',
                                    decomposeNodeName   = f'{baseName}_{blendNodeA.taggedTag}_lwrTwist_decompose',
                                    quatToEulerNodeName = f'{baseName}_{blendNodeA.taggedTag}_lwrTwist_quatToEuler',
                                    baseGroup           = twistLwrBaseGroup,
                                    offsetGroup         = twistLwrOffsetGroup,
                                    targetGroup         = lwrTwistTargetGroup,
                                    xyzStr              = xyzStr)
    
    # to meta                                
    extraNodes = [aimGroup, twistUprBaseGroup, twistUprOffsetGroup, uprTwistTargetGroup, uprBlendMatrixNode,
                 uprmultMatrixNode, twistLwrBaseGroup, twistLwrOffsetGroup, lwrTwistTargetGroup]
    extraNodes.extend(uprTwistNodes)
    extraNodes.extend(lwrTwistNodes)
    extraNodes.extend(aimConstraint)
    if rigLayer:
        rigLayer.addExtraNodesToMeta(extraNodes)
        
        rigLayer.addTaggedNodetoMeta(aimGroup, aimGroupTag)
        rigLayer.addTaggedNodetoMeta(uprTwistTargetGroup, uprTwistTargetTag)
        rigLayer.addTaggedNodetoMeta(lwrTwistTargetGroup, lwrTwistTargetTag)
        rigLayer.addTaggedNodetoMeta(twistLwrBaseGroup, lwrbaseGroupTag)
        
        
def createBlendTwist(baseName:str, 
                     uprTarger:str, 
                     lwrTarget:str, 
                     twistControls:list, 
                     weights:list, 
                     parent:str, 
                     rigLayer=None):
    '''
    Set the position of twist controllers based on weights.
    '''
    extraNodes = []
    
    for twistCtrl, weight in zip(twistControls, weights):
        _baseName = f'{baseName}_{twistCtrl.controlTag}'
        blendMatrixNode = cmds.createNode('blendMatrix', name=f'{_baseName}_blendMatrix')
        multMatrixNode  = cmds.createNode('multMatrix', name=f'{_baseName}_multMatrix')
        
        cmds.connectAttr(f'{lwrTarget}.worldMatrix[0]', f'{blendMatrixNode}.inputMatrix')
        cmds.connectAttr(f'{uprTarger}.worldMatrix[0]', f'{blendMatrixNode}.target[0].targetMatrix')
        
        cmds.connectAttr(f'{blendMatrixNode}.outputMatrix', f'{multMatrixNode}.matrixIn[0]')
        cmds.connectAttr(f'{parent}.worldInverseMatrix[0]', f'{multMatrixNode}.matrixIn[1]')
        
        topParent = twistCtrl.topParent
        cmds.connectAttr(f'{multMatrixNode}.matrixSum', f'{topParent}.offsetParentMatrix')
        cmds.xform(topParent, m=list(om2.MMatrix()), ws=False)
        
        # set wight
        cmds.setAttr(f'{blendMatrixNode}.envelope', weight)
        
        extraNodes.extend([blendMatrixNode, multMatrixNode])
    
    if rigLayer:
        rigLayer.addExtraNodesToMeta(extraNodes)
        
    
    
    
    
    
    

    
if __name__ == '__main__':
    upr = nodes.TaggedNode.create('joint', 'joint', 'upr', 'blend', layer=None)
    mid = nodes.TaggedNode.create('joint', 'joint', 'mid', 'blend', layer=None)
    lwr = nodes.TaggedNode.create('joint', 'joint', 'lwr', 'blend', layer=None)
    createBaseTwist('test', mid, lwr, [1, 0, 0], [0, 0, -1])
    createBaseTwist('test', upr, mid, [1, 0, 0], [0, 0, -1])
    
    cmds.lockNode('vchain_L_controlPanel_settings', l=False)
    
    
    
    
    
    
