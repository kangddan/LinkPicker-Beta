from maya import cmds
from maya.api import OpenMaya as om2
from linkRigger.core import nodes
from linkRigger.utils import attrUtils, nodeUtils, mathUtils
from linkRigger.rig  import jointBinding

'''
This bendy system was inspired by the rigging I provided at AnGu Animation School (https://www.animguru.com/)
with major credit going to Angelo (https://www.instagram.com/angelo.sta.catalina/)
The only difference is that I used a large number of matrix calculation nodes to replace conventional constraints
'''


def aimVectorToXYZ(aimVector:list) -> str:
    '''
    Determine the direction based on vector values.
    '''
    for v, string in zip(aimVector, ['x', 'y', 'z']):
        if v != 0:
            return string

 
def createTwistHrcs(baseName:str, tag:str) -> dict:
    extend = {}
    extend['lwrTwistHrc'] = cmds.createNode('transform', name=f'{baseName}_{tag}_lwrTwist_hrc')
    extend['uprTwistHrc'] = cmds.createNode('transform', name=f'{baseName}_{tag}_uprTwist_hrc')
    
    # lwr twist hrcs
    extend['lwrTwistTargetHrc'] = cmds.createNode('transform', name=f'{baseName}_{tag}_lwrTwistTarget_hrc')
    extend['lwrTwistBaseHrc']   = cmds.createNode('transform', name=f'{baseName}_{tag}_lwrTwistBase_hrc')
    extend['lwrTwistOffsetHrc'] = cmds.createNode('transform', name=f'{baseName}_{tag}_lwrTwistOffset_hrc')
    
    # upr twist hrcs
    extend['uprTwistTargetHrc'] = cmds.createNode('transform', name=f'{baseName}_{tag}_uprTwistTarget_hrc')
    extend['uprTwistBaseHrc']   = cmds.createNode('transform', name=f'{baseName}_{tag}_uprTwistBase_hrc')
    extend['uprTwistOffsetHrc'] = cmds.createNode('transform', name=f'{baseName}_{tag}_uprTwistOffset_hrc')
    
    # parent
    cmds.parent(extend['lwrTwistTargetHrc'], extend['lwrTwistBaseHrc'], extend['lwrTwistOffsetHrc'], extend['lwrTwistHrc'])
    cmds.parent(extend['uprTwistTargetHrc'], extend['uprTwistBaseHrc'], extend['uprTwistOffsetHrc'], extend['uprTwistHrc'])
    
    #cmds.setAttr(f"{extend['lwrTwistTargetHrc']}.displayLocalAxis", True)
    #cmds.setAttr(f"{extend['uprTwistTargetHrc']}.displayLocalAxis", True)
    return extend

    
def createTwistNetwork(baseName:str, 
                       tag:str, 
                       tag2:str,
                       targetNode:str, 
                       baseNode:str, 
                       offsetNode:str, 
                       xyzStr:str) -> dict:
    '''
    create base twist nodes
    '''
    extend = {}
    extend['multMatrixNode']  = cmds.createNode('multMatrix', name=f'{baseName}_{tag}_{tag2}_twist_MultMatrix')
    extend['decomposeNode']   = cmds.createNode('decomposeMatrix', name=f'{baseName}_{tag}_{tag2}_twist_decompose')
    extend['quatToEulerNode'] = cmds.createNode('quatToEuler', name=f'{baseName}_{tag}_{tag2}_twist_quatToEuler')
    
    cmds.connectAttr(f'{baseNode}.worldMatrix[0]', f"{extend['multMatrixNode']}.matrixIn[0]")
    cmds.connectAttr(f'{offsetNode}.worldInverseMatrix[0]', f"{extend['multMatrixNode']}.matrixIn[1]")
    cmds.connectAttr(f"{extend['multMatrixNode']}.matrixSum", f"{extend['decomposeNode']}.inputMatrix")
    cmds.connectAttr(f"{extend['decomposeNode']}.outputQuat{xyzStr.upper()}", f"{extend['quatToEulerNode']}.inputQuat{xyzStr.upper()}")
    cmds.connectAttr(f"{extend['decomposeNode']}.outputQuatW", f"{extend['quatToEulerNode']}.inputQuatW")
    cmds.connectAttr(f"{extend['quatToEulerNode']}.outputRotate{xyzStr.upper()}", f'{targetNode}.rotate{xyzStr.upper()}')
    return extend


def createMidTwist(baseName:str,
                   tag:str,
                   aimVector:list,
                   
                   midSubAimGroup:str,
                   midPinCtrl:str,
                   endBlendNode:str,
                   midOffsetCtrl:str,
                   rigLayer:'RigLayer'=None):
    '''
    Create the twist for the mid joint. 
    The difference from createUprTwist is that it places the uprTwistBaseHrc on the wrist blendNode.
    '''
    xyzStr = aimVectorToXYZ(aimVector)  
    # create twist groups              
    extend = createTwistHrcs(baseName, tag)
    
    # create twist nodes
    uprTwistExtend = createTwistNetwork(baseName, tag, 'upr',
                     extend['uprTwistTargetHrc'], extend['uprTwistBaseHrc'], extend['uprTwistOffsetHrc'], xyzStr)
    lwrTwistExtend = createTwistNetwork(baseName, tag, 'lwr',
                     extend['lwrTwistTargetHrc'], extend['lwrTwistBaseHrc'], extend['lwrTwistOffsetHrc'], xyzStr)
    # set parent
    cmds.parent(extend['lwrTwistHrc'], extend['uprTwistHrc'], midSubAimGroup)
    nodeUtils.resetPSR([extend['lwrTwistHrc'], extend['uprTwistHrc']])
    cmds.parent(extend['lwrTwistBaseHrc'], midOffsetCtrl)
    
    # create uprTwist offset group
    extend['uprTwistRotZeroHrc'] = cmds.createNode('transform', name=f'{baseName}_{tag}_uprTwistRotZero_hrc')
    cmds.parent(extend['uprTwistBaseHrc'], extend['uprTwistRotZeroHrc'])
    cmds.parent(extend['uprTwistRotZeroHrc'], endBlendNode)
    nodeUtils.resetPSR(extend['uprTwistBaseHrc'])
    cmds.matchTransform(extend['uprTwistRotZeroHrc'], midSubAimGroup, pos=False, rot=True, scale=False)
    cmds.matchTransform(extend['uprTwistRotZeroHrc'], endBlendNode, pos=True, rot=False, scale=False)
    
    #c connect rotate
    cmds.connectAttr(f'{midPinCtrl}.rotate', f"{extend['uprTwistBaseHrc']}.rotate")
    
    # create pin network
    pinExtend = pin(midPinCtrl, extend['uprTwistHrc'], baseName, tag)
    
    # to meta
    if rigLayer:
        rigLayer.addTaggedNodetoMeta(extend['lwrTwistTargetHrc'], taggedTag='midLwrTwistTarget')
        rigLayer.addTaggedNodetoMeta(extend['uprTwistTargetHrc'], taggedTag='midUprTwistTarget')
        newExtend = []
        newExtend.extend([node for node in extend.values()])
        newExtend.extend([node for node in uprTwistExtend.values()])
        newExtend.extend([node for node in lwrTwistExtend.values()])
        newExtend.extend([node for node in pinExtend.values()])
        rigLayer.addExtraNodesToMeta(newExtend)

    
def createUprTwist(baseName:str,
                   tag:str,
                   aimVector:list,
                   
                   uprOffsetCtrl:str,
                   uprBlendNode:str,
                   uprSubAimGroup:str,
                   midOffsetCtrl:str,
                   rigLayer:'RigLayer'=None):
    '''
    Create the twist for the upr joint. 
    The difference from createMidTwist is that it places the lwrTwistBaseHrc under the parentSpaceGroup hierarchy.
    '''
    xyzStr = aimVectorToXYZ(aimVector)  
    # create twist groups              
    extend = createTwistHrcs(baseName, tag)
    
    # create twist nodes
    uprTwistExtend = createTwistNetwork(baseName, tag, 'upr',
                     extend['uprTwistTargetHrc'], extend['uprTwistBaseHrc'], extend['uprTwistOffsetHrc'], xyzStr)
    lwrTwistExtend = createTwistNetwork(baseName, tag, 'lwr',
                     extend['lwrTwistTargetHrc'], extend['lwrTwistBaseHrc'], extend['lwrTwistOffsetHrc'], xyzStr)
    
    # set parent
    cmds.parent(extend['lwrTwistHrc'], extend['uprTwistHrc'], uprSubAimGroup)
    nodeUtils.resetPSR([extend['lwrTwistHrc'], extend['uprTwistHrc']])
    cmds.parent(extend['uprTwistBaseHrc'], midOffsetCtrl)
    cmds.matchTransform(extend['uprTwistBaseHrc'], midOffsetCtrl, pos=True, rot=False, scale=False)
    
    # create lwrTwist offset group
    extend['lwrTwistRotZeroHrc'] = cmds.createNode('transform', name=f'{baseName}_{tag}_lwrTwistRotZero_hrc')
    cmds.parent(extend['lwrTwistBaseHrc'], extend['lwrTwistRotZeroHrc'])
    
    parentSpaceGroup:str = rigLayer.taggedNodeFromTag('parentSpace')
    cmds.parent(extend['lwrTwistRotZeroHrc'], parentSpaceGroup)
    
    nodeUtils.resetPSR(extend['lwrTwistBaseHrc'])
    cmds.matchTransform(extend['lwrTwistRotZeroHrc'], uprSubAimGroup, pos=False, rot=True, scale=False)
    cmds.matchTransform(extend['lwrTwistRotZeroHrc'], uprBlendNode, pos=True, rot=False, scale=False)
    
    #c connect rotate
    cmds.connectAttr(f'{uprOffsetCtrl}.rotate', f"{extend['lwrTwistBaseHrc']}.rotate")
    
    # create pin network
    pinExtend = pin(midOffsetCtrl, extend['uprTwistHrc'], baseName, tag)
    
    # to meta
    if rigLayer:
        rigLayer.addTaggedNodetoMeta(extend['lwrTwistTargetHrc'], taggedTag='uprLwrTwistTarget')
        rigLayer.addTaggedNodetoMeta(extend['uprTwistTargetHrc'], taggedTag='uprUprTwistTarget')
        newExtend = []
        newExtend.extend([node for node in extend.values()])
        newExtend.extend([node for node in uprTwistExtend.values()])
        newExtend.extend([node for node in lwrTwistExtend.values()])
        newExtend.extend([node for node in pinExtend.values()])
        rigLayer.addExtraNodesToMeta(newExtend)
    
    
def createCurve(startVector:list, endVector:list, name:str) -> tuple:
    '''
    Create a cubic curve of degree 3.
    '''
    points = []
    for i in range(4):
        t = i / (4 - 1)  
        pt = [(1 - t) * startVector[0] + t * endVector[0],
              (1 - t) * startVector[1] + t * endVector[1],
              (1 - t) * startVector[2] + t * endVector[2]]
        points.append(pt)

    curve = cmds.curve(d=3, p=points, k=[0, 0, 0, 1, 1, 1], name=name)
    cmds.setAttr(f'{curve}.visibility', False)
    cmds.setAttr(f'{curve}.overrideEnabled', True)
    cmds.setAttr(f'{curve}.overrideDisplayType', True)
    attrUtils.lockBaseAttr(curve, ['tx', 'ty', 'tz', 'rx', 'ry', 'rz', 'sx', 'sy','sz'], vis=False)
    shape = cmds.rename(cmds.listRelatives(curve, shapes=True)[0], f'{name}Shape')
    
    return curve, shape


def createTwistCurve(baseName:str, 
                     tag:str, 
                     startNode:str, 
                     endNode:str,
                     aimVector:list,
                     
                     startCtrl:str,
                     midCtrl:str,
                     endCtrl:str,
                     rigLayer:'RigLayer'=None):
    extend = {}
    extend['curve'], extend['curveShape'] = createCurve(cmds.xform(startNode, q=True, t=True, ws=True), 
                                                        cmds.xform(endNode, q=True, t=True, ws=True),
                                                        name=f'{baseName}_{tag}_bendyCurve')
    # create points
    extend['startPointHrc'] = cmds.createNode('transform', name=f'{baseName}_{tag}_startPoint_hrc')
    extend['midPointHrc']   = cmds.createNode('transform', name=f'{baseName}_{tag}_midPoint_hrc')
    extend['endPointHrc']   = cmds.createNode('transform', name=f'{baseName}_{tag}_endPoint_hrc')
    # set parent
    cmds.parent(extend['startPointHrc'], startCtrl)
    cmds.parent(extend['midPointHrc'], midCtrl)
    cmds.parent(extend['endPointHrc'], endCtrl)
    nodeUtils.resetPSR([extend['startPointHrc'], extend['midPointHrc'], extend['endPointHrc']])
    
    # create network
    extend['startGlobalPos'] = cmds.createNode('pointMatrixMult', name=f'{baseName}_{tag}_startBendyCurve_globalPoint')
    extend['mid1GlobalPos']  = cmds.createNode('pointMatrixMult', name=f'{baseName}_{tag}_mid1BendyCurve_globalPoint')
    extend['mid2GlobalPos']  = cmds.createNode('pointMatrixMult', name=f'{baseName}_{tag}_mid2BendyCurve_globalPoint')
    extend['endGlobalPos']   = cmds.createNode('pointMatrixMult', name=f'{baseName}_{tag}_endBendyCurve_globalPoint')
    
    cmds.connectAttr(f"{extend['startPointHrc']}.worldMatrix[0]", f"{extend['startGlobalPos']}.inMatrix")
    cmds.connectAttr(f"{extend['midPointHrc']}.worldMatrix[0]", f"{extend['mid1GlobalPos']}.inMatrix")
    cmds.connectAttr(f"{extend['midPointHrc']}.worldMatrix[0]", f"{extend['mid2GlobalPos']}.inMatrix")
    cmds.connectAttr(f"{extend['endPointHrc']}.worldMatrix[0]", f"{extend['endGlobalPos']}.inMatrix")

    cmds.setAttr(f"{extend['mid1GlobalPos']}.inPoint", *mathUtils.globalToLocal(extend['midPointHrc'], f"{extend['curve']}.cv[1]"))
    cmds.setAttr(f"{extend['mid2GlobalPos']}.inPoint", *mathUtils.globalToLocal(extend['midPointHrc'], f"{extend['curve']}.cv[2]"))
    
    cmds.connectAttr(f"{extend['startGlobalPos']}.output", f"{extend['curveShape']}.controlPoints[0]")
    cmds.connectAttr(f"{extend['mid1GlobalPos']}.output", f"{extend['curveShape']}.controlPoints[1]")
    cmds.connectAttr(f"{extend['mid2GlobalPos']}.output", f"{extend['curveShape']}.controlPoints[2]")
    cmds.connectAttr(f"{extend['endGlobalPos']}.output", f"{extend['curveShape']}.controlPoints[3]")
    
    # create scale network
    extend['distanceNode']    = cmds.createNode('distanceBetween', name=f'{baseName}_{tag}_bendy_start_end_distance')
    extend['globalScaleNode'] = cmds.createNode('decomposeMatrix', name=f'{baseName}_{tag}_bendy_globalScale')
    extend['baseScaleNode']   = cmds.createNode('divide', name=f'{baseName}_{tag}_bendy_baseScale')
    extend['offsetScaleNode'] = cmds.createNode('divide', name=f'{baseName}_{tag}_bendy_offsetScale')
    
    cmds.connectAttr(f"{extend['startPointHrc']}.worldMatrix[0]", f"{extend['distanceNode']}.inMatrix1")
    cmds.connectAttr(f"{extend['endPointHrc']}.worldMatrix[0]", f"{extend['distanceNode']}.inMatrix2")
    cmds.connectAttr(f"{startNode}.worldMatrix[0]", f"{extend['globalScaleNode']}.inputMatrix")
    cmds.connectAttr(f"{extend['distanceNode']}.distance", f"{extend['baseScaleNode']}.input1")
    cmds.setAttr(f"{extend['baseScaleNode']}.input2", mathUtils.distance(extend['startPointHrc'], extend['endPointHrc']))
    
    cmds.connectAttr(f"{extend['baseScaleNode']}.output", f"{extend['offsetScaleNode']}.input1")
    cmds.connectAttr(f"{extend['globalScaleNode']}.outputScaleY", f"{extend['offsetScaleNode']}.input2")
    xyzStr = aimVectorToXYZ(aimVector)  
    cmds.connectAttr(f"{extend['offsetScaleNode']}.output", f"{extend['midPointHrc']}.scale{xyzStr.upper()}")
    
    
    # to meta
    if rigLayer:
        cmds.parent(extend['curve'], rigLayer.rigGroup)
        rigLayer.addTaggedNodetoMeta(extend['curve'], taggedTag=f'{tag}BendyCurve')
        rigLayer.addExtraNodesToMeta([node for node in extend.values()])
    

def placeNodeBetween(pointA:str, 
                     pointB:str, 
                     sourceNode:str, 
                     baseName:str, 
                     pointATag:str, 
                     pointBTag:str, 
                     sourceNodeTag:str) -> dict:
    '''
    Position the sourceNode between pointA and pointB.
    '''
    extend = {}
    pointAVector = mathUtils.globalToLocal(pointA, sourceNode)
    pointBVector = mathUtils.globalToLocal(pointB, sourceNode)

    extend['pointMatrixMultA'] = cmds.createNode('pointMatrixMult', name=f'{baseName}_{pointATag}_matrixMultPoint')
    extend['pointMatrixMultB'] = cmds.createNode('pointMatrixMult', name=f'{baseName}_{pointBTag}_matrixMultPoint')
    extend['blendNode']        = cmds.createNode('pairBlend', name=f'{baseName}_{pointATag}_{pointBTag}_mixVector')
    extend['offsetVector']     = cmds.createNode('pointMatrixMult', name=f'{baseName}_{sourceNodeTag}_globalToLocal')
    
    cmds.connectAttr(f'{pointA}.worldMatrix[0]', f"{extend['pointMatrixMultA']}.inMatrix")
    cmds.setAttr(f"{extend['pointMatrixMultA']}.inPoint", *pointAVector)
    cmds.connectAttr(f'{pointB}.worldMatrix[0]', f"{extend['pointMatrixMultB']}.inMatrix")
    cmds.setAttr(f"{extend['pointMatrixMultB']}.inPoint", *pointBVector)
    
    cmds.connectAttr(f"{extend['pointMatrixMultA']}.output", f"{extend['blendNode']}.inTranslate1")
    cmds.connectAttr(f"{extend['pointMatrixMultB']}.output", f"{extend['blendNode']}.inTranslate2")
    cmds.setAttr(f"{extend['blendNode']}.weight", 0.5)
    
    cmds.connectAttr(f'{sourceNode}.parentInverseMatrix[0]', f"{extend['offsetVector']}.inMatrix")
    cmds.connectAttr(f"{extend['blendNode']}.outTranslate", f"{extend['offsetVector']}.inPoint")
    cmds.connectAttr(f"{extend['offsetVector']}.output", f'{sourceNode}.translate')
    return extend
    

def pin(target:str, sourceNode:str, baseName:str, tag:str) -> dict:
    '''
    Fix the position of the sourceNode to the target
    '''
    extend = {}
    extend['targetGlobalPos'] = cmds.createNode('pointMatrixMult', name=f'{baseName}_{tag}_globalPos')
    extend['pointMatrixMult'] = cmds.createNode('pointMatrixMult', name=f'{baseName}_{tag}_offsetMatrix')
    cmds.connectAttr(f'{target}.worldMatrix[0]', f"{extend['targetGlobalPos']}.inMatrix")
    cmds.connectAttr(f"{extend['targetGlobalPos']}.output", f"{extend['pointMatrixMult']}.inPoint")
    cmds.connectAttr(f'{sourceNode}.parentInverseMatrix[0]', f"{extend['pointMatrixMult']}.inMatrix")
    cmds.connectAttr(f"{extend['pointMatrixMult']}.output", f"{sourceNode}.translate")
    return extend
    
    
def createRootAim(targetNode:str, 
                  parentNode:str, 
                  rotationUpNode:str, 
                  sourceNode:str, 
                  aimVector:list, 
                  upVector:list,
                  baseName:str,
                  parentNodeTag:str,
                  rotationUpNodeTag:str,
                  sourceNodeTag:str) -> dict:
    '''
    The difference from BaseAim is that the input Matrix of aimMatrixNode is dynamically variable.
    '''
    extend = {}
    extend['aimMatrixNode'] = cmds.createNode('aimMatrix', name=f'{baseName}_{sourceNodeTag}_aimMatrix')
    cmds.setAttr(f"{extend['aimMatrixNode']}.primaryInputAxis", *aimVector)
    cmds.setAttr(f"{extend['aimMatrixNode']}.secondaryInputAxis", *upVector)
    cmds.setAttr(f"{extend['aimMatrixNode']}.secondaryMode", 0) # or 2
    
    extend['rotVectorNode'] = cmds.createNode('pointMatrixMult', name=f'{baseName}_{rotationUpNodeTag}_rotVector')
    cmds.setAttr(f"{extend['rotVectorNode']}.vectorMultiply", True)
    cmds.setAttr(f"{extend['rotVectorNode']}.inPoint", *upVector)
    
    extend['transMatrixNode'] = cmds.createNode('pickMatrix', name=f'{baseName}_{parentNodeTag}_transMatrix')
    cmds.setAttr(f"{extend['transMatrixNode']}.useRotate", False)
    cmds.setAttr(f"{extend['transMatrixNode']}.useScale", False)
    cmds.setAttr(f"{extend['transMatrixNode']}.useShear", False)
    extend['rotMatrixNode'] = cmds.createNode('pickMatrix', name=f'{baseName}_{parentNodeTag}_parentRotScaleMatrix')
    cmds.setAttr(f"{extend['rotMatrixNode']}.useTranslate", False)
    extend['composeNewMatrixNode'] = cmds.createNode('multMatrix', name=f'{baseName}_{parentNodeTag}_composeNewMatrix')
    
    extend['offsetMatrixNode'] = cmds.createNode('multMatrix', name=f'{baseName}_{sourceNodeTag}_offsetMatrix')

    cmds.connectAttr(f'{targetNode}.worldMatrix[0]', f"{extend['aimMatrixNode']}.primaryTargetMatrix")
    cmds.connectAttr(f'{rotationUpNode}.worldMatrix[0]', f"{extend['rotVectorNode']}.inMatrix")
    cmds.connectAttr(f"{extend['rotVectorNode']}.output", f"{extend['aimMatrixNode']}.secondaryTargetVector")
    
    cmds.connectAttr(f'{parentNode}.worldMatrix[0]', f"{extend['transMatrixNode']}.inputMatrix")
    cmds.connectAttr(f'{parentNode}.parentMatrix[0]', f"{extend['rotMatrixNode']}.inputMatrix")
    cmds.connectAttr(f"{extend['rotMatrixNode']}.outputMatrix", f"{extend['composeNewMatrixNode']}.matrixIn[0]")
    cmds.connectAttr(f"{extend['transMatrixNode']}.outputMatrix", f"{extend['composeNewMatrixNode']}.matrixIn[1]")
    cmds.connectAttr(f"{extend['composeNewMatrixNode']}.matrixSum", f"{extend['aimMatrixNode']}.inputMatrix")
    
    cmds.connectAttr(f"{extend['aimMatrixNode']}.outputMatrix", f"{extend['offsetMatrixNode']}.matrixIn[0]")
    cmds.connectAttr(f'{rotationUpNode}.worldInverseMatrix[0]', f"{extend['offsetMatrixNode']}.matrixIn[1]")
    
    cmds.connectAttr(f"{extend['offsetMatrixNode']}.matrixSum", f'{sourceNode}.offsetParentMatrix')
    return extend
    

def createBaseAim(targetNode:str, 
                  parentNode:str, 
                  sourceNode:str, 
                  aimVector:list, 
                  upVector:list,
                  baseName:str,
                  parentNodeTag:str,
                  sourceNodeTag:str) -> dict:
    extend = {}
    extend['aimMatrixNode'] = cmds.createNode('aimMatrix', name=f'{baseName}_{sourceNodeTag}_aimMatrix')
    cmds.setAttr(f"{extend['aimMatrixNode']}.primaryInputAxis", *aimVector)
    cmds.setAttr(f"{extend['aimMatrixNode']}.secondaryInputAxis", *upVector)
    cmds.setAttr(f"{extend['aimMatrixNode']}.secondaryMode", 0) # or 2
    
    extend['rotVectorNode'] = cmds.createNode('pointMatrixMult', name=f'{baseName}_{parentNodeTag}_rotVector')
    cmds.setAttr(f"{extend['rotVectorNode']}.vectorMultiply", True)
    cmds.setAttr(f"{extend['rotVectorNode']}.inPoint", *upVector)
    
    extend['offsetMatrixNode'] = cmds.createNode('multMatrix', name=f'{baseName}_{sourceNodeTag}_offsetMatrix')
    
    cmds.connectAttr(f'{parentNode}.worldMatrix[0]', f"{extend['aimMatrixNode']}.inputMatrix")
    cmds.connectAttr(f'{targetNode}.worldMatrix[0]', f"{extend['aimMatrixNode']}.primaryTargetMatrix")
    cmds.connectAttr(f'{parentNode}.worldMatrix[0]', f"{extend['rotVectorNode']}.inMatrix")
    cmds.connectAttr(f"{extend['rotVectorNode']}.output", f"{extend['aimMatrixNode']}.secondaryTargetVector")
    
    cmds.connectAttr(f"{extend['aimMatrixNode']}.outputMatrix", f"{extend['offsetMatrixNode']}.matrixIn[0]")
    cmds.connectAttr(f'{parentNode}.worldInverseMatrix[0]', f"{extend['offsetMatrixNode']}.matrixIn[1]")
    
    cmds.connectAttr(f"{extend['offsetMatrixNode']}.matrixSum", f'{sourceNode}.offsetParentMatrix')
    return extend
    

class Bendy(object):
    
    BENDY_TAG = ['uprOffset', 'uprMidOffset', 'midOffset', 'midEndOffset', 'endOffset']
    
    def __init__(self, arm:'Arm'=None):
        self.arm = arm
        
        self.baseName    = arm.baseName
        self.rigLayer    = arm.rigLayer
        self.deformLayer = arm.deformLayer
        
        self.guideLayer  = arm.guideLayer
        self.aimVector   = arm.aimVector
        self.upVector    = arm.upVector
        
        self.uprTwistWeight = arm.uprTwistWeight
        self.lwrTwistWeight = arm.lwrTwistWeight
        
        self.uprBlend = self.rigLayer.taggedNodeFromTag('upr', asObject=True)
        self.midBlend = self.rigLayer.taggedNodeFromTag('mid', asObject=True)
        self.endBlend = self.rigLayer.taggedNodeFromTag('end', asObject=True)
        
        self.bendyGuideNodes = [self.guideLayer.guideNodeFromTag(tag) for tag in Bendy.BENDY_TAG]
        
        self.extend = {}
        

    def createBendyControls(self):
        '''
        Create bendy controls.
        '''
        for guide in self.bendyGuideNodes:
            tag  = guide.guideTag
            ctrl = nodes.ControlNode.create(self.baseName, 
                                            guide.guideTag, 
                                            'BENDY_CTRL', 1, 
                                            axis='y', 
                                            spaceGroup=True, 
                                            rigLayer=self.rigLayer)
            ctrl.rotateOrderBy(guide)
            '''
            add property:
                
            self.uprOffsetCtrl 
            self.uprMidOffsetCtrl 
            self.midOffsetCtrl 
            self.midEndOffsetCtrl 
            self.endOffsetCtrl
            '''
            setattr(self, f'{tag}Ctrl', ctrl)
        
        
    def createRigGroups(self):
        '''
        Create bendyAim groups
        '''
        self.extend['uprRootAimGroup']     = cmds.createNode('transform', name=f'{self.baseName}_uprRootAim_hrc', ss=True)
        self.extend['uprSubAimGroup']      = cmds.createNode('transform', name=f'{self.baseName}_uprSubAim_hrc', ss=True)
        self.extend['uprOffsetPointGroup'] = cmds.createNode('transform', name=f'{self.baseName}_uprOffset_point_hrc', ss=True)
        
        self.extend['midRootAimGroup']     = cmds.createNode('transform', name=f'{self.baseName}_midRootAim_hrc', ss=True)
        self.extend['midSubAimGroup']      = cmds.createNode('transform', name=f'{self.baseName}_midSubAim_hrc', ss=True)
        self.extend['midOffsetPointGroup'] = cmds.createNode('transform', name=f'{self.baseName}_midOffset_point_hrc', ss=True)
        
        # set baseParent
        cmds.parent(self.uprMidOffsetCtrl.topParent, self.extend['uprSubAimGroup'])
        cmds.parent(self.midEndOffsetCtrl.topParent, self.extend['midSubAimGroup'])
        cmds.parent(self.uprOffsetCtrl.topParent, self.extend['uprSubAimGroup'], self.extend['uprOffsetPointGroup'], self.extend['uprRootAimGroup'])
        cmds.parent(self.endOffsetCtrl.topParent, self.extend['midSubAimGroup'], self.extend['midOffsetPointGroup'], self.extend['midRootAimGroup'])
        
        # parent to blendNode
        cmds.parent(self.extend['uprRootAimGroup'], self.uprBlend.nodeName)
        cmds.parent(self.midOffsetCtrl.topParent, self.extend['midRootAimGroup'], self.midBlend.nodeName)
        
        # reset 
        nodeUtils.resetPSR([self.extend['uprRootAimGroup'], 
                            self.extend['midRootAimGroup'], 
                            self.midOffsetCtrl.topParent])

        
        # set pos
        cmds.matchTransform(self.extend['uprOffsetPointGroup'], self.midBlend, pos=True, rot=False, scale=False)
        cmds.matchTransform(self.extend['midOffsetPointGroup'], self.midBlend, pos=True, rot=False, scale=False)
        
        mathUtils.placeNodeInBetween(self.extend['uprRootAimGroup'], self.extend['uprOffsetPointGroup'], self.uprMidOffsetCtrl.topParent)                         
        mathUtils.placeNodeInBetween(self.endBlend.nodeName, self.extend['midOffsetPointGroup'], self.midEndOffsetCtrl.topParent)
        
         
    def createBendyNetwork(self):
        # pin upr
        pinNodes1:dict = pin(self.midOffsetCtrl.nodeName, self.extend['uprOffsetPointGroup'], self.baseName, 'uprPin')
        # pin mid
        pinNodes2:dict = pin(self.endBlend.nodeName, self.endOffsetCtrl.topParent, self.baseName, 'endPin')
        
        # upr blend mid bendy
        bldNodes1:dict = placeNodeBetween(pointA        = self.uprOffsetCtrl.nodeName,
                                          pointB        = self.extend['uprOffsetPointGroup'], 
                                          sourceNode    = self.uprMidOffsetCtrl.topParent,
                                          baseName      = self.baseName,
                                          pointATag     = 'uprOffset1',
                                          pointBTag     = 'uprOffset2' ,
                                          sourceNodeTag = 'uprMidOffset')
        # mid blend mid bendy
        bldNodes2:dict = placeNodeBetween(pointA        = self.extend['midOffsetPointGroup'],
                                          pointB        = self.endOffsetCtrl.nodeName, 
                                          sourceNode    = self.midEndOffsetCtrl.topParent,
                                          baseName      = self.baseName,
                                          pointATag     = 'midOffset1',
                                          pointBTag     = 'midOffset2' ,
                                          sourceNodeTag = 'midEndOffset')
        # connect mid offset
        cmds.connectAttr(f'{self.midOffsetCtrl.nodeName}.rotate', f"{self.extend['uprOffsetPointGroup']}.rotate")
        cmds.connectAttr(f'{self.midOffsetCtrl.nodeName}.scale', f"{self.extend['uprOffsetPointGroup']}.scale")
        
        cmds.connectAttr(f'{self.midOffsetCtrl.nodeName}.rotate', f"{self.extend['midOffsetPointGroup']}.rotate")
        cmds.connectAttr(f'{self.midOffsetCtrl.nodeName}.scale', f"{self.extend['midOffsetPointGroup']}.scale")
        
        # create upr aimNodes
        # root aim
        uprRootAimNodes:dict = createBaseAim(targetNode = self.midOffsetCtrl.nodeName,
                                             parentNode = self.uprBlend.nodeName,
                                             sourceNode = self.extend['uprRootAimGroup'],
                                             aimVector  = self.aimVector,
                                             upVector   = self.upVector,
                                             baseName   = self.baseName,
                                             parentNodeTag = 'upr',
                                             sourceNodeTag = 'uprRootAim')
        # base aim
        uprBaseAimNodes:dict = createRootAim(targetNode     = self.midOffsetCtrl.nodeName,
                                             parentNode     = self.uprOffsetCtrl.nodeName,
                                             rotationUpNode = self.extend['uprRootAimGroup'], 
                                             sourceNode     = self.extend['uprSubAimGroup'],
                                             aimVector      = self.aimVector,
                                             upVector       = self.upVector,
                                             baseName       = self.baseName,
                                             parentNodeTag  = 'uprOffset',
                                             rotationUpNodeTag = 'uprRootAimGroup',
                                             sourceNodeTag     = 'uprSubAim')
        
        # create mid aimNodes
        # root aim
        midRootAimNodes:dict = createRootAim(targetNode     = self.endBlend.nodeName,
                                             parentNode     = self.midOffsetCtrl.nodeName,
                                             rotationUpNode = self.midBlend.nodeName, 
                                             sourceNode     = self.extend['midRootAimGroup'],
                                             aimVector      = self.aimVector,
                                             upVector       = self.upVector,
                                             baseName       = self.baseName,
                                             parentNodeTag  = 'midOffset',
                                             rotationUpNodeTag = 'midBlend',
                                             sourceNodeTag     = 'midRootAim')
                                        
        # base aim
        midBaseAimNodes:dict = createBaseAim(targetNode = self.endOffsetCtrl.nodeName,
                                             parentNode = self.extend['midRootAimGroup'],
                                             sourceNode = self.extend['midSubAimGroup'],
                                             aimVector  = self.aimVector,
                                             upVector   = self.upVector,
                                             baseName   = self.baseName,
                                             parentNodeTag = 'midRootAimGroup',
                                             sourceNodeTag = 'midSubAim')
                                             
        # create twist tagets
        # create mid twist
        createMidTwist(baseName  = self.baseName,
                       tag       = 'mid',
                       aimVector = self.aimVector,
                       
                       midSubAimGroup = self.extend['midSubAimGroup'],
                       midPinCtrl     = self.endOffsetCtrl.nodeName,
                       endBlendNode   = self.endBlend.nodeName,
                       midOffsetCtrl  =  self.midOffsetCtrl.nodeName,
                       rigLayer       = self.rigLayer)
                       
        # create upr twist
        createUprTwist(baseName  = self.baseName,
                       tag       = 'upr',
                       aimVector = self.aimVector,
                   
                       uprOffsetCtrl  = self.uprOffsetCtrl.nodeName,
                       uprBlendNode   = self.uprBlend.nodeName,
                       uprSubAimGroup = self.extend['uprSubAimGroup'],
                       midOffsetCtrl  = self.midOffsetCtrl.nodeName,
                       rigLayer       = self.rigLayer)
                       
        # create spline
        # create mid spline
        createTwistCurve(baseName  = self.baseName,
                         tag       = 'mid',
                         startNode = self.midBlend.nodeName,
                         endNode   = self.endBlend.nodeName,
                         aimVector = self.aimVector,
                     
                         startCtrl = self.midOffsetCtrl.nodeName,
                         midCtrl   = self.midEndOffsetCtrl.nodeName,
                         endCtrl   = self.endOffsetCtrl.nodeName,
                         rigLayer  = self.rigLayer)
                         
        # create upr spline
        createTwistCurve(baseName  = self.baseName,
                         tag       = 'upr',
                         startNode = self.uprBlend.nodeName,
                         endNode   = self.midBlend.nodeName,
                         aimVector = self.aimVector,
                     
                         startCtrl = self.uprOffsetCtrl.nodeName,
                         midCtrl   = self.uprMidOffsetCtrl.nodeName,
                         endCtrl   = self.midOffsetCtrl.nodeName,
                         rigLayer  = self.rigLayer)
                         
        # create twist ctrls
        self.createTwistCtrls()

        # to meta
        newExtend = []
        newExtend.extend([node for node in self.extend.values()])
        newExtend.extend([node for node in pinNodes1.values()])
        newExtend.extend([node for node in pinNodes2.values()])
        newExtend.extend([node for node in bldNodes1.values()])
        newExtend.extend([node for node in bldNodes2.values()])
        
        newExtend.extend([node for node in uprRootAimNodes.values()])
        newExtend.extend([node for node in uprBaseAimNodes.values()])
        newExtend.extend([node for node in midRootAimNodes.values()])
        newExtend.extend([node for node in midBaseAimNodes.values()])
        self.rigLayer.addExtraNodesToMeta(newExtend)
        
        
    def createTwistCtrls(self):
        uprTwistControlsList = []
        lwrTwistControlsList = []
        for joint in self.deformLayer.listJointNodes():
            jointTag = joint.jointTag
            if 'Twist' not in jointTag:
                continue
            # 0 create twist ctrl
            twistControl = nodes.ControlNode.create(self.baseName, jointTag, 'TWIST', 0.6, 
                                                    axis='y', spaceGroup=True, rigLayer=self.rigLayer)
            twistControl.rotateOrderBy(joint)
            #cmds.matchTransform(twistControl.topParent, joint.nodeName, pos=True, rot=True, scale=False)
            # 1 set matrix
            extraNodes = jointBinding.bindJointByMatrix(self.baseName, 
                                                        joint.jointTag, 
                                                        twistControl.nodeName, 
                                                        joint.nodeName,
                                                        sourceParent=True)
            joint.addExtraNodestoMeta(extraNodes)
            # to map
            if 'upr' in jointTag:
                uprTwistControlsList.append(twistControl)
            else:
                lwrTwistControlsList.append(twistControl)
        
        # 2 SET PARENT
        cmds.parent([u.topParent for u in uprTwistControlsList], self.uprBlend.nodeName)
        cmds.parent([l.topParent for l in lwrTwistControlsList], self.midBlend.nodeName)
        
        # reset psr
        nodeUtils.resetPSR([c.topParent for c in uprTwistControlsList])
        nodeUtils.resetPSR([c.topParent for c in lwrTwistControlsList])
        
        # 3 pin curve
        # upr
        self.pinCurve(self.baseName, 'upr', self.aimVector, self.upVector, 
                      self.rigLayer.taggedNodeFromTag('uprBendyCurve'),
                      self.rigLayer.taggedNodeFromTag('uprUprTwistTarget'),
                      self.rigLayer.taggedNodeFromTag('uprLwrTwistTarget'),
                      self.uprBlend.nodeName,
                      uprTwistControlsList,
                      self.uprTwistWeight,
                      self.rigLayer)
        
        # mid
        self.pinCurve(self.baseName, 'mid', self.aimVector, self.upVector, 
                      self.rigLayer.taggedNodeFromTag('midBendyCurve'),
                      self.rigLayer.taggedNodeFromTag('midUprTwistTarget'),
                      self.rigLayer.taggedNodeFromTag('midLwrTwistTarget'),
                      self.midBlend.nodeName,
                      lwrTwistControlsList,
                      self.lwrTwistWeight,
                      self.rigLayer)
        
        # add vis attr
        
        
    
    @staticmethod    
    def pinCurve(
                 baseName:str,
                 tag:str,
                 
                 aimVector:list,
                 upVector:list,
                 
                 curveShape:str, 
                 uprTargetHrc:str, 
                 lwrTargetHrc:str,
                 parentNode:str,
                 
                 twistControls:'list[ControlNode]',
                 weights:list,
                 rigLayer:'RigLayer'
                 ):
        
        extendNodes = []
        
        for ctrl, weight in zip(twistControls, weights):
            extend = {}
            ctrlTag = ctrl.controlTag
            extend['pointOnCurveInfoNode'] = cmds.createNode('pointOnCurveInfo', name=f'{baseName}_{tag}_{ctrlTag}_curveInfo')
            cmds.setAttr(f"{extend['pointOnCurveInfoNode']}.turnOnPercentage", True)
            cmds.setAttr(f"{extend['pointOnCurveInfoNode']}.parameter", weight)
            cmds.connectAttr(f'{curveShape}.worldSpace[0]', f"{extend['pointOnCurveInfoNode']}.inputCurve")
            
            extend['targetVectorNode'] = cmds.createNode('plusMinusAverage', name=f'{baseName}_{tag}_{ctrlTag}_targetPoint')
            cmds.connectAttr(f"{extend['pointOnCurveInfoNode']}.tangent", f"{extend['targetVectorNode']}.input3D[0]")
            cmds.connectAttr(f"{extend['pointOnCurveInfoNode']}.position", f"{extend['targetVectorNode']}.input3D[1]")
            
            extend['pointMatrixNode'] = cmds.createNode('composeMatrix', name=f'{baseName}_{tag}_{ctrlTag}_pointMatrix')
            cmds.connectAttr(f"{extend['pointOnCurveInfoNode']}.position", f"{extend['pointMatrixNode']}.inputTranslate")
            
            extend['aimMatrixNode'] = cmds.createNode('aimMatrix', name=f'{baseName}_{tag}_{ctrlTag}_aimMatrix')
            cmds.connectAttr(f"{extend['pointMatrixNode']}.outputMatrix", f"{extend['aimMatrixNode']}.inputMatrix")
            cmds.connectAttr(f"{extend['targetVectorNode']}.output3D", f"{extend['aimMatrixNode']}.primaryTargetVector")
            
            cmds.setAttr(f"{extend['aimMatrixNode']}.primaryInputAxis", *aimVector)
            cmds.setAttr(f"{extend['aimMatrixNode']}.secondaryInputAxis", *upVector)
            cmds.setAttr(f"{extend['aimMatrixNode']}.secondaryTargetVector", *upVector)
            cmds.setAttr(f"{extend['aimMatrixNode']}.secondaryMode", 2)
            
            # create blendMatrix
            extend['blendMatrixNode'] = cmds.createNode('blendMatrix', name=f'{baseName}_{tag}_{ctrlTag}_blendRotateMatrix')
            cmds.connectAttr(f'{lwrTargetHrc}.worldMatrix[0]', f"{extend['blendMatrixNode']}.inputMatrix")
            cmds.connectAttr(f'{uprTargetHrc}.worldMatrix[0]', f"{extend['blendMatrixNode']}.target[0].targetMatrix")
            cmds.setAttr(f"{extend['blendMatrixNode']}.envelope", weight)
            cmds.connectAttr(f"{extend['blendMatrixNode']}.outputMatrix", f"{extend['aimMatrixNode']}.secondaryTargetMatrix")
            
            extend['offsetMatrixNode'] = cmds.createNode('multMatrix', name=f'{baseName}_{tag}_{ctrlTag}_aimOffsetMatrix')
            cmds.connectAttr(f"{extend['aimMatrixNode']}.outputMatrix", f"{extend['offsetMatrixNode']}.matrixIn[0]")
            cmds.connectAttr(f'{parentNode}.worldInverseMatrix[0]', f"{extend['offsetMatrixNode']}.matrixIn[1]")
            
            extend['noScaleMatrix'] = cmds.createNode('pickMatrix', name=f'{baseName}_{tag}_{ctrlTag}_noScaleMatrix')
            cmds.setAttr(f"{extend['noScaleMatrix']}.useScale", False)
            cmds.connectAttr(f"{extend['offsetMatrixNode']}.matrixSum", f"{extend['noScaleMatrix']}.inputMatrix")
            
            cmds.connectAttr(f"{extend['noScaleMatrix']}.outputMatrix", f'{ctrl.topParent}.offsetParentMatrix')
            
            extendNodes.extend([node for node in extend.values()])
            
        if rigLayer:
            rigLayer.addExtraNodesToMeta(extendNodes)
            

        
    def nodesToMeta(self):
        pass
            
     
    def create(self):
        self.createBendyControls()
        self.createRigGroups()
        self.createBendyNetwork()
        self.nodesToMeta()
        LinearScaleJoint(self.arm).create()
        
        
        
        
        
        
        
        
        
        
        
        
        
class LinearScaleJoint(object):
    
    def __init__(self, arm:'Arm'=None):
        self.arm = arm
        
        self.baseName    = arm.baseName
        self.rigLayer    = arm.rigLayer
        self.deformLayer = arm.deformLayer
        self.aimVector   = arm.aimVector
        self.getControls()
    
  
    def getControls(self):
        '''
        Get the twist controls of upr and lwr
        '''
        self.uprTwistControlsList = []
        self.lwrTwistControlsList = []

        for control in self.rigLayer.listControlNodes():
            controlTag = control.controlTag
            if 'Twist' not in controlTag:
                continue
            if 'upr' in controlTag:
                self.uprTwistControlsList.append(control)
            else:
                self.lwrTwistControlsList.append(control)
    
    @staticmethod
    def splitCtrlsByProximity(startNode:str,
                              midNode:str, 
                              endNode:str, 
                              controlsList:list) -> tuple:
        '''
        Split the control into upper and lower parts
        '''              
        startToMidDistance = mathUtils.distance(startNode, midNode)
        endToMidDistance   = mathUtils.distance(endNode, midNode)
        
        startScaleControls = []
        endScaleControls   = []
        
        for control in controlsList:
            distance1 = mathUtils.distance(control.nodeName, startNode)
            distance2 = mathUtils.distance(control.nodeName, endNode)
            if distance1 < startToMidDistance:
                startScaleControls.append(control)
            if distance2 < endToMidDistance:
                endScaleControls.append(control)
        '''
        Ensure that there are no identical controllers in the two lists, 
        as distance errors may cause the middle controller to belong to either the upper or lower part. 
        Therefore, we need to perform a check
        '''        
        return LinearScaleJoint.removeCommonElements(startScaleControls, endScaleControls)
    
    
    @staticmethod
    def removeCommonElements(listA, listB) -> list:
        '''
        Make sure the two lists have no elements in common
        '''
        setA = set(listA)
        setB = set(listB)
        common = setA & setB
        return list(setA - common), list(setB - common)   
        
        
    @staticmethod
    def computeLinearWeights(controlNodes:list, start:str, end:str, curve:float=0.5) -> dict:
        '''
        Get the linear weight values of the twist control influenced by the two bend controls
        '''
        weightDict = {}
        for control in controlNodes:
            distToS = mathUtils.distance(start, control.nodeName)
            distToE = mathUtils.distance(control.nodeName, end)

            t = distToE / (distToE + distToS) if (distToE + distToS) > 0 else 0.5
            t = max(0.0, min(1.0, t))
            
            # add bezier 
            #weight = (1-t)**2 * 0 + 2*(1-t)*t * curve + t**2 * 1
            # Compute weights using Hermite/Smoothstep interpolation (smooth easing at ends)
            weight = t * t * (3.0 - 2.0 * t)
            
            weightDict[control] = round(weight, 3)

        return weightDict
        
        
    @staticmethod
    def getScaleXYZ(aimVector:list) -> list:
        '''
        Use the aimVector to determine the correct scaling axis
        '''
        axiss = []
        for num, axis in zip(aimVector, ['x', 'y', 'z']):
            if num == 0:
                axiss.append(axis)
        return axiss
    
    

    def connectScale(self, nodeA:str, nodeB:'ControlNode', axiss:list):
        scaleMatrixNode = cmds.createNode('composeMatrix', name=f'{self.baseName}_{nodeB.controlTag}_scaleMatrix')   
        cmds.connectAttr(f'{nodeA}.scale{axiss[0].upper()}', f'{scaleMatrixNode}.inputScale{axiss[0].upper()}')
        cmds.connectAttr(f'{nodeA}.scale{axiss[1].upper()}', f'{scaleMatrixNode}.inputScale{axiss[1].upper()}')
        cmds.connectAttr(f'{scaleMatrixNode}.outputMatrix', f'{nodeB.nodeName}.offsetParentMatrix')
        self.rigLayer.addExtraNodesToMeta([scaleMatrixNode])
            
    def connectBlendColors(self,
                           nodeA:str,
                           nodeB:str,
                           controlNode:'ControlNode',
                           axiss:list,
                           weight:float):
                            
        blendNode       = cmds.createNode('blendColors', name=f'{self.baseName}_{controlNode.controlTag}_scaleBlend')
        scaleMatrixNode = cmds.createNode('composeMatrix', name=f'{self.baseName}_{controlNode.controlTag}_scaleMatrix')
        # update base attr
        cmds.setAttr(f'{blendNode}.color1', 1, 1, 1)
        cmds.setAttr(f'{blendNode}.color2', 1, 1, 1)
        
        rgbMap = {'x':'R', 'y':'G', 'z':'B'}

        cmds.connectAttr(f'{nodeA}.scale{axiss[0].upper()}', f'{blendNode}.color1{rgbMap[axiss[0]]}')
        cmds.connectAttr(f'{nodeA}.scale{axiss[1].upper()}', f'{blendNode}.color1{rgbMap[axiss[1]]}')
        
        cmds.connectAttr(f'{nodeB}.scale{axiss[0].upper()}', f'{blendNode}.color2{rgbMap[axiss[0]]}')
        cmds.connectAttr(f'{nodeB}.scale{axiss[1].upper()}', f'{blendNode}.color2{rgbMap[axiss[1]]}')
        
        cmds.setAttr(f'{blendNode}.blender', weight)
        cmds.connectAttr(f'{blendNode}.output', f'{scaleMatrixNode}.inputScale')
        cmds.connectAttr(f'{scaleMatrixNode}.outputMatrix', f'{controlNode.nodeName}.offsetParentMatrix')
        self.rigLayer.addExtraNodesToMeta([blendNode, scaleMatrixNode])
        
        
            
    def addControlsScale(self, uprTag, midTag, endTag, controlList, curve:float=0.5):
        
        # 0 get start - mid - end  bendyControl
        uprOffsetCtrl    = self.rigLayer.controlNodeFromTag(uprTag).nodeName
        uprMidOffsetCtrl = self.rigLayer.controlNodeFromTag(midTag).nodeName
        midOffsetCtrl    = self.rigLayer.controlNodeFromTag(endTag).nodeName
        
        # 1 decompose upr and lwr controls
        startScaleControls, endScaleControls = self.splitCtrlsByProximity(uprOffsetCtrl,
                                                                          uprMidOffsetCtrl,
                                                                          midOffsetCtrl,
                                                                          controlList)
        # 2 get mid controls if there is :)
        midScaleControls = [jnt for jnt in controlList 
                          if jnt not in set(startScaleControls + endScaleControls)]
        
        # 3 get weights
        startScaleControlWeights = self.computeLinearWeights(startScaleControls, uprOffsetCtrl, uprMidOffsetCtrl, curve)
        endScaleControlWeights   = self.computeLinearWeights(endScaleControls,   midOffsetCtrl, uprMidOffsetCtrl, curve)
        
        # 4 get axis
        axiss = self.getScaleXYZ(self.aimVector)
        
        # 5 set mid scale
        for ctrl in midScaleControls:
            self.connectScale(uprMidOffsetCtrl, ctrl, axiss)

        # 6 set upr scale
        for ctrl in startScaleControls:
            weight = startScaleControlWeights[ctrl]
            if weight == 1:
                self.connectScale(uprOffsetCtrl, ctrl, axiss)
                continue
            elif weight == 0:
                self.connectScale(uprMidOffsetCtrl, ctrl, axiss)
                continue
            self.connectBlendColors(uprOffsetCtrl, uprMidOffsetCtrl, ctrl, axiss, weight)
        
        # 7 set lwr scale
        for ctrl in endScaleControls:
            weight = endScaleControlWeights[ctrl]
            if weight == 1:
                self.connectScale(midOffsetCtrl, ctrl, axiss)
                continue
            elif weight == 0:
                self.connectScale(uprMidOffsetCtrl, ctrl, axiss)
                continue
            self.connectBlendColors(midOffsetCtrl, uprMidOffsetCtrl, ctrl, axiss, weight)
            
        
    def create(self):
        self.addControlsScale('uprOffset', 'uprMidOffset', 'midOffset', self.uprTwistControlsList, 0.15)
        self.addControlsScale('midOffset', 'midEndOffset', 'endOffset', self.lwrTwistControlsList, 0.15)
        
        


        
        
    